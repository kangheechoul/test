<?php
    class BlogModel extends gf{
        private $param;
        private $dir;
        private $conn;
        function __construct($array){
            $this->param = $array["json"];
            $this->dir = $array["dir"];
            $this->conn = $array["db"];
            $this->project_name = $array["project_name"];
            $this->file_manager = $array["file_manager"];
            $this->result = array(
                "result" => null,
                "error_code" => null,
                "message" => null,
                "value" => null,
            );
            $this->session = $array["session"];
        }
        /********************************************************************* 
        // 함 수 : empty 체크
        // 설 명 : array("id","pw")
        // 만든이: 안정환
        *********************************************************************/
        function value_check($check_value_array){
            $object = array(
                "param"=>$this->param,
                "array"=>$check_value_array
            );
            $check_result = $this->empty_check($object);
            if($check_result["result"]){//param 값 체크 비어있으면 실행 안함
                if($check_result["value_empty"]){//필수 값이 비었을 경우
                    $this->result["result"]="0";
                    $this->result["error_code"]="101";
                    $this->result["message"]=$check_result["value_key"]."가 비어있습니다.";
                    return false;
                }else{
                    return true;
                }
            }else{
                $this->result["result"]="0";
                $this->result["error_code"]="100";
                $this->result["message"]=$check_result["value"]." 가 없습니다.";
                return false;
            }
        }

        function request_blog_menu6_list(){ //블로그 menu6 리스트
            $param = $this->param;
            $move_list = json_decode($param["move_list"], true);

            if($this->value_check(array("page_size", "move_page"))){ //필수값 체크
                
                $sql_where = "";
                if(isset($move_list["search_text"])) {
                    $sql_where = " and (title LIKE '%".$move_list["search_text"]."%' or sub_title LIKE '%".$move_list["search_text"]."%' or content LIKE '%".$move_list["search_text"]."%') ";
                }
                
                $page_size = (int)$param["page_size"];
                $page = (int)$param["move_page"];
                $sql = "select * from blog";
                $sql .= " where state != 0";
                $sql .= $sql_where;
                $sql .= " order by regdate desc";
                $sql .= " limit ".$page_size*($page-1).",".$page_size;
                $this->result = $this->conn->db_select($sql);
                
                $sql = "select count(*) total_count from blog where state != 0 ";
                $sql .= $sql_where;
                $total_result = $this->conn->db_select($sql);
                
                $this->result["total_count"] = $total_result["value"][0]["total_count"];
            }

            echo $this->jsonEncode($this->result, JSON_UNESCAPED_UNICODE);
        }
        
        function request_blog_view() {
            $param = $this->param;

            $idx = $param["idx"];

            // 조회수
            $sql = "update blog set 
                        view_count = view_count + 1 
                    where idx = $idx";
            $this->conn->db_update($sql);

            //현재
            $sql = "select * from blog where idx = $idx";
            $this->result = $this->conn->db_select($sql);

            //다음
            $sql = "select idx, title from blog where idx > $idx and state != 0 order by idx asc limit 1";
            $next = $this->conn->db_select($sql);
            if($next["value"]) {    
                $this->result["next"] = $next["value"][0]["idx"];
                $this->result["next_title"] = $next["value"][0]["title"];
            }
            
            //이전
            $sql = "select idx, title from blog where idx < $idx and state != 0 order by idx desc limit 1";
            $prev = $this->conn->db_select($sql);
            if($prev["value"]) {
                $this->result["prev"] = $prev["value"][0]["idx"];
                $this->result["prev_title"] = $prev["value"][0]["title"];
            }

            echo $this->jsonEncode($this->result, JSON_UNESCAPED_UNICODE);
        }

        function request_blog_state_modify() {
            $param = $this->param;

            $state = $this->null_check($param["state"]);
            $idx = $this->null_check($param["idx"]);

            $sql = "update blog set state = $state where idx = $idx";
            $result = $this->conn->db_update($sql);

            if($result) {
                $this->result["result"] = 1;
            }else{
                $this->result["result"] = 0;
                $this->result["message"] = "오류가 발생했습니다.";
            }

            echo $this->jsonEncode($this->result, JSON_UNESCAPED_UNICODE);
        }
    }
?>