<?php 
    class MemberModel extends gf{
        private $param;
        private $dir;
        private $conn;
        function __construct($array){
            $this->param = $array["json"];
            $this->dir = $array["dir"];
            $this->conn = $array["db"];
            $this->project_name = $array["project_name"];
            $this->file_manager = $array["file_manager"];
            $this->result = array(
                "result" => null,
                "error_code" => null,
                "message" => null,
                "value" => null,
            );
            $this->session = $array["session"];
        }
        /********************************************************************* 
        // 함 수 : empty 체크
        // 설 명 : array("id","pw")
        // 만든이: 안정환
        *********************************************************************/
        function value_check($check_value_array){
            $object = array(
                "param"=>$this->param,
                "array"=>$check_value_array
            );
            $check_result = $this->empty_check($object);
            if($check_result["result"]){//param 값 체크 비어있으면 실행 안함
                if($check_result["value_empty"]){//필수 값이 비었을 경우
                    $this->result["result"]="0";
                    $this->result["error_code"]="101";
                    $this->result["message"]=$check_result["value_key"]."가 비어있습니다.";
                    return false;
                }else{
                    return true;
                }
            }else{
                $this->result["result"]="0";
                $this->result["error_code"]="100";
                $this->result["message"]=$check_result["value"]." 가 없습니다.";
                return false;
            }
        }

        //회원 start
        function request_id_check() { //아이디체크
            $param = $this->param;
            $mb_id = $this->null_check($param["mb_id"]);

            $sql = "select mb_id from member where mb_id = $mb_id";
            $this->result = $this->conn->db_select($sql);

            echo $this->jsonEncode($this->result, JSON_UNESCAPED_UNICODE);
        }
        
        function request_user_reg() { //회원등록
            $param = $this->param;
            if($this->value_check(array("mb_id", "mb_company", "mb_name", "mb_hp", "mb_type"))){//value check
                // $param = $this->null_check_v3($param,array("mb_company","mb_name","mb_hp","mb_id","mb_type","mb_domain"));
                $mb_company = $this->null_check($param["mb_company"]);
                $mb_name = $this->null_check($param["mb_name"]);
                $mb_hp = $this->null_check($param["mb_hp"]);
                $mb_id = $this->null_check($param["mb_id"]);
                $mb_type = $this->null_check($param["mb_type"]);
                $mb_domain = $this->null_check($param["mb_domain"]);

                $sql = "insert into member (mb_id, mb_name, mb_hp, mb_company, mb_type, mb_domain, mb_join_date)
                        select $mb_id, $mb_name, $mb_hp, $mb_company, $mb_type, $mb_domain, now()
                        from dual
                        where not exists
                        (select mb_id from member where mb_id = $mb_id)";
                
                $this->result = $this->conn->db_insert($sql);
            }
            

            echo $this->jsonEncode($this->result, JSON_UNESCAPED_UNICODE);
        }

        function request_user_modify(){ //회원 수정
            $param = $this->param;
             
            if($this->value_check(array("mb_id", "mb_company", "mb_name", "mb_hp", "mb_type", "member_idx"))){//value check
                $sql = "select * from member where idx=".$param["member_idx"];
                $result = $this->conn->db_select($sql);
                $original_member = $result["value"][0];

                $mb_id = $this->null_check($param["mb_id"]);
                $mb_name = $this->null_check($param["mb_name"]);
                $mb_company = $this->null_check($param["mb_company"]);
                $mb_hp = $this->null_check($param["mb_hp"]);
                $mb_type = $this->null_check($param["mb_type"]);
                $mb_domain = $this->null_check($param["mb_domain"]);

                if($original_member["mb_id"]) {
                    $update_sql = "update member set mb_name = $mb_name, mb_company = $mb_company, mb_hp = $mb_hp, mb_domain = $mb_domain, mb_type = $mb_type where mb_id = $mb_id";
                    $this->result = $this->conn->db_update($update_sql);
                }else{
                    $this->result["result"]="0";
                    $this->result["error_code"]="101";
                    $this->result["message"]="삭제되었거나 존재하지 않는 회원입니다.";
                }
            }
            
            echo json_encode($this->result, JSON_UNESCAPED_UNICODE);
        }

        function request_user_list() { //회원목록
            $param = $this->param;

            if($this->value_check(array("page_size", "move_page"))){ //필수값 체크
                $page_size = (int)$param["page_size"];
                $page = (int)$param["move_page"];
                $sql = "select * from member";
                $sql .= " order by mb_join_date desc";
                $sql .= " limit ".$page_size*($page-1).",".$page_size;
                $this->result = $this->conn->db_select($sql);

                $sql = "select count(*) total_count from member";
                $total_result = $this->conn->db_select($sql);

                $this->result["total_count"] = $total_result["value"][0]["total_count"];

            }

            echo $this->jsonEncode($this->result, JSON_UNESCAPED_UNICODE);
        }

        function request_user_edit_view() { // 회원수정 정보
            $param = $this->param;
            $sql = "select * from member where idx = ".$param["idx"];

            $this->result = $this->conn->db_select($sql);
            echo $this->jsonEncode($this->result, JSON_UNESCAPED_UNICODE);
        }

        function request_admin_login() {
            $param = $this->param;
            
            $mb_id = $this->null_check($param["mb_id"]);

            if($this->value_check(array("mb_id", "mb_password"))){ //필수값 체크
                $sql = "select * from member where mb_id = $mb_id ";//아이디와 비밀번호를 함께 체크하지 않음
                $mb = $this->conn->db_select($sql);
                
                if(count($mb["value"]) == 0 || $mb["value"][0]["mb_id"] != $param["mb_id"]) {
                    $this->result["result"]="0";
                    $this->result["error_code"]="100";
                    $this->result["message"]="아이디 혹은 비밀번호가 틀렸습니다.";
                }else{
                    $keypw = new MyEncryption();
                    $param["mb_password"] = $keypw->pw_encrypt($param["mb_password"]);
                    $mb_password = $this->null_check($param["mb_password"]);
                    $sql = "select md5($mb_password) as mb_pass";
                    $md5 = $this->conn->db_select($sql);
                    // 비밀번호를 따로 확인해야 sql injection에서 비교적 자유로움
                    if($mb["value"][0]["mb_password"] == $md5["value"][0]["mb_pass"]) {
                        $this->session->success_admin_login($mb["value"][0]["idx"]);
                        
                        $this->result["result"]="1";
                        $this->result["message"]="로그인성공";
                    }else{
                        $this->result["result"]="0";
                        $this->result["error_code"]="100";
                        $this->result["message"]="아이디 혹은 비밀번호가 틀렸습니다.";
                    }
                }
            }

            echo $this->jsonEncode($this->result, JSON_UNESCAPED_UNICODE);
        }

        function request_login() {
            $param = $this->param;
            
            $mb_id = $this->null_check($param["mb_id"]);

            if($this->value_check(array("mb_id", "mb_password"))){ //필수값 체크
                $sql = "select * from member where mb_id = $mb_id ";//아이디와 비밀번호를 함께 체크하지 않음
                $mb = $this->conn->db_select($sql);
                
                if(count($mb["value"]) == 0 || $mb["value"][0]["mb_id"] != $param["mb_id"]) {
                    $this->result["result"]="0";
                    $this->result["error_code"]="100";
                    $this->result["message"]="아이디 혹은 비밀번호가 틀렸습니다.";
                }else{
                    $keypw = new MyEncryption();
                    $param["mb_password"] = $keypw->pw_encrypt($param["mb_password"]);
                    $mb_password = $this->null_check($param["mb_password"]);
                    $sql = "select md5($mb_password) as mb_pass";
                    $md5 = $this->conn->db_select($sql);
                    // 비밀번호를 따로 확인해야 sql injection에서 비교적 자유로움
                    if($mb["value"][0]["mb_password"] == $md5["value"][0]["mb_pass"]) {
                        $this->session->success_user_login($mb["value"][0]["idx"]);
                        
                        $this->result["result"]="1";
                        $this->result["message"]="로그인성공";
                    }else{
                        $this->result["result"]="0";
                        $this->result["error_code"]="100";
                        $this->result["message"]="아이디 혹은 비밀번호가 틀렸습니다.";
                    }
                }
            }

            echo $this->jsonEncode($this->result, JSON_UNESCAPED_UNICODE);
        }

        function request_signout(){ // 로그아웃

            $this->session->user_logout();

        }

        function request_signup(){//회원가입
            $param = $this->param;

            $mb_id = $this->null_check($param["mb_id"]);

            if($this->value_check(array("mb_id", "mb_password", "mb_password_re"))){ //필수값 체크
                $email_check = preg_match("/^[_\.0-9a-zA-Z-]+@([0-9a-zA-Z][0-9a-zA-Z-]+\.)+[a-zA-Z]{2,6}$/i", $param["mb_id"]);
                if(!$email_check) { //이메일 형식 체크
                    $this->result["result"]="0";
                    $this->result["error_code"]="100";
                    $this->result["message"]="이메일 형식이 맞지않습니다.";
                }else{
                    $sql = "select mb_id from member where mb_id = $mb_id";
                    $mb = $this->conn->db_select($sql);
                    if(count($mb["value"]) != 0) {//아이디 중복체크
                        $this->result["result"]="0";
                        $this->result["error_code"]="100";
                        $this->result["message"]="이미 사용중인 아이디입니다.";
                    }else{
                        if($param["mb_password"] != $param["mb_password_re"]){//비밀번호 비밀번호확인 체크
                            $this->result["result"]="0";
                            $this->result["error_code"]="100";
                            $this->result["message"]="비밀번호가 다릅니다.";
                        }else{
                            if(strlen($param["mb_password"]) < 6) {//비밀번호 6자 이상
                                $this->result["result"]="0";
                                $this->result["error_code"]="100";
                                $this->result["message"]="비밀번호는 6자 이상입니다.";
                            }else{
                                $keypw = new MyEncryption();
                                $param["mb_password"] = $keypw->pw_encrypt($param["mb_password"]);
                                $mb_password = $this->null_check($param["mb_password"]);

                                $sql = "insert into member (mb_id, mb_password, mb_join_date)
                                        values ($mb_id, md5($mb_password), now())";
                                $this->result = $this->conn->db_insert($sql);
                            }
                        }
                    }
                }
            }

            echo $this->jsonEncode($this->result, JSON_UNESCAPED_UNICODE);
        }
    }
?>