<?php
	class MailForm extends gf{
		private $param;
        private $dir;
        private $conn;
        function __construct($array){
            $this->param = $array["json"];
            $this->dir = $array["dir"];
            $this->conn = $array["db"];
            $this->project_name = $array["project_name"];
            $this->result = array(
                "result" => null,
                "error_code" => null,
                "message" => null,
                "value" => null,
            );
            $this->session = $array["session"];

            $this->mail_model = new MailModel();
            
           
        }

        function send_email($param){

            $param["set_from"] = "ogla@naver.com";
            $param["project"] = "test";
            $param["from_name"] = "fkdlzmeltm";
            

            $param["title"] = "메일테스트제목";
            $param["body"] = "메일테스트";

            // 메일발송
            $result = $this->mail_model->send_mail($param);
            print_r($result);
        }

        
	}
?>
