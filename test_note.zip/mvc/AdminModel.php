<?php
    class AdminModel extends gf{
        private $param;
        private $dir;
        private $conn;
        function __construct($array){
            $this->param = $array["json"];
            $this->dir = $array["dir"];
            $this->conn = $array["db"];
            $this->project_name = $array["project_name"];
            $this->file_manager = $array["file_manager"];
            $this->result = array(
                "result" => null,
                "error_code" => null,
                "message" => null,
                "value" => null,
            );
            $this->session = $array["session"];
        }
        /********************************************************************* 
        // 함 수 : empty 체크
        // 설 명 : array("id","pw")
        // 만든이: 안정환
        *********************************************************************/
        function value_check($check_value_array){
            $object = array(
                "param"=>$this->param,
                "array"=>$check_value_array
            );
            $check_result = $this->empty_check($object);
            if($check_result["result"]){//param 값 체크 비어있으면 실행 안함
                if($check_result["value_empty"]){//필수 값이 비었을 경우
                    $this->result["result"]="0";
                    $this->result["error_code"]="101";
                    $this->result["message"]=$check_result["value_key"]."가 비어있습니다.";
                    return false;
                }else{
                    return true;
                }
            }else{
                $this->result["result"]="0";
                $this->result["error_code"]="100";
                $this->result["message"]=$check_result["value"]." 가 없습니다.";
                return false;
            }
        }
        /********************************************************************* 
        // 함수 설명 : 블로그 게시글 등록
        //            
        // 만든이: 안정환
        *********************************************************************/
        function request_blog_reg(){
            $param = $this->param;

            $save_files = array();

            $file_name = null;
            
            if($this->value_check(array("title", "subtitle", "content","state"))){//value check

                if($_FILES["thumnail_files"]["type"][0] == ""){ //thumbnail check
                    $this->value_check(array("thumnail_files"));
                }else{
                    $result = $this->file_manager->upload_file($_FILES["thumnail_files"], "_uploads/blog_thumnail_img/", "_uploads/blog_origin_thumnail_img/");
                    $save_files = array_merge($save_files,$result["error_file_array"]); //에러났을경우를 대비하여 저장된 파일 목록을 save_files에 merge 
                    $file_name = $result['file_name'][0];
                    
                    $description = $param["content"];

                    $convert_description = $this->file_manager->convert_description("_uploads/blog_description_img/","https://elasticbeanstalk-ap-northeast-2-038372400108.s3.ap-northeast-2.amazonaws.com/files/bada_soft/_uploads/blog_description_img/", $description); //이미지 저장 및 변환                
                    $new_file_array = $this->file_manager->get_s3_image_array($convert_description["description"], "https://elasticbeanstalk-ap-northeast-2-038372400108.s3.ap-northeast-2.amazonaws.com/files/bada_soft/_uploads/blog_description_img/");
                    $save_files = array_merge($save_files,$new_file_array); //에러났을경우를 대비하여 저장된 파일 목록을 save_files에 merge
                    $this->conn->set_file_list($save_files); //db오류 생겻을경우 롤백으로 인한 저장된 파일 삭제
                    
                    $mb_idx = $this->session->get_admin_info();
                    $sql = "select * from member where idx = $mb_idx";
                    $mb = $this->conn->db_select($sql);
                    $mb_id = $this->null_check($mb["value"][0]["mb_id"]);
                    $mb_name = $this->null_check($mb["value"][0]["mb_name"]);

                    $sql = "insert into blog(state,title,sub_title,thumnail_file_name,content,regdate,mb_id,mb_name) values(".$this->null_check($param["state"]).",".$this->null_check($param["title"]).",".$this->null_check($param["subtitle"]).",".$this->null_check($file_name).",".$this->null_check($convert_description["description"]).", now(), $mb_id, $mb_name)";
                    $this->result = $this->conn->db_insert($sql);
                }
            }

            echo json_encode($this->result, JSON_UNESCAPED_UNICODE);
        }

        function request_blog_edit_modify(){ //블로그 게시글 수정
            $param = $this->param;
             
            $save_files = array(); //저장된 이미지 파일 풀경로를 담는 배열(중간에 에러가 발생하였을경우 전부 삭제해야함)
            $delete_description_files = []; //삭제해야할 description 파일 이름
            $merge_file_name = []; //경로저장한 파일 리스트
            $file_name = "";

            
            $file_name = null; //썸네일 있는지 확인

            if($this->value_check(array("title", "subtitle", "content","state","blog_idx"))){
                $sql = "select * from blog where idx=".$param["blog_idx"];
                $result = $this->conn->db_select($sql);
                $original_blog = $result["value"][0];

                if($_FILES["thumnail_files"]["type"][0] == "" && $original_blog["thumnail_file_name"] == "") { //썸네일 이미지 있는지 확인
                    $this->value_check(array("thumnail_files"));
                } else {
                    if($_FILES["thumnail_files"]["type"][0] == ""){ //새로 등록한 썸네일이 없을때
                        $file_name = $original_blog["thumnail_file_name"];
                    }else{
                        $result = $this->file_manager->upload_file($_FILES["thumnail_files"], "_uploads/blog_thumnail_img/", "_uploads/blog_origin_thumnail_img/");
                        $save_files = array_merge($save_files,$result["error_file_array"]); //에러났을경우를 대비하여 저장된 파일 목록을 save_files에 merge 
                        $file_name = $result['file_name'][0]; //썸네일 파일 추출
                    }
                
                    $description = $param["content"];
                    $convert_description = $this->file_manager->convert_description("_uploads/blog_description_img/","https://elasticbeanstalk-ap-northeast-2-038372400108.s3.ap-northeast-2.amazonaws.com/files/bada_soft/_uploads/blog_description_img/", $description); //이미지 저장 및 변환
                    
                    $origin_file_array = $this->file_manager->get_s3_image_array($original_blog["content"], "https://elasticbeanstalk-ap-northeast-2-038372400108.s3.ap-northeast-2.amazonaws.com/files/bada_soft/_uploads/blog_description_img/");
                    $new_file_array = $this->file_manager->get_s3_image_array($convert_description["description"], "https://elasticbeanstalk-ap-northeast-2-038372400108.s3.ap-northeast-2.amazonaws.com/files/bada_soft/_uploads/blog_description_img/");
                    $delete_file = array_diff($origin_file_array, $new_file_array); //삭제해야할 이미지 파일가져옴(배열1 값중 배열2에 없는 값만 배열 형태로 반환.)
                    
                    for($i = 0; $i < count($delete_file); $i++) {
                        $merge_file_name[$i] = "_uploads/blog_description_img/".$delete_file[$i];
                    }
                    
                    if($file_name != null)
                        $update_sql_thumnail = ", thumnail_file_name = ".$this->null_check($file_name);

                    $save_files = array_merge($save_files,$merge_file_name); //에러났을경우를 대비하여 저장된 파일 목록을 save_files에 merge
                    $this->conn->set_file_list($save_files); //db오류 생겻을경우 롤백으로 인한 저장된 파일 삭제
                    $update_sql = "update blog set title = ".$this->null_check($param["title"]).", sub_title = ".$this->null_check($param["subtitle"]).", content = ".$this->null_check($convert_description["description"]).$update_sql_thumnail.", state = ".$this->null_check($param["state"])." where idx = ".$param["blog_idx"];
                    $this->result = $this->conn->db_update($update_sql);
                }
            }
            
            echo json_encode($this->result, JSON_UNESCAPED_UNICODE);
        }
        
        function request_blog_edit_delete(){ //블로그 게시글 삭제
            $param = $this->param;

            $sql = "select * from blog where idx = ".$this->null_check($param["blog_idx"]);
            $result = $this->conn->db_select($sql);
            $original_blog = $result["value"][0];
            
            if(count($original_blog) > 1) {

                $save_files = array(); //삭제할 파일 리스트
                $merge_file_name = []; // 디스크립션 파일 삭제 리스트

                if($original_blog["thumnail_file_name"]) {
                    $save_files = array_merge($save_files, ["_uploads/blog_origin_thumnail_img/".$original_blog["thumnail_file_name"], "_uploads/blog_thumnail_img/".$original_blog["thumnail_file_name"]]);
                }

                if($original_blog["content"]) {
                    $description = $original_blog["content"];
                    
                    $origin_file_array = $this->file_manager->get_s3_image_array($original_blog["content"], "https://elasticbeanstalk-ap-northeast-2-038372400108.s3.ap-northeast-2.amazonaws.com/files/bada_soft/_uploads/blog_description_img/");

                    for($i = 0; $i < count($origin_file_array); $i++) {
                        $merge_file_name[$i] = "_uploads/blog_description_img/".$origin_file_array[$i];
                    }

                    $save_files = array_merge($save_files, $merge_file_name);
                }

                $sql = "delete from blog where idx = ".$this->null_check($param["blog_idx"]);
                $this->result = $this->conn->db_delete($sql);

                if($this->result["result"] == "1") {
                    $this->file_manager->delete_file($save_files); //삭제요청
                }
            }

            echo json_encode($this->result, JSON_UNESCAPED_UNICODE);
        }

        function request_blog_list(){ //블로그 리스트
            $param = $this->param;
            $move_list = json_decode($param["move_list"], true);

            if($this->value_check(array("page_size", "move_page"))){ //필수값 체크
                
                $sql_where = "";
                if(isset($move_list["search_text"]) && isset($move_list["search_type"])) {
                    if($move_list["search_type"] == "1") {
                        $sql_where = " where title LIKE '%".$move_list["search_text"]."%' ";
                    }else if($move_list["search_type"] == "2") {
                        $sql_where = " where content LIKE '%".$move_list["search_text"]."%' ";
                    }
                }

                $page_size = (int)$param["page_size"];
                $page = (int)$param["move_page"];
                $sql = "select * from blog";
                $sql .= $sql_where;
                $sql .= " order by regdate desc";
                $sql .= " limit ".$page_size*($page-1).",".$page_size;
                $this->result = $this->conn->db_select($sql);
                
                $sql = "select count(*) total_count from blog";
                $sql .= $sql_where;
                $total_result = $this->conn->db_select($sql);
                
                $this->result["total_count"] = $total_result["value"][0]["total_count"];
            }

            echo $this->jsonEncode($this->result, JSON_UNESCAPED_UNICODE);
        }

        function request_blog_edit_view() { // 블로그 수정 정보
            $param = $this->param;
            $sql = "select * from blog where idx = ".$param["idx"];

            $this->result = $this->conn->db_select($sql);
            echo $this->jsonEncode($this->result, JSON_UNESCAPED_UNICODE);
        }

        function request_blog_index_list(){ //블로그 index page 리스트
            $param = $this->param;

            $sql = "select * from blog";
            $sql .= " where state = 1 ";
            $sql .= " limit 6";
            $this->result = $this->conn->db_select($sql);
            
            $sql = "select count(*) total_count from blog where state = 1 limit 6";
            $total_result = $this->conn->db_select($sql);

            $this->result["total_count"] = $total_result["value"][0]["total_count"];
            
            echo $this->jsonEncode($this->result, JSON_UNESCAPED_UNICODE);
        }

        
        // 추천홈페이지 start
        function request_recommend_reg() { //추천홈페이지 등록
            $param = $this->param;
            
            $save_files = array();

            $file_name = null;
            
            if($this->value_check(array("title", "sub_title", "content", "state", "url"))){//value check

                if($_FILES["thumnail_files"]["type"][0] == ""){ //thumbnail check
                    $this->value_check(array("thumnail_files"));
                }else{
                    $result = $this->file_manager->upload_file($_FILES["thumnail_files"], "_uploads/recommend_thumnail_img/", "_uploads/recommend_origin_thumnail_img/");
                    $save_files = array_merge($save_files,$result["error_file_array"]); //에러났을경우를 대비하여 저장된 파일 목록을 save_files에 merge 
                    $file_name = $result['file_name'][0];
                    
                    $description = $param["content"];

                    $convert_description = $this->file_manager->convert_description("_uploads/recommend_description_img/","https://elasticbeanstalk-ap-northeast-2-038372400108.s3.ap-northeast-2.amazonaws.com/files/bada_soft/_uploads/recommend_description_img/", $description); //이미지 저장 및 변환                
                    $new_file_array = $this->file_manager->get_s3_image_array($convert_description["description"], "https://elasticbeanstalk-ap-northeast-2-038372400108.s3.ap-northeast-2.amazonaws.com/files/bada_soft/_uploads/recommend_description_img/");
                    $save_files = array_merge($save_files,$new_file_array); //에러났을경우를 대비하여 저장된 파일 목록을 save_files에 merge
                    $this->conn->set_file_list($save_files); //db오류 생겻을경우 롤백으로 인한 저장된 파일 삭제

                    $sql = "insert into recommend(state,title,sub_title,url,thumnail_file_name,content,regdate) values(".$this->null_check($param["state"]).",".$this->null_check($param["title"]).",".$this->null_check($param["sub_title"]).",".$this->null_check($param["url"]).",".$this->null_check($file_name).",".$this->null_check($convert_description["description"]).", now())";
                    $this->result = $this->conn->db_insert($sql);
                }
            }

            echo $this->jsonEncode($this->result, JSON_UNESCAPED_UNICODE);
        }
        
        function request_recommend_edit_modify(){ //추천홈페이지 게시글 수정
            $param = $this->param;
             
            $save_files = array(); //저장된 이미지 파일 풀경로를 담는 배열(중간에 에러가 발생하였을경우 전부 삭제해야함)
            $delete_description_files = []; //삭제해야할 description 파일 이름
            $merge_file_name = []; //경로저장한 파일 리스트
            $file_name = "";

            
            $file_name = null; //썸네일 있는지 확인

            if($this->value_check(array("title", "sub_title", "content","state","recommend_idx","url"))){
                $sql = "select * from recommend where idx=".$param["recommend_idx"];
                $result = $this->conn->db_select($sql);
                $original_recommend = $result["value"][0];

                if($_FILES["thumnail_files"]["type"][0] == "" && $original_recommend["thumnail_file_name"] == "") { //썸네일 이미지 있는지 확인
                    $this->value_check(array("thumnail_files"));
                } else {
                    if($_FILES["thumnail_files"]["type"][0] == ""){ //새로 등록한 썸네일이 없을때
                        $file_name = $original_recommend["thumnail_file_name"];
                    }else{
                        $result = $this->file_manager->upload_file($_FILES["thumnail_files"], "_uploads/recommend_thumnail_img/", "_uploads/recommend_origin_thumnail_img/");
                        $save_files = array_merge($save_files,$result["error_file_array"]); //에러났을경우를 대비하여 저장된 파일 목록을 save_files에 merge 
                        $file_name = $result['file_name'][0]; //썸네일 파일 추출
                    }
                
                    $description = $param["content"];
                    $convert_description = $this->file_manager->convert_description("_uploads/recommend_description_img/","https://elasticbeanstalk-ap-northeast-2-038372400108.s3.ap-northeast-2.amazonaws.com/files/bada_soft/_uploads/recommend_description_img/", $description); //이미지 저장 및 변환
                    
                    $origin_file_array = $this->file_manager->get_s3_image_array($original_recommend["content"], "https://elasticbeanstalk-ap-northeast-2-038372400108.s3.ap-northeast-2.amazonaws.com/files/bada_soft/_uploads/recommend_description_img/");
                    $new_file_array = $this->file_manager->get_s3_image_array($convert_description["description"], "https://elasticbeanstalk-ap-northeast-2-038372400108.s3.ap-northeast-2.amazonaws.com/files/bada_soft/_uploads/recommend_description_img/");
                    $delete_file = array_diff($origin_file_array, $new_file_array); //삭제해야할 이미지 파일가져옴(배열1 값중 배열2에 없는 값만 배열 형태로 반환.)
                    
                    for($i = 0; $i < count($delete_file); $i++) {
                        $merge_file_name[$i] = "_uploads/recommend_description_img/".$delete_file[$i];
                    }
                    
                    if($file_name != null)
                        $update_sql_thumnail = ", thumnail_file_name = ".$this->null_check($file_name);

                    $save_files = array_merge($save_files,$merge_file_name); //에러났을경우를 대비하여 저장된 파일 목록을 save_files에 merge
                    $this->conn->set_file_list($save_files); //db오류 생겻을경우 롤백으로 인한 저장된 파일 삭제
                    $update_sql = "update recommend set title = ".$this->null_check($param["title"]).", sub_title = ".$this->null_check($param["sub_title"]).", url = ".$this->null_check($param["url"]).", content = ".$this->null_check($convert_description["description"]).$update_sql_thumnail.", state = ".$this->null_check($param["state"])." where idx = ".$param["recommend_idx"];
                    $this->result = $this->conn->db_update($update_sql);
                }
            }
            
            echo json_encode($this->result, JSON_UNESCAPED_UNICODE);
        }

        function request_recommend_edit_delete(){ //추천홈페이지 게시글 삭제
            $param = $this->param;

            $sql = "select * from recommend where idx = ".$this->null_check($param["recommend_idx"]);
            $result = $this->conn->db_select($sql);
            $original_recommend = $result["value"][0];
            
            if(count($original_recommend) > 1) {

                $save_files = array(); //삭제할 파일 리스트
                $merge_file_name = []; // 디스크립션 파일 삭제 리스트

                if($original_recommend["thumnail_file_name"]) {
                    $save_files = array_merge($save_files, ["_uploads/recommend_origin_thumnail_img/".$original_recommend["thumnail_file_name"], "_uploads/recommend_thumnail_img/".$original_recommend["thumnail_file_name"]]);
                }

                if($original_recommend["content"]) {
                    $description = $original_recommend["content"];
                    
                    $origin_file_array = $this->file_manager->get_s3_image_array($original_recommend["content"], "https://elasticbeanstalk-ap-northeast-2-038372400108.s3.ap-northeast-2.amazonaws.com/files/bada_soft/_uploads/recommend_description_img/");

                    for($i = 0; $i < count($origin_file_array); $i++) {
                        $merge_file_name[$i] = "_uploads/recommend_description_img/".$origin_file_array[$i];
                    }

                    $save_files = array_merge($save_files, $merge_file_name);
                }

                $sql = "delete from recommend where idx = ".$this->null_check($param["recommend_idx"]);
                $this->result = $this->conn->db_delete($sql);

                if($this->result["result"] == "1") {
                    $this->file_manager->delete_file($save_files); //삭제요청
                }
            }

            echo json_encode($this->result, JSON_UNESCAPED_UNICODE);
        }

        function request_recommend_list() { //추천홈페이지 리스트
            $param = $this->param;
            $move_list = json_decode($param["move_list"], true);

            if($this->value_check(array("page_size", "move_page"))){ //필수값 체크
                
                $sql_where = "";
                if(isset($move_list["search_text"]) && isset($move_list["search_type"])) {
                    if($move_list["search_type"] == "1") {
                        $sql_where = " where title LIKE '%".$move_list["search_text"]."%' ";
                    }else if($move_list["search_type"] == "2") {
                        $sql_where = " where content LIKE '%".$move_list["search_text"]."%' ";
                    }
                }

                $page_size = (int)$param["page_size"];
                $page = (int)$param["move_page"];
                $sql = "select * from recommend";
                $sql .= $sql_where;
                $sql .= " order by regdate desc";
                $sql .= " limit ".$page_size*($page-1).",".$page_size;
                $this->result = $this->conn->db_select($sql);

                $sql = "select count(*) total_count from recommend";
                $sql .= $sql_where;
                $total_result = $this->conn->db_select($sql);

                $this->result["total_count"] = $total_result["value"][0]["total_count"];

            }

            echo $this->jsonEncode($this->result, JSON_UNESCAPED_UNICODE);
        }
        
        function request_recommend_edit_view() { // 추천홈페이지 수정 정보
            $param = $this->param;
            $sql = "select * from recommend where idx = ".$param["idx"];

            $this->result = $this->conn->db_select($sql);
            echo $this->jsonEncode($this->result, JSON_UNESCAPED_UNICODE);
        }
        // 추천홈페이지 end

        // 추천앱 start
        function request_recommend_app_reg() { //추천홈페이지 등록
            $param = $this->param;
            
            $save_files = array();

            $file_name = null;
            
            if($this->value_check(array("title", "sub_title", "content", "state", "url"))){//value check

                if($_FILES["thumnail_files"]["type"][0] == ""){ //thumbnail check
                    $this->value_check(array("thumnail_files"));
                }else{
                    $result = $this->file_manager->upload_file($_FILES["thumnail_files"], "_uploads/recommend_app_thumnail_img/", "_uploads/recommend_app_origin_thumnail_img/");
                    $save_files = array_merge($save_files,$result["error_file_array"]); //에러났을경우를 대비하여 저장된 파일 목록을 save_files에 merge 
                    $file_name = $result['file_name'][0];
                    
                    $description = $param["content"];

                    $convert_description = $this->file_manager->convert_description("_uploads/recommend_app_description_img/","https://elasticbeanstalk-ap-northeast-2-038372400108.s3.ap-northeast-2.amazonaws.com/files/bada_soft/_uploads/recommend_app_description_img/", $description); //이미지 저장 및 변환                
                    $new_file_array = $this->file_manager->get_s3_image_array($convert_description["description"], "https://elasticbeanstalk-ap-northeast-2-038372400108.s3.ap-northeast-2.amazonaws.com/files/bada_soft/_uploads/recommend_app_description_img/");
                    $save_files = array_merge($save_files,$new_file_array); //에러났을경우를 대비하여 저장된 파일 목록을 save_files에 merge
                    $this->conn->set_file_list($save_files); //db오류 생겻을경우 롤백으로 인한 저장된 파일 삭제

                    $sql = "insert into recommend_app(state,title,sub_title,url,thumnail_file_name,content,regdate) values(".$this->null_check($param["state"]).",".$this->null_check($param["title"]).",".$this->null_check($param["sub_title"]).",".$this->null_check($param["url"]).",".$this->null_check($file_name).",".$this->null_check($convert_description["description"]).", now())";
                    $this->result = $this->conn->db_insert($sql);
                }
            }

            echo $this->jsonEncode($this->result, JSON_UNESCAPED_UNICODE);
        }

        function request_recommend_app_edit_modify(){ //추천홈페이지 게시글 수정
            $param = $this->param;
            
            $save_files = array(); //저장된 이미지 파일 풀경로를 담는 배열(중간에 에러가 발생하였을경우 전부 삭제해야함)
            $delete_description_files = []; //삭제해야할 description 파일 이름
            $merge_file_name = []; //경로저장한 파일 리스트
            $file_name = "";

            
            $file_name = null; //썸네일 있는지 확인

            if($this->value_check(array("title", "sub_title", "content","state","recommend_app_idx","url"))){
                $sql = "select * from recommend_app where idx=".$param["recommend_app_idx"];
                $result = $this->conn->db_select($sql);
                $original_recommend_app = $result["value"][0];
                
                if($_FILES["thumnail_files"]["type"][0] == "" && $original_recommend_app["thumnail_file_name"] == "") { //썸네일 이미지 있는지 확인
                    $this->value_check(array("thumnail_files"));
                } else {
                    if($_FILES["thumnail_files"]["type"][0] == ""){ //새로 등록한 썸네일이 없을때
                        $file_name = $original_recommend_app["thumnail_file_name"];
                    }else{
                        $result = $this->file_manager->upload_file($_FILES["thumnail_files"], "_uploads/recommend_app_thumnail_img/", "_uploads/recommend_app_origin_thumnail_img/");
                        $save_files = array_merge($save_files,$result["error_file_array"]); //에러났을경우를 대비하여 저장된 파일 목록을 save_files에 merge 
                        $file_name = $result['file_name'][0]; //썸네일 파일 추출
                    }
                
                    $description = $param["content"];
                    $convert_description = $this->file_manager->convert_description("_uploads/recommend_app_description_img/","https://elasticbeanstalk-ap-northeast-2-038372400108.s3.ap-northeast-2.amazonaws.com/files/bada_soft/_uploads/recommend_app_description_img/", $description); //이미지 저장 및 변환
                    
                    $origin_file_array = $this->file_manager->get_s3_image_array($original_recommend_app["content"], "https://elasticbeanstalk-ap-northeast-2-038372400108.s3.ap-northeast-2.amazonaws.com/files/bada_soft/_uploads/recommend_app_description_img/");
                    $new_file_array = $this->file_manager->get_s3_image_array($convert_description["description"], "https://elasticbeanstalk-ap-northeast-2-038372400108.s3.ap-northeast-2.amazonaws.com/files/bada_soft/_uploads/recommend_app_description_img/");
                    $delete_file = array_diff($origin_file_array, $new_file_array); //삭제해야할 이미지 파일가져옴(배열1 값중 배열2에 없는 값만 배열 형태로 반환.)
                    
                    for($i = 0; $i < count($delete_file); $i++) {
                        $merge_file_name[$i] = "_uploads/recommend_app_description_img/".$delete_file[$i];
                    }
                    
                    if($file_name != null)
                        $update_sql_thumnail = ", thumnail_file_name = ".$this->null_check($file_name);

                    $save_files = array_merge($save_files,$merge_file_name); //에러났을경우를 대비하여 저장된 파일 목록을 save_files에 merge
                    $this->conn->set_file_list($save_files); //db오류 생겻을경우 롤백으로 인한 저장된 파일 삭제
                    $update_sql = "update recommend_app set title = ".$this->null_check($param["title"]).", sub_title = ".$this->null_check($param["sub_title"]).", url = ".$this->null_check($param["url"]).", content = ".$this->null_check($convert_description["description"]).$update_sql_thumnail.", state = ".$this->null_check($param["state"])." where idx = ".$param["recommend_app_idx"];
                    $this->result = $this->conn->db_update($update_sql);
                }
            }
            
            echo json_encode($this->result, JSON_UNESCAPED_UNICODE);
        }

        function request_recommend_app_edit_delete(){ //추천홈페이지 게시글 삭제
            $param = $this->param;

            $sql = "select * from recommend_app where idx = ".$this->null_check($param["recommend_app_idx"]);
            $result = $this->conn->db_select($sql);
            $original_recommend_app = $result["value"][0];
            
            if(count($original_recommend_app) > 1) {

                $save_files = array(); //삭제할 파일 리스트
                $merge_file_name = []; // 디스크립션 파일 삭제 리스트

                if($original_recommend_app["thumnail_file_name"]) {
                    $save_files = array_merge($save_files, ["_uploads/recommend_app_origin_thumnail_img/".$original_recommend_app["thumnail_file_name"], "_uploads/recommend_app_thumnail_img/".$original_recommend_app["thumnail_file_name"]]);
                }

                if($original_recommend_app["content"]) {
                    $description = $original_recommend_app["content"];
                    
                    $origin_file_array = $this->file_manager->get_s3_image_array($original_recommend_app["content"], "https://elasticbeanstalk-ap-northeast-2-038372400108.s3.ap-northeast-2.amazonaws.com/files/bada_soft/_uploads/recommend_app_description_img/");

                    for($i = 0; $i < count($origin_file_array); $i++) {
                        $merge_file_name[$i] = "_uploads/recommend_app_description_img/".$origin_file_array[$i];
                    }

                    $save_files = array_merge($save_files, $merge_file_name);
                }

                $sql = "delete from recommend_app where idx = ".$this->null_check($param["recommend_app_idx"]);
                $this->result = $this->conn->db_delete($sql);

                if($this->result["result"] == "1") {
                    $this->file_manager->delete_file($save_files); //삭제요청
                }
            }

            echo json_encode($this->result, JSON_UNESCAPED_UNICODE);
        }

        function request_recommend_app_list() { //추천홈페이지 리스트
            $param = $this->param;
            $move_list = json_decode($param["move_list"], true);

            if($this->value_check(array("page_size", "move_page"))){ //필수값 체크
                
                $sql_where = "";
                if(isset($move_list["search_text"]) && isset($move_list["search_type"])) {
                    if($move_list["search_type"] == "1") {
                        $sql_where = " where title LIKE '%".$move_list["search_text"]."%' ";
                    }else if($move_list["search_type"] == "2") {
                        $sql_where = " where content LIKE '%".$move_list["search_text"]."%' ";
                    }
                }

                $page_size = (int)$param["page_size"];
                $page = (int)$param["move_page"];
                $sql = "select * from recommend_app";
                $sql .= $sql_where;
                $sql .= " order by regdate desc";
                $sql .= " limit ".$page_size*($page-1).",".$page_size;
                $this->result = $this->conn->db_select($sql);

                $sql = "select count(*) total_count from recommend_app";
                $sql .= $sql_where;
                $total_result = $this->conn->db_select($sql);

                $this->result["total_count"] = $total_result["value"][0]["total_count"];

            }

            echo $this->jsonEncode($this->result, JSON_UNESCAPED_UNICODE);
        }

        function request_recommend_app_edit_view() { // 추천홈페이지 수정 정보
            $param = $this->param;
            $sql = "select * from recommend_app where idx = ".$param["idx"];

            $this->result = $this->conn->db_select($sql);
            echo $this->jsonEncode($this->result, JSON_UNESCAPED_UNICODE);
        }
        // 추천앱 end

        //이미지관리 start

        function dir_register(){
			$param = $this->param;
			// if($param["img_type"]=="0"){
				$s3Manage = new s3Manager();
			// }else{
				// $s3Manage = new s3Manager_shop();
			// }
			
			$dir = "_uploads/".$param["dir"]."/";
			$s3Manage->createFolder($dir);

			$sql = "insert into img_manager (dir,name,img_type,regdate) values('_uploads',".$this->null_check($param["dir"]).",".$param["img_type"].",now())";
			$this->conn->db_insert($sql);
			echo "success";
		}

        function folder_list(){
			//실제 연결 리스트를 전달할 필요있음 등록 할때 위치를 다 지정 해주고 리스트를 반환 하는형태로 변경
			//등록 할때 애초에 db저장 형태로
			// $s3Manage = new s3Manager();
			// $result = $s3Manage->folderList("images");
			$param = $this->param;
			$page_size = (int)$param["page_size"];
			$page = (int)$param["move_page"];
			$sql = "select * from img_manager where img_type=".$param["img_type"]." order by regdate desc limit ".$page_size*($page-1).",".$page_size;
			$list = $this->conn->db_select($sql);
		
			$this->result = array(
				"result"=>"1",
				"value"=>$list
			);

			$sql="select count(*) as count from img_manager where img_type=".$param["img_type"];
			$result = $this->conn->db_select($sql);
			$this->result["total_count"] = $result["value"][0]["count"];
            
            echo $this->jsonEncode($this->result, JSON_UNESCAPED_UNICODE);
		}

        function object_list(){
			$param = $this->param;
            $s3Manage = new s3Manager();

            $page_size = (int)$param["page_size"];
			$page = (int)$param["move_page"];
            $start_page = 1;
            $end_page = $page_size;
            if($page > 1) {
                $start_page = (int)$page * $page_size - ($page_size - 1);
                $end_page = $page * $page_size;
            }

			$img = $s3Manage->objectList($param["dir"]);
            if(count($img) > 0 && $img != "") {
                $this->result["result"] = "1";
                $this->result["total_count"] = count($img);
                $i = 1;
                $j = 1;
                foreach($img as $value){
                    if($i >= $start_page) {
                        $this->result["value"][$j-1]["idx"] = $i;
                        $this->result["value"][$j-1]["img"] = $value;
                        $j++;
                    }
                    if($i == $end_page) break;
                    $i++;
                }
                // print_r($this->result["value"]);
            }else{
                $this->result["result"] = "0";
                $this->result["error_code"] = "200";
                $this->result["message"] = "조회된 파일이 없습니다.";
            }

            echo $this->jsonEncode($this->result, JSON_UNESCAPED_UNICODE);
		}

		// function object_del(){
		// 	$param = $this->param;
            
		// 	// if($param["img_type"]=="0"){
		// 		$s3Manage = new s3Manager();
		// 	// }else{
		// 	// 	$s3Manage = new s3Manager_shop();
		// 	// }

        //     // $img = array($param["img"]);

		// 	$result = $s3Manage->multiDel("https://elasticbeanstalk-ap-northeast-2-038372400108.s3.ap-northeast-2.amazonaws.com/",array(
        //         "img"=>$param["img"]
        //     ));
		// 	if($result=="ok"){
		// 		$this->result["result"] = "1";
		// 	}else{
        //         $this->result["result"] = "0";
        //         $this->result["error_code"] = "201";
        //         $this->result["message"] = "파일삭제에 실패했습니다.";
        //     }
        //     echo $this->jsonEncode($this->result, JSON_UNESCAPED_UNICODE);
		// }

        function object_del(){
            $param = $this->param;
			$s3Manage = new s3Manager();
			$result = $s3Manage->delFile($param["img"]);
			if($result==false){
				$this->result["result"] = "1";
			}else{
                $this->result["result"] = "0";
                $this->result["error_code"] = "201";
                $this->result["message"] = "파일삭제에 실패했습니다.";
            }
            echo $this->jsonEncode($this->result, JSON_UNESCAPED_UNICODE);
		}
        
		function register(){
			$param = $this->param;
            $s3Manage = new s3Manager();
			
			$someTime=$this->rand_name();

			if($_FILES['fileUpload']['name']!=""){
				$info = new SplFileInfo($_FILES['fileUpload']['name']);
				$file_name = $someTime.".".$info->getExtension();
				$s3Manage->insertFile($param["dir"]."/".$file_name,$_FILES['fileUpload']['tmp_name']);
				
				echo "sucess";
			}
		}

        // customer 고객문의 임시 시작
        function request_customer_reg() { //고객문의 임시 등록
            $param = $this->param;

            if($this->value_check(array("state", "name"))){//value check
                $sql = "insert into customer(state, name) values(".$this->null_check($param["state"]).",".$this->null_check($param["name"]).")";
                $this->result = $this->conn->db_insert($sql);
            }

            echo $this->jsonEncode($this->result, JSON_UNESCAPED_UNICODE);

        }

        function request_customer_list() { //고객문의 임시 리스트
            $param = $this->param;
            $move_list = json_decode($param["move_list"], true);

            if($this->value_check(array("page_size", "move_page"))){ //필수값 체크
                
                $sql_where = "";
                if(isset($move_list["search_text"]) && isset($move_list["search_type"])) {
                    if($move_list["search_type"] == "1") {
                        $sql_where = " where state LIKE '%".$move_list["search_text"]."%' ";
                    }else if($move_list["search_type"] == "2") {
                        $sql_where = " where name LIKE '%".$move_list["search_text"]."%' ";
                    }
                }

                $page_size = (int)$param["page_size"];
                $page = (int)$param["move_page"];
                $sql = "select * from customer";
                $sql .= $sql_where;
                $sql .= " order by idx desc";
                $sql .= " limit ".$page_size*($page-1).",".$page_size;
                $this->result = $this->conn->db_select($sql);

                $sql = "select count(*) total_count from customer";
                $sql .= $sql_where;
                $total_result = $this->conn->db_select($sql);

                $this->result["total_count"] = $total_result["value"][0]["total_count"];

            }

            echo $this->jsonEncode($this->result, JSON_UNESCAPED_UNICODE);
        }
        
        function request_customer_edit_view() { // 고객문의 임시 수정 정보
            $param = $this->param;
            $sql = "select * from customer where idx = ".$param["idx"];

            $this->result = $this->conn->db_select($sql);
            echo $this->jsonEncode($this->result, JSON_UNESCAPED_UNICODE);
        }

        function request_customer_edit_modify(){ //고객문의 임시 게시글 수정
            $param = $this->param;

            if($this->value_check(array("state", "name"))){//value check
                $sql = "update customer set state = ".$this->null_check($param["state"]).", name = ".$this->null_check($param["name"])." where idx = ".$this->null_check($param["idx"]);
                $this->result = $this->conn->db_update($sql);
            }
            
            echo json_encode($this->result, JSON_UNESCAPED_UNICODE);
        }

        function request_customer_edit_delete() { // 고객문의 임시 삭제
            $param = $this->param;
            
            $sql = "delete from customer where idx = ".$param["idx"];
            $this->result = $this->conn->db_delete($sql);
            echo $this->jsonEncode($this->result, JSON_UNESCAPED_UNICODE);

        }
    }
?>