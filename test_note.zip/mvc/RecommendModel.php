<?php 
    class RecommendModel extends gf{
        private $param;
        private $dir;
        private $conn;
        function __construct($array){
            $this->param = $array["json"];
            $this->dir = $array["dir"];
            $this->conn = $array["db"];
            $this->project_name = $array["project_name"];
            $this->file_manager = $array["file_manager"];
            $this->result = array(
                "result" => null,
                "error_code" => null,
                "message" => null,
                "value" => null,
            );
            $this->session = $array["session"];
        }
        /********************************************************************* 
        // 함 수 : empty 체크
        // 설 명 : array("id","pw")
        // 만든이: 안정환
        *********************************************************************/
        function value_check($check_value_array){
            $object = array(
                "param"=>$this->param,
                "array"=>$check_value_array
            );
            $check_result = $this->empty_check($object);
            if($check_result["result"]){//param 값 체크 비어있으면 실행 안함
                if($check_result["value_empty"]){//필수 값이 비었을 경우
                    $this->result["result"]="0";
                    $this->result["error_code"]="101";
                    $this->result["message"]=$check_result["value_key"]."가 비어있습니다.";
                    return false;
                }else{
                    return true;
                }
            }else{
                $this->result["result"]="0";
                $this->result["error_code"]="100";
                $this->result["message"]=$check_result["value"]." 가 없습니다.";
                return false;
            }
        }

        function request_recommend_menu1_list() { //추천홈페이지 리스트
            $param = $this->param;

            if($this->value_check(array("page_size", "move_page"))){ //필수값 체크

                $sql_where = "";
                if(isset($move_list["search_text"])) {
                    $sql_where = " and (title LIKE '%".$move_list["search_text"]."%' or sub_title LIKE '%".$move_list["search_text"]."%' or content LIKE '%".$move_list["search_text"]."%') ";
                }

                $sql_order_by = "";
                if($param["idx"] != "undefined") {
                    $sql_order_by = " field(idx, '".$param['idx']."') desc, ";
                }

                $page_size = (int)$param["page_size"];
                $page = (int)$param["move_page"];
                $sql = "select * from recommend";
                $sql .= " where state != 2 ";
                $sql .= $sql_where;
                $sql .= " order by $sql_order_by regdate desc";
                $sql .= " limit ".$page_size*($page-1).",".$page_size;
                $this->result = $this->conn->db_select($sql);

                $sql = "select count(*) total_count from recommend where state != 2";
                $sql .= $sql_where;
                $total_result = $this->conn->db_select($sql);

                $this->result["total_count"] = $total_result["value"][0]["total_count"];

            }

            echo $this->jsonEncode($this->result, JSON_UNESCAPED_UNICODE);
        }
        
        function request_recommend_index_list(){ //블로그 index page 리스트
            $param = $this->param;

            $sql = "select * from recommend";
            $sql .= " where state != 2 ";
            $sql .= " limit 6";
            $this->result = $this->conn->db_select($sql);
            
            $sql = "select count(*) total_count from recommend where state != 2 limit 6";
            $total_result = $this->conn->db_select($sql);

            $this->result["total_count"] = $total_result["value"][0]["total_count"];
            
            echo $this->jsonEncode($this->result, JSON_UNESCAPED_UNICODE);
        }
        
        function request_recommend_state_modify() {
            $param = $this->param;

            $state = $this->null_check($param["state"]);
            $idx = $this->null_check($param["idx"]);

            $sql = "update recommend set state = $state where idx = $idx";
            $result = $this->conn->db_update($sql);

            if($result) {
                $this->result["result"] = 1;
            }else{
                $this->result["result"] = 0;
                $this->result["message"] = "오류가 발생했습니다.";
            }

            echo $this->jsonEncode($this->result, JSON_UNESCAPED_UNICODE);
        }
    }
?>