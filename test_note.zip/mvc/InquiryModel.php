<?php 
    class InquiryModel extends gf{
        private $param;
        private $dir;
        private $conn;
        function __construct($array){
            $this->param = $array["json"];
            $this->dir = $array["dir"];
            $this->conn = $array["db"];
            $this->project_name = $array["project_name"];
            $this->file_manager = $array["file_manager"];
            $this->result = array(
                "result" => null,
                "error_code" => null,
                "message" => null,
                "value" => null,
            );
            $this->session = $array["session"];
        }
        /********************************************************************* 
        // 함 수 : empty 체크
        // 설 명 : array("id","pw")
        // 만든이: 안정환
        *********************************************************************/
        function value_check($check_value_array){
            $object = array(
                "param"=>$this->param,
                "array"=>$check_value_array
            );
            $check_result = $this->empty_check($object);
            if($check_result["result"]){//param 값 체크 비어있으면 실행 안함
                if($check_result["value_empty"]){//필수 값이 비었을 경우
                    $this->result["result"]="0";
                    $this->result["error_code"]="101";
                    $this->result["message"]=$check_result["value_key"]."가 비어있습니다.";
                    return false;
                }else{
                    return true;
                }
            }else{
                $this->result["result"]="0";
                $this->result["error_code"]="100";
                $this->result["message"]=$check_result["value"]." 가 없습니다.";
                return false;
            }
        }

        //고객문의 start
        function request_inquiry_list() { //고객문의목록
            $param = $this->param;
            
            if($this->value_check(array("page_size", "move_page"))){ //필수값 체크
                $page_size = (int)$param["page_size"];
                $page = (int)$param["move_page"];
                $sql = "select * from inquiry";
                $sql .= " order by iq_date desc";
                $sql .= " limit ".$page_size*($page-1).",".$page_size;
                $this->result = $this->conn->db_select($sql);

                $sql = "select count(*) total_count from inquiry";
                $total_result = $this->conn->db_select($sql);

                $this->result["total_count"] = $total_result["value"][0]["total_count"];

            }

            echo $this->jsonEncode($this->result, JSON_UNESCAPED_UNICODE);
        }

        function request_inquiry_service_check() {//고객문의 서비스확인
            $param = $this->param;

            if($this->value_check(array("idx"))){ //필수값 체크
                $sql = "update inquiry set iq_service = 1 where idx = ".$this->null_check($param["idx"]);
                $this->result = $this->conn->db_update($sql);
            }

            echo $this->jsonEncode($this->result, JSON_UNESCAPED_UNICODE);
        }

        function request_inquiry_save() {//고객문의 저장
            $param = $this->param;
            $save_files = array();

            $file_name = "null";
            $iq_origin_file = "null";

            if($this->value_check(array("iq_company", "iq_hp", "iq_email", "iq_type", "iq_purpose"))){ //필수값 체크
                $iq_company = $this->null_check($param["iq_company"]);
                $iq_hp = $this->null_check($param["iq_hp"]);
                $iq_email = $this->null_check($param["iq_email"]);
                $iq_type = $this->null_check($param["iq_type"]);
                $iq_purpose = $this->null_check($param["iq_purpose"]);
                $iq_price = $this->null_check($param["iq_price"]);
                if($_FILES["iq_file"]["type"][0] != "") {
                    $result = $this->file_manager->no_image_upload_file($_FILES["iq_file"], "_uploads/inquiry_file/");
                    $save_files = array_merge($save_files,$result["error_file_array"]); //에러났을경우를 대비하여 저장된 파일 목록을 save_files에 merge 
                    $file_name = $result['file_name'][0];
                    $iq_origin_file = $this->null_check($_FILES["iq_file"]["name"][0]);
                    
                    $this->conn->set_file_list($save_files); //db오류 생겻을경우 롤백으로 인한 저장된 파일 삭제
                    $file_name = $this->null_check($file_name);
                }
                $sql = "insert into inquiry(iq_company, iq_hp, iq_email, iq_type, iq_purpose, iq_file, iq_origin_file, iq_price, iq_date) 
                        values ($iq_company, $iq_hp, $iq_email, $iq_type, $iq_purpose, $file_name, $iq_origin_file, $iq_price, now())";
                        
                $this->result = $this->conn->db_insert($sql);
            }

            echo $this->jsonEncode($this->result, JSON_UNESCAPED_UNICODE);
        }

        /********************************************************************* 
        // 함 수 : 상세보기 파일 다운로드 함수
        // 설 명 : 
        // 만든이: 조경민
        *********************************************************************/
        function file_download(){
            $param = $this->param;
            $orign = $param;
            $column = array('realname', 'url');
            $check_parameter = $this->column_check($orign, $column);
            if ($check_parameter) {
                include_once("common_php/lib/download/Download.php");
                if (new Download($param["download_type"], $param["url"], $param["realname"], $this->dir)) {
                    // $this->result["result"] = "0";
                    // $this->result["error_code"] = "1";
                    // $this->result["message"] = "DB오류 관리자에게 문의해주세요";
                    // echo json_encode($this->result, JSON_UNESCAPED_UNICODE);
                }
            } else {
                $this->result["result"] = "0";
                $this->result["error_code"] = "1";
                $this->result["message"] = "DB오류 관리자에게 문의해주세요";
                echo json_encode($this->result, JSON_UNESCAPED_UNICODE);
            }
            echo json_encode($this->result, JSON_UNESCAPED_UNICODE);
        }
    }
?>