<?php
	class UtillView extends gf{
		private $json;
		private $board;
		function __construct($json,$board){
			$this->json = $json;
			$this->board = $board;
		}

		function folder_list($result){
			for($i=0;$i<count($result);$i++){
				$param = $result[$i];
				$html = '<tr><td><div class="folder" onclick="object_list(\''.$param.'\')">'.str_replace("images/","",$param).'</div></td></tr>';
				echo $html;
			}
		}

		function object_list($result){
			$param = $this->json;
			if($param["img_type"]=="0"){
				$link = "https://elasticbeanstalk-ap-northeast-2-038372400108.s3.ap-northeast-2.amazonaws.com/files/bada_soft/_uploads/";
			}else{
				$link = "https://elasticbeanstalk-ap-northeast-2-038372400108.s3.ap-northeast-2.amazonaws.com/files/bada_soft/_uploads/";
			}

			for($i=1;$i<count($result);$i++){
				$html = '<div><img onclick="pop(\''.$link.$result[$i].'\')" style="background-color:black;width:100px;" src="'.$link.$result[$i].'"/>
				<img onclick="pop(\''.$link.$result[$i].'\')" style="width:100px;" src="'.$link.$result[$i].'"/>
				<input type="button" onclick="copy_link(\''.$link.$result[$i].'\')" value="링크복사"/>
				<input type="button" onclick="del(\''.$result[$i].'\')" value="삭제"/></div>';
				echo $html;
			}
		}
	}
?>