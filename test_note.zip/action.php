<?php
    $Root = $_SERVER["DOCUMENT_ROOT"]; 
    $project_name = 'test_note'; 
    $dir = $Root.'/PROJECT/'.$project_name.'/'; 
    include_once($Root.'/common_php/vendor/autoloader_register.php');
    include_once($Root.'/common_php/vendor/autoloader.php');
  
    $server_mode = "s3"; //서버 동작모드(server or s3)

    $server_mode = "s3"; //서버 동작모드(server or s3)
    $email = "test@naver.com";
    $email_project_name = "ELBAT";
    $email_logo = "https://s3.ap-northeast-2.amazonaws.com/lbcontents/images/ELBAT/156942767324131.png";
    
    //이미지가 없을때 보여지는 이미지
    $no_image = "https://s3.ap-northeast-2.amazonaws.com/lbcontents/images/admin/157403903875431.jpg";

    if(!isset($json["move_page"])){
        $json["move_page"]="1";
    }
    
    $import_class = []; //import할 php 폴더 경로
    //공통 import 
    $DirInc = $Root.'/common_php/lb';
    $import_class = array_merge($import_class,[$DirInc]);

    //이동 전용 라이브러리 import 
    
    if(!isset($json["ctl"]) || $json["ctl"] == "move"){ // ctl이 move이거나 없을경우
        $MoveController = $dir.'MoveController';
        $import_class =  array_merge($import_class,[$MoveController]);
    }else{
        //api 전용 라이브러리 import
        require 'common_php/lib/aws-sdk-php-resources-master/vendor/autoload.php';
        $DirApp = $dir.'app';
        $MVC = $dir.'mvc';
        $Excel = $Root.'/common_php/lib/PHPExcel-1.8.2/Classes';
        
        $import_class = array_merge($import_class,[$MVC,$DirApp,$Excel]);
        
    }

    $autoloader = new AutoLoaderRegister($import_class);//include_once에 있는 클래스
    
    $array = array(
        "json"=>$json,
        "dir"=>$dir,
        "project_name" => $project_name,
        "project_path" => "PROJECT/".$project_name."/page/user/",
        "project_admin_path" => "PROJECT/".$project_name."/page/adm/",
        "project_admin_image_path" => "https://lbcontents.s3.ap-northeast-2.amazonaws.com/images/admin/",
        "to_email"=>$email,
        "email_project_name" => $email_project_name,
        "email_logo" => $email_logo,
        "no_image" => $no_image,
        "data"=>json_encode($json),
        "session"=>new Session($project_name),
        "version"=>"?v=".date("Y-m-d H:i:s"),
        "file_path"=>new file_path($server_mode, $project_name),

        "send_number" => "01024949278",
        "send_id" => "tester",
    );
    
    if(!isset($json["ctl"]) || $json["ctl"] == "move"){
        new MoveController($array);
    }else{
        $db = new db($project_name); // DB변경시 여기 수정
        $array["file_manager"] = new file_manager($array["dir"], $server_mode, $project_name); //파일매니저 프로젝트 경로, 저장모드(s3,server), 프로젝트이름
        $array["db"] = new AppDB($db, $array["file_manager"]);
        $app = new App($array);
    }
    
?>