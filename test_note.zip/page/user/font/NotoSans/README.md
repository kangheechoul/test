# NotoSans-subset

NotoSansCJKkr(bold, light, medium, regular)을 경량화한 한글 웹폰트입니다. 경량화한 방법은 [한글 웹 폰트 경량화해 사용하기](http://coderifleman.tumblr.com/post/111825720099/%ED%95%9C%EA%B8%80-%EC%9B%B9-%ED%8F%B0%ED%8A%B8-%EA%B2%BD%EB%9F%89%ED%99%94%ED%95%B4-%EC%82%AC%EC%9A%A9%ED%95%98%EA%B8%B0)를 참고해주세요.

[NotoSans](https://www.google.com/get/noto/#/)는 Google과 어도비가 합작해 개발한 웹폰트입니다. 라이센스는 [Apache License 2.0](http://www.apache.org/licenses/LICENSE-2.0.html) 입니다.
