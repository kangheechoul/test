<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <meta name="format-detection" content="telephone=no">

	<title>경남해운</title>

    <!-- FONT -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Exo:ital,wght@0,300;0,500;0,700;0,900;1,900&family=Noto+Sans+JP:wght@300;400;500;700&display=swap" rel="stylesheet">

	<!-- CSS -->
    <?php include_once $this->project_path."include/common_css.php"; ?>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/sub_page.css"/>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/side_tab.css"/>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/mypage.css"/>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/notice_board.css"/>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/attend.css"/>
    
    <!-- JS -->
    <?php include_once $this->project_path."include/common_js.php"; ?>
    
</head>
<body>
    <div class="Wrap">        
        <?php include_once  $this->project_path."include/header.php"; ?>
        <div class="Container" id="content">
            <div class="bd-md section">
                <div class="row">
                    <?php include_once  $this->project_path."include/my_side.php"; ?>
                    <div class="col-md-10 col-sm-12">
                        <!-- tab -->
                        <div class="col-md-12 my-tab-wrap">
                            <ul class="my-tab cf">
                                <li>
                                    <p>회원이름</p>
                                    <span><b>홍길동</b></span>
                                </li>
                                <li>
                                    <p>보유쿠폰</p>
                                    <span><b>0</b>개</span>
                                </li>
                                <li>
                                    <p>적립금</p>
                                    <span><b>0</b>p</span>
                                </li>
                                <li>
                                    <p>예치금</p>
                                    <span><b>0</b>원</span>
                                </li>
                            </ul>
                        </div>
                        <!-- /tab -->
                        
                        <div class="col-md-12 attend-wrap">
                            <div class="attend-header">
                                <button class="nav-btn go-prev"><</button>
                                <h4 class="year-month"></h4>
                                <button class="nav-btn go-prev">></button>
                            </div>
                            <div class="main">
                                <div class="days">
                                    <div class="day">일</div>
                                    <div class="day">월</div>
                                    <div class="day">화</div>
                                    <div class="day">수</div>
                                    <div class="day">목</div>
                                    <div class="day">금</div>
                                    <div class="day">토</div>
                                </div>
                                <div class="dates cf"></div>
                            </div>

                        </div>
                        
                    </div>
                        
                </div>
            </div>
        </div>
        <?php include_once  $this->project_path."include/footer.php"; ?>

    </div>
    <script src="<?php echo $this->project_path;?>/js/attend.js"></script>
</body>
</html>