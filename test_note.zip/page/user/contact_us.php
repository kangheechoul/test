<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <meta name="format-detection" content="telephone=no">

	<title>바다소프트</title>

    <!-- FONT -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Exo:ital,wght@0,300;0,500;0,700;0,900;1,900&family=Noto+Sans+JP:wght@300;400;500;700&display=swap" rel="stylesheet">

	<!-- CSS -->
    <?php include_once $this->project_path."include/common_css.php"; ?>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/sub.css<?php echo $this->version;?>"/>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/contact.css<?php echo $this->version;?>"/>

    <!-- JS -->
    <?php include_once $this->project_path."include/common_js.php"; ?>
    <script type="text/javascript" src="<?php echo $this->project_path;?>js/menu5.js<?php echo $version;?>"></script>

</head>
<body>
    <div class="Wrap">        
        <?php include_once  $this->project_path."include/header.php"; ?>
        <div class="Container" id="content">
            <div class="bd-md">
                <div class="contact_form">
                    <form class="form" id="form" onsubmit='return false;'>
                        <div class="row">
                            <dl class="col-md-6 col-xs-12">
                                <dt>회사명</dt>
                                <dd>
                                    <div class="insert_wrap">
                                        <input type="text" id="iq_company" name="iq_company"/>
                                    </div>
                                </dd>
                            </dl>
                            <dl class="col-md-6 col-xs-12">
                                <dt>담당자명</dt>
                                <dd>
                                    <div class="insert_wrap">
                                        <input type="text" id="iq_name" name="iq_name"/>
                                    </div>
                                </dd>
                            </dl>
                            <dl class="col-md-6 col-xs-12">
                                <dt>연락처</dt>
                                <dd>
                                    <div class="insert_wrap">
                                        <input type="number" id="iq_hp" name="iq_hp"/>
                                    </div>
                                </dd>
                            </dl>
                            <dl class="col-md-6 col-xs-12">
                                <dt>이메일</dt>
                                <dd>
                                    <div class="insert_wrap">
                                        <input type="text" id="iq_email" name="iq_email"/>
                                    </div>
                                </dd>
                            </dl>
                            <dl class="col-md-6 col-xs-12">
                                <dt>참고사이트 URL</dt>
                                <dd>
                                    <div class="insert_wrap">
                                        <input type="text" id="iq_link" name="iq_link"/>
                                    </div>
                                </dd>
                            </dl>
                            <dl class="col-md-6 col-xs-12">
                                <dt>제작예산</dt>
                                    <dd>
                                        <div class="insert_wrap">
                                            <select id="iq_price" name="iq_price">
                                                <option value="2">100~200만원</option>
                                                <option value="3">200~300만원</option>
                                                <option value="4">300~500만원</option>
                                                <option value="5">500~1000만원</option>
                                                <option value="6">1000~3000만원</option>
                                                <option value="7">3000~5000만원</option>
                                                <option value="8">5000만원 이상</option>
                                            </select>
                                        </div>
                                    </dd>
                                </dl>
                                <dl class="col-md-6 col-xs-12">
                                    <dt>의뢰범위</dt>
                                    <dd>
                                        <div class="insert_wrap">
                                            <select id="iq_type" name="iq_type">
                                                <option value="1">홈페이지</option>
                                                <option value="2">쇼핑몰</option>
                                                <option value="3">어플리케이션</option>
                                            </select>
                                        </div>
                                    </dd>
                                </dl>
                            <dl class="col-md-6 col-xs-12">
                                <dt>파일첨부</dt>
                                <dd>
                                    <div class="insert_wrap">
                                        <input type="text" class="file_ipt" id="file_name" readonly/>
                                        <span class="btnarea">
                                            <button type="button" id="btn_cancel" style="display:none;">Cancel</button>
                                            <input type="file" id="file_add" name="iq_file[]"/>
                                            <label for="file_add" class="text-primary">업로드</label>
                                        </span>
                                    </div>
                                </dd>
                            </dl>
                            <dl class="col-md-12">
                                <dt>상담 내용</dt>
                                <dd>
                                    <div class="insert_wrap">
                                        <textarea id="content" name="iq_purpose" placeholder="">1. 개발배경 및 목적 :&#13;&#10;2. 이용자 타겟 :&#13;&#10;3. 컨셉 :&#13;&#10;4. 자유롭게 내용을 입력해주시면 꼼꼼히 확인하겠습니다.^^</textarea>
                                    </div>
                                </dd>
                            </dl>
                        </div>
                    </form>
                    <div class="etc_txt xsmall text-gray">
                        <p>※ 관련 문의 내용과 맞지 않는 글을 등록 하실 경우 원하는 답변을 받을 수 없거나 처리가 지연될 수 있습니다.</p>
                        <p>※ ‘접수하기’버튼을 클릭과 동시에 개인정보 수집 및 취급에 동의하게 됩니다.</p>
                    </div>
                    <div class="mt-4 box text-center">
                        <button type="button" class="main_btn2" id="btn_save">빠른 견적 받기</button>
                    </div>
                </div>
            </div>
        </div>
        <?php include_once  $this->project_path."include/footer.php"; ?>
    </div>
</body>
</html>