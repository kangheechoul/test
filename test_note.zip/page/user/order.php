<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <meta name="format-detection" content="telephone=no">

	<title>경남해운</title>

    <!-- FONT -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Exo:ital,wght@0,300;0,500;0,700;0,900;1,900&family=Noto+Sans+JP:wght@300;400;500;700&display=swap" rel="stylesheet">

	<!-- CSS -->
    <?php include_once $this->project_path."include/common_css.php"; ?>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/sub_page.css"/>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/payment.css"/>

    <!-- JS -->
    <?php include_once $this->project_path."include/common_js.php"; ?>
</head>
<body>
    <div class="Wrap">        
        <?php include_once  $this->project_path."include/header.php"; ?>
        <div class="Container" id="content">
            <div class="bd-md section" id="pay-list-section">
                <div class="row">
                    <div class="col-md-12">
                        <ul class="pay-list-wrap">
                            <li class="list-con list-con-head">
                                <dl>
                                    <dd class="xs-etc chk">
                                        <label for="">
                                            <input type="hidden">
                                            <input type="checkbox">
                                            <span class="checkmark"></span>
                                        </label>
                                    </dd><!-- 선택 -->
                                    <dd class="sm-etc imgbox">이미지</dd><!-- 이미지 -->
                                    <dd class="tit">상품정보</dd><!-- 상품정보 -->
                                    <dd class="sm-etc">판매가</dd><!-- 판매가격 -->
                                    <dd class="sm-etc">수량</dd><!-- 수량 -->
                                    <dd class="sm-etc">적립금</dd><!-- 적립금 -->
                                    <dd class="sm-etc">배송구분</dd><!-- 배송구분 -->
                                    <dd class="sm-etc">배송비</dd><!-- 배송비 -->
                                    <dd class="sm-etc">합계</dd><!-- 합계 -->
                                    <dd class="sm-etc">선택</dd><!-- 선택 -->
                                </dl>
                            </li>
                            <li class="list-con list-con-body">
                                <dl>
                                    <dd class="xs-etc chk">
                                        <label for="">
                                            <input type="hidden">
                                            <input type="checkbox">
                                            <span class="checkmark"></span>
                                        </label>
                                    </dd><!-- 선택 -->
                                    <dd class="sm-etc imgbox">
                                        <div class="img-box">
                                            <img src="<?php echo $this->project_path;?>images/no_image.gif" alt="">
                                        </div>
                                    </dd><!-- 이미지 -->
                                    <dd class="tit">
                                        <p>상품이름</p>
                                        <span>[상품옵션 : 옵션옵션옵션]</span>
                                        <a href="javascript:;" class="btn">옵션변경</a>
                                    </dd><!-- 상품정보 -->
                                    <dd class="sm-etc">9,900원</dd><!-- 판매가격 -->
                                    <dd class="sm-etc count">
                                        <div class="length">
                                            <input type="number" min="1" value="1">
                                            <a href="#a">증가</a>
                                            <a href="#a">감소</a>
                                        </div>
                                        <a href="javascript:;" class="btn count-change">변경</a>
                                    </dd><!-- 수량 -->
                                    <dd class="sm-etc">-</dd><!-- 적립금 -->
                                    <dd class="sm-etc">기본배송</dd><!-- 배송구분 -->
                                    <dd class="sm-etc">무료</dd><!-- 배송비 -->
                                    <dd class="sm-etc">9,900원</dd><!-- 합계 -->
                                    <dd class="sm-etc">
                                        <a href="javascript:;" class="btn">관심상품등록</a>
                                        <a href="javascript:;" class="btn">삭제</a>
                                    </dd><!-- 선택 -->
                                </dl>
                            </li>
                            <li class="list-con list-con-body-none">
                                장바구니가 비어있습니다.
                            </li>
                            <li class="list-con list-con-footer">
                                <p>상품구매액 : <span>9,900원</span> + 배송비 <span>0(무료)</span> = 합계 <b class="total">9,900</b>원</p>
                            </li>
                        </ul>
                        <!-- moblie pay-list -->
                        <ul class="m-pay-list-wrap">
                            <li class="m-list-con-body">
                                <dl>
                                    <dd class="chk">
                                        <label for="">
                                            <input type="hidden">
                                            <input type="checkbox">
                                            <span class="checkmark"></span>
                                        </label>
                                    </dd>
                                    <dd>
                                        <div class="list-con-info">
                                            <p class="item-name">상품이름영역</p>
                                            <span>배송 : [무료] / 기본배송</span>
                                            <span class=item-option>[상품옵션: 옵션내용~~]</span>
                                            <p class="price">9,900원</p>
                                            <div class="m-length">
                                                <div>
                                                    <a href="javasceipr:;">-</a>
                                                    <input type="number" value="1">
                                                    <a href="javascript:;">+</a>
                                                </div>
                                                <a href="javascript:;" class="btn">변경</a>
                                            </div>
                                        </div>
                                        <div class="img-box">
                                            <img src="<?php echo $this->project_path;?>images/no_image.gif" alt="">
                                        </div>
                                    </dd>
                                    <dd>
                                        <p class="total">합계 : <b>9,900</b>원</p>
                                    </dd>
                                    <dd>
                                        <a href="javascript:;" class="btn">관심상품등록</a>
                                        <a href="javascript:;" class="btn delete">삭제</a>
                                    </dd>
                                </dl>
                            </li>
                            <li class="m-list-con-body-none">
                                장바구니가 비었습니다.
                            </li>
                            <li class="m-list-con-footer">
                                <p>상품구매액 : <span>9,900원</span> + 배송비 <span>0(무료)</span> = 합계 <b class="total">9,900</b>원</p>
                            </li>
                        </ul>
                    </div>
                    <div class="col-md-12 btn-small-wrap">
                        <a href="javascript:;" class="btn chk-delete">선택삭제</a>
                        <a href="javascript:;" class="btn chk-delete-all">전체삭제</a>
                        <a href="javascript:;" class="btn btn-back">이전페이지</a>
                    </div>
                </div>
            </div>

            <div class="bd-md order-section">
                <div class="row">
                    <form action="">
                        <!-- 주문 정보 -->
                        <div class="col-md-12 section">
                            <div class="title">
                                <h4>주문정보</h4>
                            </div>
                            <div class="order-box">
                                <div class="order-row">
                                    <div class="input-title">주문자</div>
                                    <div class="order-input">
                                        <input type="text">
                                    </div>
                                </div>

                                <div class="order-row">
                                    <div class="input-title">주소</div>
                                    <div class="order-input">
                                        <input type="text">
                                        <a href="javascript:;" class="btn btn-address">우편번호</a>
                                        <div class="input-address">
                                            <input type="text" placeholder="기본주소"><span>기본주소</span>
                                        </div>
                                        <div class="input-address">
                                            <input type="text" placeholder="상세주소"><span>상세주소</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="order-row">
                                    <div class="input-title">일반전화</div>
                                    <div class="order-input">
                                        <input type="text">
                                    </div>
                                </div>
                                <div class="order-row">
                                    <div class="input-title">휴대전화</div>
                                    <div class="order-input">
                                        <input type="text">
                                    </div>
                                </div>
                                <div class="order-row">
                                    <div class="input-title">이메일</div>
                                    <div class="order-input">
                                        <input type="email">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- 배송정보 -->
                        <div class="col-md-12 section">
                            <div class="title">
                                <h4>배송 정보</h4>
                            </div>
                            <div class="order-box">
                                <div class="order-row">
                                    <div class="input-title">배송지 선택</div>
                                    <div class="order-radio">
                                        <label for="">
                                            <input type="radio">
                                            <span>주문자 정보와 동일</span>
                                        </label>
                                        <label for="">
                                            <input type="radio" checked>
                                            <span>새로운 배송지</span>
                                        </label>
                                    </div>
                                </div>
                                <div class="order-row">
                                    <div class="input-title">받으시는 분</div>
                                    <div class="order-input">
                                        <input type="text">
                                    </div>
                                </div>

                                <div class="order-row">
                                    <div class="input-title">주소</div>
                                    <div class="order-input">
                                        <input type="text">
                                        <a href="javascript:;" class="btn btn-address">우편번호</a>
                                        <div class="input-address">
                                            <input type="text" placeholder="기본주소"><span>기본주소</span>
                                        </div>
                                        <div class="input-address">
                                            <input type="text" placeholder="상세주소"><span>상세주소</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="order-row">
                                    <div class="input-title">휴대전화</div>
                                    <div class="order-input">
                                        <input type="text">
                                    </div>
                                </div>
                                <div class="order-row">
                                    <div class="input-title">배송메세지</div>
                                    <div class="order-textarea">
                                        <textarea name="" id=""></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- 결제 예정금액 -->
                        <div class="col-md-12 section">
                            <table class="table table-type4">
                                <colgroup>
                                    <col width="33.333%">
                                    <col width="33.333%">
                                    <col width="33.333%">
                                </colgroup>

                                <thead>
                                    <tr>
                                        <th>
                                            총 주문 금액
                                            <a href="#pay-list-section" class="btn">내역보기</a>
                                        </th>
                                        <th>총 할인 + 부가결제 금액</th>
                                        <th>총 결제예정 금액</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><b>43,800</b>원</td>
                                        <td><b>- 0</b>원</td>
                                        <td><b>= 43,800</b>원</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <!-- 결제수단 -->
                        <div class="col-md-12 pay-form pay-type mt-3">
                            <div class="title">
                                <h4>결제수단 
                                    <span class="chk dis-in-block"><!--  -->
                                        <label for="">
                                            <input type="checkbox">
                                            <span>결제수단과 입력정보를 다음에도 사용</span>
                                        </label>
                                    </span>
                                </h4>
                            </div>
                            <div class="pay-type-con">
                                <div class="pay-type-box cf">
                                    <ul class="mt-1 col-md-8 col-xs-12">
                                        <li class="col-md-4 col-xs-12 mb-1">
                                            <label class="check-label" for= "pay_type0">카드결제
                                                <input type="radio" id = "pay_type0" name = "pay_type" value = "card" checked>
                                                <span class="checkmark"></span>
                                            </label>
                                        </li>
                                        <li class="col-md-4 col-xs-12 mb-1">
                                            <label class="check-label" for= "pay_type1">실시간계좌이체
                                                <input type="radio" id = "pay_type1" name = "pay_type" value = "transfer">
                                                <span class="checkmark"></span>
                                            </label>
                                        </li>
                                        <li class="col-md-4 col-xs-12 mb-1">
                                            <label class="check-label" for= "pay_type2">무통장입금 
                                                <input type="radio" id = "pay_type2" name = "pay_type"  value = "account">
                                                <span class="checkmark"></span>
                                            </label>
                                        </li>
                                        <div class="col-lg-12 signup_form pt-1" id="account_name_div">
                                        <ul>
                                            <li>
                                                <p class="input_title">입금자명<em class="point">*</em></p> 
                                                <div class="insert inpbox"><input type="text" id = "account_name" placeholder=""></div>
                                            </li>
                                        </ul>
                                    </div>
                                    </ul>
                                    <!-- 무통장입금시 입금자명 -->
                                    <div class="col-md-4 col-xs-12 payment-total">
                                        <p><span>카드결제</span> 최종결제금액</p>
                                        <p><b>49,900</b>원</p>
                                        <p class="mileage">적립금액 : <span>499원</span></p>
                                        <a href="javascript:;" class="btn btn-order">결제하기</a>
                                    </div>
                                </div>

                                    <!-- 계좌이체는 내용이 없습니다 -->
                                <div class="signup_form pay-type-detail mt-1"  id = "receipt_elem">
                                    <form>
                                        <ul>
                                            <li>
                                                
                                            </li>
                                            <li>
                                                <p class="input_title">현금영수증</p> 
                                                <ul class="row mb-1">
                                                    <li class="col-md-4 col-sm-12 mt-1 pt-ss0 check">
                                                        <label class="check-label" for= "trader_kind0">선택안함
                                                            <input type="radio" id = "trader_kind0" name = "receipt" value = "0" checked>
                                                            <span class="checkmark"></span>
                                                        </label>
                                                    </li>
                                                    <li class="col-md-4 col-sm-12 mt-1 pt-0">
                                                        <label class="check-label" for= "trader_kind1">개인소득공제
                                                            <input type="radio" id = "trader_kind1" name = "receipt" value = "1">
                                                            <span class="checkmark"></span>
                                                        </label>
                                                    </li>
                                                    <li class="col-md-4 col-sm-12 mt-1 pt-0">
                                                        <label class="check-label" for= "trader_kind2">사업자증빙용
                                                            <input type="radio" id = "trader_kind2"  name = "receipt" value = "2">
                                                            <span class="checkmark" ></span>
                                                        </label>
                                                    </li>
                                                </ul>
                                            </li>
                                            <!-- 개인소득공제, 사업자 선택시에만 나와야합니다 -->
                                            <li class="pt-0" id = "receipt_number_elem">
                                                <div class="insert"><input type="text" id = "receipt_number" placeholder="숫자만 입력"></div> 
                                            </li>
                                            <!-- 현금영수증 번호입력 // -->
                                        </ul>
                                    </form>
                                </div>
                                <!-- 무통장입금 // -->
                            </div>
                        </div>

                    </form>
                </div>
            </div>
            
        </div>
        <?php include_once  $this->project_path."include/footer.php"; ?>
    </div>
</body>
</html>