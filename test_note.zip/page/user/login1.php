<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <meta name="format-detection" content="telephone=no">

	<title>경남해운</title>

    <!-- FONT -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Exo:ital,wght@0,300;0,500;0,700;0,900;1,900&family=Noto+Sans+JP:wght@300;400;500;700&display=swap" rel="stylesheet">

	<!-- CSS -->
    <?php include_once $this->project_path."include/common_css.php"; ?>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/sub_page.css"/>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/login.css"/>

    <!-- JS -->
    <?php include_once $this->project_path."include/common_js.php"; ?>
</head>
<body>
    <div class="Wrap">        
        <?php include_once  $this->project_path."include/header.php"; ?>
        <div class="Container" id="content">
            <!-- type1 -->
            <div class="bd-xxxs login-section1 section">
                <div class="row">
                    <div class="col-md-12">
                        <div class="title">
                            <h4>로그인</h4>
                        </div>
                        <div class="log-form">
                            <form action="">
                                <div class="login-input">
                                    <input type="text" placeholder="아이디를 입력해주새요.">
                                </div>
                                <div class="login-input">
                                    <input type="text" placeholder="비밀번호를 입력해주새요.">
                                </div>
                                <div class="checkbox_save">
                                    <label for="">
                                        <input type="checkbox" name="" id="">
                                        <span>아이디저장</span>
                                    </label>
                                    <div class="login-search">
                                        <a href="javascript:;">아이디 찾기</a>
                                        <span class="bar"></span>
                                        <a href="javascript:;">비밀번호 찾기</a>
                                    </div>
                                </div>
                                <button class="btn-type1">로그인</button>
                            </form>
                            <a href=".?param=join" class="btn-type2">회원가입</a>
                        </div>
                        <ul class="sns-login-wrap cf">
                            <p>간련로그인</p>
                            <li><a href="javascript:;"><img src="<?php echo $this->project_path;?>images/icon-naver-type1.png" alt=""></a></li>
                            <li><a href="javascript:;"><img src="<?php echo $this->project_path;?>images/icon-naver-type1.png" alt=""></a></li>
                            <li><a href="javascript:;"><img src="<?php echo $this->project_path;?>images/icon-fb-type1.png" alt=""></a></li>
                            <li><a href="javascript:;"><img src="<?php echo $this->project_path;?>images/icon-google-type1.png" alt=""></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <?php include_once  $this->project_path."include/footer.php"; ?>
    </div>
</body>
</html>