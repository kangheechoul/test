<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <meta name="format-detection" content="telephone=no">

	<title>경남해운</title>

    <!-- FONT -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Exo:ital,wght@0,300;0,500;0,700;0,900;1,900&family=Noto+Sans+JP:wght@300;400;500;700&display=swap" rel="stylesheet">

	<!-- CSS -->
    <?php include_once $this->project_path."include/common_css.php"; ?>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/sub_page.css"/>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/side_tab.css"/>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/mypage.css"/>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/notice_board.css"/>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/layout/css/jquery-ui.css"/>

    <!-- JS -->
    <?php include_once $this->project_path."include/common_js.php"; ?>
    <script src="<?php echo $this->project_path;?>/layout/js/jquery-ui.js"></script>
</head>
<body>
    <div class="Wrap">        
        <?php include_once  $this->project_path."include/header.php"; ?>
        <div class="Container" id="content">
            <div class="bd-md tracking-section section">
                <div class="row">
                    <?php include_once  $this->project_path."include/my_side.php"; ?>
                    <div class="col-md-10 col-sm-12">
                        <!-- tab -->
                        <div class="col-md-12">
                            <ul class="my-tab cf">
                                <li>
                                    <p>회원이름</p>
                                    <span><b>홍길동</b></span>
                                </li>
                                <li>
                                    <p>보유쿠폰</p>
                                    <span><b>0</b>개</span>
                                </li>
                                <li>
                                    <p>적립금</p>
                                    <span><b>0</b>p</span>
                                </li>
                                <li>
                                    <p>예치금</p>
                                    <span><b>0</b>원</span>
                                </li>
                            </ul>
                        </div>
                        <!-- /tab -->
                        <div class="col-md-12 my-order">
                            <div class="title">
                                <h4>주문배송 조회</h4>
                            </div>
                            <div class="col-md-12 mys_state">
                                <div class="col-md-6">
                                    <p>입금대기중 <b>0</b><span>건</span></p>
                                </div>
                                <div class="col-md-6">
                                <p>배송중 <b>0</b><span>건</span></p>
                                </div>
                            </div>
                        </div>
                        <!--  -->

                        <div class="col-md-12 period-wrap">
                            <div class="col-md-12 period-box">
                                <div class="top">
                                    <span class="tl" id="tl">조회기간</span>
                                    <div id="radioset">
                                        <input type="radio" id="radio1" name="radio" checked><label for="radio1">1주일</label>
                                        <input type="radio" id="radio2" name="radio"><label for="radio2">1개월</label>
                                        <input type="radio" id="radio3" name="radio"><label for="radio3">3개월</label>
                                        <input type="radio" id="radio4" name="radio"><label for="radio4">6개월</label>
                                    </div>
                                </div>
                                <div>
                                    <span class="date-input">
                                        <input type="text" class="date">
                                    </span>
                                    <span class="tx">~</span>
                                    <span class="date-input">
                                        <input type="text" class="date">
                                    </span>
                                    <button class="btn">조회</button>
                                </div>
                            </div>


                            <table class="table board_type1">
                                <colgroup>
                                    <col width="20%">
                                    <col width="35%">
                                    <col width="15%">
                                    <col width="15%">
                                    <col width="15%">
                                </colgroup>
                                <thead>
                                    <tr>
                                        <th>주문일자</th>
                                        <th>주문내역</th>
                                        <th>주문수량</th>
                                        <th>가격</th>
                                        <th>주문상태</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr class="no-list">
                                        <td class="no-data" colspan="5">
                                            찾으시는 기간 내에 해댕하는 내역이 없습니다.
                                        </td>
                                    </tr>
                                    <tr class="main-list">
                                        <td>21.06.03</td>
                                        <td class="title">
                                            <span>oooooooo주문 외 3건</span>
                                        </td>
                                        <td>2개</td>
                                        <td>18,800원</td>
                                        <td>배송중</td>
                                    </tr>

                                    <!-- 주문 리스트가 몇가지 있을경우 위에 td.title클릭시 list-info toggle되면서 리스트 보이게 -->
                                    <tr class="list-info dis-none">
                                        <td colspan="2">
                                            <dl class="list-name cf">
                                                <dt class="img"><img src="<?php echo $this->project_path;?>images/no_image.gif" alt=""></dt>
                                                <dd>[열무김치 1.5KG]</dd>
                                            </dl>
                                            <dl class="list-name">
                                                <dt class="img"><img src="<?php echo $this->project_path;?>images/no_image.gif" alt=""></dt>
                                                <dd>[배추김치 1.5KG]</dd>
                                            </dl>
                                        </td>
                                        <td>
                                            <dl class="list-etc cf">
                                                <dd>1개</dd>
                                            </dl>
                                            <dl class="list-etc cf">
                                                <dd>1개</dd>
                                            </dl>
                                        </td>
                                        <td>
                                            <dl class="list-price cf">
                                                <dd>18,900원</dd>
                                            </dl>
                                            <dl class="list-price cf">
                                                <dd>20,900원</dd>
                                            </dl>
                                        </td>
                                        <td><dl></dl></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php include_once  $this->project_path."include/footer.php"; ?>
    </div>

    <script>
        $(document).ready(function(){
            $('.date').datepicker({
            })

            $(".main-list").click(function(){
                $(".list-info").toggle(300);
            })
        })//
        $(function() {
            $( "input" ).checkboxradio();
        });
    </script>
</body>
</html>