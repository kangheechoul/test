<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <meta name="format-detection" content="telephone=no">

	<title>경남해운</title>

    <!-- FONT -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Exo:ital,wght@0,300;0,500;0,700;0,900;1,900&family=Noto+Sans+JP:wght@300;400;500;700&display=swap" rel="stylesheet">

	<!-- CSS -->
    <?php include_once $this->project_path."include/common_css.php"; ?>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/sub_page.css"/>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/join.css"/>

    <!-- JS -->
    <?php include_once $this->project_path."include/common_js.php"; ?>
</head>
<body>
    <div class="Wrap">        
        <?php include_once  $this->project_path."include/header.php"; ?>
        <div class="Container" id="content">
            <div class="bd-xxs join-write-section1 section">
                <div class="row">
                    <div class="col-md-12 end-wrap">
                        <h3>회원가입이 <b>완료</b> 되었습니다.</h3>
                        <div class="btn-wrap">
                            <a href=".?param=index">홈으로</a>
                            <a href=".?param=login1">로그인</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php include_once  $this->project_path."include/footer.php"; ?>
    </div>
</body>
</html>