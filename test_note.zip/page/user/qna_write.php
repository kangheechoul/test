<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <meta name="format-detection" content="telephone=no">

	<title>경남해운</title>

    <!-- FONT -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Exo:ital,wght@0,300;0,500;0,700;0,900;1,900&family=Noto+Sans+JP:wght@300;400;500;700&display=swap" rel="stylesheet">

	<!-- CSS -->
    <?php include_once $this->project_path."include/common_css.php"; ?>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/sub_page.css"/>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>css/sub_banner.css<?php echo $version;?>"/>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/notice_board.css"/>

    <!-- JS -->
    <?php include_once $this->project_path."include/common_js.php"; ?>
    <script type="text/javascript" src="<?php echo $this->project_path;?>js/qna.js<?php echo $version;?>"></script>

</head>
<body>
    <div class="Wrap">        
        <?php include_once  $this->project_path."include/header.php"; ?>
        <div class="Container" id="content">
            
            <div class="bd-md section">
                <div class="contact_form">
                    <form class="form" id="form" onsubmit='return false;'>
                        <div class="row">

                            <div class="col-md-12">
                                <div class="col-md-4 col-xs-12">
                                    <div class="insert_wrap">
                                        <input type="text" placeholder="이름">
                                    </div>
                                </div>
                                <div class="col-md-4 col-xs-12">
                                    <div class="insert_wrap">
                                        <input type="password" placeholder="비밀번호">
                                    </div>
                                </div>
                                <div class="col-md-4 col-xs-12">
                                    <div class="insert_wrap">
                                        <input type="email" placeholder="이메일">
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-12">
                                <div class="insert_wrap">
                                    <input type="email" placeholder="제목">
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="insert_wrap">
                                    <textarea name="" placeholder="상남내용"></textarea>
                                </div>
                                
                            </div>

                            <div class="col-md-12">
                                <div class="insert_wrap">
                                    <input type="text" class="file_ipt" id="file_name" readonly/>
                                    <span class="btnarea">
                                        <button type="button" id="btn_cancel" style="display:none;">Cancel</button>
                                        <input type="file" id="file_add" name="iq_file[]"/>
                                        <label for="file_add" class="text-primary">업로드</label>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </form>
                    <div class="etc_txt xsmall text-gray">
                        <p>※ 관련 문의 내용과 맞지 않는 글을 등록 하실 경우 원하는 답변을 받을 수 없거나 처리가 지연될 수 있습니다.</p>
                        <p>※ ‘접수하기’버튼을 클릭과 동시에 개인정보 수집 및 취급에 동의하게 됩니다.</p>
                    </div>
                    
                    <div class="btn_wrap text-center">
                        <a href=".?param=menu5-3">취소</a>
                        <a href="javascript:;">질문등록</a>
                    </div>
                </div>
            </div>
        </div>
        <?php include_once  $this->project_path."include/footer.php"; ?>
    </div>
</body>
</html>