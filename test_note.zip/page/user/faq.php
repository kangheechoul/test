<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <meta name="format-detection" content="telephone=no">

	<title>경남해운</title>

    <!-- FONT -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Exo:ital,wght@0,300;0,500;0,700;0,900;1,900&family=Noto+Sans+JP:wght@300;400;500;700&display=swap" rel="stylesheet">

	<!-- CSS -->
    <?php include_once $this->project_path."include/common_css.php"; ?>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/sub_page.css"/>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/side_tab.css"/>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/mypage.css"/>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/notice_board.css"/>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/layout/css/jquery-ui.css"/>

    <!-- JS -->
    <?php include_once $this->project_path."include/common_js.php"; ?>
    <script src="<?php echo $this->project_path;?>/layout/js/jquery-ui.js"></script>
</head>
<body>
    <div class="Wrap">        
        <?php include_once  $this->project_path."include/header.php"; ?>
        <div class="Container" id="content">
            <div class="bd-md section">
                <div class="row">
                <?php include_once  $this->project_path."include/cs_side.php"; ?>
                    <div class="col-md-10 col-sm-12">
                        <div class="col-md-12 faq-wrap">

                            <div class="category-select text-right">
                                <select name="" id="">
                                    <option value="">전체</option>
                                    <option value="">환불안내</option>
                                    <option value="">배송안내</option>
                                    <option value="">기타</option>
                                    <option value="">주문안내</option>
                                    <option value="">적립금쿠폰</option>
                                </select>
                            </div>

                            <table class="table board_type1">
                                <tbody>
                                    <tr class="question">
                                        <td class="title">
                                            <dl class="qst">
                                                <dt>#환불안내</dt>
                                                <dd>질문의 대한 관리자의 답변~</dd>
                                            </dl>
                                        </td>
                                    </tr>
                                    <tr class="answer dis-none">
                                        <td class="text-left">
                                            <dl class="asw">
                                                <dd>질문의 대한 관리자의 답변~</dd>
                                            </dl>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>

                            <div class="pagination_container mt-3" id = "paging">
                                <div class="page_item arrow prev">«</div>
                                <div class="page_item active">1</div>
                                <div class="page_item ">2</div>
                                <div class="page_item arrow next">»</div>
                            </div>

                            <div class="search_area text-center mt-2">
                                <div class="insert_wrap">
                                    <div class="insert">
                                        <input type="text" id="search_text" name="search_text" onkeydown="enter_search();" placeholder="검색어"/>
                                        <span class="btn" id="btn_search"><img src="<?php echo $this->project_path;?>images/i_search.png" alt="button" onclick="search();"/></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php include_once  $this->project_path."include/footer.php"; ?>
    </div>

    <script>
        $(document).ready(function(){
            $('.date').datepicker({
            })

            $(".question").click(function(){
                $(".answer").toggle(300);
            })
        })//
        $(function() {
            $( "input" ).checkboxradio();
        });
    </script>
</body>
</html>