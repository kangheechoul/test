<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <meta name="format-detection" content="telephone=no">

	<title>경남해운</title>

    <!-- FONT -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Exo:ital,wght@0,300;0,500;0,700;0,900;1,900&family=Noto+Sans+JP:wght@300;400;500;700&display=swap" rel="stylesheet">

	<!-- CSS -->
    <?php include_once $this->project_path."include/common_css.php"; ?>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/sub_page.css"/>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/join.css"/>

    <!-- JS -->
    <?php include_once $this->project_path."include/common_js.php"; ?>
</head>
<body>
    <div class="Wrap">        
        <?php include_once  $this->project_path."include/header.php"; ?>
        <div class="Container" id="content">
            <div class="bd-xxxs join-check-section1 section">
                <div class="row">
                    <div class="col-md-12">
                        <div class="title">
                            <h4>회원가입</h4>
                            <p class="text-center">원하시는 회원가입 방식을 선택하여 주세요</p>
                        </div>
                        <div class="join-wrap">
                            <a href=".?param=join_write">일반 회원가입</a>
                        </div>
                        <div class="sns-join-wrap naver">
                            <a href="javascript:;">
                                <dl class="cf">
                                    <dt><img src="<?php echo $this->project_path;?>images/icon-naver-type2.png" alt=""></dt>
                                    <dd>네이버로 회원가입</dd>
                                </dl>
                            </a>
                        </div>
                        <div class="sns-join-wrap fb">
                            <a href="javascript:;">
                                <dl class="cf">
                                    <dt><img src="<?php echo $this->project_path;?>images/icon-fb-type2.png" alt=""></dt>
                                    <dd>페이스북 회원가입</dd>
                                </dl>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php include_once  $this->project_path."include/footer.php"; ?>
    </div>
</body>
</html>