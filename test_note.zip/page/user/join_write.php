<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <meta name="format-detection" content="telephone=no">

	<title>경남해운</title>

    <!-- FONT -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Exo:ital,wght@0,300;0,500;0,700;0,900;1,900&family=Noto+Sans+JP:wght@300;400;500;700&display=swap" rel="stylesheet">

	<!-- CSS -->
    <?php include_once $this->project_path."include/common_css.php"; ?>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/sub_page.css"/>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/join.css"/>

    <!-- JS -->
    <?php include_once $this->project_path."include/common_js.php"; ?>
</head>
<body>
    <div class="Wrap">        
        <?php include_once  $this->project_path."include/header.php"; ?>
        <div class="Container" id="content">
            <div class="bd-xxs join-write-section1 section">
                <div class="row">
                    <form action="" class="cf">
                        <div class="col-md-12 write-wrap">
                            <div class="title">
                                <h4>회원가입</h4>
                            </div>
                            <p class="pointP text-right"><em class="point">*</em>은 필수입력입니다.</p>
                            <div class="write-box">
                                <div class="write-row">
                                    <div class="input-title">아이디 <em class="point">*</em></div>
                                    <div class="write-input">
                                        <input type="text">
                                        <span>(영문소문자/숫자, 4~16자)</span>
                                    </div>
                                </div>
                                <div class="write-row">
                                    <div class="input-title">비밀번호 <em class="point">*</em></div>
                                    <div class="write-input">
                                        <input type="text">
                                        <span>(영문 대소문자/숫자/특수문자 중 2가지 이상 조합, 8~16자)</span>
                                    </div>
                                </div>
                                <div class="write-row">
                                    <div class="input-title">비밀번호 확인 <em class="point">*</em></div>
                                    <div class="write-input">
                                        <input type="text">
                                        <span></span>
                                    </div>
                                </div>
                                <div class="write-row">
                                    <div class="input-title">이름 <em class="point">*</em></div>
                                    <div class="write-input">
                                        <input type="text">
                                    </div>
                                </div>
                                <div class="write-row">
                                    <div class="input-title">연락처</div>
                                    <div class="write-input phone">
                                        <input type="text">
                                        <a href="javascript:;" class="btn">인증요청</a>
                                        <div class="ctc-number">
                                            <input type="text">
                                        </div>
                                    </div>
                                    
                                </div>
                                <div class="write-row">
                                    <div class="input-title">이메일</div>
                                    <div class="write-input">
                                        <input type="email">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-12 agree-wrap">
                            <ul class="agree-box">
                                <li>
                                    <label for="">
                                        <input type="checkbox">
                                        <b>전체 동의</b>
                                    </label>
                                    <ul class="agree-inner-box">
                                        <li><b>필수항목</b></li>
                                        <li>
                                            <label for="">
                                                <input type="checkbox">
                                                <span>서비스 이용약관</span>
                                            </label>
                                            <a href="javascript:;">내용보기</a>
                                        </li>
                                        <li>
                                            <label for="">
                                                <input type="checkbox">
                                                <span>서비스 이용약관</span>
                                            </label>
                                            <a href="javascript:;">내용보기</a>
                                        </li>
                                        <li>
                                            <label for="">
                                                <input type="checkbox">
                                                <span>본인은 <b>만 14세 </b>이상힙니다.</span>
                                            </label>
                                        </li>
                                        <li><b>선택 항목</b></li>
                                        <li>
                                            <label for="">
                                                <input type="checkbox">
                                                <span>개인정보 이용 및 수집(선택)</span>
                                            </label>
                                            <a href="javascript:;">내용보기</a>
                                        </li>
                                        <li>
                                            <label for="">
                                                <input type="checkbox">
                                                <span>개인정보 평생 보관동의(탈퇴시 삭제)</span>
                                            </label>
                                            <a href="javascript:;">내용보기</a>
                                        </li>
                                        <li>
                                            <label for="">
                                                <input type="checkbox">
                                                <span>쇼핑 혜택 SMS 및 이메일 수신</span>
                                            </label>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </form>
                    <div class="btn-wrap text-center">
                        <a href="javascript:;" class="btn-harf">가입하기</a>
                    </div>
                </div>
            </div>
        </div>
        <?php include_once  $this->project_path."include/footer.php"; ?>
    </div>
</body>
</html>