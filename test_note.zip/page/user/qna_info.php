<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <meta name="format-detection" content="telephone=no">

	<title>경남해운</title>

    <!-- FONT -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Exo:ital,wght@0,300;0,500;0,700;0,900;1,900&family=Noto+Sans+JP:wght@300;400;500;700&display=swap" rel="stylesheet">

	<!-- CSS -->
    <?php include_once $this->project_path."include/common_css.php"; ?>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/sub_page.css"/>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/side_tab.css"/>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/notice_board.css"/>

    <!-- JS -->
    <?php include_once $this->project_path."include/common_js.php"; ?>
</head>
<body>
    <div class="Wrap">        
        <?php include_once  $this->project_path."include/header.php"; ?>
        <div class="Container" id="content">
            

            <div class="bd-md section">
                <div class="row">
                <?php include_once  $this->project_path."include/cs_side.php"; ?>
                <div class="col-md-10 col-xs-12">
                        <div class="board_view">
                            <div class="title">
                                <h5 id="title">질문에 대한 제목</h5>
                                <p><span class="material-icons">schedule</span><label id="regdate">21-04-29</label> <span class="material-icons">person</span><label id="name">유재석</label></p>
                            </div>
                            <div class="text_area" id="content"></div>
                        </div>
                        <div class="btn_wrap text-right">
                            <a href="javascript:;" id="btn_delete">삭제</a>
                            <a href="javascript:;" id="btn_modify">수정</a>
                            <a href="/?param=menu5-3">목록</a>
                        </div>
                        <!-- 답변이 없을시에는 안보임 view_comment에 클레스명 dis-none -->
                        <div class="view_comment board_view" id="answer">
                            <div class="title">
                                <h4 id="a_title">질문답변대기중</h4>
                                <p><span class="material-icons">schedule</span><label id="a_regdate">0-0-0</label> <span class="material-icons">person</span><label id="a_name">관리자</label></p>
                            </div>
                            
                            <div id="a_content">질문답변 대기중입니다.
                            </div>
                        </div>
                        <!-- 답변이 없을시에는 안보임 -->

                        <!-- 댓글 -->
                        <!-- <div class="comment_write">
                            <form action="">
                                <div class="comment_write_inner">
                                    <div>
                                        <p>이름</p>
                                        <input type="text">
                                    </div>
                                    <div>
                                        <p>비밀번호</p>
                                        <input type="password">
                                    </div>
                                </div>
                            </form>
                        </div> -->
                        <!-- 댓글 -->

                        
                    </div>
                </div>
            </div>
            
        </div>
        <?php include_once  $this->project_path."include/footer.php"; ?>
    </div>
</body>
</html>