<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <meta name="format-detection" content="telephone=no">

	<title>경남해운</title>

    <!-- FONT -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Exo:ital,wght@0,300;0,500;0,700;0,900;1,900&family=Noto+Sans+JP:wght@300;400;500;700&display=swap" rel="stylesheet">

	<!-- CSS -->
    <?php include_once $this->project_path."include/common_css.php"; ?>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/sub_page.css"/>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/side_tab.css"/>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/mypage.css"/>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/notice_board.css"/>
    
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/layout/css/jquery-ui.css"/>

    <!-- JS -->
    <?php include_once $this->project_path."include/common_js.php"; ?>
    <script src="<?php echo $this->project_path;?>/layout/js/jquery-ui.js"></script>
</head>
<body>
    <div class="Wrap">        
        <?php include_once  $this->project_path."include/header.php"; ?>
        <div class="Container" id="content">
            <div class="bd-md section">
                <div class="row">
                    <?php include_once  $this->project_path."include/my_side.php"; ?>
                    <div class="col-md-10 col-sm-12">
                        <!-- tab -->
                        <div class="col-md-12 my-tab-wrap">
                            <ul class="my-tab cf">
                                <li>
                                    <p>회원이름</p>
                                    <span><b>홍길동</b></span>
                                </li>
                                <li>
                                    <p>보유쿠폰</p>
                                    <span><b>0</b>개</span>
                                </li>
                                <li>
                                    <p>적립금</p>
                                    <span><b>0</b>p</span>
                                </li>
                                <li>
                                    <p>예치금</p>
                                    <span><b>0</b>원</span>
                                </li>
                            </ul>
                        </div>
                        <!-- /tab -->
                        
                        <div class="col-md-12">
                            <a href="javascript:;" class="btn">선택삭제</a>
                            <a href=".?param=my_address_create" class="btn fl-right">배송지 추가</a>
                        </div>
                        <div class="col-md-12">
                            <table class="table board_type1">
                                <colgroup>
                                    <col width="8%">
                                    <col width="12%">
                                    <col width="auto">
                                    <col width="18%">
                                    <col width="15%">
                                </colgroup>
                                <thead>
                                    <tr>
                                        <th>
                                            <input type="checkbox">
                                        </th>
                                        <th>이름</th>
                                        <th class="title">주소</th>
                                        <th>연락처</th>
                                        <th>수정</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr class="no-list">
                                        <td class="no-data" colspan="5">등록되어있는 배송지 정보가 없습니다.</td>
                                    </tr>

                                    <tr>
                                        <td><input type="checkbox"></td>
                                        <td>배*현</td>
                                        <td class="title">
                                            <span>서울특별시 OO0길 00 (00동, 0000아파트)</span>
                                            <span>상세주소~~</span>
                                        </td>
                                        <td>010-0000-0000</td>
                                        <td><a href=".?param=my_address_edit" class="btn">수정</a></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                        
                </div>
            </div>
        </div>
        <?php include_once  $this->project_path."include/footer.php"; ?>

    </div>

    <script>
        $(document).ready(function(){
            $('.date').datepicker({
            })
        })//
        $(function() {
            $( "input" ).checkboxradio();
        });
    </script>
</body>
</html>