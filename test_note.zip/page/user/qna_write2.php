<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <meta name="format-detection" content="telephone=no">

	<title>경남해운</title>

    <!-- FONT -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Exo:ital,wght@0,300;0,500;0,700;0,900;1,900&family=Noto+Sans+JP:wght@300;400;500;700&display=swap" rel="stylesheet">

	<!-- CSS -->
    <?php include_once $this->project_path."include/common_css.php"; ?>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/sub_page.css"/>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/side_tab.css"/>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/write2.css"/>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/notice_board.css"/>

    <!-- JS -->
    <?php include_once $this->project_path."include/common_js.php"; ?>
    <script type="text/javascript" src="<?php echo $this->project_path;?>js/qna.js<?php echo $version;?>"></script>

</head>
<body>
    <div class="Wrap">        
        <?php include_once  $this->project_path."include/header.php"; ?>
        <div class="Container" id="content">

            <div class="bd-md section">
                <div class="row">
                    <?php include_once  $this->project_path."include/cs_side.php"; ?>
                    <div class="col-md-10 col-xs-12 contact_form">
                        <form class="form" id="form" onsubmit='return false;'>
                            <div class="write-wrap2">
                                <div class="write-box">
                                    <div class="write-row">
                                        <div class="input-title">아이디</div>
                                        <div class="write-input"><input type="text" value="dddd@naver.com" readonly></div>
                                    </div>
                                    <div class="write-row">
                                        <div class="input-title">이메일</div>
                                        <div class="write-input"><input type="email"></div>
                                    </div>
                                    <div class="write-row">
                                        <div class="input-title">문의 내용</div>
                                        <div class="write-input"><input type="text" placeholder="제목을 입력해 주세요"></div>
                                    </div>
                                    <div class="write-row">
                                        <div class="input-title">&nbsp;</div>
                                        <div class="write-textarea"><textarea name="" id="" ></textarea></div>
                                    </div>
                                    <div class="write-row">
                                        <div class="input-title">첨부파일</div>
                                        <div class="write-file">
                                            <input type="text" class="file_ipt" id="file_name" readonly="">
                                            <span class="btnarea">
                                                <button type="button" id="btn_cancel" style="display:none;">Cancel</button>
                                                <input type="file" id="file_add" name="iq_file[]">
                                                <label for="file_add" class="text-primary">업로드</label>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                        <div class="btn-wrap text-center">
                        <a href="javasceipr:;" class="btn">작성취소</a>
                            <a href="javasceipr:;" class="btn">작성완료</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php include_once  $this->project_path."include/footer.php"; ?>
    </div>
</body>
</html>