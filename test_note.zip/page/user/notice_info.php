<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <meta name="format-detection" content="telephone=no">

	<title>경남해운</title>

    <!-- FONT -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Exo:ital,wght@0,300;0,500;0,700;0,900;1,900&family=Noto+Sans+JP:wght@300;400;500;700&display=swap" rel="stylesheet">

	<!-- CSS -->
    <?php include_once $this->project_path."include/common_css.php"; ?>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/sub_page.css"/>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/side_tab.css"/>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/notice_board.css"/>

    <!-- JS -->
    <?php include_once $this->project_path."include/common_js.php"; ?>
</head>
<body>
    <div class="Wrap">        
        <?php include_once  $this->project_path."include/header.php"; ?>
        <div class="Container" id="content">
            <div class="bd-md section">
                <div class="row">
                    <?php include_once  $this->project_path."include/cs_side.php"; ?>
                    <div class="col-md-10 col-xs-12">
                        <div class="board_view">
                            <div class="title">
                                <h5>공지사항 제목</h5>
                                <p><span class="material-icons">schedule</span>21-04-29 <span class="material-icons">visibility</span>200 <span></span></p>
                            </div>
                            <div class="text_area">
                                <p>내용이 들어가는 부분~~~</p>
                                <p>내용이 들어가는 부분~~~</p>
                                <p>내용이 들어가는 부분~~~</p>
                                <p>내용이 들어가는 부분~~~</p>
                                <p>내용이 들어가는 부분~~~</p>
                            </div>
                            <div class="btn_wrap text-center">
                                <a href=".?param=notice_view">목록</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            
        </div>
        <?php include_once  $this->project_path."include/footer.php"; ?>
    </div>
</body>
</html>