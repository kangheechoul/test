<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <meta name="format-detection" content="telephone=no">

	<title>경남해운</title>

    <!-- FONT -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Exo:ital,wght@0,300;0,500;0,700;0,900;1,900&family=Noto+Sans+JP:wght@300;400;500;700&display=swap" rel="stylesheet">

	<!-- CSS -->
    <?php include_once $this->project_path."include/common_css.php"; ?>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/sub_page.css"/>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/side_tab.css"/>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/mypage.css"/>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/notice_board.css"/>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/layout/css/jquery-ui.css"/>

    <!-- JS -->
    <?php include_once $this->project_path."include/common_js.php"; ?>
    <script src="<?php echo $this->project_path;?>/layout/js/jquery-ui.js"></script>
</head>
<body>
    <div class="Wrap">        
        <?php include_once  $this->project_path."include/header.php"; ?>
        <div class="Container" id="content">
            <div class="bd-md section">
                <div class="row">
                    <?php include_once  $this->project_path."include/my_side.php"; ?>
                    <div class="col-md-10 col-sm-12">
                        <!-- tab -->
                        <div class="col-md-12 my-tab-wrap">
                            <ul class="my-tab cf">
                                <li>
                                    <p>회원이름</p>
                                    <span><b>홍길동</b></span>
                                </li>
                                <li>
                                    <p>보유쿠폰</p>
                                    <span onclick="location.href='.?param=my_coupon'"><b>0</b>개</span>
                                </li>
                                <li>
                                    <p>적립금</p>
                                    <span onclick="location.href='.?param=my_point'"><b>0</b>p</span>
                                </li>
                                <li>
                                    <p>예치금</p>
                                    <span onclick="location.href='.?param=my_deposit'"><b>0</b>원</span>
                                </li>
                            </ul>
                        </div>
                        

                        <div class="col-md-12 period-wrap">
                            <div class="col-md-12 period-box">
                                <div class="col-md-7 col-sm-6 col-xs-12">
                                    <span class="tl" id="tl">조회기간</span>
                                    <div id="radioset">
                                        <input type="radio" id="radio1" name="radio" checked><label for="radio1">1주일</label>
                                        <input type="radio" id="radio2" name="radio"><label for="radio2">1개월</label>
                                        <input type="radio" id="radio3" name="radio"><label for="radio3">3개월</label>
                                        <input type="radio" id="radio4" name="radio"><label for="radio4">6개월</label>
                                    </div>
                                </div>
                                <div class="col-md-5 col-sm-6 col-xs-12">
                                    <span class="date-input">
                                        <input type="text" class="date">
                                    </span>
                                    <span class="tx">~</span>
                                    <span class="date-input">
                                        <input type="text" class="date">
                                    </span>
                                    <button class="btn">조회</button>
                                </div>
                            </div>

                            <div class="col-md-12 coupon-wrap">
                                <table class="table board_type1">
                                    <colgroup>
                                        <col width="39%">
                                        <col width="26%">
                                        <col width="20%">
                                        <col width="15%">
                                    </colgroup>
                                    <thead>
                                        <tr>
                                            <th>쿠폰명</th>
                                            <th>사용조건</th>
                                            <th>사용기한</th>
                                            <th>사용여부</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr class="no-list">
                                            <td class="no-data" colspan="5">
                                                찾으시는 기간 내에 해댕하는 쿠폰이 없습니다.
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="text-left">
                                                <span>[신규회원] 무료 배송 쿠폰</span>
                                            </td>
                                            <td>10,000원 이상 결제시 사용</td>
                                            <td class="date">
                                                <span>2021.06.14</span>
                                                <span>~</span>
                                                <span>2021.06.17</span>
                                            </td>
                                            <td><span class="point use">기간만료</span></td>
                                        </tr>
                                        <tr>
                                            <td class="text-left">
                                                <span>[신규회원] 무료 배송 쿠폰</span>
                                            </td>
                                            <td>10,000원 이상 결제시 사용</td>
                                            <td class="date">
                                                <span>2021.06.14</span>
                                                <span>~</span>
                                                <span>2021.06.17</span>
                                            </td>
                                            <td><span class="point useing">사용가능</span></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php include_once  $this->project_path."include/footer.php"; ?>
    </div>

    <script>
        $(document).ready(function(){
            $('.date').datepicker({})
        })//
        $(function() {
            $( "input" ).checkboxradio();
        });
    </script>
</body>
</html>