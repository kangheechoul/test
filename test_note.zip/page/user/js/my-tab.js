$(document).ready(function(){
    const ww = window.outerWidth;
    $(window).resize(function(){
        if(ww <= 1024){
            $('.link-tabs li').addClass("col-sm-6");
        }else{
            $('.link-tabs li').removeClass("col-sm-6");
        }
    })
})//