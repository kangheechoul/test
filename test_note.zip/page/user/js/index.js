$(document).ready(function() {
    init_slider();
});

function init_slider(){
    $('.slideMain').bxSlider({
        mode: 'fade',
        pager:false,
        controls: true,
        nextText: '',
        prevText: '',
        nextSelector: '#main_next',
        prevSelector: '#main_prev',
        touchEnabled : false,
    });

    // $('.slideTwo').bxSlider({
    //     auto: false,
    //     pager: true,
    //     infiniteLoop: false,
    //     controls: true,
    //     shrinkItems: true,
    //     minSlides: 3,
    //     maxSlides: 3,
    //     slideWidth: 640,
    //     slideMargin: 40,
    //     nextText: '',
    //     prevText: '',
    //     nextSelector: '#bx_next',
    //     prevSelector: '#bx_prev',
    // });
}
