/* const mobileMenuOpen = document.querySelector('#mobile_burger');
    const mobileMenuClose = document.querySelector('#mobile_close');
    const mobileHeader = document.querySelector('#mobile_header');
    const CLILKED_CLASS = "on";


    function handleOpenMenu(){
        mobileHeader.classList.add(CLILKED_CLASS)
    };

    function handleCloseMenu(){
        mobileHeader.classList.remove(CLILKED_CLASS)
    }

    function init(){
        mobileMenuOpen.addEventListener("click", handleOpenMenu);
        mobileMenuClose.addEventListener("click", handleCloseMenu);
    }
    init(); */