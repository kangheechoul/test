function move_page(page_name){
    location.href="?ctl=move&param=adm&param1=" + page_name;
}

function check_admin_login(){

    
}

function logout(){
    lb.ajax({
        type:"JsonAjaxPost",
        list : {
            ctl:"AdminUser",
            param1:"logout",
        },
        action : lb.obj.address,
        havior : function(result){
            result = JSON.parse(result);
            logout_result(result);
        }    
    });
}

function logout_result(result){
    if(result.result == "1"){
        move_page("login");
    }
}

function elem_select(elem, value){
    $(elem).val(value); // Change the value or make some change to the internal state
    $(elem).trigger('change.select2'); // Notify only Select2 of changes
}

function show_popup(link) { 
    var window_width = window.screen.width; //화면 사이즈 가로
    var window_height = window.screen.height; //화면 사이즈 세로
    console.log(window_width + ":" + window_height);
    var popupWidth= 1600; //팝업창 가로크기
    var popupHeight=900;  //팝업창 세로크기
    var popupX = (window_width / 2) - (popupWidth / 2);
    var popupY= (window_height / 2) - (popupHeight / 2);

    window.open(link, 'a', 'status=no, height=' + popupHeight  + ', width=' + popupWidth  + ', left='+ popupX + ', top='+ popupY);
}

// 언디파인드, 널 체크
function null_exception(data){
    if(typeof data != "undefined" && typeof data != undefined && data != "null" && data != null){
        return 1;
    }else{
        return 0;
    }
}

//가격 3자리 마다 , 찍어주기 ( 10000 -> 10,000 )
function number_comma(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}
//콤마제거하기
function removeComma(str){
    n = parseInt(str.replace(/,/g,""));
    return n;
}




// 쇼핑몰 페이지로 이동
function go_mall(){
    window.open("?param=index", "_blank" );
}