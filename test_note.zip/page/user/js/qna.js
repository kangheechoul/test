$(document).ready(function() {
    
    document.getElementById("file_add").addEventListener("change",  file_name_view, false);
    document.getElementById("btn_cancel").addEventListener("click",  file_cancel, false);
});

function file_name_view(ev) { // 파일첨부하면 파일명 보이게
    var target_id = ev.target.id;
    var val = document.getElementById(target_id).value;
    var temp = val.split("\\"); // fakepath 없애고 파일명만 보이게
    document.getElementById("file_name").value = temp[temp.length-1];
    document.getElementById("btn_cancel").style = "display:inline";
}

function file_cancel(){
    document.getElementById("file_name").value = "";
    document.getElementById("file_add").value = "";
    document.getElementById("btn_cancel").style = "display:none";
}