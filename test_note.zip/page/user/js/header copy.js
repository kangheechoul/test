var current_mob_list = null;

$(document).ready(function(){
    //header mouseover시 배경색 흰색
    $('header').mouseover(function(){
    $(this).css({backgroundColor:"white"});
    });

    $('header').mouseout(function(){
        $(this).css({backgroundColor:"transparent"});
        });
    // //header mouseout시 배경색 투명색

    //menu mouseover시 sub_dep 나타나기
    $('.gnb>li').mouseover(function(){
    $(this).addClass('on');
    });

    //menu mouseout시 sub_dep 사라지기
    $('.gnb>li').mouseout(function(){
        $(this).removeClass('on');
        });

    //버거 메뉴 클릭시 전체 메뉴 open
    var flag = 0;
    var menu_btn = document.getElementById('mobile_burger'); //메뉴 Open 버튼
    menu_btn.onclick = function(){ //메뉴 클릭시 발생
        var menu_wrap = document.querySelector('#main_category_wrap');
        var li = menu_wrap.querySelectorAll('[data-hover]'); //메뉴 밑에 있는 각 카테고리의 li 태그들

        //flag가 0이면 모든 li 밑에 있는 ul 태그들 block , 1이면 none
        for(var i = 0; i < li.length; i++){
            if(flag == 0){
                li[i].querySelector('ul').style.display = "block";
                $(li[i]).off();
            }else{
                li[i].querySelector('ul').style.display = "none";

                //li에 mouse event 연결
                $(li[i]).mouseover(function(){
                    $(this).find('ul').css('display', 'block');
                });

                $(li[i]).mouseout(function(){
                    $(this).find('ul').css('display', 'none');
                });
            }
            
        }

        //flag가 0이면 background 영역 block으로 변경하고 color white로 변경
        if(flag == 0){
            document.querySelector('#header_bg').style.display = "block";
            document.querySelector('#header_bg').style.backgroundColor = "white";
            flag = 1;
            //header mouseout시 배경색 투명색
            $('header').off();
        }else{
            document.querySelector('#header_bg').style.display = "none";
            document.querySelector('#header_bg').style.backgroundColor = "white";
            flag = 0;
            //header mouseover시 배경색 흰색
            $('header').mouseover(function(){
                $(this).css('backgroundColor', 'white');
            });

            //header mouseout시 배경색 투명색
            $('header').mouseout(function(){
                $(this).css('backgroundColor', 'rgba(255,255,255,.5)');
            });
        }
    }

    //header menu list hover event
    var hover_li = document.querySelectorAll('[data-hover]');
    for(var i = 0; i < hover_li.length; i++){
        $(hover_li[i]).mouseover(function(){
            $(this).find('ul').css('display', 'block');
        });

        $(hover_li[i]).mouseout(function(){
            $(this).find('ul').css('display', 'none');
        });
    }
    var lang_array = ["", "KOR", "ENG", "JPN", "CHN", "IDN", "VNM"];
    var lang_img = ["", "kor", "eng", "jpn", "chn", "idn", "vnm"];
    //lang list에 현재 선택중인 언어를 제외한 나머지 언어 생성
    // var lang_list = document.querySelector('#lang_list');
    // lang_list.innerHTML = "";
    // for(var i = 1; i <= 6; i++){
    //     if(i != obj.language){ //현재 선택된 언어가 아닌 경우만 list 생성
    //         var li = document.createElement('li');
    //         li.innerHTML = '<img src="<?php echo $this->project_path;?>images/flag/'+ lang_img[i] +'.jpg" alt="eng"/>' + lang_array[i];
    //         li.setAttribute('onclick', 'lang_change(' + i + ')');
    //         lang_list.appendChild(li);
    //     }
    // }

    obj.elem.mobile_burger.onclick = function(){
        obj.elem.mobile_header.style.display = "block";
    }

    obj.elem.close_mobile_burger.onclick = function(){
        obj.elem.mobile_header.style.display = "none";
    }

    $(window).resize(function(){
        var width = $(window).width();
        if(width > 1024){ //pc
            obj.elem.mobile_header.style.display = "none";
        }
    });

    var mob_list = obj.elem.mob_category_list_wrap.querySelectorAll('li');
    for(var i = 0; i < mob_list.length; i++){
        function closer(index){
            mob_list[index].onclick = function(){
                for(var j = 0; j < mob_list.length; j++){
                    mob_list[j].classList.remove('open');
                    if(mob_list[j].querySelector('div') != null){
                        mob_list[j].querySelector('div').classList.add('dis-none');
                    }
                }

                if(current_mob_list != index){
                    mob_list[index].classList.add('open');
                    mob_list[index].querySelector('div').classList.remove('dis-none');
                    current_mob_list = index;
                }else{
                    current_mob_list = null;
                }
            }
        }
        closer(i);
    }

    // mobile_gnb>li 클릭시 mobie_sub_dep toggle
    $('.mobile_sub_dep').each(function(index){
        $(this).attr('data-index',index);
    });


    $('.depth1').each(function(index){
        $(this).attr('data-index',index);
    }).click(function(){
        var i = $(this).attr('data-index');
        /* $('.mobile_sub_dep').toggle(); */
        $('.mobile_sub_dep[data-index!='+i+']').slideUp();
        $('.mobile_sub_dep[data-index='+i+']').slideDown();
    });

});
