<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <meta name="format-detection" content="telephone=no">

	<title>바다소프트</title>

    <!-- FONT -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Exo:ital,wght@0,300;0,500;0,700;0,900;1,900&family=Noto+Sans+JP:wght@300;400;500;700&display=swap" rel="stylesheet">

	<!-- CSS -->
    <?php include_once $this->project_path."include/common_css.php"; ?>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/sub_page.css"/>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/shoping.css<?php echo $this->version;?>"/>

    <!-- JS -->
    <?php include_once $this->project_path."include/common_js.php"; ?>
    
</head>
<body>
    <div class="Wrap">        
        <?php include_once  $this->project_path."include/header.php"; ?>
        <div class="Container" id="content">

            <div class="bd-md section product-wrap">
                <div class="row">
                    <div class="col-md-12">
                        <div class="col-md-5 col-sm-12 img-info">
                            <div>
                                <figure>
                                    <img src="<?php echo $this->project_path;?>images/no_image.gif" alt="">
                                </figure>
                                <ul>
                                    <li><a href="javascript:;"><img src="<?php echo $this->project_path;?>images/no_image.gif" alt=""></a></li>
                                    <li><a href="javascript:;"><img src="<?php echo $this->project_path;?>images/no_image.gif" alt=""></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-md-7 col-sm-12 product-view">
                            <h2>소니 스마트밴드 토크 SWR30 (안드로이드 4.4.2 킷캣 버전이상 호환)</h2>
                            <table>
                                <!-- <caption class="hidden">
                                    <summary>상품정보</summary>
                                    판매가, 상품코드, 옵션 및 결제금액 안내
                                </caption> -->
                                <tr>
                                    <th>판매가</th>
                                    <td class="price">129,000원</td>
                                </tr>
                                <tr>
                                    <th>상품코드</th>
                                    <td>C004843</td>
                                </tr>
                                <tr>
                                    <th>제조사/공급사</th>
                                    <td>SONY / 자강정보통신</td>
                                </tr>
                                <tr>
                                    <th>구매수량</th>
                                    <td>
                                        <div class="length">
                                            <input type="number" min="1" value="1">
                                            <a href="#a">증가</a>
                                            <a href="#a">감소</a>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <th>사용가능쿠폰</th>
                                    <td>0개</td>
                                </tr>
                                <tr>
                                    <th>옵션선택</th>
                                    <td>
                                        <div class="inner">
                                            <select name="" id="">
                                                <option value="">선택</option>
                                                <option value="">옵션1</option>
                                                <option value="">옵션2</option>
                                            </select>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <th>배송비</th>
                                    <td>무료배송</td>
                                </tr>
                                <tr>
                                    <th>결재금액</th>
                                    <td class="total"><b>129,000</b>원</td>
                                </tr>
                            </table>

                            <div class="btns">
                                <a href=".?param=cart" class="btn1">장바구니</a>
                                <a href=".?param=order" class="btn2">구매하기</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- 상세정보페이지 -->
            <?php include_once  $this->project_path."include/shoping_info2.php"; ?>
            
        </div>
        <?php include_once  $this->project_path."include/footer.php"; ?>
    </div>
</body>
</html>