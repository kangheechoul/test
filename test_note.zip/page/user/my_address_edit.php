<!DOCTYPE html>
<html lang="ko">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <meta name="format-detection" content="telephone=no">

    <title>경남해운</title>

    <!-- FONT -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link
        href="https://fonts.googleapis.com/css2?family=Exo:ital,wght@0,300;0,500;0,700;0,900;1,900&family=Noto+Sans+JP:wght@300;400;500;700&display=swap"
        rel="stylesheet">

    <!-- CSS -->
    <?php include_once $this->project_path."include/common_css.php"; ?>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/sub_page.css"/>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/side_tab.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/mypage.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/write2.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/layout/css/jquery-ui.css" />

    <!-- JS -->
    <?php include_once $this->project_path."include/common_js.php"; ?>
    <script src="<?php echo $this->project_path;?>/layout/js/jquery-ui.js"></script>

</head>

<body>
    <div class="Wrap">
        <?php include_once  $this->project_path."include/header.php"; ?>
        <div class="Container" id="content">
            <div class="bd-md section">
                <div class="row">
                    <?php include_once  $this->project_path."include/my_side.php"; ?>
                    <div class="col-md-10 col-xs-12">
                        <!-- tab -->
                        <div class="col-md-12 my-tab-wrap">
                            <ul class="my-tab cf">
                                <li>
                                    <p>회원이름</p>
                                    <span><b>홍길동</b></span>
                                </li>
                                <li>
                                    <p>보유쿠폰</p>
                                    <span><b>0</b>개</span>
                                </li>
                                <li>
                                    <p>적립금</p>
                                    <span><b>0</b>p</span>
                                </li>
                                <li>
                                    <p>예치금</p>
                                    <span><b>0</b>원</span>
                                </li>
                            </ul>
                        </div>
                        <!-- /tab -->

                        <div class="com-md-12 cf">
                            <form action="">
                                <div class="write-wrap2">
                                    <div class="write-box">
                                        <div class="write-row">
                                            <div class="input-title">이름<em class="point">*</em></div>
                                            <div class="write-input">
                                                <input type="text">
                                            </div>
                                        </div>
                                        <div class="write-row">
                                            <div class="input-title">휴대폰</div>
                                            <div class="write-input phone">
                                                <input type="text" placeholder="">
                                                <a href="javascript:;" class="btn">본인인증</a>
                                            </div>
                                        </div>
                                        <div class="write-row">
                                            <div class="input-title">주소</div>
                                            <div class="write-input phone">
                                                <input type="text" placeholder="">
                                                <a href="javascript:;" class="btn">본인인증</a>
                                                <div class="input-address">
                                                    <input type="text">
                                                </div>
                                            </div>
                                        </div>
                                        <label for="">
                                            <input type="checkbox">
                                            <span class="dis-inline">기본 배송지로 설정</span>
                                        </label>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="btn-wrap text-center">
                            <a href="javascript:;" class="btn">수정취소</a>
                            <a href="javascript:;" class="btn">수정완료</a>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <?php include_once  $this->project_path."include/footer.php"; ?>
    </div>

    <script>
        /* const linkTab = document.querySelectorAll(".link-tabs");
        function handleClass(){
            const li = linkTab.childNodes("li");
            li.classList.add("col-sm-6");
        }

        window.addEventListener("resize", handleClass); */

        $(document).ready(function () {
            $('.date').datepicker({})
        }) //
        $(function () {
            $("input").checkboxradio();
        });
    </script>
    <script src="<?php echo $this->project_path;?>/js/my-tab.js"></script>
</body>

</html>