<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <meta name="format-detection" content="telephone=no">

	<title>경남해운</title>

    <!-- FONT -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Exo:ital,wght@0,300;0,500;0,700;0,900;1,900&family=Noto+Sans+JP:wght@300;400;500;700&display=swap" rel="stylesheet">

	<!-- CSS -->
    <?php include_once $this->project_path."include/common_css.php"; ?>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/main.css<?php echo $this->version;?>"/>

    <!-- JS -->
    <?php include_once $this->project_path."include/common_js.php"; ?>
    <script type="text/javascript" src="<?php echo $this->project_path;?>js/index.js<?php echo $version;?>"></script>

    <!-- BX SLIDER -->
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>layout/css/jquery.bxslider.css"/>
    <script type="text/javascript" src="<?php echo $this->project_path;?>layout/js/jquery.bxslider.js"></script>
    
    <!-- SLICK SLIDER -->
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>layout/css/slick.css"/>
    <script type="text/javascript" src="<?php echo $this->project_path;?>layout/js/slick.min.js"></script>


    <!-- SWIPER -->
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>layout/css/swiper.min.css"/>
    <script type="text/javascript" src="<?php echo $this->project_path;?>layout/js/swiper.min.js"></script>
    
</head>
<body>
    <div class="Wrap">        
        <?php include_once  $this->project_path."include/header.php"; ?>
        <div class="Container">
            <!-- mainSlide -->
            <div class="mainSlide">
                <ul class="slideMain">
                    <li class="clip1 slide">
                        <div class="bd-md">
                            <div class="txt_wrap">
                                <p>욕지도까지 최단거리 직통 여객선</p>
                                <strong>경남해운</strong>
                            </div>
                        </div>
                    </li>
                    <li class="clip1 slide">
                        <div class="bd-md">
                            <div class="txt_wrap">
                                <p>욕지도까지 최단거리 직동 여객선</p>
                                <strong>경남해운</strong>
                            </div>
                        </div>
                    </li>
                </ul>
                <div class="bd">
                    <div class="btn_wrap cf">
                        <div id='prevBtn' class='slide_btn arrowPrev'><a href="#" id="main_prev"></a></div>
                        <div id='nextBtn' class='slide_btn arrowNext'><a href="#" id="main_next"></a></div>
                    </div>
                </div>
            </div>
            <!-- /mainSlide -->
        </div>
            <?php include_once  $this->project_path."include/footer.php"; ?>
    </div>
<!-- 
        <li class="col-md-4 col-sm-12" data-copy="copy">
            <figure>
                <div class="img">
                    <img data-attr="thumnail_file_name">
                </div>
                <div class="txt">
                    <strong class="ellipsis" data-attr="title">홈페이지 시안1</strong>
                    <p class="ellipsis2" data-attr="sub_title">서브텍스트가 필요합니다.</p>
                </div>
            </figure>
        </li>
    </ul>
-->
</body>
</html>