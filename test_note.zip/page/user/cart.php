<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <meta name="format-detection" content="telephone=no">

	<title>경남해운</title>

    <!-- FONT -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Exo:ital,wght@0,300;0,500;0,700;0,900;1,900&family=Noto+Sans+JP:wght@300;400;500;700&display=swap" rel="stylesheet">

	<!-- CSS -->
    <?php include_once $this->project_path."include/common_css.php"; ?>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/sub_page.css"/>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/payment.css"/>

    <!-- JS -->
    <?php include_once $this->project_path."include/common_js.php"; ?>
</head>
<body>
    <div class="Wrap">        
        <?php include_once  $this->project_path."include/header.php"; ?>
        <div class="Container" id="content">
            <div class="bd-md section">
                <div class="row">
                    <div class="col-md-12">
                        <ul class="pay-list-wrap">
                            <li class="list-con list-con-head">
                                <dl>
                                    <dd class="xs-etc chk">
                                        <label for="">
                                            <input type="hidden">
                                            <input type="checkbox">
                                            <span class="checkmark"></span>
                                        </label>
                                    </dd><!-- 선택 -->
                                    <dd class="sm-etc imgbox">이미지</dd><!-- 이미지 -->
                                    <dd class="tit">상품정보</dd><!-- 상품정보 -->
                                    <dd class="sm-etc">판매가</dd><!-- 판매가격 -->
                                    <dd class="sm-etc">수량</dd><!-- 수량 -->
                                    <dd class="sm-etc">적립금</dd><!-- 적립금 -->
                                    <dd class="sm-etc">배송구분</dd><!-- 배송구분 -->
                                    <dd class="sm-etc">배송비</dd><!-- 배송비 -->
                                    <dd class="sm-etc">합계</dd><!-- 합계 -->
                                    <dd class="sm-etc">선택</dd><!-- 선택 -->
                                </dl>
                            </li>
                            <li class="list-con list-con-body">
                                <dl>
                                    <dd class="xs-etc chk">
                                        <label for="">
                                            <input type="hidden">
                                            <input type="checkbox">
                                            <span class="checkmark"></span>
                                        </label>
                                    </dd><!-- 선택 -->
                                    <dd class="sm-etc imgbox">
                                        <div class="img-box">
                                            <img src="<?php echo $this->project_path;?>images/no_image.gif" alt="">
                                        </div>
                                    </dd><!-- 이미지 -->
                                    <dd class="tit">
                                        <p>상품이름</p>
                                        <span>[상품옵션 : 옵션옵션옵션]</span>
                                        <a href="javascript:;" class="btn">옵션변경</a>
                                    </dd><!-- 상품정보 -->
                                    <dd class="sm-etc">9,900원</dd><!-- 판매가격 -->
                                    <dd class="sm-etc count">
                                        <div class="length">
                                            <input type="number" min="1" value="1">
                                            <a href="#a">증가</a>
                                            <a href="#a">감소</a>
                                        </div>
                                        <a href="javascript:;" class="btn count-change">변경</a>
                                    </dd><!-- 수량 -->
                                    <dd class="sm-etc">-</dd><!-- 적립금 -->
                                    <dd class="sm-etc">기본배송</dd><!-- 배송구분 -->
                                    <dd class="sm-etc">무료</dd><!-- 배송비 -->
                                    <dd class="sm-etc">9,900원</dd><!-- 합계 -->
                                    <dd class="sm-etc">
                                        <a href="javascript:;" class="btn">관심상품등록</a>
                                        <a href="javascript:;" class="btn">삭제</a>
                                    </dd><!-- 선택 -->
                                </dl>
                            </li>
                            <li class="list-con list-con-body-none">
                                장바구니가 비어있습니다.
                            </li>
                            <li class="list-con list-con-footer">
                                <p>상품구매액 : <span>9,900원</span> + 배송비 <span>0(무료)</span> = 합계 <b class="total">9,900</b>원</p>
                            </li>
                        </ul>
                        <!-- moblie pay-list -->
                        <ul class="m-pay-list-wrap">
                            <li class="m-list-con-body">
                                <dl>
                                    <dd class="chk">
                                        <label for="">
                                            <input type="hidden">
                                            <input type="checkbox">
                                            <span class="checkmark"></span>
                                        </label>
                                    </dd>
                                    <dd>
                                        <div class="list-con-info">
                                            <p class="item-name">상품이름영역</p>
                                            <span>배송 : [무료] / 기본배송</span>
                                            <span class=item-option>[상품옵션: 옵션내용~~]</span>
                                            <p class="price">9,900원</p>
                                            <div class="m-length">
                                                <div>
                                                    <a href="javasceipr:;">-</a>
                                                    <input type="number" value="1">
                                                    <a href="javascript:;">+</a>
                                                </div>
                                                <a href="javascript:;" class="btn">변경</a>
                                            </div>
                                        </div>
                                        <div class="img-box">
                                            <img src="<?php echo $this->project_path;?>images/no_image.gif" alt="">
                                        </div>
                                    </dd>
                                    <dd>
                                        <p class="total">합계 : <b>9,900</b>원</p>
                                    </dd>
                                    <dd>
                                        <a href="javascript:;" class="btn">관심상품등록</a>
                                        <a href="javascript:;" class="btn delete">삭제</a>
                                    </dd>
                                </dl>
                            </li>
                            <li class="m-list-con-body-none">
                                장바구니가 비었습니다.
                            </li>
                            <li class="m-list-con-footer">
                                <p>상품구매액 : <span>9,900원</span> + 배송비 <span>0(무료)</span> = 합계 <b class="total">9,900</b>원</p>
                            </li>
                        </ul>
                    </div>
                    <div class="col-md-12 btn-small-wrap">
                        <a href="javascript:;" class="btn chk-delete">선택삭제</a>
                        <a href="javascript:;" class="btn chk-delete-all">전체삭제</a>
                    </div>
                    <div class="col-md-12 btn-wrap text-center">
                        <a href=".?param=order" class="btn">전체상품주문</a>
                        <a href="javascript:;" class="btn">선택상품주문</a>
                    </div>
                </div>
            </div>
            
        </div>
        <?php include_once  $this->project_path."include/footer.php"; ?>
    </div>
</body>
</html>