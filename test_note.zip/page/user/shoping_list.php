<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <meta name="format-detection" content="telephone=no">

	<title>바다소프트</title>

    <!-- FONT -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Exo:ital,wght@0,300;0,500;0,700;0,900;1,900&family=Noto+Sans+JP:wght@300;400;500;700&display=swap" rel="stylesheet">

	<!-- CSS -->
    <?php include_once $this->project_path."include/common_css.php"; ?>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/sub_page.css"/>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/shoping.css<?php echo $this->version;?>"/>

    <!-- JS -->
    <?php include_once $this->project_path."include/common_js.php"; ?>
</head>
<body>
    <div class="Wrap">        
        <?php include_once  $this->project_path."include/header.php"; ?>
        <div class="Container" id="content">
            <div class="bd-md section category-tab-wrap">
                <div class="row">

                    <div class="col-md-12">
                        <ul class="cf category-tab">
                            <li><a href="javascript:;" class="active">배추김치</a></li>
                            <li><a href="javascript:;">기타김치</a></li>
                            <li><a href="javascript:;">절임류</a></li>
                            <li><a href="javascript:;">밑반찬 및 장아찌</a></li>
                            <li><a href="javascript:;">선물SET</a></li>
                            <li><a href="javascript:;">MD추천상품</a></li>
                            <li><a href="javascript:;">BEST 상품</a></li>
                            <li><a href="javascript:;">반짝세일</a></li>
                            <li><a href="javascript:;">개인결제</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="bd-md items-type3">
                <div class="row">
                    <div class="col-md-12">
                        <ul class="order-by-list">
                            <li><a href="javascript:;" class="active">신상품순</a></li>
                            <li><a href="javascript:;">상품명</a></li>
                            <li><a href="javascript:;">인기순</a></li>
                            <li><a href="javascript:;">낮은가격</a></li>
                            <li><a href="javascript:;">높은가격</a></li>
                        </ul>
                    </div>
                    <div class="col-md-4 col-xs-12">
                        <a href=".?param=shoping_info">
                            <div class="img-box">
                                <img src="<?php echo $this->project_path;?>images/no_image.gif" alt="">
                            </div>
                            <div class="text-box">
                                <p>아이템 이름</p>
                                <h5 class="price">21,900원</h5>
                                <span class="info">아이템에 대한 설명</span>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-4 col-xs-12">
                        <a href="javascript:;">
                            <div class="img-box">
                                <img src="<?php echo $this->project_path;?>images/no_image.gif" alt="">
                            </div>
                            <div class="text-box">
                                <p>아이템 이름</p>
                                <h5 class="price">21,900원</h5>
                                <span class="info">아이템에 대한 설명</span>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-4 col-xs-12">
                        <a href="javascript:;">
                            <div class="img-box">
                                <img src="<?php echo $this->project_path;?>images/no_image.gif" alt="">
                            </div>
                            <div class="text-box">
                                <p>아이템 이름</p>
                                <h5 class="price">21,900원</h5>
                                <span class="info">아이템에 대한 설명</span>
                            </div>
                        </a>
                    </div>
                    
                </div>

                <!-- pagination -->
                <div class="pagination_container mt-3" id = "paging">
                    <div class="page_item arrow prev">«</div>
                    <div class="page_item active">1</div>
                    <div class="page_item ">2</div>
                    <div class="page_item arrow next">»</div>
                </div>
                <!-- /pagination -->
            </div>

            <div class="bd-md section items-type4">
                <div class="row">
                    <div class="col-md-12">
                        <ul class="order-by-list">
                            <li><a href="javascript:;" class="active">신상품순</a></li>
                            <li><a href="javascript:;">상품명</a></li>
                            <li><a href="javascript:;">인기순</a></li>
                            <li><a href="javascript:;">낮은가격</a></li>
                            <li><a href="javascript:;">높은가격</a></li>
                        </ul>
                    </div>
                    <div class="col-md-3 col-sm-4 col-xs-6">
                        <a href=".?param=shoping_info">
                            <div class="img-box">
                                <img src="<?php echo $this->project_path;?>images/no_image.gif" alt="">
                            </div>
                            <div class="text-box">
                                <p>아이템 이름</p>
                                <h5 class="price">21,900원</h5>
                                <span class="info">아이템에 대한 설명</span>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-3 col-sm-4 col-xs-6">
                        <a href="javascript:;">
                            <div class="img-box">
                                <img src="<?php echo $this->project_path;?>images/no_image.gif" alt="">
                            </div>
                            <div class="text-box">
                                <p>아이템 이름</p>
                                <h5 class="price">21,900원</h5>
                                <span class="info">아이템에 대한 설명</span>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-3 col-sm-4 col-xs-6">
                        <a href="javascript:;">
                            <div class="img-box">
                                <img src="<?php echo $this->project_path;?>images/no_image.gif" alt="">
                            </div>
                            <div class="text-box">
                                <p>아이템 이름</p>
                                <h5 class="price">21,900원</h5>
                                <span class="info">아이템에 대한 설명</span>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-3 col-sm-4 col-xs-6">
                        <a href="javascript:;">
                            <div class="img-box">
                                <img src="<?php echo $this->project_path;?>images/no_image.gif" alt="">
                            </div>
                            <div class="text-box">
                                <p>아이템 이름</p>
                                <h5 class="price">21,900원</h5>
                                <span class="info">아이템에 대한 설명</span>
                            </div>
                        </a>
                    </div>
                    
                </div>

                <!-- pagination -->
                <div class="pagination_container mt-3" id = "paging">
                    <div class="page_item arrow prev">«</div>
                    <div class="page_item active">1</div>
                    <div class="page_item ">2</div>
                    <div class="page_item arrow next">»</div>
                </div>
                <!-- /pagination -->
            </div>
        </div>
        <?php include_once  $this->project_path."include/footer.php"; ?>
    </div>

</body>
</html>