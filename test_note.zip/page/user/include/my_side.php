<div class="col-md-2 col-xs-12 link-tab">
    <ul>
        <li>
            <h4>나의 쇼핑정보</h4>
            <ul>
                <li id="myHome"><a href=".?param=my_home">주문/배송 조회</a></li>
                <li id="myReview"><a href="">상품후기 작성</a></li>
                <li id="myQna"><a href=".?param=my_1on1">1:1문의</a></li>
                <li id="myCart"><a href=".?param=cart">장바구니</a></li>
                <li id="myScrap"><a href=".?param=my_scrap">관심상품</a></li>
                <li id="myScrap"><a href=".?param=my_scrap">대량주문 문의</a></li>
            </ul>
        </li>
        <li>
            <h4>나의 계정</h4>
            <ul>
                <li id="myInfo"><a href=".?param=my_change_info">회원정보 수정</a></li>
                <li id="myAddress"><a href=".?param=my_address_list">배송지 관리</a></li>
                <li id="myCoupon"><a href=".?param=my_coupon">쿠폰</a></li>
                <li id="myPoint"><a href=".?param=my_point">적립금</a></li>
                <li id="myDeposit"><a href="">예치금</a></li>
                <li id="myCheck"><a href="">출석체크</a></li>
            </ul>
        </li>
    </ul>
</div>



<script>
    $(function(){
        const queryString = window.location.search;
        if(queryString == '?param=my_home'){
            $('#myHome').addClass('active');
        }else if(queryString == '?param='){
            $('#myReview').addClass('active');
        }else if(queryString == '?param=my_1on1'){
            $('#myQna').addClass('active');
        }else if(queryString == '?param=cart'){
            $('#myCart').addClass('active');
        }else if(queryString == '?param=my_scrap'){
            $('#myScrap').addClass('active');
        }else if(queryString == '?param=my_change_info'){
            $('#myInfo').addClass('active');
        }else if(queryString == '?param=my_address_list'){
            $('#myAddress').addClass('active');
        }else if(queryString == '?param=my_address_create'){
            $('#myAddress').addClass('active');
        }else if(queryString == '?param=my_address_edit'){
            $('#myAddress').addClass('active');
        }else if(queryString == '?param=my_coupon'){
            $('#myCoupon').addClass('active');
        }else if(queryString == '?param=my_point'){
            $('#myPoint').addClass('active');
        }else if(queryString == '?param=my_deposit'){
            $('#myDeposit').addClass('active');
        }
    });
</script>