<footer class="footer fp-auto-height">
    <a class="move_top" href="#wrap"><i class="arrow"></i></a>
    <div class="legal_wrap">
        <ul class="bd bd-lg">
            <li>
                <a href="?param=legal_terms">이용약관</a>
            </li>
            <li>
                <a href="?param=legal_privacy">개인정보처리방침</a>
            </li>
        </ul>
    </div>
    <div class="bd bd-lg">
        <div class="f-top">
            <p>
                <span>대표 <b>이영배</b></span>
                <span>상호 <b>경남해운</b></span>
                <span>사업자등록번호 <b>612-81-50388</b></span><br/>
                <span>법인등록번호 <b>191211-0024425</b></span><br/>
                <span>주소  <b>경상남도 통영시 산양읍 원항 1길 3</b></span>
                <span>E-mail  <b>bada@badasoft.co.kr</b></span>
                <span>TEL,FAX  <b>055-641-3560</b></span>
            </p>
        </div>
    </div>
    <div class="f-copy"><span class="mt-1">Copyright ⓒ KNSHIP.All right Reserved.</span></div>
    <a class="adm_btn" target="_blank" href="/?ctl=move&param=adm">
        <img src="https://s3.ap-northeast-2.amazonaws.com/lbcontents/images/ELBAT/156944738875600.png"/>
    </a>
</footer>
<script>
    $(document).ready(function(){
        document.querySelector('.move_top').onclick = function(){
            window.scroll({
                behavior:'smooth',
                left:0,
                top:0
            });
        }
    });

    $(window).on('scroll', function() {
        if ($(window).scrollTop() < $(document).height() - $(window).height() - $('footer').outerHeight() + 110) {
            $('.move_top').addClass('active');
        } else {
            $('.move_top').removeClass('active');
        }
        
        if ($(window).scrollTop() >= 100) {
            $('.move_top').addClass('fiexd');
        }
        else {
            $('.move_top').removeClass('fiexd');
        }

        // if ($(window).scrollTop() < $(document).height() - $(window).height() - $('.footer').outerHeight()) {
        //     $('.btn_contact').removeClass('fiexd');
        //     $('.area_history .wrap > span').removeClass('stopped');
        // } else {
        //     $('.btn_contact').addClass('fiexd');
        //     $('.area_history .wrap > span').addClass('stopped');
        // }
    });
  
</script>