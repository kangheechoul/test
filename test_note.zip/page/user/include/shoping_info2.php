<link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/notice_board.css<?php echo $this->version;?>"/>
<div class="bd-md section  product-info-wrap">
                <div class="row">
                    <div class="col-md-12 tab-wrap">
                        <ul>
                            <li class="col-md-3"><a href="javascript:;" class="active">상세정보</a></li>
                            <li class="col-md-3"><a href="javascript:;">배송정보</a></li>
                            <li class="col-md-3"><a href="javascript:;">상품후기</a></li>
                            <li class="col-md-3"><a href="javascript:;">상품Q&A</a></li>
                        </ul>
                    </div>

                    <!-- 상품상세정보 (이미지) -->
                    <div class="col-md-12 tab-content active detail">
                        <div class="detail-img">
                            <img src="<?php echo $this->project_path;?>images/no_image.gif" alt="">
                        </div>
                        <div class="text-box">
                            <p></p>
                            <p><span>‘Bipolar’(양극성)라는 대주제 아래 이번 pt.1에서는 청소년기에 겪게 되는 다양한 ‘불안의 시작’에 대한 이야기들을 담고 있다.&nbsp;</span></p>
                            <p><span>‘Bipolar’(양극성)라는 대주제 아래 이번 pt.1에서는 청소년기에 겪게 되는 다양한 ‘불안의 시작’에 대한 이야기들을 담고 있다.&nbsp;</span></p>
                            <p><span>‘Bipolar’(양극성)라는 대주제 아래 이번 pt.1에서는 청소년기에 겪게 되는 다양한 ‘불안의 시작’에 대한 이야기들을 담고 있다.&nbsp;</span></p>
                            <p><span>‘Bipolar’(양극성)라는 대주제 아래 이번 pt.1에서는 청소년기에 겪게 되는 다양한 ‘불안의 시작’에 대한 이야기들을 담고 있다.&nbsp;</span></p>
                        </div>
                    </div>
                    
                    <!-- /상품상세정보 -->

                    <!-- 배송정보 -->
                    <div class="col-md-12 tab-content active delivery">
                        <div class="text-box">
                            <p></p>
                            <p><span>‘Bipolar’(양극성)라는 대주제 아래 이번 pt.1에서는 청소년기에 겪게 되는 다양한 ‘불안의 시작’에 대한 이야기들을 담고 있다.&nbsp;</span></p>
                            <p><span>‘Bipolar’(양극성)라는 대주제 아래 이번 pt.1에서는 청소년기에 겪게 되는 다양한 ‘불안의 시작’에 대한 이야기들을 담고 있다.&nbsp;</span></p>
                            <p><span>‘Bipolar’(양극성)라는 대주제 아래 이번 pt.1에서는 청소년기에 겪게 되는 다양한 ‘불안의 시작’에 대한 이야기들을 담고 있다.&nbsp;</span></p>
                            <p><span>‘Bipolar’(양극성)라는 대주제 아래 이번 pt.1에서는 청소년기에 겪게 되는 다양한 ‘불안의 시작’에 대한 이야기들을 담고 있다.&nbsp;</span></p>
                        </div>
                    </div>
                    <!-- /배송정보 -->

                    <!-- 상품후기 -->
                    <div class="col-md-12 tab-content active review">
                        <div class="board">
                            <ul class="boad_type3">
                                <li class="no-data">
                                    리뷰가 없습니다.
                                </li>

                                <li>
                                    <dl>
                                    <dt class="toggles">
                                            <div class="title">후기 제목이들어가요~</div>
                                            <div class="names">
                                                <p>배*현</p>
                                                <span>2021.05.31</span>
                                                <span class="star-wrap">
                                                    <span>★</span>
                                                    <span>★</span>
                                                    <span>★</span>
                                                    <span>★</span>
                                                    <span>★</span>
                                                </span>
                                            </div>
                                        </dt>
                                        <dd>
                                            <div class="inner">
                                                <p>[상품이름]</p>
                                                <span><img src="<?php echo $this->project_path;?>images/no_image.gif" alt=""></span>
                                                <span><img src="<?php echo $this->project_path;?>images/no_image.gif" alt=""></span>
                                                <span>내용내용내용</span>
                                                <span>내용내용내용</span>
                                            </div>
                                        </dd>
                                    </dl>
                                </li>
                            </ul>
                        </div>

                        <!-- pagination -->
                        <div class="pagination_container mt-3" id = "paging">
                            <div class="page_item arrow prev">«</div>
                            <div class="page_item active">1</div>
                            <div class="page_item ">2</div>
                            <div class="page_item arrow next">»</div>
                        </div>
                        <!-- /pagination -->
                    </div>
                    <!-- /상품후기 -->

                    <!-- 상품Q&A -->
                    <div class="col-md-12 tab-content active qna">
                        <div class="board">
                            <ul class="boad_type3">
                                <li class="no-data">
                                    리뷰가 없습니다.
                                </li>

                                <li>
                                    <dl>
                                        <dt class="toggles">
                                            <div class="title">후기 제목이들어가요~</div>
                                            <div class="names">
                                                <p>배*현</p>
                                                <span>2021.05.31</span>
                                            </div>
                                        </dt>
                                        <dd class="active">
                                            <div class="inner">
                                                <p>[상품이름]</p>
                                                <span><img src="<?php echo $this->project_path;?>images/no_image.gif" alt=""></span>
                                                <span><img src="<?php echo $this->project_path;?>images/no_image.gif" alt=""></span>
                                                <span>내용내용내용</span>
                                                <span>내용내용내용</span>

                                                <div class="answer">
                                                    <p>admin</p>
                                                    <span>2021.05.31</span>
                                                    <div class="text-box">
                                                        <span>답변답변답변 답변답변답변답변답변답변 답변답변답변답변답변답변답변답변답변</span>
                                                        <span>답변답변답변</span>
                                                        <span>답변답변답변</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </dd>
                                    </dl>
                                </li>
                            </ul>
                        </div>

                        <!-- pagination -->
                        <div class="pagination_container mt-3" id = "paging">
                            <div class="page_item arrow prev">«</div>
                            <div class="page_item active">1</div>
                            <div class="page_item ">2</div>
                            <div class="page_item arrow next">»</div>
                        </div>
                        <!-- /pagination -->
                    </div>
                    <!-- /상품Q&A -->
                </div>
            </div>
    <script>
        const board3 = document.querySelector(".boad_type3");
        const dt = board3.querySelector("dt");
        const dd = board3.querySelector("dd");

        function handleClick(){
            dd.classList.toggle("active");
        }

        dt.addEventListener("click", handleClick);
    </script>