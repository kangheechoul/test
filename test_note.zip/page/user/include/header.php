<script type="text/javascript" src="<?php echo $this->project_path;?>js/header.js<?php echo $version;?>"></script>

<!-- header -->
<header id="header" class="header">
    <!-- pc_header -->
    <nav class="main_nav">
        <div class="bd-md"><!-- 그때그때 따라 클레스명으로 사이즈 조절 -->
            <h1 class="nav_inner left"><a class="logo" href=".?param=index"></a></h1>

            <!-- menu_list -->
            <div class="nav_inner right">
                <div class="gnb_wrap">
                    <ul class="gnb">
                        <li>
                            <a href=".?param=shoping_list">상품</a>
                            <ul class="sub_dep">
                                <li><a href="javascript:;">sub_menu1</a></li>
                                <li><a href="javascript:;">sub_menu1</a></li>
                                <li><a href="javascript:;">sub_menu1</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href=".?param=my_home">myhome</a>
                            <ul class="sub_dep">
                                <li><a href="javascript:;">sub</a></li>
                                <li><a href="javascript:;">sub</a></li>
                                <li><a href="javascript:;">sub</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="javascript:;">menu3</a>
                            <ul class="sub_dep">
                                <li><a href="javascript:;">sub_menu1</a></li>
                                <li><a href="javascript:;">sub</a></li>
                                <li><a href="javascript:;">sub_menu1</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="javascript:;">menu4</a>
                        </li>
                        <li>
                            <a href=".?param=notice_view">고객센터</a>
                            <ul class="sub_dep">
                                <li><a href=".?param=notice_view">공지사항</a></li>
                                <li><a href=".?param=faq">자주하는 질문</a></li>
                                <li><a href=".?param=qna_view">질문 및 답변</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
            <!-- /menu_list -->
        </div>
    </nav>
    <!-- /pc_header -->

    <!-- mobile_header -->
    <nav class="mobile_nav">
        <h1 class="mobile_nav_inner left">
            <a href=".?param=index" class="logo"><img src="<?php echo $this->project_path;?>images/logo_active.png" alt=""></a>
        </h1>

        <div class="mobile_nav_inner right">
            <a href="javascript:;" class="burger_menu" id="mobile_burger">
                <span class="btn-mobile-menu-icon">Menu</span>
            </a>
        </div>
    </nav>
    <!-- /mobile_header -->
</header>
<!-- /header -->

<!-- mobile_header 내용 -->
<div class="mobile_gnb_wrap" id="mobile_header">
    <div class="mobile_gnb">
        <div class="close">
            <a href="javascript:;" class="close_menu" id="mobile_close">
                <span class="btn-close-menu-icon">Close</span>
            </a>
        </div>
        <div class="mob_top_wrap"></div>

        <div class="mob_category_wrap">
            <ul class="mob_category_list_wrap cf" id="mob_category_list_wrap">
                <li class="depth1">
                    <a href="javascript:;" class="mob_depth1">상품</a>
                    <ul class="moblie_sub_dep">
                        <li><a href=".?param=shoping_list">상품</a></li>
                        <li><a href="javascript:;">sub_menu2</a></li>
                        <li><a href="javascript:;">sub_menu3</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <a href="javascript:;" class="mob_depth1">menu1</a>
                    <ul class="moblie_sub_dep">
                        <li><a href="javascript:;">sub_menu1</a></li>
                        <li><a href="javascript:;">sub_menu2</a></li>
                        <li><a href="javascript:;">sub_menu3</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <a href="javascript:;" class="mob_depth1">menu1</a>
                    <ul class="moblie_sub_dep">
                        <li><a href="javascript:;">sub_menu1</a></li>
                        <li><a href="javascript:;">sub_menu2</a></li>
                        <li><a href="javascript:;">sub_menu3</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <a href="javascript:;" class="mob_depth1">menu1</a>
                    <ul class="moblie_sub_dep">
                        <li><a href="javascript:;">sub_menu1</a></li>
                        <li><a href="javascript:;">sub_menu2</a></li>
                        <li><a href="javascript:;">sub_menu3</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <a href="javascript:;" class="mob_depth1">고객센터</a>
                    <ul class="moblie_sub_dep">
                        <li><a href=".?param=notice_view">공지사항</a></li>
                        <li><a href=".?param=faq">자주하는 질문</a></li>
                        <li><a href=".?param=qna_view">질문 및 답변</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</div>
<!-- mobile_header 내용 -->

<script>
    const mobileMenuOpen = document.querySelector('#mobile_burger');
    const mobileMenuClose = document.querySelector('#mobile_close');
    const mobileHeader = document.querySelector('#mobile_header');
    const mobileDepth1 = document.getElementsByClassName('.mob_depth1');
    const mobileDepth2 = document.getElementsByClassName('.moblie_sub_dep');
    
    const CLICKED_CL = "on";


    //burger btn 클릭시 mobile_header open
    function handleOpenMenu(){
        mobileHeader.classList.add(CLICKED_CL);
    };

    //close btn 클릭시 mobile_header close
    function handleCloseMenu(){
        mobileHeader.classList.remove(CLICKED_CL);
    };

    
    mobileMenuOpen.addEventListener("click", handleOpenMenu);
    mobileMenuClose.addEventListener("click", handleCloseMenu);

</script>