<div class="col-md-2 col-xs-12 link-tab">
    <ul>
        <li>
            <h4>고객센터</h4>
            <ul>
                <li id="notice"><a href=".?param=notice_view">공지사항</a></li>
                <li id="event"><a href=".?param=event_view">이벤트</a></li>
                <li id="faq"><a href=".?param=faq">자주하는 질문</a></li>
                <li id="qna"><a href=".?param=qna_view">1:1문의</a></li>
                <li id="qnaMy"><a href=".?param=qna_my">1:1문의내역</a></li>
            </ul>
        </li>
    </ul>
</div>

<!-- <div class="col-xs-12 m-link-tab">
    
</div> -->

<script>
    $(function(){
        const queryString = window.location.search;
        if(queryString == '?param=notice_view'){
            $('#notice').addClass('active');
        }else if(queryString == '?param=notice_info'){
            $('#notice').addClass('active');
        }else if(queryString == '?param=event_view'){
            $('#event').addClass('active');
        }else if(queryString == '?param=faq'){
            $('#faq').addClass('active');
        }else if(queryString == '?param=qna_view'){
            $('#qna').addClass('active');
        }else if(queryString == '?param=qna_wirte2'){
            $('#qna').addClass('active');
        }else if(queryString == '?param=qna_info'){
            $('#qna').addClass('active');
        }else if(queryString == '?param=qna_my'){
            $('#qnaMy').addClass('active');
        }
    });
</script>