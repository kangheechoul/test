
<link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>css/reset.css<?php echo $version;?>"/>
<link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>css/font.css<?php echo $version;?>"/>
<link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>css/style.css<?php echo $version;?>"/>
<link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>css/common.css<?php echo $version;?>"/>

<!-- WOW -->
<link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>layout/css/animate.css"/>
<script type="text/javascript" src="<?php echo $this->project_path;?>layout/js/wow.min.js"></script>
<script>
    new WOW().init();
</script>


<!-- material-icons -->
<link href="https://fonts.googleapis.com/icon?family=Material+Icons"
      rel="stylesheet">