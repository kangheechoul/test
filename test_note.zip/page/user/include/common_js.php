<script>var data = <?php echo $data;?>;</script>
<script type="text/javascript" src="common_js/jquery.js<?php echo $version;?>"></script>
<script type="text/javascript" src="common_js/lb.js<?php echo $version;?>"></script>
<script type="text/javascript" src="common_js/gu.js<?php echo $version;?>"></script>
<script type="text/javascript" src="<?php echo $this->project_path;?>js/common.js<?php echo $version;?>"></script>
<!-- 공통 적용 스크립트 , 모든 페이지에 노출되도록 설치. 단 전환페이지 설정값보다 항상 하단에 위치해야함 --> 
<script type="text/javascript" src="//wcs.naver.net/wcslog.js"> </script> 
<script type="text/javascript"> 
if (!wcs_add) var wcs_add={};
wcs_add["wa"] = "s_16e26e38e072";
if (!_nasa) var _nasa={};
if(window.wcs){
wcs.inflow();
wcs_do(_nasa);
}
</script>
