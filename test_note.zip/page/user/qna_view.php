<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <meta name="format-detection" content="telephone=no">

	<title>경남해운</title>

    <!-- FONT -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Exo:ital,wght@0,300;0,500;0,700;0,900;1,900&family=Noto+Sans+JP:wght@300;400;500;700&display=swap" rel="stylesheet">

	<!-- CSS -->
    <?php include_once $this->project_path."include/common_css.php"; ?>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/sub_page.css"/>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/side_tab.css"/>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->project_path;?>/css/notice_board.css"/>

    <!-- JS -->
    <?php include_once $this->project_path."include/common_js.php"; ?>
</head>
<body>
    <div class="Wrap">        
        <?php include_once  $this->project_path."include/header.php"; ?>
        <div class="Container" id="content">
            <div class="bd-md section">
                <div class="row">
                    <?php include_once  $this->project_path."include/cs_side.php"; ?>
                    <div class="col-md-10 col-xs-12">
                        <table class="table board_type1">
                            <colgroup>
                                <col width="10%">
                                <col width="55%">
                                <col width="10%%">
                                <col width="15%">
                                <col width="10%">
                            </colgroup>
                            <tr>
                                <th>번호</th>
                                <th class="title">제목</th>
                                <th>글쓴이</th>
                                <th>날짜</th>
                                <th>조회수</th>
                            </tr>
                            <tr>
                                <td>2</td>
                                <td class="title"><a href=".?param=qna_info">공지사항 제목이 들어갈 부분입니다.</a></td>
                                <td>유재석</td>
                                <td>21-04-29</td>
                                <td>240</td>
                            </tr>
                            <tr>
                                <td>1</td>
                                <td class="title"><a href="javascript:;">공지사항 제목이 들어갈 부분입니다.</a></td>
                                <td>박명수</td>
                                <td>21-04-29</td>
                                <td>200</td>
                            </tr>
                            <!-- 글이없을 경우 -->
                            <tr class="dis-none">
                                <td colspan="5" class="text-center">등록된 글이 없습니다.</td>
                            </tr>
                        </table>
                            <div class="btn_wrap text-right">
                                <a href=".?param=qna_write">글쓰기</a>
                            </div>
                        <div class="pagination_container mt-3" id = "paging">
                            <div class="page_item arrow prev">«</div>
                            <div class="page_item active">1</div>
                            <div class="page_item ">2</div>
                            <div class="page_item arrow next">»</div>
                        </div>

                        <div class="search_area text-center mt-2">
                            <div class="insert_wrap">
                                <div class="insert">
                                    <input type="text" id="search_text" name="search_text" onkeydown="enter_search();" placeholder="검색어"/>
                                    <span class="btn" id="btn_search"><img src="<?php echo $this->project_path;?>images/i_search.png" alt="button" onclick="search();"/></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="bd-md section">
                <div class="row">
                <div class="col-md-12 tab-content active qna">
                    <!-- 검색 -->
                        <div class="search_area">
                            <div class="insert_wrap">
                                <div class="insert">
                                    <input type="text" id="search_text" name="search_text" onkeydown="enter_search();" placeholder="검색어"/>
                                    <span class="btn" id="btn_search"><img src="<?php echo $this->project_path;?>images/i_search.png" alt="button" onclick="search();"/></span>
                                </div>
                            </div>
                        </div>
                    <!-- /검색 -->
                        <div class="board">
                            <ul class="boad_type3">
                                <li class="no-data">
                                    리뷰가 없습니다.
                                </li>

                                <li>
                                    <dl>
                                        <dt class="toggles">
                                            <div class="title">후기 제목이들어가요~</div>
                                            <div class="names">
                                                <p>배*현</p>
                                                <span>2021.05.31</span>
                                            </div>
                                        </dt>
                                        <dd class="active">
                                            <div class="inner">
                                                <p>[상품이름]</p>
                                                <span><img src="<?php echo $this->project_path;?>images/no_image.gif" alt=""></span>
                                                <span><img src="<?php echo $this->project_path;?>images/no_image.gif" alt=""></span>
                                                <span>내용내용내용</span>
                                                <span>내용내용내용</span>

                                                <div class="answer">
                                                    <p>admin</p>
                                                    <span>2021.05.31</span>
                                                    <div class="text-box">
                                                        <span>답변답변답변 답변답변답변답변답변답변 답변답변답변답변답변답변답변답변답변</span>
                                                        <span>답변답변답변</span>
                                                        <span>답변답변답변</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </dd>
                                    </dl>
                                </li>
                            </ul>
                        </div>

                        <!-- 글쓰기 -->
                        <div class="btn_wrap text-right">
                            <a href=".?param=qna_write">글쓰기</a>
                        </div>
                        <!-- /글쓰기 -->

                        <!-- pagination -->
                        <div class="pagination_container mt-3" id = "paging">
                            <div class="page_item arrow prev">«</div>
                            <div class="page_item active">1</div>
                            <div class="page_item ">2</div>
                            <div class="page_item arrow next">»</div>
                        </div>
                        <!-- /pagination -->
                    </div>
                </div>
            </div>
            
        </div>
        <?php include_once  $this->project_path."include/footer.php"; ?>
    </div>
</body>
</html>