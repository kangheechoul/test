<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<title>회원등급 설정</title>
	<!-- font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
	<link href='//spoqa.github.io/spoqa-han-sans/css/SpoqaHanSans-kr.css' rel='stylesheet' type='text/css'>

	<!-- css -->
	<?php include_once $this->dir."page/adm/inc/common_css.php"; ?>

	<!-- script -->
	<?php include_once $this->dir."page/adm/inc/common_js.php"; ?>
	<script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/crm_grade.js"></script>
	<style>
		[data-attr=grade_name]{margin-top:4px; margin-bottom:4px;}
	</style>
</head>
<body>
	<div class="wrap">
        <?php include_once $dir."page/adm/include/adm_aside.php";?>
			<div class="bd">
				<article class="body-container">
					<div class="body-head"><h2>회원등급 설정</h2></div>
					<form class="form" id = "form">
						<div class="body-box">
							<div class="table-container">
								<table class="table4">
									<thead>
										<tr>
											<th rowspan="2">순위</th>
											<th rowspan="2">사용</th>
                                            <th rowspan="2">등급명</th>
											<th colspan="3">혜택 및 조건</th>
											<th colspan="2">등급조건</th>
											<th colspan="2">유지조건</th>
											<th rowspan="2">회원수</th>
											<th rowspan="2">등록</th>
                                        </tr>
                                        <tr>
                                            <th >무료배송</th>
											<th >할인</th>
											<th>적립</th>
											<th>구매금액</th>
											<th>구매횟수</th>
											<th>구매금액</th>
											<th>구매횟수</th>
										</tr>
									</thead>
									<tbody>
										<tr>
											<td class="col-num">1</td>
											<td class="col-num">
												<div class="insert insert-chk">
													<label class="check_label">
														<input type="checkbox" id = "is_use_1" />
														<span class="checkmark"></span>
													</label>
												</div>
											</td>
                                            <td class="" data-wrap= "wrap_1" id = "wrap_1">
                                                <!-- <div class="insert insert-input">
                                                    <input type="text" class="input-32 input-lg">
                                                </div> -->
                                            </td>
                                            <td class="col-short-num">
												<div class="insert insert-chk">
													<label class="check_label">
														<input type="checkbox" id = "delivery_free_1" />
														<span class="checkmark"></span>
													</label>
												</div>
                                            </td>
                                            <td class="">
                                                <div class="insert insert-input">
                                                    <input type="text" id = "discount_rate_1" class="input-32 input-min"><span class="ml-1">%</span>
                                                </div>
                                            </td>
                                            <td class="">
                                                <div class="insert insert-input">
                                                    <input type="text" id = "point_percent_1" class="input-32 input-min"><span class="ml-1">%</span>
                                                </div>
											</td>
											<td class="">
                                                <div class="insert insert-input">
                                                    <input type="text" id= "buy_condition_1" class="input-32 input-xs"><span class="ml-1">원 이상</span>
                                                </div>
											</td>
											<td class="">
                                                <div class="insert insert-input">
                                                    <input type="text" id = "buy_count_1" class="input-32 input-xs"><span class="ml-1">건 이상</span>
                                                </div>
											</td>
											<td class="">
                                                <div class="insert insert-input">
                                                    <input type="text" id= "maintain_condition_1" class="input-32 input-xs"><span class="ml-1">원 이상</span>
                                                </div>
											</td>
											<td class="">
                                                <div class="insert insert-input">
                                                    <input type="text" id = "maintain_count_1" class="input-32 input-xs"><span class="ml-1">건 이상</span>
                                                </div>
											</td>
											<td><span class="c-pointer bold blue" id = "user_total_1" onclick="">0명</span></td>
											<td class="">
                                                <div class="insert insert-input">
                                                    <input type="button" id ="user_grade_btn_1" class="btn-default btn-32" value ="등록" />
                                                </div>
											</td>
										</tr>
										<!-- 1 // -->
										<tr>
											<td class="col-num">2</td>
											<td class="col-num">
												<div class="insert insert-chk">
													<label class="check_label">
														<input type="checkbox" id = "is_use_2" />
														<span class="checkmark"></span>
													</label>
												</div>
											</td>
                                            <td class="" data-wrap= "wrap_2" id = "wrap_2">
                                                <!-- <div class="insert insert-input">
                                                    <input type="text" class="input-32 input-lg">
                                                </div> -->
                                            </td>
                                            <td class="col-short-num">
												<div class="insert insert-chk">
													<label class="check_label">
														<input type="checkbox" id = "delivery_free_2" />
														<span class="checkmark"></span>
													</label>
												</div>
                                            </td>
                                            <td class="">
                                                <div class="insert insert-input">
                                                    <input type="text" id = "discount_rate_2" class="input-32 input-min"><span class="ml-1">%</span>
                                                </div>
                                            </td>
                                            <td class="">
                                                <div class="insert insert-input">
                                                    <input type="text" id = "point_percent_2" class="input-32 input-min"><span class="ml-1">%</span>
                                                </div>
											</td>
											<td class="">
                                                <div class="insert insert-input">
                                                    <input type="text" id= "buy_condition_2" class="input-32 input-xs"><span class="ml-1">원 이상</span>
                                                </div>
											</td>
											<td class="">
                                                <div class="insert insert-input">
                                                    <input type="text" id = "buy_count_2" class="input-32 input-xs"><span class="ml-1">건 이상</span>
                                                </div>
											</td>
											<td class="">
                                                <div class="insert insert-input">
                                                    <input type="text" id= "maintain_condition_2" class="input-32 input-xs"><span class="ml-1">원 이상</span>
                                                </div>
											</td>
											<td class="">
                                                <div class="insert insert-input">
                                                    <input type="text" id = "maintain_count_2" class="input-32 input-xs"><span class="ml-1">건 이상</span>
                                                </div>
											</td>
											<td><span class="c-pointer bold blue" id = "user_total_2" onclick="">0명</span></td>
											<td class="">
                                                <div class="insert insert-input">
                                                    <input type="button" id ="user_grade_btn_2" class="btn-default btn-32" value ="등록" />
                                                </div>
											</td>
										</tr>
										<!-- 2 // -->
										<tr>
											<td class="col-num">3</td>
											<td class="col-num">
												<div class="insert insert-chk">
													<label class="check_label">
														<input type="checkbox" id = "is_use_3"/>
														<span class="checkmark"></span>
													</label>
												</div>
											</td>
                                            <td class="" data-wrap= "wrap_3" id = "wrap_3">
                                                <!-- <div class="insert insert-input">
                                                    <input type="text" class="input-32 input-lg">
                                                </div> -->
                                            </td>
                                            <td class="col-short-num">
												<div class="insert insert-chk">
													<label class="check_label">
														<input type="checkbox" id = "delivery_free_3" />
														<span class="checkmark"></span>
													</label>
												</div>
                                            </td>
                                            <td class="">
                                                <div class="insert insert-input">
                                                    <input type="text" id = "discount_rate_3" class="input-32 input-min"><span class="ml-1">%</span>
                                                </div>
                                            </td>
                                            <td class="">
                                                <div class="insert insert-input">
                                                    <input type="text" id = "point_percent_3" class="input-32 input-min"><span class="ml-1">%</span>
                                                </div>
											</td>
											<td class="">
                                                <div class="insert insert-input">
                                                    <input type="text" id= "buy_condition_3" class="input-32 input-xs"><span class="ml-1">원 이상</span>
                                                </div>
											</td>
											<td class="">
                                                <div class="insert insert-input">
                                                    <input type="text" id = "buy_count_3" class="input-32 input-xs"><span class="ml-1">건 이상</span>
                                                </div>
											</td>
											<td class="">
                                                <div class="insert insert-input">
                                                    <input type="text" id= "maintain_condition_3" class="input-32 input-xs"><span class="ml-1">원 이상</span>
                                                </div>
											</td>
											<td class="">
                                                <div class="insert insert-input">
                                                    <input type="text" id = "maintain_count_3" class="input-32 input-xs"><span class="ml-1">건 이상</span>
                                                </div>
											</td>
											<td><span class="c-pointer bold blue" id = "user_total_3" onclick="">0명</span></td>
											<td class="">
                                                <div class="insert insert-input">
                                                    <input type="button" id ="user_grade_btn_3" class="btn-default btn-32" value ="등록" />
                                                </div>
											</td>
										</tr>
										<!-- 3 // -->
										<tr>
											<td class="col-num">4</td>
											<td class="col-num">
												<div class="insert insert-chk">
													<label class="check_label">
														<input type="checkbox" id = "is_use_4"/>
														<span class="checkmark"></span>
													</label>
												</div>
											</td>
                                            <td class="" data-wrap= "wrap_4" id = "wrap_4">
                                                <!-- <div class="insert insert-input">
                                                    <input type="text" class="input-32 input-lg">
                                                </div> -->
                                            </td>
                                            <td class="col-short-num">
												<div class="insert insert-chk">
													<label class="check_label">
														<input type="checkbox" id = "delivery_free_4" />
														<span class="checkmark"></span>
													</label>
												</div>
                                            </td>
                                            <td class="">
                                                <div class="insert insert-input">
                                                    <input type="text" id = "discount_rate_4" class="input-32 input-min"><span class="ml-1">%</span>
                                                </div>
                                            </td>
                                            <td class="">
                                                <div class="insert insert-input">
                                                    <input type="text" id = "point_percent_4" class="input-32 input-min"><span class="ml-1">%</span>
                                                </div>
											</td>
											<td class="">
                                                <div class="insert insert-input">
                                                    <input type="text" id= "buy_condition_4" class="input-32 input-xs"><span class="ml-1">원 이상</span>
                                                </div>
											</td>
											<td class="">
                                                <div class="insert insert-input">
                                                    <input type="text" id = "buy_count_4" class="input-32 input-xs"><span class="ml-1">건 이상</span>
                                                </div>
											</td>
											<td class="">
                                                <div class="insert insert-input">
                                                    <input type="text" id= "maintain_condition_4" class="input-32 input-xs"><span class="ml-1">원 이상</span>
                                                </div>
											</td>
											<td class="">
                                                <div class="insert insert-input">
                                                    <input type="text" id = "maintain_count_4" class="input-32 input-xs"><span class="ml-1">건 이상</span>
                                                </div>
											</td>
											<td><span class="c-pointer bold blue" id = "user_total_4" onclick="">0명</span></td>
											<td class="">
                                                <div class="insert insert-input">
                                                    <input type="button" id ="user_grade_btn_4" class="btn-default btn-32" value ="등록" />
                                                </div>
											</td>
										</tr>
										<!-- 4 // -->
										<tr>
											<td class="col-num">5</td>
											<td class="col-num">
												<div class="insert insert-chk">
													<label class="check_label">
														<input type="checkbox" id = "is_use_5"/>
														<span class="checkmark"></span>
													</label>
												</div>
											</td>
                                            <td class="" data-wrap= "wrap_5" id = "wrap_5">
                                                <!-- <div class="insert insert-input">
                                                    <input type="text" class="input-32 input-lg">
                                                </div> -->
                                            </td>
                                            <td class="col-short-num">
												<div class="insert insert-chk">
													<label class="check_label">
														<input type="checkbox" id = "delivery_free_5" />
														<span class="checkmark"></span>
													</label>
												</div>
                                            </td>
                                            <td class="">
                                                <div class="insert insert-input">
                                                    <input type="text" id = "discount_rate_5" class="input-32 input-min"><span class="ml-1">%</span>
                                                </div>
                                            </td>
                                            <td class="">
                                                <div class="insert insert-input">
                                                    <input type="text" id = "point_percent_5" class="input-32 input-min"><span class="ml-1">%</span>
                                                </div>
											</td>
											<td class="">
                                                <div class="insert insert-input">
                                                    <input type="text" id= "buy_condition_5" class="input-32 input-xs"><span class="ml-1">원 이상</span>
                                                </div>
											</td>
											<td class="">
                                                <div class="insert insert-input">
                                                    <input type="text" id = "buy_count_5" class="input-32 input-xs"><span class="ml-1">건 이상</span>
                                                </div>
											</td>
											<td class="">
                                                <div class="insert insert-input">
                                                    <input type="text" id= "maintain_condition_5" class="input-32 input-xs"><span class="ml-1">원 이상</span>
                                                </div>
											</td>
											<td class="">
                                                <div class="insert insert-input">
                                                    <input type="text" id = "maintain_count_5" class="input-32 input-xs"><span class="ml-1">건 이상</span>
                                                </div>
											</td>
											<td><span class="c-pointer bold blue" id = "user_total_5" onclick="">0명</span></td>
											<td class="">
                                                <div class="insert insert-input">
                                                    <input type="button" id ="user_grade_btn_5" class="btn-default btn-32" value ="등록" />
                                                </div>
											</td>
										</tr>
										<!-- 5 // -->
									</tbody>
								</table>
							</div>
						</div>
					</form>
				</article>
			</div>
	</div>
	<div style = "display:none">
		<div class="insert insert-input" data-copy="copy">
			<input type="text" class="input-32 input-lg" data-attr="grade_name">
		</div>
	</div>

</body>
<!-- select2 -->
<link rel="stylesheet" type="text/css" href="<?php echo $this->project_admin_path;?>layout/select2/css/select2.min.css"/>
<link rel="stylesheet" type="text/css" href="common_css/adm/adm_select.css?<?php echo $version;?>"/>
<script type="text/javascript" src="<?php echo $this->project_admin_path;?>layout/select2/js/select2.full.min.js"></script>
<script type="text/javascript">
	$(document).ready(function() {
        $('.select-custom').select2({
            minimumResultsForSearch: -1
        });
    });
</script>
