<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>회원 상품후기</title>
	<!-- font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
	<link href='//spoqa.github.io/spoqa-han-sans/css/SpoqaHanSans-kr.css' rel='stylesheet' type='text/css'>

	<!-- css -->
	<link rel="stylesheet" type="text/css" href="common_css/adm/adm_reset.css?<?php echo $version;?>"/>
	<link rel="stylesheet" type="text/css" href="common_css/adm/adm_style.css?<?php echo $version;?>"/>
	<link rel="stylesheet" type="text/css" href="common_css/adm/adm_select.css?<?php echo $version;?>"/>
    <link rel="stylesheet" type="text/css" href="common_css/adm/adm_form.css?<?php echo $version;?>"/>
    <link rel="stylesheet" type="text/css" href="common_css/adm/adm_modal.css?<?php echo $version;?>"/>
    <link rel="stylesheet" type="text/css" href="common_css/adm/adm_common.css?<?php echo $version;?>"/>

	<!-- script -->
    <?php include_once $this->dir."page/adm/inc/common_js.php"; ?>
    <script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/popup_init.js<?php echo $version;?>"></script>
    <script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/pupup_review.js<?php echo $version;?>"></script>
</head>
<body>
    <div class="modal user-modal d-none">
        <div class="modal-wrap">
            <div class="modal-container">
                <span class="modal-close" onclick = "">&#10005;</span><!-- 모달 닫기 // -->
                <!-- 모달 본문 -->
                <div class="modal-container-inner">
                    <div class="align-center"><img src="<?php echo $this->project_admin_path;?>images/sample2.png" onerror="this.style.display='none'" alt="img_load"></div>
                </div>
                <!-- 모달 본문 // -->
            </div>
        </div>
    </div>
    <!-- 첨부이미지 확대 모달 // -->
	<div class="wrap" style="background-color:#e8edf3">
		<?php include_once $dir."page/adm/include/adm_member_header.php";?>
		<?php include_once $dir."page/adm/include/adm_member_aside.php";?>
        <div class="bd">
            <article class="body-container">
                <div class="body-head"><h2>상품후기</h2></div>
                <form class="form">
                    <div class="row">
                        <div class="col-md-7">
                            <div class="body-box">
                                <div class="table-container">
                                    <table class="table3">
                                        <thead>
                                            <tr>
                                                <th>번호</th>
                                                <th class="col-tit">상품명</th>
                                                <th class="col-tit">리뷰</th>
                                                <th>점수</th>
                                                <th>등록일</th>
                                            </tr>
                                        </thead>
                                        <tbody data-wrap = "wrap" id ="wrap">
                                            <!-- <tr class="current">
                                                <td class="col-num">1</td>
                                                <td class="col-tit">
                                                    <div>
                                                        <p class="tit"><span class="ellipsis c-pointer" onclick="">상품명이 들어갑니다.</span></p>
                                                    </div>
                                                </td>
                                                <td class="col-tit">
                                                    <div>
                                                        <p class="tit"><span class="bold c-pointer ellipsis" onclick="">잘 받았습니다 너무 좋네요 ><</span></p>
                                                    </div>
                                                </td>
                                                <td class="col-num">5</td>
                                                <td class="col-long-num">20.03.24 18:12:06</td>
                                            </tr> -->
                                            <!-- 2 // -->
                                        </tbody>
                                    </table>
                                </div>
                                <div class="pagination_container mt-3" id = "paging">
                                    <!-- <div class="page_item arrow prev">«</div>
                                    <div class="page_item active">1</div>
                                    <div class="page_item ">2</div>
                                    <div class="page_item arrow next">»</div> -->
                                </div>
                            </div>
                        </div>
                        <div class="col-md-5">
                            <div class="body-box">
                                <div class="box-table-container box-table-container2">
                                    <div class="box-tit mb-1"><h3>후기</h3></div>
                                    <dl class="box-tbody">
                                        <dt class="box-th box-head">
                                            <p>상품</p>
                                        </dt>
                                        <dd class="box-td">
                                            <p class="c-pointer" onclick="" id = "d_product_name">상품명이 들어갑니다.</p>
                                        </dd>
                                    </dl>
                                    <!-- <dl class="box-tbody">
                                        <dt class="box-th box-head">
                                            <p>제목</p>
                                        </dt>
                                        <dd class="box-td">
                                            <p class="bold">잘 받았습니다 너무 좋네요 ><</p>
                                        </dd>
                                    </dl> -->
                                    <dl class="box-tbody">
                                        <dt class="box-th box-head">
                                            <p>등록일</p>
                                        </dt>
                                        <dd class="box-td">
                                            <p class="" id = "d_regdate"></p>
                                        </dd>
                                    </dl>
                                    <dl class="box-tbody">
                                        <dt class="box-th box-head">
                                            <p>리뷰내용</p>
                                        </dt>
                                        <dd class="box-td">
                                            <div class="insert insert-textarea">
                                                <textarea readonly id = "d_review"></textarea>
                                            </div>
                                        </dd>
                                    </dl>
                                    <dl class="box-tbody">
                                        <dt class="box-th box-head">
                                            <p>첨부이미지</p>
                                        </dt>
                                        <dd class="box-td">

                                            <div data-wrap = "img_wrap" id = "img_wrap">
                                                <!-- <div class="img-load" style="overflow: hidden;">
                                                    <img src="<?php echo $this->project_path;?>/images/sample.png" onerror="this.style.display='none'" alt="img_load">
                                                </div> -->
                                            </div>
                                                

                                            <!-- 이미지 1 // -->
                                            <p class="xsmall">이미지를 클릭하면 확대되어 나타납니다.</p>
                                        </dd>
                                    </dl>
                                </div>
                                <!-- 상품후기 // -->
                                <!-- <div class="box-table-container box-table-container2 mt-3">
                                    <div class="box-tit mb-1"><h3>답변</h3></div>
                                    <dl class="box-tbody">
                                        <dt class="box-th box-head">
                                            <p>답변일</p>
                                        </dt>
                                        <dd class="box-td">
                                            <p></p>
                                        </dd>
                                    </dl>
                                    <dl class="box-tbody">
                                        <dt class="box-th box-head">
                                            <p>답변내용</p>
                                        </dt>
                                        <dd class="box-td">
                                            <div class="insert insert-textarea">
                                                <textarea></textarea>
                                            </div>
                                        </dd>
                                    </dl>
                                </div>
                                <div class="insert-wrap mt-2 align-center">
                                    <div class="insert insert-input-btn"><input class="btn-primary" type="button" value="완료"></div>
                                    <div class="insert insert-input-btn"><input class="btn-default" type="button" value="취소"></div>
                                </div> -->
                                <!-- 상품후기 답변 // -->
                            </div>
                        </div>
                    </div>
                </form>
            </article>
        </div>
    </div>
    <div style = "display:none;">
        <table>
            <tr data-copy ="copy">
                <td class="col-num" data-attr="num"></td>
                <td class="col-tit">
                    <div>
                        <p class="tit"><span class="ellipsis c-pointer" onclick="" data-attr="product_name"></span></p>
                    </div>
                </td>
                <td class="col-tit">
                    <div>
                        <p class="tit"><span class="bold c-pointer ellipsis" onclick="" data-attr="review"></span></p>
                    </div>
                </td>
                <td class="col-num" data-attr="grade_point"></td>
                <td class="col-long-num" data-attr="regdate"></td>
            </tr>
        </table>

        <div class="img-load" style="overflow: hidden;" data-copy = "img_copy">
            <img src="<?php echo $this->project_path;?>/images/sample.png" alt="img_load" data-attr="img">
        </div>
    </div>
</body>
</html>