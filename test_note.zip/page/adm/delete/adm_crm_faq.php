<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<title>FAQ 관리</title>
	<!-- font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
	<link href='//spoqa.github.io/spoqa-han-sans/css/SpoqaHanSans-kr.css' rel='stylesheet' type='text/css'>

	<!-- css -->
	<?php include_once $this->dir."page/adm/inc/common_css.php"; ?>
	<link rel="stylesheet" type="text/css" href="common_css/adm/jquery-ui.min.css?<?php echo $version;?>"/>

	<!-- script -->
	<?php include_once $this->dir."page/adm/inc/common_js.php"; ?>
	<script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/crm_faq.js"></script>
	
</head>
<body>
	<div class="wrap">
        <?php include_once $dir."page/adm/include/adm_aside.php";?>
		<div class="bd">
			<article class="body-container">
				<div class="body-head"><h2>FAQ 관리</h2></div>
				<form class="form">
					<div class="body-box mb-3">
						<div class="box-search-container">
							<div class="insert-wrap">
								<div class="insert insert-select">
									<select class="select-custom" id ="search_kind" type="text">
										<option value = "title">질문</option>
									</select>
								</div>
								<div class="insert insert-input"><input class="input-lg" id = "keyword" type="text"/></div>
							</div>
						</div>
						<div class="insert-wrap align-center mt-3">
							<div class="insert insert-input-btn"><input class="btn-primary" id = "select_btn" type="button" value="검색"/></div>
							<div class="insert insert-input-btn"><input class="btn-default" id = "init_btn" type="button" value="초기화"/></div>
						</div>
					</div>
					<div class="body-out mb-3">
						<div class="out-tit-container">
							<h4 class="medium bold"><b id="total_count">&nbsp;</b>개 검색되었습니다.</h4>
						</div>
						<div class="insert-wrap mb-1">
							<div class="insert insert-input-btn"><input class="btn-primary" onclick = "register_btn();" type="button" value="등록하기"></div>
							<div class="insert insert-input-btn"><input class="btn-default" onclick = "remove_btn();" type="button" value="삭제"></div>
						</div>
					</div>
					<div class="body-box">
						<div class="table-container">
							<table class="table3">
								<thead>
									<tr>
										<th>
											<div class="insert insert-chk">
												<label class="check_label">
													<input type="checkbox" id = "all_check_input" onchange = "all_check(this);">
													<span class="checkmark"></span>
												</label>
											</div>
										</th>
										<th>번호</th>
										<th class="col-tit">질문</th>
										<th>등록일</th>
									</tr>
								</thead>
								<tbody data-wrap = "wrap" id = "wrap">
									<!-- <tr>
										<td>
											<div class="insert insert-chk">
												<label class="check_label">
													<input type="checkbox">
													<span class="checkmark"></span>
												</label>
											</div>
										</td>
										<td class="col-num">2</td>
										<td class="col-tit">
											<div>
												<p class="tit"><span class="ellipsis c-pointer" onclick="">상품이 onclick 되어야합니다.</span></p>
											</div>
										</td>
										<td class="col-tit">
											<div>
												<p class="tit"><span class="bold c-pointer ellipsis" onclick="">제목을 누르면 팝업이 나타납니다.</span></p>
											</div>
										</td>
										<td>5</td>
										<td>하예든</td>
										<td>sample</td>
										<td class="col-long-num">20.03.24  18:00:06</td>
										<td class="col-long-num">미답변</td>
									</tr>
									1 //
									<tr>
										<td>
											<div class="insert insert-chk">
												<label class="check_label">
													<input type="checkbox">
													<span class="checkmark"></span>
												</label>
											</div>
										</td>
										<td class="col-num">1</td>
										<td class="col-tit">
											<div>
												<p class="tit"><span class="ellipsis c-pointer" onclick="">상품명이 들어갑니다.</span></p>
											</div>
										</td>
										<td class="col-tit">
											<div>
												<p class="tit"><span class="bold c-pointer ellipsis" onclick="">제목 들어갑니다.</span></p>
											</div>
										</td>
										<td>5</td>
										<td>이재영</td>
										<td>sampleid</td>
										<td class="col-long-num">20.03.24 18:00:06</td>
										<td class="col-long-num">20.03.24 18:12:06</td>
									</tr> -->
									<!-- 2 // -->
								</tbody>
							</table>
						</div>
						<div class="pagination_container mt-3" id = "paging">
							<!-- <div class="page_item arrow prev">«</div>
							<div class="page_item active">1</div>
							<div class="page_item ">2</div>
							<div class="page_item arrow next">»</div> -->
						</div>
					</div>
				</form>
			</article>
		</div>
	</div>
	<div style = "display:none">
		<table>
			<tr data-copy ="copy">
				<td>
					<div class="insert insert-chk">
						<label class="check_label">
							<input type="checkbox" data-attr="checkbox">
							<span class="checkmark"></span>
						</label>
					</div>
				</td>
				<td class="col-num" data-attr="num"></td>
				<td class="col-tit">
					<div>
						<p class="tit"><span class="bold c-pointer ellipsis" data-attr = "title">제목을 누르면 팝업이 나타납니다.</span></p>
					</div>
				</td>
				<td class="col-long-num" data-attr="regdate">20.03.24  18:00:06</td>
			</tr>
		</table>
	</div>
</body>
<!-- select2 -->
<link rel="stylesheet" type="text/css" href="<?php echo $this->project_admin_path;?>layout/select2/css/select2.min.css"/>
<link rel="stylesheet" type="text/css" href="common_css/adm/adm_select.css?<?php echo $version;?>"/>
<script type="text/javascript" src="<?php echo $this->project_admin_path;?>layout/select2/js/select2.full.min.js"></script>
<script type="text/javascript">
	$(document).ready(function() {
        $('.select-custom').select2({
            minimumResultsForSearch: -1
        });
    });
</script>
