<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>회원 쿠폰내역</title>
	<!-- font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
	<link href='//spoqa.github.io/spoqa-han-sans/css/SpoqaHanSans-kr.css' rel='stylesheet' type='text/css'>

	<!-- css -->
	<?php include_once $this->dir."page/adm/inc/common_css.php"; ?>

	<!-- script -->
    <?php include_once $this->dir."page/adm/inc/common_js.php"; ?>
    <script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/popup_init.js<?php echo $version;?>"></script>
    <script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/popup_coupon.js<?php echo $version;?>"></script>
</head>
<body>
	<div class="wrap" style="background-color:#e8edf3">
		<?php include_once $dir."page/adm/include/adm_member_header.php";?>
		<?php include_once $dir."page/adm/include/adm_member_aside.php";?>
        <div class="bd">
            <article class="body-container">
                <div class="body-head"><h2>쿠폰내역</h2></div>
                <form class="form">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="body-box">
                                <div class="table-container">
                                    <table class="table3">
                                        <thead>
                                            <tr>
                                                <th>
                                                    <div class="insert insert-chk">
                                                        <label class="check_label">
                                                            <input type="checkbox" onchange = "all_check(this);"/>
                                                            <span class="checkmark"></span>
                                                        </label>
                                                    </div>
                                                </th>
                                                <th>번호</th>
                                                <th class="col-tit">쿠폰명</th>
                                                <th>할인금액(율)</th>
                                                <th>사용제한</th>
                                                <th>최대할인</th>
                                                <th>발급일</th>
                                                <th>만료예정일</th>
                                                <th>사용일</th>
                                            </tr>
                                        </thead>
                                        <tbody data-wrap = "wrap" id ="wrap">
                                            <!-- <tr>
                                                <td>
                                                    <div class="insert insert-chk">
                                                        <label class="check_label">
                                                            <input type="checkbox"/>
                                                            <span class="checkmark"></span>
                                                        </label>
                                                    </div>
                                                </td>
                                                <td class="col-num">2</td>
                                                
                                                <td class="col-tit">
                                                    <div class="table-tit">
                                                        <p class="tit">쿠폰명이 들어갑니다.</p>
                                                    </div>
                                                </td>
                                                <td><div class="table-won">10%</div></td>
                                                <td><div class="table-won">15,000원 이상</div></td>

                                                <td><div class="table-won">500,000</div></td>
                                                <td>20.03.24</td>
                                                <td>무제한</td>
                                                <td>사용안함</td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <div class="insert insert-chk">
                                                        <label class="check_label">
                                                            <input type="checkbox"/>
                                                            <span class="checkmark"></span>
                                                        </label>
                                                    </div>
                                                </td>
                                                <td class="col-num">1</td>
                                                
                                                <td class="col-tit">
                                                    <div class="table-tit">
                                                        <p class="tit">쿠폰명이 들어갑니다.</p>
                                                    </div>
                                                </td>
                                                <td><div class="table-won">10%</div></td>
                                                <td><div class="table-won">15,000원 이상</div></td>

                                                <td><div class="table-won">500,000</div></td>
                                                <td>20.03.24</td>
                                                <td>20.03.31</td>
                                                <td>20.03.24</td>
                                            </tr> -->
                                            <!-- 2 // -->
                                        </tbody>
                                    </table>
                                </div>
                                <div class="insert-wrap mt-1">
                                    <div class="insert insert-input-btn"><input class="btn-default btn-32" type="button" onclick = "coupon_retrieve();" value="쿠폰회수"></div>
                                </div>
                                <div class="pagination_container mt-3" id ="paging">
                                    <!-- <div class="page_item arrow prev">«</div>
                                    <div class="page_item active">1</div>
                                    <div class="page_item ">2</div>
                                    <div class="page_item arrow next">»</div> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </article>
        </div>
    </div>
    <div style = "display:none">
        <table>
            <tr data-copy ="copy">
                <td>
                    <div class="insert insert-chk">
                        <label class="check_label">
                            <input type="checkbox" data-attr="checkbox"/>
                            <span class="checkmark"></span>
                        </label>
                    </div>
                </td>
                <td class="col-num" data-attr="num"></td>
                <td class="col-tit">
                    <div class="table-tit">
                        <p class="tit" data-attr="name">쿠폰명이 들어갑니다.</p>
                    </div>
                </td>
                <td><div class="table-won" data-attr="percent"></div></td>
                <td><div class="table-won" data-attr="min_limited"></div></td>
                <td><div class="table-won" data-attr="max_discount"></div></td>
                <td data-attr="regdate">20.03.24</td>
                <td data-attr="expire_date">무제한</td>
                <td data-attr="use_date">사용안함</td>
            </tr>
        </table>
        
    </div>  
</body>
</html>