<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>이미지</title>
	<!-- font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
    <link href='//spoqa.github.io/spoqa-han-sans/css/SpoqaHanSans-kr.css' rel='stylesheet' type='text/css'>
    <!-- css -->
    <?php include_once $this->dir."page/adm/inc/common_css.php"; ?>
    
	<!-- script -->
    <?php include_once $this->dir."page/adm/inc/common_js.php"; ?>
</head>
<body>
    <img id = "img" style = "width: 100%; height:100%;" src="">
</body>
<script>
    document.getElementById("img").src = data.img;
    console.log(data.img);
</script>
</html>