<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>쿠폰 카테고리 설정</title>
	<!-- font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
	<link href='//spoqa.github.io/spoqa-han-sans/css/SpoqaHanSans-kr.css' rel='stylesheet' type='text/css'>

	<!-- css -->
	<?php include_once $this->dir."page/adm/inc/common_css.php"; ?>
	<script>
        var data = <?php echo $data;?>
	</script>
	<!-- script -->
	<?php include_once $this->dir."page/adm/inc/common_js.php"; ?>
	<script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/promotion_coupon_category_popup.js<?php echo $version;?>"></script>
</head>
<body>
	<div class="wrap" style="background-color:#e8edf3">
		<?php include_once $dir."page/adm/include/adm_member_header.php";?>
		<div class = "wrap">
			<div class ="bd">
				<article>
					<form class = "form">
						<div class = "row">
							<div class="col-md-12">
								<div class = "body-box mt-1">
									<div class="box-search-container mt-2">
										<div>
											<h1>대분류</h1>
										</div>
										<div class="insert insert-select mt-1">
											<select class="select-custom" id = "select_0" type="text">
												<option value = "0">대분류를 선택해주세요</option>
											</select>
										</div>
									</div>
									<div class="box-search-container mt-2" style = "display:none">
										<div>
											<h1>중분류</h1>
										</div>
										<div class="insert insert-select mt-1">
											<select class="select-custom" id = "select_1" type="text">
												<option value = "0">중분류를 선택해주세요</option>
											</select>
										</div>
									</div>
									<div class="box-search-container mt-2" style = "display:none">
										<div>
											<h1>소분류</h1>
										</div>
										<div class="insert insert-select mt-1">
											<select class="select-custom" id = "select_2" type="text">
												<option value = "0">소분류를 선택해주세요</option>
											</select>
										</div>
									</div>
									<div class="box-search-container mt-2" style = "display:none">
										<div>
											<h1>세분류</h1>
										</div>
										<div class="insert insert-select mt-1">
											<select class="select-custom" id = "select_3" type="text">
												<option value = "0">세분류를 선택해주세요</option>
											</select>
										</div>
									</div>
									<div class="insert-wrap align-center mt-3">
										<div class="insert insert-input-btn" id = "cancel_btn"><input class="btn-default" type="button" value="취소"/></div>
										<div class="insert insert-input-btn" id = "select_btn"><input class="btn-primary" type="button" value="선택"/></div>
									</div>
								</div>
							</div>
						</div>
					</form>
				</article>
			</div>
		</div>
	</div>
</body>

<!-- select2 -->
<link rel="stylesheet" type="text/css" href="<?php echo $this->project_admin_path;?>layout/select2/css/select2.min.css"/>
<link rel="stylesheet" type="text/css" href="common_css/adm/adm_select.css?<?php echo $version;?>"/>
<style>
	.select2.select2-container.select2-container--default{
		width :100% !important;
	}
</style>
<script type="text/javascript" src="<?php echo $this->project_admin_path;?>layout/select2/js/select2.full.min.js"></script>
<script type="text/javascript">
	$(document).ready(function() {
        $('.select-custom').select2({
            minimumResultsForSearch: -1
        });
    });
</script>
</html>