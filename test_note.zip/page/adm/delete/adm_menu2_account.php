<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<title>무통장입금계좌 설정</title>
	<!-- font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
	<link href='//spoqa.github.io/spoqa-han-sans/css/SpoqaHanSans-kr.css' rel='stylesheet' type='text/css'>

	<!-- css -->
	<?php include_once $this->dir."page/adm/inc/common_css.php"; ?>

	<!-- script -->
	<?php include_once $this->dir."page/adm/inc/common_js.php"; ?>
	<script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/menu2_account.js<?php echo $version;?>"></script>
	
</head>
<body>
	<div class="wrap">
        <?php include_once $dir."page/adm/include/adm_aside.php";?>
			<div class="bd">
				<article class="body-container">
					<div class="body-head"><h2>무통장입금계좌 설정</h2></div>
					<form class="form">
						<div class="body-box">
							<div class="box-table-container">
								<dl class="box-tbody">
									<dt class="box-th box-head"><p class="medium">입금기한 설정</p></dt>
									<dd class="box-td">
										<ul class="insert-wrap">
											<li class="insert insert-select">
												<select class="select-custom" id="deposit_day">
													<option value="1">1일</option>
													<option value="2">2일</option>
													<option value="3">3일</option>
													<option value="4">4일</option>
													<option value="5">5일</option>
												</select>
												<div class="insert insert-input-btn"><input class="btn-disabled" type="button" value="저장" id="btn_deposit_day_save"></div>
											</li>
										</ul>
									</dd>
								</dl>
								<dl class="box-tbody">
									<dt class="box-th box-head"><p class="medium">등록한 계좌번호</p></dt>
									<dd class="box-td">
										<div class="insert insert-select">
											<select class="select-list" size="4" id="deposit_account_list">
												<!-- <option value="독수리">독수리</option>
												<option value="매">매</option>
												<option value="까치">까치</option>
												<option value="두루미">두루미</option>
												<option value="까마귀">까마귀</option>
												<option value="참새">참새</option>
												<option value="뻐꾸기">뻐꾸기</option>
												<option value="왕뿌리새">왕뿌리새</option> -->
											</select>
										</div>
										<div class="insert-wrap mt-1">
											<div class="insert insert-input-btn"><input class="btn-default btn-32" type="button" value="선택삭제" onclick="delete_deposit_account()"/></div>
										</div>
									</dd>
								</dl>
							</div>
						</div>
						<div class="body-box mt-3">
							<div class="box-tit mb-2"><h3>계좌번호 등록</h3></div>
							<div class="box-table-container">
								<dl class="box-tbody">
									<dt class="box-th box-head"><p class="medium">은행선택</p></dt>
									<dd class="box-td">
										<ul class="insert-wrap">
											<li class="insert insert-select">
												<select class="select-custom" id="bank_list">
													<!-- <option value="1">국민은행</option>
													<option value="2">기업은행</option>
													<option value="3">외환은행</option>
													<option value="4">신한은행</option>
													<option value="5">우리은행</option>
													<option value="6">SC제일은행</option>
													<option value="7">하나은행</option>
													<option value="8">한국씨티은행</option>
													<option value="9">농협중앙회</option>
													<option value="10">수협중앙회</option>
													<option value="11">부산은행</option>
													<option value="12">대구은행</option>
													<option value="13">광주은행</option>
													<option value="14">전북은행</option>
													<option value="15">경남은행</option>
													<option value="16">우체국</option> -->
												</select>
											</li>
											
										</ul>
									</dd>
								</dl>
								<dl class="box-tbody">
									<dt class="box-th box-head"><p class="medium">계좌번호</p></dt>
									<dd class="box-td">
										<ul class="insert-wrap">
											<li class="insert insert-input">
												<input class="input-sm" type="text" id="account_number"/>
												<p class="mt-1 xsmall">'-'을 추가하여 입력하세요. ex) 123-4567-891011</p>
											</li>
										</ul>
									</dd>
								</dl>
								<dl class="box-tbody">
									<dt class="box-th box-head"><p class="medium">예금주</p></dt>
									<dd class="box-td">
										<ul class="insert-wrap">
											<li class="insert insert-input">
												<input class="input-xs" type="text" id="depositor"/>
											</li>
										</ul>
									</dd>
								</dl>
							</div>
							<div class="insert-wrap mt-2">
								<div class="insert insert-input-btn"><input class="btn-primary" type="button" value="계좌등록" onclick="add_deposit_account()"></div>
                            </div>
						</div>
					</form>
				</article>
			</div>
	</div>

</body>
<!-- select2 -->
<link rel="stylesheet" type="text/css" href="<?php echo $this->project_admin_path;?>layout/select2/css/select2.min.css"/>
<link rel="stylesheet" type="text/css" href="common_css/adm/adm_select.css?<?php echo $version;?>"/>
<script type="text/javascript" src="<?php echo $this->project_admin_path;?>layout/select2/js/select2.full.min.js"></script>
<script type="text/javascript">
	$(document).ready(function() {
        $('.select-custom').select2({
            minimumResultsForSearch: -1
        });
    });
</script>
</html>