<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>회원 1:1문의</title>
	<!-- font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
	<link href='//spoqa.github.io/spoqa-han-sans/css/SpoqaHanSans-kr.css' rel='stylesheet' type='text/css'>

	<!-- css -->
	<?php include_once $this->dir."page/adm/inc/common_css.php"; ?>
	<!-- script -->
    <?php include_once $this->dir."page/adm/inc/common_js.php"; ?>
    <script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/popup_init.js<?php echo $version;?>"></script>
    <script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/popup_1to1.js<?php echo $version;?>"></script>
</head>
<body>
    <div class="modal user-modal d-none">
        <div class="modal-wrap">
            <div class="modal-container">
                <span class="modal-close" onclick = "">&#10005;</span><!-- 모달 닫기 // -->
                <!-- 모달 본문 -->
                <div class="modal-container-inner">
                    <div class="align-center"><img src="<?php echo $this->project_admin_path;?>images/sample2.png" onerror="this.style.display='none'" alt="img_load"></div>
                </div>
                <!-- 모달 본문 // -->
            </div>
        </div>
    </div>
    <!-- 첨부이미지 확대 모달 // -->
	<div class="wrap" style="background-color:#e8edf3">
		<?php include_once $dir."page/adm/include/adm_member_header.php";?>
		<?php include_once $dir."page/adm/include/adm_member_aside.php";?>
        <div class="bd">
            <article class="body-container">
                <div class="body-head"><h2>1:1문의</h2></div>
                <form class="form">
                    <div class="row">
                        <div class="col-md-7">
                            <div class="body-box">
                                <div class="table-container">
                                    <table class="table3">
                                        <thead>
                                            <tr>
                                                <th>번호</th>
                                                <th>분류</th>
                                                <th>주문번호</th>
                                                <th class="col-tit">제목</th>
                                                <th>등록일시</th>
                                                <th>답변일시</th>
                                            </tr>
                                        </thead>
                                        <tbody data-wrap = "wrap" id = "wrap">
                                            <!-- <tr class="current">
                                                <td class="col-num">1</td>
                                                <td class="col-short-num">배송</td>
                                                <td class="col-long-num">1234567890</td>
                                                <td class="col-tit">
                                                    <div>
                                                        <p class="tit"><span class="bold c-pointer ellipsis" onclick="">제목 들어갑니다.</span></p>
                                                    </div>
                                                </td>
                                                <td class="col-long-num">20.03.24 18:00:06</td>
                                                <td class="col-long-num">20.03.24 18:12:06</td>
                                            </tr> -->
                                            <!-- 2 // -->
                                        </tbody>
                                    </table>
                                </div>
                                <div class="pagination_container mt-3" id ="paging">
                                    <!-- <div class="page_item arrow prev">«</div>
                                    <div class="page_item active">1</div>
                                    <div class="page_item arrow next">»</div> -->
                                </div>
                            </div>
                        </div>
                        <div class="col-md-5">
                            <div class="body-box">
                                <div class="box-table-container box-table-container2">
                                    <div class="box-tit mb-1"><h3>질문</h3></div>
                                    <!-- <dl class="box-tbody">
                                        <dt class="box-th box-head">
                                            <p>상품</p>
                                        </dt>
                                        <dd class="box-td">
                                            <p class="c-pointer" onclick="" id = "d_product_name">상품명이 들어갑니다.</p>
                                        </dd>
                                    </dl> -->
                                    <dl class="box-tbody">
                                        <dt class="box-th box-head">
                                            <p>제목</p>
                                        </dt>
                                        <dd class="box-td">
                                            <p class="bold" id = "d_title"></p>
                                        </dd>
                                    </dl>
                                    <dl class="box-tbody">
                                        <dt class="box-th box-head">
                                            <p>등록일</p>
                                        </dt>
                                        <dd class="box-td">
                                            <p class="" id = "d_regdate"></p>
                                        </dd>
                                    </dl>
                                    <dl class="box-tbody">
                                        <dt class="box-th box-head">
                                            <p>문의내용</p>
                                        </dt>
                                        <dd class="box-td">
                                            <div class="insert insert-textarea">
                                                <textarea readonly id = "d_content"></textarea>
                                            </div>
                                        </dd>
                                    </dl>
                                    <dl class="box-tbody">
                                        <dt class="box-th box-head">
                                            <p>첨부이미지</p>
                                        </dt>
                                        <dd class="box-td">
                                            <div data-wrap = "img_wrap" id = "img_wrap">
                                                <!-- <div class="img-load" style="overflow: hidden;">
                                                    <img src="<?php echo $this->project_path;?>/images/sample.png" onerror="this.style.display='none'" alt="img_load">
                                                </div> -->
                                                <!-- 이미지 1 // -->
                                            </div>
                                            <p class="xsmall">이미지를 클릭하면 확대되어 나타납니다.</p>
                                        </dd>
                                    </dl>
                                </div>
                                <!-- 질문 // -->
                                <div class="box-table-container box-table-container2 mt-3">
                                    <div class="box-tit mb-1"><h3>답변</h3></div>
                                    <dl class="box-tbody">
                                        <dt class="box-th box-head">
                                            <p>답변일</p>
                                        </dt>
                                        <dd class="box-td">
                                            <p id = "d_answer_date"></p>
                                        </dd>
                                    </dl>
                                    <dl class="box-tbody">
                                        <dt class="box-th box-head">
                                            <p>답변내용</p>
                                        </dt>
                                        <dd class="box-td">
                                            <div class="insert insert-textarea">
                                                <textarea id = "d_answer"></textarea>
                                            </div>
                                        </dd>
                                    </dl>
                                </div>
                                <!-- 답변 // -->
                                <div class="insert-wrap mt-2 align-center">
                                    <div class="insert insert-input-btn"><input id = "answer_btn" class="btn-primary" type="button" value="완료"></div>
                                    <div class="insert insert-input-btn"><input id = "refresh_btn" class="btn-default" type="button" value="취소"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </article>
        </div>
    </div>
    
    <div style = "display:none;">
        <table>
            <tr data-copy="copy"><!-- 질문내용을 클릭해서 볼 경우 class 추가 "current" -->
                <td class="col-num" data-attr="num">1</td>
                <td class="col-short-num" data-attr="kind">배송</td>
                <td class="col-long-num" data-attr="order_number">1234567890</td>
                <td class="col-tit">
                    <div>
                        <p class="tit"><span class="bold c-pointer ellipsis" onclick="" data-attr="title">제목 들어갑니다.</span></p>
                    </div>
                </td>
                <td class="col-long-num" data-attr="regdate">20.03.24 18:00:06</td>
                <td class="col-long-num" data-attr="answer_date">20.03.24 18:12:06</td>
            </tr>
        </table>

        <div class="img-load" style="overflow: hidden;" data-copy = "img_copy">
            <img src="<?php echo $this->project_path;?>/images/sample.png" data-attr="img" alt="img_load">
        </div>
    </div>
</body>
</html>