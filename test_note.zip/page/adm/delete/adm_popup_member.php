<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>회원 상세주문서</title>
	<!-- font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
	<link href='//spoqa.github.io/spoqa-han-sans/css/SpoqaHanSans-kr.css' rel='sstylesheet' type='text/css'>
	<!-- css -->
	<?php include_once $this->dir."page/adm/inc/common_css.php"; ?>
	<!-- script -->
	<?php include_once $this->dir."page/adm/inc/common_js.php"; ?>
	<script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/popup_init.js<?php echo $version;?>"></script>
	<script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/popup_member.js<?php echo $version;?>"></script>
</head>
<body>
	<div class="wrap" style="background-color:#e8edf3">
		<?php include_once $dir."page/adm/include/adm_member_header.php";?>
		<?php include_once $dir."page/adm/include/adm_member_aside.php";?>
		<div class="bd">
			<article class="body-container">
				<div class="body-head"><h2>주문내역</h2></div>
				<form class="form">
					<div class="body-box">
						<div class="table-container">
							<table class="table3">
								<thead>
									<tr>
										<th>
											<div class="insert insert-chk">
												<label class="check_label">
													<input type="checkbox">
													<span class="checkmark"></span>
												</label>
											</div>
										</th>
										<th>번호</th>
										<th>주문번호</th>
										<th class="col-tit">주문상품</th>
										<th>주문일시</th>
										<th>연락처</th>
										<th>총 주문액</th>
										<th>실결제액</th>
										<th>결제수단</th>
										<th>상태</th>
									</tr>
								</thead>
								<tbody data-wrap="wrap" id = "wrap">
									<!-- <tr>
										<td>
											<div class="insert insert-chk">
												<label class="check_label">
													<input type="checkbox">
													<span class="checkmark"></span>
												</label>
											</div>
										</td>
										<td>1</td>
										<td class="col-long-num">123456789</td>
										<td class="col-tit">
											<div class="table-tit">
												<p class="tit"><span class="ellipsis" onclick="">제품타이틀입니다.</span></p>
											</div>
										</td>
										<td class="col-long-num"><div class="table-date">20.03.20 16:00:04</div></td>
										<td class="col-long-num">01030215554</td>
										<td><div class="table-won">19,000</div></td>
										<td><div class="table-won">19,000</div></td>
										<td>
											<div class="table-pay-method">
												<span class="pay-method-con card">신용카드</span>
												<span class="pay-method-con account">무통장</span>
												<span class="pay-method-con transfer">이체</span>
												<span class="pay-method-con point">적립금</span>
												<span class="pay-method-con coupon">쿠폰</span>
											</div>
										</td>
										<td>입금완료</td>
									</tr> -->
									<!-- 1 // -->
								</tbody>
							</table>
						</div>
						<div class="pagination_container mt-3" id ="paging">
							<!-- <div class="page_item arrow prev">«</div>
							<div class="page_item active">1</div>
							<div class="page_item ">2</div>
							<div class="page_item arrow next">»</div> -->
						</div>
					</div>
				</form>
			</article>
		</div>
	</div>

	<div style ="display:none;">
		<table>
			<tr data-copy = "copy">
				<td>
					<div class="insert insert-chk">
						<label class="check_label">
							<input type="checkbox">
							<span class="checkmark"></span>
						</label>
					</div>
				</td>
				<td data-attr="num">1</td>
				<td class="col-long-num" data-attr="order_number">123456789</td>
				<td class="col-tit">
					<div class="table-tit">
						<p class="tit"><span class="ellipsis" onclick="" data-attr="products">제품타이틀입니다.</span></p>
					</div>
				</td>
				<td class="col-long-num"><div class="table-date" data-attr="regdate">20.03.20 16:00:04</div></td>
				<td class="col-long-num" data-attr="phone_number">01030215554</td>
				<td><div class="table-won" data-attr="total_order_price">19,000</div></td>
				<td><div class="table-won" data-attr="total_price">19,000</div></td>
				<td>
					<div class="table-pay-method" data-attr="pay_type">
						<span class="pay-method-con card">신용카드</span>
						<span class="pay-method-con account">무통장</span>
						<span class="pay-method-con transfer">이체</span>
						<span class="pay-method-con point">적립금</span>
						<span class="pay-method-con coupon">쿠폰</span>
					</div>
				</td>
				<td data-attr="state">입금완료</td>
			</tr>

		</table>
		
	</div>
</body>

</html>