<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<title>현금영수증 관리</title>
	<!-- font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
	<link href='//spoqa.github.io/spoqa-han-sans/css/SpoqaHanSans-kr.css' rel='stylesheet' type='text/css'>
	<!-- css -->
	<?php include_once $this->dir."page/adm/inc/common_css.php"; ?>
	<link rel="stylesheet" type="text/css" href="common_css/adm/jquery-ui.min.css?<?php echo $version;?>"/>
	<!-- script -->
    <?php include_once $this->dir."page/adm/inc/common_js.php"; ?>
	<script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/jquery-ui.min.js<?php echo $version;?>"></script>
    <script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/datepicker-ko.js<?php echo $version;?>"></script>
	<script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/menu4_cash_receipt.js<?php echo $version;?>"></script>
</head>
<body>
	<div class="wrap">
        <?php include_once $dir."page/adm/include/adm_menu4_aside.php";?>
        <div class="bd">
            <article class="body-container">
                <div class="body-head"><h2>현금영수증 관리</h2></div>
                <form class="form">
                    <div class="body-box mb-3">
                        <div class="box-table-container">
                            <dl class="box-tbody">
                                <dt class="box-th box-head"><p>발급상태</p></dt>
                                <dd class="box-td">
                                    <div class="insert">
                                        <div class="insert-wrap">
                                            <div class="insert insert-chk">
                                                <label class="check_label" for="issue_all">전체
                                                    <input type="radio" id="issue_all" value="issue_all" name="issue_state"/>
                                                    <span class="checkmark radio"></span>
                                                </label>
                                            </div>
                                            <div class="insert insert-chk">
                                                <label class="check_label" for="issue_not">미발급
                                                    <input type="radio" id="issue_not" value="issue_not" name="issue_state"/>
                                                    <span class="checkmark radio"></span>
                                                </label>
                                            </div>
                                            <div class="insert insert-chk">
                                                <label class="check_label" for="issue_complete">발급완료
                                                    <input type="radio" id="issue_complete" value="issue_complete" name="issue_state"/>
                                                    <span class="checkmark radio"></span>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </dd>
                            </dl>
                            <dl class="box-tbody">
                                <dt class="box-th box-head"><p>주문상태</p></dt>
                                <dd class="box-td">
                                    <div class="insert">
                                        <div class="insert-wrap">
                                            <div class="insert insert-chk">
                                                <label class="check_label" for="order_all">전체
                                                    <input type="radio" id="order_all" value="order_all" name="order_state"/>
                                                    <span class="checkmark radio"></span>
                                                </label>
                                            </div>
                                            <div class="insert insert-chk">
                                                <label class="check_label" for="order_not_deposit">미입금
                                                    <input type="radio" id="order_not_deposit" value="order_not_deposit" name="order_state"/>
                                                    <span class="checkmark radio"></span>
                                                </label>
                                            </div>
                                            <div class="insert insert-chk">
                                                <label class="check_label" for="order_deposit_complete">입금완료
                                                    <input type="radio" id="order_deposit_complete" value="order_deposit_complete" name="order_state"/>
                                                    <span class="checkmark radio"></span>
                                                </label>
                                            </div>
                                            <div class="insert insert-chk">
                                                <label class="check_label" for="order_ready">상품준비중
                                                    <input type="radio" id="order_ready" value="order_ready" name="order_state"/>
                                                    <span class="checkmark radio"></span>
                                                </label>
                                            </div>
                                            <div class="insert insert-chk">
                                                <label class="check_label" for="order_shipping">배송중
                                                    <input type="radio" id="order_shipping" value="order_shipping" name="order_state"/>
                                                    <span class="checkmark radio"></span>
                                                </label>
                                            </div>
                                            <div class="insert insert-chk">
                                                <label class="check_label" for="order_complete">배송완료
                                                    <input type="radio" id="order_complete" value="order_complete" name="order_state"/>
                                                    <span class="checkmark radio"></span>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </dd>
                            </dl>
                            <dl class="box-tbody">
                                <dt class="box-th box-head"><p>기간</p></dt>
                                <dd class="box-td">
                                    <ul class="insert-wrap">
                                        <li class="insert">
                                            <select class="select-custom" id ="date_select_kind" type="text">
                                                <option value = "cash_receipt_regdate">신청일기준</option>
                                                <option value = "regdate">주문일기준</option>
                                            </select>
                                        </li>
                                        <li class="insert insert-chk">
                                            <label class="check_label" for="all_search">전체
                                                <input type="radio" id="all_search" value="all_search" name="condition">
                                                <span class="checkmark radio"></span>
                                            </label>
                                        </li>
                                        <li class="insert insert-chk">
                                            <label class="check_label" for="today">오늘
                                                <input type="radio" id="today" value="today" name="condition">
                                                <span class="checkmark radio"></span>
                                            </label>
                                        </li>
                                        <li class="insert insert-chk">
                                            <label class="check_label" for="1month">1개월
                                                <input type="radio" id="1month" value="1month" name="condition">
                                                <span class="checkmark radio"></span>
                                            </label>
                                        </li>
                                        
                                        <li class="insert insert-chk">
                                            <label class="check_label" for="3month">3개월
                                                <input type="radio" id="3month" value="3month" name="condition">
                                                <span class="checkmark radio"></span>
                                            </label>
                                        </li>
                                        <li class="insert insert-chk">
                                            <label class="check_label" for="6month">6개월
                                                <input type="radio" id="6month" value="6month" name="condition">
                                                <span class="checkmark radio"></span>
                                            </label>
                                        </li>
                                        <li class="insert insert-chk">
                                            <label class="check_label" for="year">1년
                                                <input type="radio" id="year" value="year" name="condition">
                                                <span class="checkmark radio"></span>
                                            </label>
                                        </li>
                                    </ul>
                                    <ul class="insert-wrap">
                                        <li class="insert insert-input datepick-wirte"><input id ="start_date" class="input-32 input-xs" type="text"/><i></i></li>
                                        <li class="insert">~</li>
                                        <li class="insert insert-input datepick-wirte"><input id ="end_date" class="input-32 input-xs" type="text"/><i></i></li>
                                    </ul>
                                </dd>
                            </dl>
                        </div>
                        <div class="box-search-container mt-3">
                            <div class="insert-wrap">
                                <div class="insert insert-select">
                                    <select class="select-custom" id="search_kind" type="text">
                                        <option value = "not_select">선택</option>
                                        <!-- <option>신청번호</option> -->
                                        <option value = "cash_receipt_number">현금영수증 번호</option>
                                        <option value = "order_number">주문번호</option>
                                        <option value = "orderer_name">주문자</option>
                                    </select>
                                </div>
                                <div class="insert insert-input"><input class="input-lg" id = "keyword" type="text"/></div>
                            </div>
                        </div>
                        <div class="insert-wrap align-center mt-3">
                            <div class="insert insert-input-btn"><input class="btn-primary" id = "select_btn" type="button" value="검색"/></div>
                            <div class="insert insert-input-btn"><input class="btn-default" id = "init_btn" type="button" value="초기화"/></div>
                        </div>
                    </div>
                    <div class="body-out mb-3">
                        <div class="out-tit-container">
                            <h4 class="medium bold"><b id = "total_count"></b>건이 검색되었습니다.</h4>
                        </div>
                        <div class="insert-wrap mb-1">
                            <div class="insert insert-input-btn"><input class="btn-xlsx" type="button" onclick ="excel_download();" value="엑셀다운로드"/></div>
                        </div>
                    </div>
                    <div class="body-box mt-3">
                        <div class="table-container">
                            <table class="table3">
                                <thead>
                                    <tr>
                                        <th>번호</th>
                                        <th>주문번호</th>
                                        <th>신청일시</th>
                                        <th>거래자 구분</th>
                                        <th>현금영수증 번호</th>
                                        <th>주문자</th>
                                        <th>총 결제액</th>
                                        <th>결제수단</th>
                                        <th>주문상태</th>
                                        <th>발급상태</th>
                                    </tr>
                                </thead>
                                <tbody data-wrap = "wrap" id = "wrap">
                                    <!-- <tr>
                                        <td>
                                            <div class="insert insert-chk">
                                                <label class="check_label">
                                                    <input type="checkbox">
                                                    <span class="checkmark"></span>
                                                </label>
                                            </div>
                                        </td>
                                        <td class="col-num">1</td>
                                        <td class="col-long-num">123456789</td>
                                        <td class="col-long-num"><div class="table-date">20.03.20 16:00:04</div></td>
                                        <td class="col-long-num">-</td>
                                        <td class="col-long-num">01030215554</td>
                                        <td>하예든</td>
                                        <td ><div class="table-won">19,000</div></td>
                                        <td>
                                            <div class="table-pay-method">
                                                <span class="pay-method-con account">무통장</span>
                                            </div>
                                        </td>
                                        <td><div>입금완료</div></td>
                                        <td>미발급<input class="btn-default btn-32 ml-1" type="button" value="발급" data-attr="btn_option"></td>
                                        
                                    </tr> -->
                                    <!-- 1 // -->
                                </tbody>
                            </table>
                        </div>
                        <div class="pagination_container mt-3" id = "paging">
                            <!-- <div class="page_item arrow prev">«</div>
                            <div class="page_item active">1</div>
                            <div class="page_item ">2</div>
                            <div class="page_item arrow next">»</div> -->
                        </div>
                    </div>
                </form>
            </article>
        </div>
    </div>
    <div style = "display:none;">
        <table>
            <tr data-copy = "copy">
                <td class="col-num" data-attr="num"></td>
                <td class="col-long-num" data-attr="order_number"></td>
                <td class="col-long-num"><div class="table-date" data-attr="receipt_regdate"></div></td>
                <td class="col-long-num" data-attr="cash_receipt_trader_kind"></td>
                <td class="col-long-num" data-attr="cash_receipt_number"></td>
                <td data-attr="orderer_name"></td>
                <td ><div class="table-won" data-attr="total_price"></div></td>
                <td>
                    <div class="table-pay-method"  data-attr="pay_type">
                        <span class="pay-method-con account" style = "display:none;">무통장</span>
                        <span class="pay-method-con card"style = "display:none;">신용카드</span>
                        <span class="pay-method-con account"style = "display:none;">무통장</span>
                        <span class="pay-method-con transfer"style = "display:none;">이체</span>
                    </div>
                </td>
                <td><div data-attr="state"></div></td>
                <td><span data-attr="receipt_state">미발급</span><input class="btn-default btn-32 ml-1" type="button" value="발급" data-attr="btn_option"></td>
                <!-- value 값만 변경하시면 됩니다. '발급완료' 되었을 때는 '취소' -->
            </tr>
        </table>
    </div>
</body>
<!-- select2 -->
<link rel="stylesheet" type="text/css" href="<?php echo $this->project_admin_path;?>layout/select2/css/select2.min.css"/>
<link rel="stylesheet" type="text/css" href="common_css/adm/adm_select.css?<?php echo $version;?>"/>
<script type="text/javascript" src="<?php echo $this->project_admin_path;?>layout/select2/js/select2.full.min.js"></script>
<script type="text/javascript">
	$(document).ready(function() {
        $('.select-custom').select2({
            minimumResultsForSearch: -1
        });
    });
</script>
</html>