<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<title>쿠폰사용 설정</title>
	<!-- font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
	<link href='//spoqa.github.io/spoqa-han-sans/css/SpoqaHanSans-kr.css' rel='stylesheet' type='text/css'>

	<!-- css -->
	<?php include_once $this->dir."page/adm/inc/common_css.php"; ?>

	<!-- script -->
	<?php include_once $this->dir."page/adm/inc/common_js.php"; ?>
    <script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/menu4_coupon.js"></script>
	
</head>
<body>
	<div class="wrap">
        <?php include_once $dir."page/adm/include/adm_menu4_aside.php";?>
        <div class="bd">
            <article class="body-container">
                <div class="body-head"><h2>쿠폰사용 설정</h2></div>
                <form class="form">
                    <div class="body-box">
                        <div class="box-table-container">
                            <dl class="box-tbody">
                                <dt class="box-th box-head">
                                    <p class="medium">쿠폰사용</p>
                                </dt>
                                <dd class="box-td">
                                    <div class="insert-wrap">
                                        <div class="insert insert-chk">
                                            <label class="check_label" for="all">전체결제
                                                <input type="radio" name="coupon" value = "2" id="all">
                                                <span class="checkmark radio"></span>
                                            </label>
                                        </div>
                                        <div class="insert insert-chk">
                                            <label class="check_label" for="bank">무통장입금
                                                <input type="radio" name="coupon" value ="1" id="bank">
                                                <span class="checkmark radio"></span>
                                            </label>
                                        </div>
                                        <div class="insert insert-chk">
                                            <label class="check_label" for="not">사용불가
                                                <input type="radio" name="coupon" value = "0" id="not">
                                                <span class="checkmark radio"></span>
                                            </label>
                                        </div>
                                    </div>
                                </dd>
                            </dl>
                        </div>
                        <!-- <div class="insert-wrap mt-2">
                            <div class="insert insert-chk">
                                <label class="check_label">할인 중에 쿠폰과 중복사용 가능
                                    <input type="checkbox" id = "coupon_discount_dup">
                                    <span class="checkmark"></span>
                                </label>
                            </div>
                        </div> -->
                    </div>
                </form>
                <div class="btn-container align-right mt-3"><button type="button" id = "save_btn" class="btn btn-primary">저장하기</button></div>
            </article>
        </div>
    </div>
</body>
</html>