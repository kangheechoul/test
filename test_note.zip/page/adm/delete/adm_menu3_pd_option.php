<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<title>상품등록</title>
	<!-- font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
	<link href='//spoqa.github.io/spoqa-han-sans/css/SpoqaHanSans-kr.css' rel='stylesheet' type='text/css'>

	<!-- css -->
	<?php include_once $this->dir."page/adm/inc/common_css.php"; ?>

	<!-- script -->
	<?php include_once $this->dir."page/adm/inc/common_js.php"; ?>
	<script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/menu3_pd_option.js<?php echo $version;?>"></script>
	
</head>
<body>
	<div class="modal user-modal" id="reg_modal" style="display:none;">
		<div class="modal-wrap modal-sm">
			<div class="modal-container">
				<!-- 모달 본문 -->
				<div class="modal-container-inner">
					<div class="modal-head bold" id="reg_modal_title">옵션생성</div>
					<div class="modal-body">
						<form class="form" id="reg_form">
							<div class="box-table-container">
								<div class="mt-2" data-wrap="reg_input_view">
									<!-- <div class="insert insert-input">
										<p class="mb-1 bold">옵션명</p>
										<input type="text" class="input-sm">
									</div> -->
								</div>
								<!-- 옵션명 1 // -->
								<div class="mt-2">
									<div class="insert insert-input">
										<p class="mb-1 bold">옵션금액</p>
										<input type="text" class="input-lg" id="reg_price" onkeyup="lb.validate_number(this)">
									</div>
								</div>
								<!-- 옵션 금액 // -->
								<div class="mt-2">
									<ul class="insert-wrap">
										<li class="insert insert-chk">
											<label class="check_label" for="reg_option_is_stock_on">재고 사용
												<input type="radio" id="reg_option_is_stock_on" name="reg_is_stock" value="1" onchange="change_stock_ui(0,this.value)">
												<span class="checkmark radio"></span>
											</label>
										</li>
										<li class="insert insert-chk">
											<label class="check_label" for="reg_option_is_stock_off">재고 사용안함
												<input type="radio" id="reg_option_is_stock_off" name="reg_is_stock" value="0" onchange="change_stock_ui(0,this.value)" checked>
												<span class="checkmark radio"></span>
											</label>
										</li>
									</ul>
								</div>
								<div class="mt-2">
									<div class="insert insert-input">
										<p class="mb-1 bold">재고설정(재고 사용시 값을 넣지않으면 0으로 처리됩니다)</p>
										<input type="text" class="input-lg" id="reg_stock" onkeyup="lb.validate_number(this)" disabled="true">
									</div>
								</div>
							</div>
						</div>
					</form>
					<ul class="btn-container align-right">
						<li><button type="button" class="btn btn-ghost" onclick ="reg_modal_hide()">취소</button></li>
						<li><button type="button" class="btn btn-primary" onclick="add_option()">등록</button></li>
					</ul>
				</div>
				<!-- 모달 본문 // -->
			</div>
		</div>
	</div>
	<div class="modal user-modal" id="modify_modal" style="display:none;">
		<div class="modal-wrap modal-sm">
			<div class="modal-container">
				<!-- 모달 본문 -->
				<div class="modal-container-inner">
					<div class="modal-head bold" id="reg_modal_title">옵션생성</div>
					<div class="modal-body">
						<form class="form" id="reg_form">
							<div class="box-table-container">
								<div class="mt-2">
									<div class="insert insert-input">
										<p class="mb-1 bold">재고설정(재고 사용시 값을 넣지않으면 0으로 처리됩니다)</p>
										<input type="text" class="input-lg" id="modify_stock" onkeyup="lb.validate_number(this)">
									</div>
								</div>
							</div>
						</div>
					</form>
					<ul class="btn-container align-right">
						<li><button type="button" class="btn btn-ghost" onclick ="modify_modal_hide()">취소</button></li>
						<li><button type="button" class="btn btn-primary" id="btn_modify">등록</button></li>
					</ul>
				</div>
				<!-- 모달 본문 // -->
			</div>
		</div>
	</div>
	
	<div class="wrap">
        <?php include_once $dir."page/adm/include/adm_aside.php";?>
			<div class="bd">
				<article class="body-container">
					<div class="body-head"><h2>옵션설정</h2></div>
					<form class="form" id="form">
						<div class="row">
							<div class="col-md-12">
								<div class="body-box mt-3">
									<div class="box-tit"><h3>옵션</h3></div>
									<ul class="row tog-container category-container">
										<li class="col-md-3">
											<div class="">
												<div class="box-table-container">
													<div>
														<div class="insert insert-select">
															<p class="mb-1 bold">등록된 옵션1</p>
															<select class="select-list" multiple="multiple" size="4" id="option_1" onchange="request_option_list(2, this.value)">
																<!-- <option value="독수리">독수리</option>  -->
															</select>
														</div>
														<div class="insert-wrap mt-1">
															<div class="insert insert-input-btn"><input class="btn-default btn-32" type="button" value="선택삭제" onclick="delete_option(1)"/></div>
															<div class="insert insert-input-btn"><input class="btn-primary btn-32" type="button" value="생성" onclick="reg_modal_show(1)"/></div>
														</div>
													</div>
												</div>
												<!-- 등록된 옵션 // -->
												<div class="box-table-container" id="option_1_modfiy_view">
													<div class="mt-2" data-wrap="option1_input_view">
														<!-- <div class="insert insert-input">
															<p class="mb-1 bold">옵션명</p>
															<input type="text" class="input-sm">
														</div> -->
													</div>
													<div class="mt-2" style="display:none;">
														<div class="insert insert-input">
															<p class="mb-1 bold">옵션금액</p>
															<input type="text" class="input-sm" id="price_1" onkeyup="lb.validate_number(this)" disabled="true">
														</div>
													</div>
													<div id="view_stock_1" style="display:none;">
														<div class="mt-2">
															<ul class="insert-wrap">
																<li class="insert insert-chk">
																	<label class="check_label" for="option_1_is_stock_on">재고 사용
																		<input type="radio" id="option_1_is_stock_on" value="1" name="option_1_is_stock" onchange="change_stock_ui(1,this.value)">
																		<span class="checkmark radio"></span>
																	</label>
																</li>
																<li class="insert insert-chk">
																	<label class="check_label" for="option_1_is_stock_off">재고 사용안함
																		<input type="radio" id="option_1_is_stock_off" value="0" name="option_1_is_stock" onchange="change_stock_ui(1,this.value)" checked>
																		<span class="checkmark radio"></span>
																	</label>
																</li>
															</ul>
														</div>
														<div class="mt-2">
															<div class="insert insert-input">
																<p class="mb-1 bold">재고설정</p>
																<input type="text" class="input-sm" id="stock_1" onkeyup="lb.validate_number(this)" disabled="true">
															</div>
														</div>
													</div>
													<div class="insert-wrap mt-2">
														<div class="insert insert-input-btn"><input class="btn-primary" type="button" value="재고수정" onclick="modify_modal_show(1)"></div>
													</div>
												</div>
												<!-- 수정 // -->

											</div>
										</li>
										<!-- 옵션 // -->
										<li class="col-md-3">
											<div class="">
												<div class="box-table-container">
													<div>
														<div class="insert insert-select">
															<p class="mb-1 bold">등록된 옵션2</p>
															<select class="select-list" multiple="multiple" size="4" id="option_2" onchange="request_option_list(3, this.value)">
																<!-- <option value="독수리">독수리</option> -->
															</select>
														</div>
														<div class="insert-wrap mt-1">
															<div class="insert insert-input-btn"><input class="btn-default btn-32" type="button" value="선택삭제" onclick="delete_option(2)"/></div>
															<div class="insert insert-input-btn"><input class="btn-primary btn-32" type="button" value="생성" onclick="reg_modal_show(2)"/></div>
														</div>
													</div>
												</div>
												<!-- 등록된 옵션 // -->
												<div class="box-table-container" id="option_2_modfiy_view">
													<div class="mt-2" data-wrap="option2_input_view">
														<!-- <div class="insert insert-input">
															<p class="mb-1 bold">옵션명</p>
															<input type="text" class="input-sm">
														</div> -->
													</div>
													<div class="mt-2" style="display:none;">
														<div class="insert insert-input">
															<p class="mb-1 bold">옵션금액</p>
															<input type="text" class="input-sm" id="price_2" onkeyup="lb.validate_number(this)" disabled="true">
														</div>
													</div>
													<div id="view_stock_2" style="display:none;">
														<div class="mt-2">
															<ul class="insert-wrap">
																<li class="insert insert-chk">
																	<label class="check_label" for="option_2_is_stock_on">재고 사용
																		<input type="radio" id="option_2_is_stock_on" value="1" name="option_2_is_stock" onchange="change_stock_ui(2,this.value)">
																		<span class="checkmark radio"></span>
																	</label>
																</li>
																<li class="insert insert-chk">
																	<label class="check_label" for="option_2_is_stock_off">재고 사용안함
																		<input type="radio" id="option_2_is_stock_off" value="0" name="option_2_is_stock" onchange="change_stock_ui(2,this.value)" checked>
																		<span class="checkmark radio"></span>
																	</label>
																</li>
															</ul>
														</div>
														<div class="mt-2">
															<div class="insert insert-input">
																<p class="mb-1 bold">재고설정</p>
																<input type="text" class="input-sm" id="stock_2" onkeyup="lb.validate_number(this)" disabled="true">
															</div>
														</div>
													</div>
													
													<div class="insert-wrap mt-2">
														<div class="insert insert-input-btn"><input class="btn-primary" type="button" value="재고수정" onclick="modify_modal_show(2)"></div>
													</div>
												</div>
												<!-- 수정 // -->

											</div>
										</li>
										<!-- 옵션 // -->
										<li class="col-md-3">
											<div class="">
												<div class="box-table-container">
													<div>
														<div class="insert insert-select">
															<p class="mb-1 bold">등록된 옵션3</p>
															<select class="select-list" multiple="multiple" size="4" id="option_3" onchange="request_option_list(4, this.value)">
																<!-- <option value="독수리">독수리</option> -->
															</select>
														</div>
														<div class="insert-wrap mt-1">
															<div class="insert insert-input-btn"><input class="btn-default btn-32" type="button" value="선택삭제" onclick="delete_option(3)"/></div>
															<div class="insert insert-input-btn"><input class="btn-primary btn-32" type="button" value="생성" onclick="reg_modal_show(3)"/></div>
														</div>
													</div>
												</div>
												<!-- 등록된 옵션 // -->
												<div class="box-table-container" id="option_3_modfiy_view">
													<div class="mt-2" data-wrap="option3_input_view">
														<!-- <div class="insert insert-input">
															<p class="mb-1 bold">옵션명</p>
															<input type="text" class="input-sm">
														</div> -->
													</div>
													<div class="mt-2" style="display:none;">
														<div class="insert insert-input">
															<p class="mb-1 bold">옵션금액</p>
															<input type="text" class="input-sm" id="price_3" onkeyup="lb.validate_number(this)" disabled="true">
														</div>
													</div>
													<div id="view_stock_3" style="display:none;">
														<div class="mt-2">
															<ul class="insert-wrap">
																<li class="insert insert-chk">
																	<label class="check_label" for="option_3_is_stock_on">재고 사용
																		<input type="radio" id="option_3_is_stock_on" value="1" name="option_3_is_stock" onchange="change_stock_ui(3,this.value)">
																		<span class="checkmark radio"></span>
																	</label>
																</li>
																<li class="insert insert-chk">
																	<label class="check_label" for="option_3_is_stock_off">재고 사용안함
																		<input type="radio" id="option_3_is_stock_off" value="0" name="option_3_is_stock" onchange="change_stock_ui(3,this.value)" checked>
																		<span class="checkmark radio"></span>
																	</label>
																</li>
															</ul>
														</div>
														<div class="mt-2">
															<div class="insert insert-input">
																<p class="mb-1 bold">재고설정</p>
																<input type="text" class="input-sm" id="stock_3" onkeyup="lb.validate_number(this)" disabled="true">
															</div>
														</div>
													</div>
													<div class="insert-wrap mt-2">
														<div class="insert insert-input-btn"><input class="btn-primary" type="button" value="재고수정" onclick="modify_modal_show(3)"></div>
													</div>
												</div>
												<!-- 수정 // -->
											</div>
										</li>
										<!-- 옵션 // -->
										<li class="col-md-3">
											<div class="">
												<div class="box-table-container">
													<div>
														<div class="insert insert-select">
															<p class="mb-1 bold">등록된 옵션4</p>
															<select class="select-list" multiple="multiple" size="4" id="option_4">
																<!-- <option value="독수리">독수리</option> -->
															</select>
														</div>
														<div class="insert-wrap mt-1">
															<div class="insert insert-input-btn"><input class="btn-default btn-32" type="button" value="선택삭제" onclick="delete_option(4)"/></div>
															<div class="insert insert-input-btn"><input class="btn-primary btn-32" type="button" value="생성" onclick="reg_modal_show(4)"/></div>
														</div>
													</div>
												</div>
												<!-- 등록된 옵션 // -->
												<div class="box-table-container" id="option_4_modfiy_view">
													<div class="mt-2" data-wrap="option4_input_view">
														<!-- <div class="insert insert-input">
															<p class="mb-1 bold">옵션명</p>
															<input type="text" class="input-sm">
														</div> -->
													</div>
													<div class="mt-2" style="display:none;">
														<div class="insert insert-input">
															<p class="mb-1 bold">옵션금액</p>
															<input type="text" class="input-sm" id="price_4" onkeyup="lb.validate_number(this)" disabled="true">
														</div>
													</div>
													<div id="view_stock_4" style="display:none;">
														<div class="mt-2">
															<ul class="insert-wrap">
																<li class="insert insert-chk">
																	<label class="check_label" for="option_4_is_stock_on">재고 사용
																		<input type="radio" id="option_4_is_stock_on" value="1" name="option_4_is_stock" onchange="change_stock_ui(4,this.value)">
																		<span class="checkmark radio"></span>
																	</label>
																</li>
																<li class="insert insert-chk">
																	<label class="check_label" for="option_4_is_stock_off">재고 사용안함
																		<input type="radio" id="option_4_is_stock_off" value="0" name="option_4_is_stock" onchange="change_stock_ui(4,this.value)" checked>
																		<span class="checkmark radio"></span>
																	</label>
																</li>
															</ul>
														</div>
														<div class="mt-2">
															<div class="insert insert-input">
																<p class="mb-1 bold">재고설정</p>
																<input type="text" class="input-sm" id="stock_4" onkeyup="lb.validate_number(this)" disabled="true">
															</div>
														</div>
													</div>
													<div class="insert-wrap mt-2">
														<div class="insert insert-input-btn"><input class="btn-primary" type="button" value="재고수정" onclick="modify_modal_show(4)"></div>
													</div>
												</div>
												<!-- 수정 // -->

											</div>
										</li>
										<!-- 옵션 // -->
										
									</ul>
								</div>
							</div>
						</div>
						<!-- 옵션 // -->
					</form>
					<div class="btn-container align-right mt-3">
						<!-- <button type="button" class="btn btn-ghost">취소</button> -->
						<button type="button" class="btn btn-primary ml-1">목록으로</button>
					</div>
				</article>
			</div>
	</div>
	<div style="display:none">
		<div style="display:none">
			<div class="insert insert-input mb-1" data-copy="input_copy">
				<p class="mb-1 bold">옵션명<i class="i-lang" data-attr="lang">(한국어<img src="<?php echo $this->project_admin_path;?>images/i-kor.png" alt="kor"/>)</i></p>
				<input type="text" class="input-sm" data-attr="input">
			</div>
		</div>
	</div>
</body>
<!-- select2 -->
<link rel="stylesheet" type="text/css" href="<?php echo $this->project_admin_path;?>layout/select2/css/select2.min.css"/>
<link rel="stylesheet" type="text/css" href="common_css/adm/adm_select.css?<?php echo $version;?>"/>
<script type="text/javascript" src="<?php echo $this->project_admin_path;?>layout/select2/js/select2.full.min.js"></script>

<!-- yd custom -->
<script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/custom.js"></script>

</html>