<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<title>쿠폰생성</title>
	<!-- font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
	<link href='//spoqa.github.io/spoqa-han-sans/css/SpoqaHanSans-kr.css' rel='stylesheet' type='text/css'>
	<!-- css -->
	<?php include_once $this->dir."page/adm/inc/common_css.php"; ?>
    <link rel="stylesheet" type="text/css" href="common_css/adm/jquery-ui.min.css?<?php echo $version;?>"/>
    <script>
        var data = <?php echo $data?>;
    </script>
	<!-- script -->
	<?php include_once $this->dir."page/adm/inc/common_js.php"; ?>
    <script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/jquery-ui.min.js<?php echo $version;?>"></script>
    <script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/datepicker-ko.js<?php echo $version;?>"></script>
    <script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/promotion_coupon_upload.js<?php echo $version;?>"></script>
</head>
<body>
	<div class="wrap">
        <?php include_once $dir."page/adm/include/adm_promotion_aside.php";?>
        <div class="bd">
            <article class="body-container">
                <div class="body-head"><h2>쿠폰생성</h2></div>
                <form class="form" id = "form" onsubmit='return false;'>
                    <div class="row"> 
                        <div class="col-md-12">
                            <div class="body-box mt-1">
                                <div class="box-table-container">
                                    <dl class="box-tbody">
                                        <dt class="box-th box-head">
                                            <p>쿠폰 발급방식</p>
                                        </dt>
                                        <dd class="box-td">
                                            <div class="insert-wrap">
                                                <div class="insert insert-chk">
                                                    <label class="check_label" for="download_issue">회원 다운로드
                                                        <input type="radio" id="download_issue" value="1" name="issue_kind"/>
                                                        <span class="checkmark radio"></span>
                                                    </label>
                                                </div>
                                                <div class="insert insert-chk">
                                                    <label class="check_label" for="all_issue">자동발급
                                                        <input type="radio" id="all_issue" value="2" name="issue_kind"/>
                                                        <span class="checkmark radio"></span>
                                                    </label>
                                                </div>
                                                <div class="insert insert-chk">
                                                    <label class="check_label" for="manual_issue">수동발급
                                                        <input type="radio" id="manual_issue" value="3" name="issue_kind"/>
                                                        <span class="checkmark radio"></span>
                                                    </label>
                                                </div>
                                            </div>
                                        </dd>
                                    </dl>
                                    <dl class="box-tbody">
                                        <dt class="box-th box-head">
                                            <p>쿠폰 발급형태</p>
                                        </dt>
                                        <dd class="box-td">
                                            <div class="insert-wrap">
                                                <div class="insert insert-chk">
                                                    <label class="check_label" for="all_grade">전체
                                                        <input type="radio" id="all_grade" value="1" name="grade"/>
                                                        <span class="checkmark radio"></span>
                                                    </label>
                                                </div>
                                                <div class="insert insert-chk">
                                                    <label class="check_label" for="select_grade">회원등급별
                                                        <input type="radio" id="select_grade" value="2" name="grade"/>
                                                        <span class="checkmark radio"></span>
                                                    </label>
                                                </div>
                                                <!-- 회원 등급별을 누르면 아래가 나타납니다 -->
                                                <div class="insert insert-select" style ="display:none;">
                                                    <select class="select-custom" id = "selecting_grade_elem" type="text">
                                                        <option value = "0">선택</option>
                                                        <!-- <option>1등급</option> -->
                                                    </select>
                                                </div>
                                                <!-- 등급별 셀렉트 // -->
                                            </div>
                                        </dd>
                                    </dl>
                                    <dl class="box-tbody">
                                        <dt class="box-th box-head">
                                            <p>할인 구분</p>
                                        </dt>
                                        <dd class="box-td">
                                            <div class="insert-wrap">
                                                <div class="insert insert-chk">
                                                    <label class="check_label" for="all_discount">전체 적용
                                                        <input type="radio" id="all_discount" value="1" name="discount"/>
                                                        <span class="checkmark radio"></span>
                                                    </label>
                                                </div>
                                                <div class="insert insert-chk">
                                                    <label class="check_label" for="select_discount">카테고리별 할인
                                                        <input type="radio" id="select_discount" value="2" name="discount"/>
                                                        <span class="checkmark radio"></span>
                                                    </label>
                                                </div>
                                                <!-- 카테고리별 할인을 누르면 아래가 나타납니다 -->
                                                <div class="insert insert-input-btn" style ="display:none;">
                                                    <input id = "category_btn" class="btn-default" type="button" value="카테고리 선택">
                                                    <input id = "category_select" type = "hidden"/>
                                                    <!-- <p style = "display:inline-block;" id ="category_select"></p> -->
                                                </div>
                                                <!-- 등급별 셀렉트 // -->
                                            </div>
                                        </dd>
                                    </dl>
                                    <dl class="box-tbody">
                                        <dt class="box-th box-head">
                                            <p>무료배송</p>
                                        </dt>
                                        <dd class="box-td">
                                            <div class="insert-wrap">
                                                <div class="insert insert-chk">
                                                    <label class="check_label">무료배송 쿠폰
                                                        <input type="checkbox" id = "delivery_coupon" />
                                                        <span class="checkmark"></span>
                                                    </label>
                                                </div>
                                            </div>
                                        </dd>
                                    </dl>
                                    <!-- 무료배송 쿠폰을 선택시 할인금액(율), 최대할인금액 입력은 disable -->
                                    <dl class="box-tbody">
                                        <dt class="box-th box-head">
                                            <p>할인금액(율)</p>
                                        </dt>
                                        <dd class="box-td">
                                            <div class="insert-wrap">
                                                <div class="insert">
                                                    <input type="text" id = "discount_price" class="input-xs"/>
                                                </div>
                                                <div class="insert insert-select">
                                                    <select class="select-custom" id = "discount_kind" type="text">
                                                        <option value = "1">원</option>
                                                        <option value = "2">%</option>
                                                    </select>
                                                </div>
                                                <div class = "insert" id = "discount_state_wrap" style = "display:none;">
                                                    <div class="insert insert-chk">
                                                        <label class="check_label" for="ceil">올림
                                                            <input type="radio" id="ceil" value="1" name="discount_state"/>
                                                            <span class="checkmark radio"></span>
                                                        </label>
                                                    </div>
                                                    <div class="insert insert-chk">
                                                        <label class="check_label" for="floor">내림
                                                            <input type="radio" id="floor" value="2" name="discount_state"/>
                                                            <span class="checkmark radio"></span>
                                                        </label>
                                                    </div>
                                                    <div class="insert insert-chk">
                                                        <label class="check_label" for="round">반올림
                                                            <input type="radio" id="round" value="3" name="discount_state"/>
                                                            <span class="checkmark radio"></span>
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                        </dd>
                                    </dl>
                                    <dl class="box-tbody">
                                        <dt class="box-th box-head">
                                            <p>최대 할인금액</p>
                                        </dt>
                                        <dd class="box-td">
                                            <div class="insert">
                                                <input type="text" disabled id = "max_discount_price" class="input-xs"/>
                                                <span class="ml-1">원 미만까지 할인</span>
                                            </div>
                                        </dd>
                                    </dl>
                                    <dl class="box-tbody">
                                        <dt class="box-th box-head">
                                            <p>최소 결제금액</p>
                                        </dt>
                                        <dd class="box-td">
                                            <div class="insert">
                                                <input type="text" id = "min_limited_price" class="input-xs"/>
                                                <span class="ml-1">원 이상 결제 시 사용 가능</span>
                                            </div>
                                        </dd>
                                    </dl>
                                    <dl class="box-tbody">
                                        <dt class="box-th box-head">
                                            <p>중복할인</p>
                                        </dt>
                                        <dd class="box-td">
                                            <div class="insert-wrap">
                                                <div class="insert insert-chk">
                                                    <label class="check_label" for="non_limit">제한 없음
                                                        <input type="radio" id="non_limit" value="1" name="limit"/>
                                                        <span class="checkmark radio"></span>
                                                    </label>
                                                </div>
                                                <div class="insert insert-chk">
                                                    <label class="check_label" for="already_discount">이미 할인 중인 상품은 쿠폰 사용 불가
                                                        <input type="radio" id="already_discount" value="2" name="limit"/>
                                                        <span class="checkmark radio"></span>
                                                    </label>
                                                </div>
                                                <div class="insert insert-chk" style = "display:none;">
                                                    <label class="check_label" for="duplication">타 쿠폰 중복 사용 불가
                                                        <input type="radio" id="duplication" value="3" name="limit"/>
                                                        <span class="checkmark radio"></span>
                                                    </label>
                                                </div>
                                            </div>
                                        </dd>
                                    </dl>
                                    <dl class="box-tbody">
                                        <dt class="box-th box-head">
                                            <p>발급기간</p>
                                        </dt>
                                        <dd class="box-td">
                                            <div class="insert-wrap">
                                                <div class="insert insert-chk">
                                                    <label class="check_label">무제한
                                                        <input type="checkbox" id = "issue_date_check"/>
                                                        <span class="checkmark"></span>
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="insert-wrap mt-1">
                                                <div class="insert insert-input datepick-wirte"><input class="input-32 input-xs" id = "issue_start_date" type="text"><i></i></div>
                                                <div class="insert">~</li>
                                                <div class="insert insert-input datepick-wirte"><input class="input-32 input-xs" id = "issue_end_date" type="text"><i></i></div>
                                            </div>
                                        </dd>
                                    </dl>
                                    <dl class="box-tbody">
                                        <dt class="box-th box-head">
                                            <p>사용기간</p>
                                        </dt>
                                        <dd class="box-td">
                                            <div class="insert-wrap">
                                                <div class="insert insert-chk">
                                                    <label class="check_label">무제한
                                                        <input type="checkbox"  id = "use_date_check"/>
                                                        <span class="checkmark"></span>
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="insert-wrap mt-1">
                                                <div class="insert insert-input datepick-wirte"><input class="input-32 input-xs" id = "use_start_date" type="text"><i></i></div>
                                                <div class="insert">~</li>
                                                <div class="insert insert-input datepick-wirte"><input class="input-32 input-xs" id = "use_end_date" type="text"><i></i></div>
                                            </div>
                                            <p class="mt-1 xsmall">이미 발급된 쿠폰은 사용기간을 수정할 수 없습니다.</p>
                                        </dd>
                                    </dl>
                                </div>
                            </div>
                            <!-- 기본정보 // -->
                        </div>
                        <div class="col-md-12">
                            <div class="h-line mt-3 mb-3"></div>
                            <div class="out-tab-container st2 mb-3">
                                <ul data-wrap = "lang_tab_wrap" id = "lang_tab_wrap">
                                    <!-- <li class="current"><a href="#ex">한국어</a></li>
                                    <li onclick = "change_lang(2);"><a href="#ex">영어</a></li>
                                    <li onclick = "change_lang(3);"><a href="#ex">중국어</a></li> -->
                                </ul>
                            </div>
                            <div class="body-box mt-1" data-wrap = "lang_wrap" id = "lang_wrap">

                                <!-- <div class="box-table-container">
                                    <dl class="box-tbody">
                                        <dt class="box-th box-head">
                                            <p>쿠폰명</p>
                                        </dt>
                                        <dd class="box-td">
                                            <div class="insert insert-input">
                                                <input type="text" class="input-sm"/>
                                            </div>
                                        </dd>
                                    </dl>
                                    <dl class="box-tbody">
                                        <dt class="box-th box-head">
                                            <p>쿠폰 이미지</p>
                                        </dt>
                                        <dd class="box-td">
                                            이미지 추가 버튼
                                            <div class="img-upload img-upload-main" style="overflow: hidden;">
                                                <span class="btn-wrap">
                                                    <button class="btn-img-upload" href="#"><strong></strong></button>
                                                    <input type="file" id="upload">
                                                </span> 				
                                                <label for="upload"></label>
                                            </div>
                                            이미지 추가 버튼
                                            이미지가 첨부될 시 옆에 나열됩니다
                                            <div style = "display:inline-block">
                                                <div class="img-upload" style="overflow: hidden;">
                                                    <img src="<?php echo $this->project_path;?>/images/sample.png" onerror="this.style.display='none'" alt="img_upload"/>
                                                    <button class="delete-btn" type="button"></button>
                                                </div>
                                            </div>
                                            <p class="xsmall">jpg, png, gif 형식의 파일확장자<br>4MB 이하의 이미지 1장까지 첨부 가능</p>
                                        </dd>
                                    </dl>
                                </div> -->

                            </div>
                            
                        </div>
                    </div>
                </form>
                <div class="btn-container align-right mt-3">
                    <button type="button" class="btn btn-ghost" onclick = "cancel_btn();">취소</button><!-- 취소 클릭시 쿠폰 관리 페이지로 이동 // -->
                    <button type="button" class="btn btn-primary ml-1" id = "register_btn">저장하기</button>
                </div>
            </article>
        </div>
    </div>
    <div style = "display:none;">
        <li data-copy = "lang_tab_copy"><a href="#ex" data-attr= "name"></a></li>
        <div class="box-table-container" data-copy = "lang_copy">
            <dl class="box-tbody">
                <dt class="box-th box-head">
                    <p>쿠폰명</p>
                </dt>
                <dd class="box-td">
                    <div class="insert insert-input">
                        <input data-attr="name" type="text" class="input-sm"/>
                    </div>
                </dd>
            </dl>
            <dl class="box-tbody">
                <dt class="box-th box-head">
                    <p>쿠폰 이미지</p>
                </dt>
                <dd class="box-td">
                    <!-- 이미지 추가 버튼 -->
                    <div class="img-upload img-upload-main" style="overflow: hidden;">
                        <span class="btn-wrap">
                            <button class="btn-img-upload" href="#"><strong></strong></button>
                            <input type="file" name = "files[]" data-attr="file">
                        </span> 				
                        <label data-attr="file_label"></label>
                    </div>
                    <!-- 이미지 추가 버튼 // -->
                    <!-- 이미지가 첨부될 시 옆에 나열됩니다 -->
                    <div style = "display:inline-block"  data-attr="img_elem">
                        <!-- <div class="img-upload" style="overflow: hidden;" >
                            <img src="<?php echo $this->project_path;?>/images/sample.png" onerror="this.style.display='none'" alt="img_upload"/>
                            <button  data-attr="del_btn" class="delete-btn" type="button"></button>
                        </div> -->
                    </div>
                    <p class="xsmall">jpg, png, gif 형식의 파일확장자<br>4MB 이하의 이미지 1장까지 첨부 가능</p>
                </dd>
            </dl>
        </div>
        <div class="img-upload" style="overflow: hidden;" data-copy = "img_copy">
            <img src="" data-attr="img" alt="img_upload"/>
            <input type="hidden" data-attr="prev_img_url"/>
            <button  data-attr="del_btn" class="delete-btn" type="button"></button>
        </div>
        <div class="img-upload" style="overflow: hidden;" id = "img_copy">
            <img src="" alt="img_upload"/>
            <button class="delete-btn" type="button"></button>
        </div>
    </div>
</body>
<!-- select2 -->
<link rel="stylesheet" type="text/css" href="<?php echo $this->project_admin_path;?>layout/select2/css/select2.min.css"/>
<link rel="stylesheet" type="text/css" href="common_css/adm/adm_select.css?<?php echo $version;?>"/>
<script type="text/javascript" src="<?php echo $this->project_admin_path;?>layout/select2/js/select2.full.min.js"></script>
<!-- yd custom -->
<script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/custom.js"></script>
</html>