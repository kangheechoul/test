<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<title>반품/교환처리 설정</title>
	<!-- font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
	<link href='//spoqa.github.io/spoqa-han-sans/css/SpoqaHanSans-kr.css' rel='stylesheet' type='text/css'>

	<!-- css -->
	<?php include_once $this->dir."page/adm/inc/common_css.php"; ?>
	<link rel="stylesheet" type="text/css" href="common_css/adm/jquery-ui.min.css?<?php echo $version;?>"/>

	<!-- script -->
	<?php include_once $this->dir."page/adm/inc/common_js.php"; ?>
	<script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/jquery-ui.min.js<?php echo $version;?>"></script>
    <script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/datepicker-ko.js<?php echo $version;?>"></script>
	<script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/menu4_refund.js"></script>
	
</head>
<body>
	<div class="wrap">
        <?php include_once $dir."page/adm/include/adm_menu4_aside.php";?>
        <div class="bd">
            <article class="body-container">
                <div class="body-head"><h2>반품/교환처리 설정</h2></div>
                <form class="form">
                    <div class="body-box mb-3">
                        <div class="box-search-container">
                            <div class="insert-wrap">
                                <div class="insert insert-select">
                                    <select class="select-custom" id ="search_kind" type="text">
                                        <option value = "order_number">주문번호</option>
                                        <option value = "orderer_name">주문자/입금자</option>
                                        <option value = "product_name">상품명</option>
                                    </select>
                                </div>
                                <div class="insert insert-input"><input id = "keyword" class="input-lg" type="text"/></div>
                                <div class="insert insert-chk">
                                    <label class="check_label">상세검색
                                        <input type="checkbox" id = "detail_search_check">
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                                <!-- 상세검색을 check 하면 상세검색 전문이 나타납니다 // -->
                            </div>
                        </div>
                        <!-- 상세검색 전문 -->
                        <div class="box-table-container mt-3" id = "detail_search_content" style ="display:none;">
                            <dl class="box-tbody">
                                <dt class="box-th box-head"><p>기간</p></dt>
                                <dd class="box-td">
                                    <ul class="insert-wrap">
                                        <li class="insert">
                                            <select class="select-custom" id ="date_select_kind" type="text">
                                                <option value = "return_request_regdate">반품신청일</option>
                                                <option value = "return_complete_regdate">반품완료일</option>
                                                <option value = "exchage_request_regdate">교환신청일</option>
                                                <option value = "exchange_complete_regdate">교환완료일</option>
                                            </select>
                                        </li>
                                        <li class="insert insert-chk">
                                            <label class="check_label" for="all_search">전체
                                                <input type="radio" id="all_search" value="all_search" name="condition">
                                                <span class="checkmark radio"></span>
                                            </label>
                                        </li>
                                        <li class="insert insert-chk">
                                            <label class="check_label" for="today">오늘
                                                <input type="radio" id="today" value="today" name="condition">
                                                <span class="checkmark radio"></span>
                                            </label>
                                        </li>
                                        <li class="insert insert-chk">
                                            <label class="check_label" for="1month">1개월
                                                <input type="radio" id="1month" value="1month" name="condition">
                                                <span class="checkmark radio"></span>
                                            </label>
                                        </li>
                                        
                                        <li class="insert insert-chk">
                                            <label class="check_label" for="3month">3개월
                                                <input type="radio" id="3month" value="3month" name="condition">
                                                <span class="checkmark radio"></span>
                                            </label>
                                        </li>
                                        <li class="insert insert-chk">
                                            <label class="check_label" for="6month">6개월
                                                <input type="radio" id="6month" value="6month" name="condition">
                                                <span class="checkmark radio"></span>
                                            </label>
                                        </li>
                                        <li class="insert insert-chk">
                                            <label class="check_label" for="year">1년
                                                <input type="radio" id="year" value="year" name="condition">
                                                <span class="checkmark radio"></span>
                                            </label>
                                        </li>
                                    </ul>
                                    <ul class="insert-wrap">
                                        <li class="insert insert-input datepick-wirte"><input id ="start_date" class="input-32 input-xs" type="text"/><i></i></li>
                                        <li class="insert">~</li>
                                        <li class="insert insert-input datepick-wirte"><input id ="end_date" class="input-32 input-xs" type="text"/><i></i></li>
                                    </ul>
                                </dd>
                            </dl>
                        </div>
                        <!-- 상세검색 전문 // -->
                        <div class="insert-wrap align-center mt-3">
                            <div class="insert insert-input-btn"><input class="btn-primary" id = "select_btn" type="button" value="검색"/></div>
                            <div class="insert insert-input-btn"><input class="btn-default" id = "init_btn" type="button" value="초기화"/></div>
                        </div>
                    </div>
                    <div class="body-out mb-3">
                    <div class="out-tab-container">
                            <ul>
                                <li id ="all"><a href="#1">전체(0)</a></li>
                                <li id ="first"><a href="#2">반품진행(0)</a></li>
                                <li id ="second"><a href="#3">반품완료(0)</a></li>
                                <li id ="third"><a href="#3">교환진행(0)</a></li>
                                <li id ="fourth"><a href="#3">교환완료(0)</a></li>
                            </ul>
                        </div>
                        <div class="insert-wrap mb-1">
                            <div class="insert insert-select">
                                <select class="select-custom" id="search_order" type="text">
                                    <option value = "return_request_regdate_desc">반품신청일순</option>
                                    <option value = "return_request_regdate_asc">반품신청일역순</option>
                                    <option value = "exchange_request_regdate_desc">교환신청일순</option>
                                    <option value = "exchange_request_regdate_asc">교환신청일역순</option>
                                </select>
                            </div>
                            <div class="insert insert-input-btn"><input class="btn-xlsx" onclick = "excel_download();" type="button" value="엑셀다운로드"/></div>
                        </div>
                    </div>
                    <div class="body-box mt-3">
                        <div class="table-container">
                            <table class="table3">
                                <thead>
                                    <tr>
                                        <!-- <th>
                                            <div class="insert insert-chk">
                                                <label class="check_label">
                                                    <input type="checkbox">
                                                    <span class="checkmark"></span>
                                                </label>
                                            </div>
                                        </th> -->
                                        <th>번호</th>
                                        <th>주문번호</th>
                                        <th class="col-tit">취소/환불 상품</th>
                                        <th>주문자</th>
                                        <th>반품/교환 신청일시</th>
                                        <th>연락처</th>
                                        <!-- <th>입금자</th> -->
                                        <th>상품금액</th>
                                        <th>실결제액</th>
                                        <th>결제수단</th>
                                        <th>상태</th>
                                    </tr>
                                </thead>
                                <tbody data-wrap ="wrap" id = "wrap">
                                    <!-- <tr>
                                        <td>
                                            <div class="insert insert-chk">
                                                <label class="check_label">
                                                    <input type="checkbox">
                                                    <span class="checkmark"></span>
                                                </label>
                                            </div>
                                        </td>
                                        <td class="col-num">1</td>
                                        <td class="col-long-num">123456789</td>
                                        <td class="col-tit">
                                            <div class="table-tit">
                                                <p class="tit"><span class="ellipsis" onclick="">제품타이틀입니다.</span></p>
                                            </div>
                                        </td>
                                        <td>하예든</td>
                                        <td class="col-long-num"><div class="table-date">20.03.20 16:00:04</div></td>
                                        <td class="col-long-num">01030215554</td>
                                        <td>하예든</td>
                                        <td><div class="table-won">19,000</div></td>
                                        <td><div class="table-won">19,000</div></td>
                                        <td>
                                            <div class="table-pay-method">
                                                <span class="pay-method-con card">신용카드</span>
                                                <span class="pay-method-con account">무통장</span>
                                                <span class="pay-method-con transfer">이체</span>
                                                <span class="pay-method-con point">적립금</span>
                                                <span class="pay-method-con coupon">쿠폰</span>
                                            </div>
                                        </td>
                                        <td>취소신청</td>
                                    </tr> -->
                                    <!-- 1 // -->
                                </tbody>
                            </table>
                        </div>
                        <div class="pagination_container mt-3" id ="paging">
                            <!-- <div class="page_item arrow prev">«</div>
                            <div class="page_item active">1</div>
                            <div class="page_item ">2</div>
                            <div class="page_item arrow next">»</div> -->
                        </div>
                    </div>
                </form>
            </article>
        </div>
    </div>
    <div style = "display:none;">
        <table>
            <tr data-copy ="copy">
                <td data-attr="num">1</td>
                <td class="col-long-num" data-attr="order_number">123456789</td>
                <td class="col-tit">
                    <div class="table-tit">
                        <p class="tit"><span class="ellipsis" onclick="" data-attr="product_name">제품타이틀입니다.</span></p>
                    </div>
                </td>
                <td data-attr="orderer_name"></td>
                <td class="col-long-num"><div class="table-date" data-attr="regdate"></div></td>
                <td class="col-long-num" data-attr="orderer_phone"></td>
                <!-- <td data-attr="orderer_name"></td> -->
                <td><div class="table-won" data-attr="total_price"></div></td>
                <td><div class="table-won" data-attr="purchase_price" ></div></td>
                <td>
                    <div class="table-pay-method" data-attr="pay_type">
                        <span class="pay-method-con card" style ="display:none;">신용카드</span>
                        <span class="pay-method-con account" style ="display:none;">무통장</span>
                        <span class="pay-method-con transfer" style ="display:none;">이체</span>
                        <span class="pay-method-con point" style ="display:none;">적립금</span>
                        <span class="pay-method-con coupon" style ="display:none;">쿠폰</span>
                    </div>
                </td>
                <td data-attr="state"></td>
            </tr>
        </table>
    </div>
</body>
<!-- select2 -->
<link rel="stylesheet" type="text/css" href="<?php echo $this->project_admin_path;?>layout/select2/css/select2.min.css"/>
<link rel="stylesheet" type="text/css" href="common_css/adm/adm_select.css?<?php echo $version;?>"/>
<script type="text/javascript" src="<?php echo $this->project_admin_path;?>layout/select2/js/select2.full.min.js"></script>
<script type="text/javascript">
	$(document).ready(function() {
        $('.select-custom').select2({
            minimumResultsForSearch: -1
        });
    });
</script>
</html>