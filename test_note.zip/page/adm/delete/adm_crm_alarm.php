<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<title>이메일/문자알림 설정</title>
	<!-- font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
	<link href='//spoqa.github.io/spoqa-han-sans/css/SpoqaHanSans-kr.css' rel='stylesheet' type='text/css'>

	<!-- css -->
    <?php include_once $this->dir."page/adm/inc/common_css.php"; ?>

    <!-- script -->
    <?php include_once $this->dir."page/adm/inc/common_js.php"; ?>
    <script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/crm_alarm.js"></script>
</head>
<body>
	<div class="wrap">
        <?php include_once $dir."page/adm/include/adm_aside.php";?>
			<div class="bd">
				<article class="body-container">
					<div class="body-head"><h2>이메일/문자알림 설정</h2></div>
					<form class="form">
                    <div class="body-box">
                            <div class="box-tit mb-1"><h3>이메일알림 설정</h3></div>
							<div class="box-table-container">
								<dl class="box-tbody">
									<dt class="box-th box-head"><p class="medium">발신이메일</p></dt>
									<dd class="box-td">
										<ul class="insert-wrap">
                                            <li class="insert insert-input" id ="email_input_inactive" style = "display:none;">
                                                <!-- sample@gmail.com -->
                                            </li>
                                            <li class="insert insert-input" id ="email_input_active" style = "display:none;">
                                                <input type="text" class="input-sm" id = "send_email"/>
                                            </li>
											<li class="insert insert-input">
                                                <input class="btn-default btn-32" id = "email_modify_btn" type="button"style = "display:none;" value="수정"/>
											</li>
										</ul>
									</dd>
                                </dl>
                                <dl class="box-tbody">
                                    <dt class="box-th box-head"><p class="medium">사용항목</p></dt>
                                    <dd class="box-td">
                                        <ul class="insert-wrap">
                                            <li class="insert insert-chk">
                                                <label class="check_label" for="e_join">회원가입
                                                    <input type="checkbox" id="e_join" value="e_join" name="email">
                                                    <span class="checkmark"></span>
                                                </label>
                                            </li>
                                            <li class="insert insert-chk">
                                                <label class="check_label" for="e_order_complete">주문완료
                                                    <input type="checkbox" id="e_order_complete" value="e_order_complete" name="email">
                                                    <span class="checkmark"></span>
                                                </label>
                                            </li>
                                            <li class="insert insert-chk">
                                                <label class="check_label" for="e_deposit_complete">입금완료
                                                    <input type="checkbox" id="e_deposit_complete" value="e_depsit_complete" name="email">
                                                    <span class="checkmark"></span>
                                                </label>
                                            </li>
                                            
                                            <li class="insert insert-chk">
                                                <label class="check_label" for="e_shipment">상품발송
                                                    <input type="checkbox" id="e_shipment" value="e_shipment" name="email">
                                                    <span class="checkmark"></span>
                                                </label>
                                            </li>
                                            <li class="insert insert-chk">
                                                <label class="check_label" for="e_delivery_complete">배송완료
                                                    <input type="checkbox" id="e_delivery_complete" value="e_delivery_complete" name="email">
                                                    <span class="checkmark"></span>
                                                </label>
                                            </li>
                                            <!-- <li class="insert insert-chk">
                                                <label class="check_label" for="e_auto_deposit">자동입금확인
                                                    <input type="checkbox" id="e_auto_deposit" value="e_auto_deposit" name="email">
                                                    <span class="checkmark"></span>
                                                </label>
                                            </li>
                                            <li class="insert insert-chk">
                                                <label class="check_label" for="e_deposit_request">입금요청
                                                    <input type="checkbox" id="e_deposit_request" value="e_deposit_request" name="email">
                                                    <span class="checkmark"></span>
                                                </label> -->
                                            </li>
                                            <li class="insert insert-chk">
                                                <label class="check_label" for="e_question">질문답변
                                                    <input type="checkbox" id="e_question" value="e_question" name="email">
                                                    <span class="checkmark"></span>
                                                </label>
                                            </li>
                                        </ul>
                                        <p class="mt-2 xsmall">체크 항목에 따라 이메일이 발송됩니다.</p>
                                    </dd>
                                </dl>
							</div>
						</div>
						<div class="body-box mt-3">
                            <div class="box-tit mb-1"><h3>문자알림 설정</h3></div>
							<div class="box-table-container">
								<dl class="box-tbody">
									<dt class="box-th box-head"><p class="medium">발신번호</p></dt>
									<dd class="box-td">
										<ul class="insert-wrap">
                                            <li class="insert insert-input" id ="sms_input_inactive">
                                                <!-- 010-3021-5551 -->
                                            </li>
                                            <!-- <li class="insert insert-input" id ="sms_input_active" style = "display:none;">
                                                <input type="text" class="input-sm" id = "send_number"/>
                                            </li> -->
											<!-- <li class="insert insert-input">
                                                <input class="btn-default btn-32" id = "sms_modify_btn" type="button" value="수정" style = "display:none;"/>
											</li> -->
										</ul>
									</dd>
                                </dl>
                                <dl class="box-tbody">
                                    <dt class="box-th box-head"><p class="medium">사용항목</p></dt>
                                    <dd class="box-td">
                                    <ul class="insert-wrap">
                                            <li class="insert insert-chk">
                                                <label class="check_label" for="s_join">회원가입
                                                    <input type="checkbox" id="s_join" value="s_join" name="sms">
                                                    <span class="checkmark"></span>
                                                </label>
                                            </li>
                                            <li class="insert insert-chk">
                                                <label class="check_label" for="s_order_complete">주문완료
                                                    <input type="checkbox" id="s_order_complete" value="s_order_complete" name="sms">
                                                    <span class="checkmark"></span>
                                                </label>
                                            </li>
                                            <li class="insert insert-chk">
                                                <label class="check_label" for="s_deposit_complete">입금완료
                                                    <input type="checkbox" id="s_deposit_complete" value="s_depsit_complete" name="sms">
                                                    <span class="checkmark"></span>
                                                </label>
                                            </li>
                                            
                                            <li class="insert insert-chk">
                                                <label class="check_label" for="s_shipment">상품발송
                                                    <input type="checkbox" id="s_shipment" value="s_shipment" name="sms">
                                                    <span class="checkmark"></span>
                                                </label>
                                            </li>
                                            <li class="insert insert-chk">
                                                <label class="check_label" for="s_delivery_complete">배송완료
                                                    <input type="checkbox" id="s_delivery_complete" value="s_delivery_complete" name="email">
                                                    <span class="checkmark"></span>
                                                </label>
                                            </li>
                                            <!-- <li class="insert insert-chk">
                                                <label class="check_label" for="s_auto_deposit">자동입금확인
                                                    <input type="checkbox" id="s_auto_deposit" value="s_auto_deposit" name="sms">
                                                    <span class="checkmark"></span>
                                                </label>
                                            </li>
                                            <li class="insert insert-chk">
                                                <label class="check_label" for="s_deposit_request">입금요청
                                                    <input type="checkbox" id="s_deposit_request" value="s_deposit_request" name="sms">
                                                    <span class="checkmark"></span>
                                                </label>
                                            </li> -->
                                            <li class="insert insert-chk">
                                                <label class="check_label" for="s_question">질문답변
                                                    <input type="checkbox" id="s_question" value="s_question" name="sms">
                                                    <span class="checkmark"></span>
                                                </label>
                                            </li>
                                        </ul>
                                        <p class="mt-2 xsmall">체크 항목에 따라 문자가 발송됩니다.</p>
                                    </dd>
                                </dl>
							</div>
						</div>
                    </form>
                    <div class="btn-container align-right mt-3">
						<button type="button" id = "save_btn" class="btn btn-primary">저장하기</button>
					</div>
				</article>
			</div>
	</div>

</body>
<!-- select2 -->
<link rel="stylesheet" type="text/css" href="<?php echo $this->project_admin_path;?>layout/select2/css/select2.min.css"/>
<link rel="stylesheet" type="text/css" href="common_css/adm/adm_select.css?<?php echo $version;?>"/>
<script type="text/javascript" src="<?php echo $this->project_admin_path;?>layout/select2/js/select2.full.min.js"></script>
<script type="text/javascript">
	$(document).ready(function() {
        $('.select-custom').select2({
            minimumResultsForSearch: -1
        });
    });
</script>
</html>