<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>회원 적립금내역</title>
	<!-- font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
	<link href='//spoqa.github.io/spoqa-han-sans/css/SpoqaHanSans-kr.css' rel='stylesheet' type='text/css'>

	<!-- css -->
	<?php include_once $this->dir."page/adm/inc/common_css.php"; ?>

	<!-- script -->
    <?php include_once $this->dir."page/adm/inc/common_js.php"; ?>
    <script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/popup_init.js<?php echo $version;?>"></script>
    <script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/popup_point.js<?php echo $version;?>"></script>
</head>
<body>
	<div class="wrap" style="background-color:#e8edf3">
		<?php include_once $dir."page/adm/include/adm_member_header.php";?>
		<?php include_once $dir."page/adm/include/adm_member_aside.php";?>
        <div class="bd">
            <article class="body-container">
                <div class="body-head"><h2>적립금내역</h2></div>
                <form class="form">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="body-box">
                                <div class="table-container">
                                    <table class="table3">
                                        <thead>
                                            <tr>
                                                <th>
                                                    <div class="insert insert-chk">
                                                        <label class="check_label">
                                                            <input type="checkbox" id = "all_check_elem" onchange = "all_check(this);"/>
                                                            <span class="checkmark"></span>
                                                        </label>
                                                    </div>
                                                </th>
                                                <th>번호</th>
                                                <th>일자</th>
                                                <th class="col-tit">적립내용</th>
                                                <th>적립</th>
                                                <th>사용</th>
                                                <th>반환</th>
                                                <th>소계</th>
                                                <th>만료예정일</th>
                                            </tr>
                                        </thead>
                                        <tbody data-wrap = "wrap" id ="wrap">
                                            <!-- <tr>
                                                <td>
                                                    <div class="insert insert-chk">
                                                        <label class="check_label">
                                                            <input type="checkbox"/>
                                                            <span class="checkmark"></span>
                                                        </label>
                                                    </div>
                                                </td>
                                                <td class="col-num">1</td>
                                                <td>20/03/24</td>
                                                <td class="col-tit">
                                                    <div class="table-tit">
                                                        <p class="tit">적립내용이 들어갑니다.</p>
                                                    </div>
                                                </td>
                                                <td><div class="table-won">190</div></td>
                                                <td><div class="table-won">0</div></td>

                                                <td><div class="table-won">190</div></td>
                                                <td>무제한</td>
                                            </tr> -->
                                            <!-- 1 // -->
                                        </tbody>
                                    </table>
                                </div>
                                <div class="insert-wrap mt-1">
                                    <div class="insert insert-input-btn"><input class="btn-default btn-32" id = "return_btn" onclick = "point_return();" type="button" value="적립금반환"></div>
                                </div>
                                <div class="pagination_container mt-3" id = "paging">
                                    <!-- <div class="page_item arrow prev">«</div>
                                    <div class="page_item active">1</div>
                                    <div class="page_item ">2</div>
                                    <div class="page_item arrow next">»</div> -->
                                </div>
                            </div>
                            <div class="body-box mt-3">
                                <div class="box-tit mb-2"><h3>적립금지급</h3></div>
                                <div class="box-table-container">
                                    <dl class="box-tbody">
                                        <dt class="box-th box-head"><p class="medium">사유</p></dt>
                                        <dd class="box-td">
                                            <div class="insert insert-input">
                                                <input class="input-sm" autocomplete="off" type="text" id ="point_reason">
                                            </div>
                                        </dd>
                                    </dl>
                                    <dl class="box-tbody">
                                        <dt class="box-th box-head"><p class="medium">적립금액</p></dt>
                                        <dd class="box-td">
                                            <div class="insert insert-input">
                                                <input class="input-xs" autocomplete="off" type="text" id = "point">
                                                <span class="ml-1">원</span>
                                            </div>
                                        </dd>
                                    </dl>
                                    <dl class="box-tbody">
                                        <dt class="box-th box-head"><p class="medium">만료예정일</p></dt>
                                        <dd class="box-td">
                                            <ul class="insert-wrap">
                                                <li class="insert insert-input">
                                                    <input class=" input-xs" autocomplete="off" type="text" id = "expire_date"><i></i>
                                                </li>
                                                <li class="insert insert-chk">
                                                    <label class="check_label">무제한
                                                        <input type="checkbox" id = "unlimited">
                                                        <span class="checkmark"></span>
                                                    </label>
                                                </li>
                                            </ul>
                                        </dd>
                                    </dl>
                                </div>
                                <div class="insert-wrap mt-2">
                                    <div class="insert insert-input-btn"><input class="btn-primary" type="button" value="적립금지급" onclick="point_add();"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </article>
        </div>
    </div>
    <div style ="display:none;">
        <table>
            <tr data-copy = "copy">
                <td>
                    <div class="insert insert-chk">
                        <label class="check_label">
                            <input type="checkbox" data-attr="checkbox" />
                            <span class="checkmark"></span>
                        </label>
                    </div>
                </td>
                <td class="col-num"  data-attr="num">1</td>
                <td data-attr="regdate">20/03/24</td>
                <td class="col-tit">
                    <div class="table-tit">
                        <p class="tit" data-attr="point_title">적립내용이 들어갑니다.</p>
                    </div>
                </td>
                <td><div class="table-won" data-attr="point">190</div></td>
                <td><div class="table-won" data-attr="use_point">0</div></td>
                <td><div class="table-won" data-attr="return_point">0</div></td>
                <td><div class="table-won" data-attr="total">190</div></td>
                <td data-attr="expire_date">무제한</td>
            </tr>
        </table>
        
    </div>
</body>
</html>