<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<title>자동 배송완료 설정</title>
	<!-- font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
	<link href='//spoqa.github.io/spoqa-han-sans/css/SpoqaHanSans-kr.css' rel='stylesheet' type='text/css'>

	<!-- css -->
	<?php include_once $this->dir."page/adm/inc/common_css.php"; ?>

	<!-- script -->
    <?php include_once $this->dir."page/adm/inc/common_js.php"; ?>
    <script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/menu4_shipping_completed.js"></script>
	
</head>
<body>
	<div class="wrap">
        <?php include_once $dir."page/adm/include/adm_menu4_aside.php";?>
			<div class="bd">
				<article class="body-container">
					<div class="body-head"><h2>자동 배송완료 설정</h2></div>
					<form class="form">
                        <div class="body-box">
                            <div class="box-table-container">
                                <dl class="box-tbody">
									<dt class="box-th box-head">
										<p class="medium">배송완료 일자</p>
									</dt>
									<dd class="box-td">
                                    <div class="insert insert-select">
                                        <select class="select-custom" id = "auto_delivery_day" type="text">
                                            <option value = "3">3일</option>
                                            <option value = "4">4일</option>
                                            <option value = "5">5일</option>
                                            <option value = "6">6일</option>
                                            <option value = "7">7일</option>
                                        </select>
                                        <p class="xsmall mt-1">배송 도착일로부터 'n일' 후 배송완료</p>
                                    </div>
                                    </dd>
                                </dl>
                            </div>
                            <div class="insert-wrap mt-2">
                                <div class="insert insert-chk">
                                    <label class="check_label">자동 배송완료 설정
                                        <input type="checkbox" id = "auto_delivery_complete">
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                            </div>
						</div>
                    </form>
                    <div class="btn-container align-right mt-3"><button type="button" id = "save_btn" class="btn btn-primary">저장하기</button></div>
				</article>
			</div>
	</div>

</body>
<!-- select2 -->
<link rel="stylesheet" type="text/css" href="<?php echo $this->project_admin_path;?>layout/select2/css/select2.min.css"/>
<link rel="stylesheet" type="text/css" href="common_css/adm/adm_select.css?<?php echo $version;?>"/>
<script type="text/javascript" src="<?php echo $this->project_admin_path;?>layout/select2/js/select2.full.min.js"></script>
<script type="text/javascript">
	$(document).ready(function() {
        $('.select-custom').select2({
            minimumResultsForSearch: -1
        });
    });
</script>
</html>