<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<title>상품등록</title>
	<!-- font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
	<link href='//spoqa.github.io/spoqa-han-sans/css/SpoqaHanSans-kr.css' rel='stylesheet' type='text/css'>

	<!-- css -->
	<?php include_once $this->dir."page/adm/inc/common_css.php"; ?>

	<!-- script -->
	<?php include_once $this->dir."page/adm/inc/common_js.php"; ?>
	<?php include_once $this->dir."page/adm/inc/summernote.php"; ?>
	<script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/menu3_pd_upload.js<?php echo $version;?>"></script>
	<style>
		.select-list{height:102px !important;}
	</style>

</head>
<body>
	<div class="wrap">
        <?php include_once $dir."page/adm/include/adm_aside.php";?>
			<div class="bd">
				<article class="body-container">
					<div class="body-head"><h2>상품등록</h2></div>
					<form class="form" id="form" onsubmit='return false;'>
						<div class="row">
							<!-- 좌 -->
							<div class="col-md-7">
								<div class="body-box mt-1">
									<div class="box-tit mb-1"><h3>기본정보</h3></div>
									<div class="box-table-container">
										<!-- 언어별 설정에서 사용함으로 주석처리 -->
										<!-- <dl class="box-tbody">
											<dt class="box-th box-head">
												<p>상태</p>
											</dt>
											<dd class="box-td">
												<div class="insert">
													<div class="insert-wrap">
														<div class="insert insert-chk">
															<label class="check_label" for="normal_state">정상
																<input type="radio" id="normal_state" value="1" name="state" checked/>
																<span class="checkmark radio"></span>
															</label>
														</div>
														<div class="insert insert-chk">
															<label class="check_label" for="soldout_state">품절
																<input type="radio" id="soldout_state" value="2" name="state"/>
																<span class="checkmark radio"></span>
															</label>
														</div>
														<div class="insert insert-chk">
															<label class="check_label" for="hide_state">숨김
																<input type="radio" id="hide_state" value="3" name="state"/>
																<span class="checkmark radio"></span>
															</label>
														</div>
													</div>
												</div>
											</dd>
										</dl> -->
										<dl class="box-tbody" style="display:none;">
											<dt class="box-th box-head">
												<p>노출위치</p>
											</dt>
											<dd class="box-td">
												<div class="insert">
													<div class="insert-wrap">
														<div class="insert insert-chk">
															<label class="check_label">상품목록
																<input type="checkbox"/>
																<span class="checkmark"></span>
															</label>
														</div>
														<div class="insert insert-chk">
															<label class="check_label">베스트셀러
																<input type="checkbox"/>
																<span class="checkmark"></span>
															</label>
														</div>
														<div class="insert insert-chk">
															<label class="check_label">인기상품
																<input type="checkbox"/>
																<span class="checkmark"></span>
															</label>
														</div>
													</div>
												</div>
											</dd>
										</dl>
										<!-- <dl class="box-tbody">
											<dt class="box-th box-head">
												<p>상품명</p>
											</dt>
											<dd class="box-td">
												<div class="insert insert-input">
													<input type="text" class="input-sm"/>
												</div>
											</dd>
										</dl> -->
										<dl class="box-tbody">
											<dt class="box-th box-head">
												<p>카테고리</p>
											</dt>
											<dd class="box-td">
												<div class="insert insert-select">
													<select class="select-list" size="4" id="select_category">
														
													</select>
												</div>
												<div class="insert-wrap mt-1">
													<div class="insert insert-input-btn"><input class="btn-default btn-32" type="button" value="선택삭제" onclick="delete_category()"></div>
												</div>
												<div class="h-line mt-2"></div>
												<div class="insert-wrap mt-2">
													<div class="insert insert-select">
														<select class="select-custom" type="text" id="main_category" name="main_category">
															<option>대분류</option>
														</select>
													</div>
													<div class="insert insert-select" id="category1_view" style="display:none;">
														<select class="select-custom" type="text" id="category_1" name="category_1" >
															<option>중분류</option>
														</select>
													</div>
													<div class="insert insert-select mt-1" id="category2_view" style="display:none;">
														<select class="select-custom" type="text" id="category_2" name="category_2" >
															<option>소분류</option>
														</select>
													</div>
													<div class="insert insert-select mt-1" id="category3_view" style="display:none;">
														<select class="select-custom" type="text" id="category_3" name="category_3">
															<option>세분류</option>
														</select>
													</div>
													<div class="insert-wrap mt-2">
														<div class="insert insert-input-btn"><input class="btn-primary btn-32" type="button" value="카테고리 등록" id="btn_category_add"></div>
													</div>
												</div>
											</dd>
										</dl>
										<dl class="box-tbody">
											<dt class="box-th box-head">
												<p>추가분류</p>
											</dt>
											<dd class="box-td">
												<div class="insert-wrap over">
													<!-- <div class="insert insert-chk">
														<label class="check_label">MD'S PICK
															<input type="checkbox" value="1" name="md_pick" />
															<span class="checkmark"></span>
														</label>
													</div> -->
													<div class="insert insert-chk">
														<label class="check_label">BEST SELLER
															<input type="checkbox" value="1" name="best_seller" />
															<span class="checkmark"></span>
														</label>
													</div>
													<!-- <div class="insert insert-chk">
														<label class="check_label">HOT DEAL
															<input type="checkbox" value="1" name="hot_deal"/>
															<span class="checkmark"></span>
														</label>
													</div> -->
												</div>
											</dd>
										</dl>
										<!-- 상품 라벨 -->
										<dl class="box-tbody">
											<dt class="box-th box-head">
												<p>라벨</p>
											</dt>
											<dd class="box-td">
												<div class="insert-wrap over">
													<div class="insert insert-chk">
														<label class="check_label">MD추천
															<input type="checkbox" value="1" name="md_pick" />
															<span class="checkmark"></span>
														</label>
													</div>
													<div class="insert insert-chk">
														<label class="check_label">주문폭주
															<input type="checkbox" value="1" name="runaway" />
															<span class="checkmark"></span>
														</label>
													</div>
												</div>
											</dd>
										</dl>
										<!-- 상품 라벨 끝 -->
										<dl class="box-tbody">
											<dt class="box-th box-head">
												<p>검색키워드</p>
											</dt>
											<dd class="box-td">
												<div class="insert">
													<input type="text" class="input-sm" name="keyword"/>
												</div>
												<p class="mt-1 xsmall">','으로 구분하여 입력하세요.</p>
											</dd>
										</dl>
										<!-- <dl class="box-tbody">
											<dt class="box-th box-head">
												<p>상태</p>
											</dt>
											<dd class="box-td">
												<div class="insert">
													<div class="insert-wrap">
														<div class="insert insert-chk">
															<label class="check_label" for="state_normal">노출
																<input type="radio" value="1" id="state_normal" name="state" checked/>
																<span class="checkmark radio"></span>
															</label>
														</div>
														<div class="insert insert-chk">
															<label class="check_label" for="state_sold_out">품절
																<input type="radio" value="2" id="state_sold_out" name="state"/>
																<span class="checkmark radio"></span>
															</label>
														</div>
														<div class="insert insert-chk">
															<label class="check_label" for="state_hide">숨김
																<input type="radio" value="3" id="state_hide" name="state"/>
																<span class="checkmark radio"></span>
															</label>
														</div>
													</div>
												</div>
											</dd>
										</dl> -->
									</div>
								</div>
								<!-- 기본정보 // -->
							</div>
							<!-- 우 -->
							<div class="col-md-5">
								<div class="body-box mt-1">
									<div class="box-tit mb-1"><h3>판매정보</h3></div>
									<div class="box-table-container">
										<dl class="box-tbody">
											<dt class="box-th box-head">
												<p>판매가</p>
											</dt>
											<dd class="box-td">
												<div class="insert">
													<input type="text" class="input-xs" id="price" name="price" onkeyup="lb.validate_number(this)"/>
													<span class="ml-1">원</span>
												</div>
											</dd>
										</dl>
										<dl class="box-tbody">
											<dt class="box-th box-head">
												<p>할인</p>
											</dt>
											<dd class="box-td">
												<div class="insert">
													<div class="insert-wrap">
														<div class="insert insert-chk">
															<label class="check_label" for="no_discount">할인 없음
																<input type="radio" id="no_discount" value="0" name="is_discount" onclick="change_discount_view(this.value)" checked/>
																<span class="checkmark radio"></span>
															</label>
														</div>
														<div class="insert insert-chk">
															<label class="check_label" for="percent_discount">할인율로 표기
																<input type="radio" id="percent_discount" value="1" name="is_discount" onclick="change_discount_view(this.value)" />
																<span class="checkmark radio"></span>
															</label>
														</div>
														<div class="insert insert-chk">
															<label class="check_label" for="number_discount">금액으로 표기
																<input type="radio" id="number_discount" value="2" name="is_discount" onclick="change_discount_view(this.value)" />
																<span class="checkmark radio"></span>
															</label>
														</div>
													</div>
												</div>
											</dd>
											
										</dl>
										<dl class="box-tbody">
											<dt class="box-th box-head">
												<p>할인율</p>
											</dt>
											<dd class="box-td">
												<div class="insert">
													<input type="text" class="input-xs" name="discount_percent" id="discount_percent" onkeyup="lb.validate_number(this)" disabled/><span class="ml-1">%</span>
												</div>
											</dd>
										</dl>
										<!-- 할인율 // -->
										<dl class="box-tbody">
											<dt class="box-th box-head">
												<p>할인금액</p>
											</dt>
											<dd class="box-td">
												<div class="insert">
													<input type="text" class="input-xs" name="discount_price" id="discount_price" onkeyup="lb.validate_number(this)" disabled/><span class="ml-1">원</span>
												</div>
											</dd>
										</dl>
										<!-- 할인금액 // -->
										<!-- 할인율 or 할인금액 -->
										<dl class="box-tbody">
											<dt class="box-th box-head">
												<p>재고관리</p>
											</dt>
											<dd class="box-td">
												<div class="insert-wrap">
													<div class="insert insert-chk">
														<label class="check_label" for="no_stock">사용안함
															<input type="radio" id="no_stock" value="0" name="is_stock" onclick="change_stock_view(this.value)" checked/>
															<span class="checkmark radio"></span>
														</label>
													</div>
													<div class="insert insert-chk">
														<label class="check_label" for="use_stock">단일 재고 사용
															<input type="radio" id="use_stock" value="1" name="is_stock" onclick="change_stock_view(this.value)"/>
															<span class="checkmark radio"></span>
														</label>
													</div>
													<div class="insert insert-chk">
														<label class="check_label" for="use_option_stock">옵션 재고 사용
															<input type="radio" id="use_option_stock" value="2" name="is_stock" onclick="change_stock_view(this.value)"/>
															<span class="checkmark radio"></span>
														</label>
													</div>
												</div>
												<div class="mt-1">
													- 사용안함일 경우 재고체크를 하지 않습니다.<br/>
													- 단일 제품일 경우 옵션과 상관없이 단일 재고 개수를 체크합니다.<br/>
													- 옵션 재고일 경우 옵션 설정에서 재고를 설정 할 수 있습니다.
												</div>
											</dd>
										</dl>
										<dl class="box-tbody">
											<dt class="box-th box-head">
												<p>재고개수</p>
											</dt>
											<dd class="box-td">
												<div class="insert">
													<input type="text" class="input-xs" name="total_stock" id="total_stock" onkeyup="lb.validate_number(this)" disabled/>
												</div>
											</dd>
										</dl>
										<!-- <dl class="box-tbody">
											<dt class="box-th box-head">
												<p>판매설정</p>
											</dt>
											<dd class="box-td">
												<div class="img-area-container cf">
													<div class="insert insert-img">
														<label class="check_label img-area">
															<input type="checkbox">
															<div class="img-area-bg">
																<p class="icon"><img src="<?php echo $this->project_admin_path;?>images/i-best01.png" alt="best01"></p>
															</div>
														</label>
													</div>
													<div class="insert insert-img">
														<label class="check_label img-area">
															<input type="checkbox">
															<div class="img-area-bg">
																<p class="icon"><img src="<?php echo $this->project_admin_path;?>images/i-best01.png" alt="best01"></p>
															</div>
														</label>
													</div>
												</div>
											</dd>
										</dl> -->
									</div>
								</div>
								<!-- 판매정보 // -->
							</div>
						</div>
						<div class="h-line mt-3 mb-3"></div>
						<div class="out-tab-container st2">
							<ul data-wrap="lang_btn_wrap" id="lang_btn_wrap">
								<!-- <li class="current"><a>한국어</a></li>
								<li><a>영어</a></li>
								<li><a>중국어</a></li> -->
							</ul>
						</div>
						<!-- 정보 // -->
						<div class="row" data-wrap="lang_input_wrap" id="lang_input_wrap">
							
						</div>
					</form>
					<div class="btn-container align-right mt-3">
						<button type="button" class="btn btn-ghost" onclick='history.back();'>취소</button>
						<button type="button" class="btn btn-primary ml-1" onclick="request_save()">저장하기</button>
					</div>
				</article>
			</div>
	</div>
<div style="display:none">
		<li class="" data-copy="lang_btn_copy"><a data-attr="lang">한국어</a></li> <!-- 언어 버튼, 활성화면 li class = current--> 

		<!-- 언어별 데이터 input  -->
		<div data-copy="lang_input_copy" style="display:none;">
			<div class="row">
				<div class="col-md-7">
					<div class="body-box mt-3">
						<div class="box-tit mb-2"><h3>상품정보</h3></div>
						<div class="box-table-container">
							<dl class="box-tbody"><!-- 상태가 언어별 각각으로 가야한다면 display block -->
								<dt class="box-th box-head">
									<p>상태</p>
								</dt>
								<dd class="box-td">
									<div class="insert">
										<div class="insert-wrap">
											<div class="insert insert-chk">
												<label class="check_label" for="1" data-attr="condition_1_label">정상
													<input type="radio" value="1"  data-attr="condition_1" checked/>
													<span class="checkmark radio"></span>
												</label>
											</div>
											<div class="insert insert-chk">
												<label class="check_label" for="2" data-attr="condition_2_label">품절
													<input type="radio" value="2"  data-attr="condition_2"/>
													<span class="checkmark radio"></span>
												</label>
											</div>
											<div class="insert insert-chk">
												<label class="check_label" for="3" data-attr="condition_3_label">숨김
													<input type="radio" value="3"  data-attr="condition_3"/>
													<span class="checkmark radio"></span>
												</label>
											</div>
										</div>
									</div>
								</dd>
							</dl>
							<dl class="box-tbody">
								<dt class="box-th box-head">
									<p>상품명</p>
								</dt>
								<dd class="box-td">
									<div class="insert insert-input">
										<input type="text" class="input-sm" data-attr="product_name"/>
									</div>
								</dd>
							</dl>
							<dl class="box-tbody">
								<dt class="box-th box-head">
									<p>추가 설명</p>
								</dt>
								<dd class="box-td">
									<div class="insert insert-input">
										<input type="text" class="input-sm" data-attr="product_info"/>
									</div>
								</dd>
							</dl>
							<dl class="box-tbody">
								<dt class="box-th box-head">
									<p>썸네일 이미지</p>
								</dt>
								<dd class="box-td">
									<!-- 이미지 추가 버튼 -->
									<div class="img-upload img-upload-main" style="overflow: hidden;">
										<span class="btn-wrap">
											<button class="btn-img-upload" ><strong></strong></button>
											<input type="file" id="upload" data-attr="thumnail_file">
										</span> 				
										<label for="upload" data-attr="thumnail_file_label"></label>
									</div>
									<!-- 이미지 추가 버튼 // -->
									<!-- 이미지가 첨부될 시 옆에 나열됩니다 -->
									<div data-attr="thumnail_wrap" style = "display:inline-block">
										<!-- <div class="img-upload" style="overflow: hidden;" >
											<img src="<?php echo $this->project_path;?>/images/sample.png" onerror="this.style.display='none'" alt="img_upload"/>
											<button class="delete-btn" type="button"></button>
										</div> -->
									</div>
									<!-- 이미지 1 // -->
									<p class="xsmall">jpg, png, gif 형식의 파일확장자<br>4MB 이하의 이미지 1장까지 첨부 가능</p>
								</dd>
							</dl>
							<dl class="box-tbody">
								<dt class="box-th box-head">
									<p>제품 이미지</p>
								</dt>
								<dd class="box-td">
									<!-- 이미지 추가 버튼 -->
									<div class="img-upload img-upload-main" style="overflow: hidden;">
										<span class="btn-wrap" data-attr="product_file_wrap">
											<!-- <button class="btn-img-upload" href="#"><strong></strong></button> -->
											<input type="file" id="upload" data-attr="product_file">
										</span> 				
										<label for="upload" data-attr="product_file_label"></label>
									</div>
									<!-- 이미지 추가 버튼 // -->
									<!-- 이미지가 첨부될 시 옆에 나열됩니다 -->
									<div data-attr="product_wrap" style = "display:inline-block">
										<!-- <div class="img-upload" style="overflow: hidden;">
											<img src="<?php echo $this->project_path;?>/images/sample.png" onerror="this.style.display='none'" alt="img_upload"/>
											<button class="delete-btn" type="button"></button>
										</div> -->
									</div>
									<!-- 이미지 1 // -->
									<p class="xsmall">jpg, png, gif 형식의 파일확장자<br>4MB 이하의 이미지 무제한 첨부 가능</p>
								</dd>
							</dl>
						</div>
					</div>
				</div>
				<!-- 상품정보 // -->
				<!-- 추가정보 -->
				<div class="col-md-5" style="display:none;">
					<div class="body-box mt-3">
						<div class="box-tit"><h3>추가정보</h3></div>
						<div class="box-table-container tog-container mt-2 d-none" style="display:block">
							<dl class="box-tbody">
								<dt class="box-th box-head">
									<p>제조사</p>
								</dt>
								<dd class="box-td">
									<div class="insert insert-textarea">
										<textarea class="textarea-xs" data-attr=""></textarea>
									</div>
								</dd>
							</dl>
							<dl class="box-tbody">
								<dt class="box-th box-head">
									<p>원산지</p>
								</dt>
								<dd class="box-td">
									<div class="insert insert-textarea">
										<textarea class="textarea-xs"></textarea>
									</div>
								</dd>
							</dl>
							<dl class="box-tbody">
								<dt class="box-th box-head">
									<p>재질</p>
								</dt>
								<dd class="box-td">
									<div class="insert insert-textarea">
										<textarea class="textarea-xs"></textarea>
									</div>
								</dd>
							</dl>
							<dl class="box-tbody">
								<dt class="box-th box-head">
									<p>치수</p>
								</dt>
								<dd class="box-td">
									<div class="insert insert-textarea">
										<textarea class="textarea-xs"></textarea>
									</div>
								</dd>
							</dl>
							<dl class="box-tbody">
								<dt class="box-th box-head">
									<p>구성</p>
								</dt>
								<dd class="box-td">
									<div class="insert insert-input">
										<textarea class="textarea-xs" size="2"></textarea>
									</div>
								</dd>
							</dl>
						</div>
					</div>
				</div>
			</div>
			<!-- 추가정보 // -->
			<div class="row">
				<div class="col-md-12">
					<div class="body-box mt-3">
						<div class="box-tit mb-2"><h3>상품설명</h3></div>
						<div class="insert insert-textarea mt-2">
							<div class="summernote" data-attr="sum_note">

							</div>
						</div>
					</div>
				</div>
				<!-- 상품정보 // -->
			</div>
		</div>

		<!-- 이미지 -->
		<div class="img-upload" style="overflow: hidden;" data-copy = "img_copy">
            <img src="" data-attr="img" alt="img_upload"/>
            <button  data-attr="del_btn" class="delete-btn" type="button"></button>
        </div>
</div>
</body>
<!-- select2 -->
<link rel="stylesheet" type="text/css" href="<?php echo $this->project_admin_path;?>layout/select2/css/select2.min.css"/>
<link rel="stylesheet" type="text/css" href="common_css/adm/adm_select.css?<?php echo $version;?>"/>
<script type="text/javascript" src="<?php echo $this->project_admin_path;?>layout/select2/js/select2.full.min.js"></script>

<!-- yd custom -->
<script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/custom.js"></script>

</html>