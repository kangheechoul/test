<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<title>휴면회원</title>
	<!-- font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
	<link href='//spoqa.github.io/spoqa-han-sans/css/SpoqaHanSans-kr.css' rel='stylesheet' type='text/css'>

	<!-- css -->
	<?php include_once $this->dir."page/adm/inc/common_css.php"; ?>

	<!-- script -->
	<?php include_once $this->dir."page/adm/inc/common_js.php"; ?>
	<script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/crm_inactive.js<?php echo $version;?>"></script>
</head>
<body>
	<div class="wrap">
        <?php include_once $dir."page/adm/include/adm_aside.php";?>
			<div class="bd">
				<article class="body-container">
					<div class="body-head"><h2>휴면회원</h2></div>
					<form class="form">
						<div class="body-box mb-3">
							<div class="box-search-container">
								<div class="insert-wrap">
									<div class="insert insert-select">
										<select class="select-custom" type="text" id="search_kind">
											<option value="0">이름</option>
											<!-- <option value="1">아이디</option> -->
											<option value="2">등급</option>
											<option value="3">이메일</option>
                                            <option value="4">주소</option>
                                            <option value="5">연락처</option>
										</select>
									</div>
									<div class="insert insert-input"><input class="input-lg" type="text" id="word"/></div>
                                </div>
							</div>
							<div class="insert-wrap align-center mt-3">
								<div class="insert insert-input-btn"><input class="btn-primary" type="button" value="검색" onclick="search()"/></div>
								<div class="insert insert-input-btn"><input class="btn-default" type="button" value="초기화" onclick="search_init()"/></div>
							</div>
						</div>
						<div class="body-out mb-3">
                            <div class="out-tit-container">
                                <h4 class="medium bold"><b id="total_count">&nbsp;</b>명이 검색되었습니다.</h4>
                            </div>
							<div class="insert-wrap mb-1">
								<div class="insert insert-input-btn"><input class="btn-xlsx" type="button" value="엑셀다운로드" onclick="excel_download()"></div>
							</div>
						</div>
						<div class="body-box">
							<div class="table-container">
								<table class="table3">
									<thead>
										<tr>
											
                                            <th>번호</th>
                                            <th>이름</th>
											<!-- <th class="col-tit">아이디</th> -->
											<th>이메일</th>
											<th>등급</th>
                                            <th>연락처</th>
                                            <th>접속</th>
                                            <th>주문</th>
											<th>구매금액</th>
											<th>환불금액</th>
											<th>가입일</th>
											<th>휴면일</th>
										</tr>
									</thead>
									<tbody data-wrap="wrap" id="wrap">
										<!-- <tr>
											<td>
												<div class="insert insert-chk">
													<label class="check_label">
														<input type="checkbox"/>
														<span class="checkmark"></span>
													</label>
												</div>
											</td>
                                            <td class="col-num">1</td>
                                            <td class="col-short-num"><span class="bold c-pointer" onclick="">하예든</span></td>
											<td class="col-tit">
												<div class="table-tit"><p class="tit"><span onclick="">sample</span></p></div>
											</td>
                                            <td class="col-long-num">01030215551</td>
                                            <td class=""><div class="ellipsis">sample@gmail.com</div></td>
                                            <td class="col-num">8</td>
                                            <td class="col-num">2</td>
											<td><div class="table-won">233,000</div></td>
											<td class="col-short-num">20.03.24</td>
											<td class="col-short-num">20.03.26</td>
										</tr> -->
										<!-- 1 // -->
									</tbody>
								</table>
							</div>
							<div class="pagination_container mt-3" id="paging">
								<!-- <div class="page_item arrow prev">«</div>
								<div class="page_item active">1</div>
								<div class="page_item ">2</div>
								<div class="page_item arrow next">»</div> -->
							</div>
						</div>
					</form>
				</article>
			</div>
	</div>
	<div style="display:none">
		<table>
			<tr data-copy="copy">
				<td class="col-num" data-attr="num">1</td>
				<td class="col-short-num"><span class="bold c-pointer" onclick="" data-attr="name"></span></td>
				<!-- <td class="col-tit">
					<div class="table-tit"><p class="tit"><span onclick="" data-attr="id">sample</span></p></div>
				</td> -->
				<td class=""><div class="ellipsis" data-attr="email"></div></td>
				<td class="col-short-num"><div data-attr="grade_name"></div></td>
				<td class="col-long-num" data-attr="phone"></td>
				<td class="col-num" data-attr="login_count"></td>
				<td class="col-num" data-attr="order_count"></td>
				<td><div class="table-won" data-attr="total_price"></div></td>
				<td><div class="table-won" data-attr="refund_price"></div></td>
				<td class="col-short-num" data-attr="regdate"></td>
				<td class="col-short-num" data-attr="dormant_regdate"></td>
			</tr>
		</table>
	</div>
</body>
<!-- select2 -->
<link rel="stylesheet" type="text/css" href="<?php echo $this->project_admin_path;?>layout/select2/css/select2.min.css"/>
<link rel="stylesheet" type="text/css" href="common_css/adm/adm_select.css?<?php echo $version;?>"/>
<script type="text/javascript" src="<?php echo $this->project_admin_path;?>layout/select2/js/select2.full.min.js"></script>
<script type="text/javascript">
	$(document).ready(function() {
        $('.select-custom').select2({
            minimumResultsForSearch: -1
        });
    });
</script>
