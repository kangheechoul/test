<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<title>배송정책 설정</title>
	<!-- font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
	<link href='//spoqa.github.io/spoqa-han-sans/css/SpoqaHanSans-kr.css' rel='stylesheet' type='text/css'>

	<!-- css -->
	<?php include_once $this->dir."page/adm/inc/common_css.php"; ?>

	<!-- script -->
	<?php include_once $this->dir."page/adm/inc/common_js.php"; ?>
	
</head>
<body>
	<div class="wrap">
        <?php include_once $dir."page/adm/include/adm_menu4_aside.php";?>
			<div class="bd">
				<article class="body-container">
					<div class="body-head"><h2>배송정책 설정</h2></div>
					<form class="form">
						<div class="body-box">
							<div class="insert-wrap">
								<div class="insert insert-chk">
									<label class="check_label" for="test1">고정배송비
										<input type="radio" name="privacy" id="test1"/>
										<span class="checkmark radio"></span>
									</label>
								</div>
								<div class="insert insert-chk">
									<label class="check_label" for="test2">전체 무료배송
										<input type="radio" name="privacy" id="test2"/>
										<span class="checkmark radio"></span>
									</label>
								</div>
							</div>
						</div>
						<div class="body-box mt-3">
							<div class="box-table-container">
                                <dl class="box-tbody">
									<dt class="box-th box-head">
										<p class="medium">배송지역</p>
									</dt>
									<dd class="box-td">
										<div class="insert">
											<input type="text" class="input-xs" placeholder="ex) 전국지역"/>
                                            <span class="ml-1">에 배송가능</span>
										</div>
                                    </dd>
                                </dl>
                                <dl class="box-tbody">
									<dt class="box-th box-head">
										<p class="medium">배송비</p>
									</dt>
									<dd class="box-td">
                                        <div class="insert">
                                            <select class="select-custom" type="text">
                                                <option>할인 전, 정상판매가격 기준</option>
                                                <option>최종결제금액 기준</option>
                                            </select>
                                            <span class="ml-1 mr-1">으로 배송비</span>
                                            <input type="text" class="input-xs"/>
                                            <span class="ml-1  mr-1">원 이상</span>
                                            <input type="text" class="input-xs"/>
                                            <span class="ml-1  mr-1">원 미만 일 때</span>
                                            <input type="text" class="input-xs"/>
                                            <span class="ml-1">원 부과</span>
                                        </div>
                                    </dd>
                                </dl>
                                <dl class="box-tbody">
									<dt class="box-th box-head">
										<p class="medium">배송비 선결제 설정</p>
									</dt>
									<dd class="box-td">
                                        <div class="insert-wrap">
                                            <div class="insert insert-chk">
                                                <label class="check_label" for="test3">착불
                                                    <input type="radio" name="privacy" id="test3"/>
                                                    <span class="checkmark radio"></span>
                                                </label>
                                            </div>
                                            <div class="insert insert-chk">
                                                <label class="check_label" for="test4">선결제
                                                    <input type="radio" name="privacy" id="test4"/>
                                                    <span class="checkmark radio"></span>
                                                </label>
                                            </div>
                                            <div class="insert insert-chk">
                                                <label class="check_label" for="test5">착불/선결제
                                                    <input type="radio" name="privacy" id="test5"/>
                                                    <span class="checkmark radio"></span>
                                                </label>
                                            </div>
                                        </div>
                                    </dd>
                                </dl>
							</div>
                        </div>
                    </form>
                    <div class="btn-container align-right mt-3"><button type="button" class="btn btn-primary">저장하기</button></div>
				</article>
			</div>
	</div>

</body>
<!-- select2 -->
<link rel="stylesheet" type="text/css" href="<?php echo $this->project_admin_path;?>layout/select2/css/select2.min.css"/>
<link rel="stylesheet" type="text/css" href="common_css/adm/adm_select.css?<?php echo $version;?>"/>
<script type="text/javascript" src="<?php echo $this->project_admin_path;?>layout/select2/js/select2.full.min.js"></script>
<script type="text/javascript">
	$(document).ready(function() {
        $('.select-custom').select2({
            minimumResultsForSearch: -1
        });
    });
</script>
</html>