<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>상품 반품/환불처리</title>
	<!-- font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
	<link href='//spoqa.github.io/spoqa-han-sans/css/SpoqaHanSans-kr.css' rel='stylesheet' type='text/css'>

	<!-- css -->
	<link rel="stylesheet" type="text/css" href="common_css/adm/adm_reset.css?<?php echo $version;?>"/>
	<link rel="stylesheet" type="text/css" href="common_css/adm/adm_style.css?<?php echo $version;?>"/>
	<link rel="stylesheet" type="text/css" href="common_css/adm/adm_select.css?<?php echo $version;?>"/>
    <link rel="stylesheet" type="text/css" href="common_css/adm/adm_form.css?<?php echo $version;?>"/>
    <link rel="stylesheet" type="text/css" href="common_css/adm/adm_modal.css?<?php echo $version;?>"/>
    <link rel="stylesheet" type="text/css" href="common_css/adm/adm_common.css?<?php echo $version;?>"/>

	<!-- script -->
    <?php include_once $this->dir."page/adm/inc/common_js.php"; ?>
    <script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/popup_init.js<?php echo $version;?>"></script>
    <script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/popup2_refund.js<?php echo $version;?>"></script>
</head>
<body>
	<div class="wrap" style="background-color:#e8edf3">
		<?php include_once $dir."page/adm/include/adm_member_header.php";?>
		<?php include_once $dir."page/adm/include/adm_member_aside.php";?>
        <div class="bd">
            <article class="body-container">
                <div class="body-head"><h2>상품 반품/환불</h2></div>
                <form class="form">
                    <div class="body-box mt-1">
                        <div class="box-tit mb-1"><h3>반품/환불처리</h3></div>
                        <div class="box-table-container">
                            <dl class="box-tbody">
                                <dt class="box-th box-head" style="">
                                    <p>반품상품</p>
                                </dt>
                                <dd class="box-td">
                                    <div id ="refund_products">
                                        <!-- <p class="bold">상품명1</p>
                                        <p class="bold">상품명2</p> -->
                                    </div>
                                </dd>
                            </dl>
                            <dl class="box-tbody">
                                <dt class="box-th box-head" style="">
                                    <p>반품금액입력</p>
                                </dt>
                                <dd class="box-td">
                                    <div class="insert">
                                        <input type="text" class="input-xs" id="refund_price" placeholder="없을시 0원입력" name="price"/>
                                        <span class="ml-1">원</span>
                                        <span>(해당 주문 환불 가능 금액 : <span id = "possible_refund_price">0</span>원)</span>
                                        
                                    </div>
                                </dd>
                            </dl>
                            <dl class="box-tbody">
                                <dt class="box-th box-head" style="">
                                    <p>사용자반환적립금입력</p>
                                </dt>
                                <dd class="box-td">
                                    <div class="insert">
                                        <input type="text" class="input-xs" id="return_give_point" placeholder="없을시 0원입력" name="price"/>
                                        <span class="ml-1">원</span>
                                        <span>(해당 주문 적립금 : <span id = "give_point">0</span>원</span>
                                        <span>, 적립여부 : <span id = "give_point_flag"></span>)</span>
                                    </div>
                                </dd>
                            </dl>
                            <dl class="box-tbody">
                                <dt class="box-th box-head">
                                    <p>사용적립금 복구</p>
                                </dt>
                                <dd class="box-td">
                                    <div class="insert">
                                        <input type="text" id = "return_use_point" placeholder="없을시 0원입력" class="input-xs"/><span class="ml-1">원</span>
                                        <span class="ml-1">(사용적립금 <b class="bold" id = "use_point"></b>원)</span>
                                    </div>
                                </dd>
                            </dl>
                            <!-- <dl class="box-tbody">
                                <dt class="box-th box-head" style="">
                                    <p>반환회원적립금</p>
                                </dt>
                                <dd class="box-td">
                                    <div class="insert">
                                        <input type="text" class="input-xs" id="price" name="price"/>
                                        <span class="ml-1">원</span>
                                    </div>
                                </dd>
                            </dl> -->
                            <dl class="box-tbody">
                                <dt class="box-th box-head">
                                    <p>반품사유</p>
                                </dt>
                                <dd class="box-td">
                                    <div class="insert">
                                        <textarea id = "reason" placeholder="구매자에게 안내할 반품사유를 입력하세요.(필수X)"></textarea>
                                    </div>
                                </dd>
                            </dl>
                        </div>
                    </div>
                    <!-- <div class="body-box mt-3">
                        <div class="box-tit mb-1"><h3>환불 설정</h3></div>
                            <div class="box-table-container">
                            <dl class="box-tbody">
                                <dt class="box-th box-head">
                                    <p>교환/반품 배송비 설정</p>
                                </dt>
                                <dd class="box-td">
                                    <div class="insert">
                                        <div class="insert-wrap">
                                            <div class="insert insert-chk">
                                                <label class="check_label">없음
                                                    <input type="radio" value="0" name=""/>
                                                    <span class="checkmark radio"></span>
                                                </label>
                                            </div>
                                            <div class="insert insert-chk">
                                                <label class="check_label">편도
                                                    <input type="radio" value="1" name=""/>
                                                    <span class="checkmark radio"></span>
                                                </label>
                                            </div>
                                            <div class="insert insert-chk">
                                                <label class="check_label">왕복
                                                    <input type="radio" value="2" name=""/>
                                                    <span class="checkmark radio"></span>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </dd>
                            </dl>
                            <dl class="box-tbody">
                                <dt class="box-th box-head">
                                    <p>교환/반품 배송비</p>
                                </dt>
                                <dd class="box-td">
                                    <div class="insert">
                                        <input type="text" class="input-xs"/><span class="ml-1">원</span>
                                        <p class="mt-1">주문 배송비에 합산됩니다.</p>
                                    </div>
                                </dd>
                            </dl>
                            <dl class="box-tbody">
                                <dt class="box-th box-head">
                                    <p>사용완료 배송비</p>
                                </dt>
                                <dd class="box-td">
                                    <div class="insert-wrap">
                                        <div class="insert insert-chk">
                                            <label class="check_label">이미 사용된 배송비 <b class="bold">3,000</b>원은 환불되지 않습니다.
                                                <input type="checkmark"/>
                                                <span class="checkmark"></span>
                                            </label>
                                        </div>
                                    </div>
                                </dd>
                            </dl>
                            <dl class="box-tbody">
                                <dt class="box-th box-head">
                                    <p>총 반품금액</p>
                                </dt>
                                <dd class="box-td">
                                    <div>
                                        <span><b class="bold">12,000</b>원</span>
                                        <span>(<span>상품 취소금액 <b>17,000</b>원</span> + <span>기본배송비 <b>3,000</b>원</span> + <span>추가배송비 <b>3,000</b>원</span> + <span>복구적립금 <b>3,000</b>원</span>)</span>
                                    </div>
                                </dd>
                            </dl>
                            <dl class="box-tbody">
                                <dt class="box-th box-head">
                                    <p>실 반품금액</p>
                                </dt>
                                <dd class="box-td">
                                    <div class="insert">
                                        <input type="text" class="input-xs"/><span class="ml-1">원</span>
                                    </div>
                                </dd>
                            </dl>
                            
                        </div>
                    </div> -->
                </form>
                <div class="btn-container align-right mt-3">
                    <button type="button" class="btn btn-primary" onclick="request_menual_refund()">반품/환불 하기</button>
                </div>
            </article>
        </div>
    </div>
    <div style = "display:none;">
        <table>
            <tr data-copy ="copy">
                <td class="col-num" data-attr="num"></td>
                <td class="col-tit">
                    <div>
                        <p class="tit"><span class="ellipsis c-pointer" onclick="" data-attr="product_name"></span></p>
                    </div>
                </td>
                <td class="col-tit">
                    <div>
                        <p class="tit"><span class="bold c-pointer ellipsis" onclick="" data-attr="review"></span></p>
                    </div>
                </td>
                <td class="col-num" data-attr="grade_point"></td>
                <td class="col-long-num" data-attr="regdate"></td>
            </tr>
        </table>

        <div class="img-load" style="overflow: hidden;" data-copy = "img_copy">
            <img src="<?php echo $this->project_path;?>/images/sample.png" alt="img_load" data-attr="img">
        </div>
    </div>
</body>
</html>