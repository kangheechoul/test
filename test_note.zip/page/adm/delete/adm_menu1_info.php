<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<title>쇼핑몰정보 설정</title>
	<!-- font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
	<link href='//spoqa.github.io/spoqa-han-sans/css/SpoqaHanSans-kr.css' rel='stylesheet' type='text/css'>

	<!-- css -->
	<?php include_once $this->dir."page/adm/inc/common_css.php"; ?>

	<!-- script -->
	<?php include_once $this->dir."page/adm/inc/common_js.php"; ?>
	<script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/menu1_info.js<?php echo $version;?>"></script>

	
</head>
<body>
	<div class="wrap">
		<?php include_once $dir."page/adm/include/adm_aside.php";?>
			<div class="bd">
				<article class="body-container">
					<div class="body-head"><h2>쇼핑몰정보 설정</h2></div>
					<form class="form">
						<div class="body-box">
							<div class="box-table-container">
								<dl class="box-tbody">
									<dt class="box-th box-head">
										<p class="medium">쇼핑몰정보</p>
										<p class="mt-1 xsmall">홈페이지 하단에 대표자, 연락처 등을 명시합니다.</p>
									</dt>
									<dd class="box-td">
										<div class="insert insert-textarea">
											<textarea id="content" spellcheck="false"></textarea>
										</div>
									</dd>
								</dl>
							</div>
						</div>
					</form>
					<div class="btn-container align-right mt-3">
						<button type="button" class="btn btn-primary" onclick="content_modify()">저장하기</button>
					</div>
				</article>
			</div>
	</div>

</body>
<!-- select2 -->
<link rel="stylesheet" type="text/css" href="<?php echo $this->project_admin_path;?>layout/select2/css/select2.min.css"/>
<link rel="stylesheet" type="text/css" href="common_css/adm/adm_select.css?<?php echo $version;?>"/>
<script type="text/javascript" src="<?php echo $this->project_admin_path;?>layout/select2/js/select2.full.min.js"></script>
<script type="text/javascript">

	$(document).ready(function() {
		$("select[class='select-custom']").select2();
	});

</script>
</html>