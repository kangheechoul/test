<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<title>쿠폰 관리</title>
	<!-- font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
	<link href='//spoqa.github.io/spoqa-han-sans/css/SpoqaHanSans-kr.css' rel='stylesheet' type='text/css'>

	<!-- css -->
	<?php include_once $this->dir."page/adm/inc/common_css.php"; ?>
	<script>
        var data = <?php echo $data;?>
	</script>
	<!-- script -->
	<?php include_once $this->dir."page/adm/inc/common_js.php"; ?>
	<script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/promotion_coupon.js"></script>
</head>
<body>
	<div class="wrap">
        <?php include_once $dir."page/adm/include/adm_promotion_aside.php";?>
		<div class="bd">
			<article class="body-container">
				<div class="body-head"><h2>쿠폰 관리</h2></div>
				<form class="form">
					<div class="body-box mb-3">
                        <div class="box-table-container">
                            <dl class="box-tbody">
                                <dt class="box-th box-head">
                                    <p class="medium">쿠폰사용</p>
                                </dt>
                                <dd class="box-td">
									<div class="insert-wrap">
										<div class="insert insert-input-switch">
											<span class="mr-1 bold">쿠폰과 적립금 중복사용</span>
											<label class="switch" onclick = "coupon_point_setting();">
												<input type="checkbox" id ="setting" disabled="true">
												<span class="slider round"></span>
											</label>
										</div>
									</div>
                                </dd>
                            </dl>
                        </div>
                    </div>
					<div class="body-out mb-3">
						<div class="out-tit-container">
							<h4 class="medium bold hidden">쿠폰 리스트</h4>
						</div>
						<div class="insert-wrap mb-1">
							<!-- <div class="insert insert-input-btn"><input class="btn-default" type="button" value="선택삭제"></div> -->
							<div class="insert insert-input-btn" onclick ="coupon_retrieve();"><input class="btn-default" type="button" value="선택회수"></div>
						</div>
					</div>
					<div class="body-box">
						<div class="table-container">
							<table class="table3">
								<thead>
									<tr>
										<th>
											<div class="insert insert-chk">
												<label class="check_label">
													<input type="checkbox" id = "all_check_elem" onchange="all_check(this)"/>
													<span class="checkmark"></span>
												</label>
											</div>
										</th>
										<th>번호</th>
										<th class="col-tit">쿠폰명</th>
										<th>쿠폰상태</th>
										<th>발급방식</th>
										<th>할인금액(율)</th>
										<th>최소 결제금액</th>
										<th>최대 할인금액</th>
										<th>발급기간</th>
										<th>사용기간</th>
									</tr>
								</thead>
								<tbody data-wrap = "wrap" id = "wrap">
									<!-- <tr>
										<td>
											<div class="insert insert-chk">
												<label class="check_label">
													<input type="checkbox"/>
													<span class="checkmark"></span>
												</label>
											</div>
										</td>
										<td class="col-num">1</td>
										<td class="col-tit">
											<div class="table-tit"><p class="tit"><span onclick="">전체회원 10% 할인 쿠폰(~3월29일까지 사용)</span></p></div>
										</td>
										<td class="col-short-num">수동발급</td>
										<td class="col-long-num"><div>10%</div></td>
										<td class="col-long-num">10,000원</td>
										<td class="col-long-num">500,000원</td>
										<td >2020.03.24~20.03.29</td>
										<td>2020.03.24~20.03.29</td>
									</tr> -->
									<!-- 1 // -->
								</tbody>
							</table>
						</div>
						<div class="pagination_container mt-3" id = "paging">
							<!-- <div class="page_item arrow prev">«</div>
							<div class="page_item active">1</div>
							<div class="page_item ">2</div>
							<div class="page_item arrow next">»</div> -->
						</div>
					</div>
				</form>
			</article>
		</div>
	</div>
	<div style = "display:none;">
		<table>
			<tr data-copy = "copy">
				<td>
					<div class="insert insert-chk">
						<label class="check_label">
							<input type="checkbox" data-attr="checkbox"/>
							<span class="checkmark"></span>
						</label>
					</div>
				</td>
				<td class="col-num" data-attr="num"></td>
				<td class="col-tit">
					<div class="table-tit"><p class="tit"><span onclick="" data-attr="name"></span></p></div>
				</td>
				<td class="col-short-num" data-attr="state"></td>
				<td class="col-short-num" data-attr="issue_kind"></td>
				<td class="col-long-num"><div data-attr="discount_price"></div></td>
				<td class="col-long-num" data-attr="min_limited"></td>
				<td class="col-long-num" data-attr="max_discount_price"></td>
				<td data-attr="issue_regdate"></td>
				<td data-attr="use_regdate"></td>
			</tr>
		</table>
		
	</div>
</body>
</script>
