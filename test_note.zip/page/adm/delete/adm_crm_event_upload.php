<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>이벤트 관리</title>
	<!-- font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
	<link href='//spoqa.github.io/spoqa-han-sans/css/SpoqaHanSans-kr.css' rel='stylesheet' type='text/css'>

	<!-- css -->
	<?php include_once $this->dir."page/adm/inc/common_css.php"; ?>

	<!-- script -->
	<?php include_once $this->dir."page/adm/inc/common_js.php"; ?>
	<?php include_once $this->dir."page/adm/inc/summernote.php"; ?>
	<script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/crm_event_upload.js"></script>
</head>
<body>
	<div class="wrap">
        <?php include_once $dir."page/adm/include/adm_aside.php";?>
		<div class="bd">
			<article class="body-container">
				<div class="body-head"><h2 id ="page_title">이벤트 등록</h2></div>
				<form class="form" id = "form" onsubmit='return false;'>
					<div class="body-box">
						<div class="box-table-container">
							<dl class="box-tbody">
								<dt class="box-th box-head">
									<p>진행여부</p>
								</dt>
								<dd class="box-td">
									<div class="insert">
										<div class="insert-wrap">
											<div class="insert insert-chk">
												<label class="check_label" for="use">진행
													<input type="radio" id="use" value="1" name="is_use" checked/>
													<span class="checkmark radio"></span>
												</label>
											</div>
											<div class="insert insert-chk">
												<label class="check_label" for="not_use">마감
													<input type="radio" id="not_use" value="0" name="is_use"/>
													<span class="checkmark radio"></span>
												</label>
											</div>
										</div>
									</div>
								</dd>
							</dl>
							<dl class="box-tbody">
								<dt class="box-th box-head">
									<p>쿠폰</p>
								</dt>
								<dd class="box-td">
									<div class="insert insert-select">
										<select class="select-custom" id = "coupon_select_list" style="width:360px;">

										</select>
									</div>
								</dd>
							</dl>
						</div>
					</div>
					<div class="h-line mt-3 mb-3"></div>
					<div class="out-tab-container st2 mt-3 mb-2">
						<ul data-wrap="lang_btn_wrap" id="lang_btn_wrap">
							<!-- <li class="current" data-copy=""><a data-attr="lang">KOR</a></li><li class="" data-copy=""><a data-attr="lang">ENG</a></li><li class="" data-copy=""><a data-attr="lang">CHN</a></li> -->
						</ul>
					</div>
					<div  data-wrap="lang_input_wrap" id="lang_input_wrap">
						
					</div>
					<!-- 정보 // -->
				</form>
				<div class="btn-container align-right mt-3">
					<button type="button" class="btn btn-ghost" onclick='cancel_location();'>취소</button>
					<button type="button" class="btn btn-primary ml-1" id = "save_btn">등록하기</button>
				</div>
			</article>
		</div>
	</div>
	<div style="display:none">
		<div class="img-upload" style="overflow: hidden;" data-copy = "img_copy">
            <img src="" data-attr="img" alt="img_upload"/>
            <input type="hidden" data-attr="prev_img_url"/>
            <button  data-attr="del_btn" class="delete-btn" type="button"></button>
        </div>
		<li class="" data-copy="lang_btn_copy"><a data-attr="lang">한국어</a></li> <!-- 언어 버튼, 활성화면 li class = current--> 
		<!-- 언어별 데이터 input  -->
		<div data-copy="lang_input_copy">
			<div class="body-box mt-3" >
				<div class="box-table-container" >
					<dl class="box-tbody">
						<dt class="box-th box-head">
							<p>썸네일 등록</p>
						</dt>
						<dd class="box-td">
							<!-- 이미지 등록 버튼 -->
							<div class="img-upload img-upload-main" style="overflow: hidden;">
								<span class="btn-wrap">
									<button class="btn-img-upload" href="#"><strong></strong></button>
									<input type="file" name="thumnail_files[]" data-attr="file">
								</span> 				
								<label data-attr="file_label"></label>
							</div>
							<!-- 이미지 등록 버튼 // -->
							<!-- 이미지가 첨부될 시 옆에 나열됩니다 -->
							<div data-attr="img_elem" style = "display:inline-block">
								
							</div>
							<!-- 이미지 1 // -->
							<p class="xsmall">jpg, png, gif 형식의 파일, 권장 사이즈 1920x<br>4MB 이하의 이미지 1장 첨부 가능</p>
						</dd>
					</dl>
					<dl class="box-tbody">
						<dt class="box-th box-head">
							<p>제목</p>
						</dt>
						<dd class="box-td">
							<div class="insert insert-input">
								<input type="text" class="input-sm" data-attr="title" />
							</div>
						</dd>
					</dl>
				</div>
			</div>
			

			<div class="body-box mt-3">
				<div class="box-tit mb-2"><h3>설명</h3></div>
				<div class="insert insert-textarea mt-2">
					<div class = "summernote" style = "width:100%; height:654px;" data-attr="sum_note"></div>
				</div>
			</div>

			
		</div>
	</div>
</body>
<!-- select2 -->
<link rel="stylesheet" type="text/css" href="<?php echo $this->project_admin_path;?>layout/select2/css/select2.min.css"/>
<link rel="stylesheet" type="text/css" href="common_css/adm/adm_select.css?<?php echo $version;?>"/>
<script type="text/javascript" src="<?php echo $this->project_admin_path;?>layout/select2/js/select2.full.min.js"></script>

<!-- yd custom -->
<script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/custom.js"></script>

<script>
	// $(document).ready(function(){
	// 	$(".select-custom").select2({
	// 		templateResult: formatState,
	// 		minimumResultsForSearch: -1
	// 	});
	// });
	
	// function formatState (state) {
	// 	if (!state.id) { return state.text; }
	// 	var $state = $(
	// 		'<span ><img style="display:intrial; vertical-align:middle; max-width:40px;" src="https://s3.ap-northeast-2.amazonaws.com/lbplatform/images/BANCHAN/154440389322996.jpg" /> ' + state.text + '</span>'
	// 		);
	// 	return $state;
	// }

</script>

</html>