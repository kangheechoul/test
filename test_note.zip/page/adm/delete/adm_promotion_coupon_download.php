<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<title>쿠폰 발급내역</title>
	<!-- font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
	<link href='//spoqa.github.io/spoqa-han-sans/css/SpoqaHanSans-kr.css' rel='stylesheet' type='text/css'>

	<!-- css -->
	<?php include_once $this->dir."page/adm/inc/common_css.php"; ?>
    <link rel="stylesheet" type="text/css" href="common_css/adm/jquery-ui.min.css?<?php echo $version;?>"/>

    <script>
        var data = <?php echo $data?>;
    </script>

	<!-- script -->
    <?php include_once $this->dir."page/adm/inc/common_js.php"; ?>
    <script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/jquery-ui.min.js<?php echo $version;?>"></script>
    <script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/datepicker-ko.js<?php echo $version;?>"></script>
	<script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/promotion_coupon_download.js"></script>
</head>
<body>
	<div class="wrap">
        <?php include_once $dir."page/adm/include/adm_promotion_aside.php";?>
        <div class="bd">
            <article class="body-container">
                <div class="body-head"><h2>쿠폰 발급내역</h2></div>
                <form class="form">
                    <div class="body-box mb-3">
                        <div class="box-search-container">
                            <div class="insert-wrap">
                                <div class="insert insert-select">
                                    <select class="select-custom" id = "select_kind" type="text">
                                        <option value = "coupon_name">쿠폰명</option>
                                        <option value = "user_name">회원이름</option>
                                        <option value = "user_id">회원아이디</option>
                                    </select>
                                </div>
                                <div class="insert insert-input"><input class="input-lg" autocomplete="off" id = "keyword" type="text"/></div>
                            </div>
                        </div>
                        <!-- 상세검색 전문 -->
                        <div class="box-table-container mt-3">
                            <dl class="box-tbody">
                                <dt class="box-th box-head"><p>발급기간</p></dt>
                                <dd class="box-td">
                                    <ul class="insert-wrap">
                                        <li class="insert insert-chk">
                                            <label class="check_label">전체
                                                <input type="checkbox" id = "issue_date" />
                                                <span class="checkmark"></span>
                                            </label>
                                        </li>
                                        <li class="insert insert-input datepick-wirte"><input class="input-32 input-xs" autocomplete="off" id ="issue_start_date" type="text"/><i></i></li>
                                        <li class="insert">~</li>
                                        <li class="insert insert-input datepick-wirte"><input class="input-32 input-xs" autocomplete="off" id ="issue_end_date" type="text"/><i></i></li>
                                    </ul>
                                </dd>
                            </dl>
                            <dl class="box-tbody">
                                <dt class="box-th box-head"><p>사용기간</p></dt>
                                <dd class="box-td">
                                    <ul class="insert-wrap">
                                        <li class="insert insert-chk">
                                            <label class="check_label">전체
                                                <input type="checkbox" id = "use_date" />
                                                <span class="checkmark"></span>
                                            </label>
                                        </li>
                                        <li class="insert insert-input datepick-wirte"><input class="input-32 input-xs" autocomplete="off" id = "use_start_date" type="text"/><i></i></li>
                                        <li class="insert">~</li>
                                        <li class="insert insert-input datepick-wirte"><input class="input-32 input-xs" autocomplete="off" id = "use_end_date" type="text"/><i></i></li>
                                    </ul>
                                </dd>
                            </dl>
                        </div>
                        <div class="insert-wrap align-center mt-3">
                            <div class="insert insert-input-btn" id ="select_btn"><input class="btn-primary" type="button" value="검색"/></div>
                            <div class="insert insert-input-btn" id ="init_btn"><input class="btn-default" type="button" value="초기화"/></div>
                        </div>
                    </div>
                    <div class="body-out mb-3">
                        <div class="out-tab-container">
                            <ul>
                                <li id = "all_tab"><a href="#1"></a></li>
                                <li id = "use_tab"><a href="#2"></a></li>
                                <li id = "unuse_tab"><a href="#3"></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="body-box">
                        <div class="table-container">
                            <table class="table1">
                                <thead>
                                    <tr>
                                        <th>번호</th>
                                        <th>이름</th>
                                        <th>아이디</th>
                                        <th class="col-tit">쿠폰명</th>
                                        <th>발급방식</th>
                                        <th>할인금액(율)</th>
                                        <th>최소 결제금액</th>
                                        <th>최대 할인금액</th>
                                        <th>발급일</th>
                                        <th>사용일</th>
                                    </tr>
                                </thead>
                                <tbody data-wrap ="wrap" id = "wrap">
                                    <!-- <tr>
                                        <td>
                                            <div class="insert insert-chk">
                                                <label class="check_label">
                                                    <input type="checkbox"/>
                                                    <span class="checkmark"></span>
                                                </label>
                                            </div>
                                        </td>
                                        <td class="col-num">1</td>
                                        <td class="col-short-num"><span class="c-pointer" onclick="">하예든</span></td>
                                        <td class="col-short-num"><span class="c-pointer" onclick="">smaple</span></td>
                                        <td class="col-tit">
                                            <div class="table-tit"><p class="tit"><span onclick="">전체회원 10% 할인 쿠폰(~3월29일까지 사용)</span></p></div>
                                        </td>
                                        <td class="col-short-num">다운로드</td>
                                        <td class="col-long-num"><div>10%</div></td>
                                        <td class="col-long-num">10,000원</td>
                                        <td class="col-long-num">500,000원</td>
                                        <td>2020.03.29</td>
                                        <td class="col-long-num">
                                            <div class="insert insert-input-btn"><input class="btn-default btn-32" type="button" value="2020.03.24"/></div>
                                            버튼 클릭시 쿠폰을 사용한 주문내역 팝업 오픈
                                        </td>
                                    </tr> -->
                                    <!-- 2 // -->
                                    <!-- <tr>
                                        <td>
                                            <div class="insert insert-chk">
                                                <label class="check_label">
                                                    <input type="checkbox"/>
                                                    <span class="checkmark"></span>
                                                </label>
                                            </div>
                                        </td>
                                        <td class="col-num">1</td>
                                        <td class="col-short-num"><span class="c-pointer" onclick="">하예든</span></td>
                                        <td class="col-short-num"><span class="c-pointer" onclick="">smaple</span></td>
                                        <td class="col-tit">
                                            <div class="table-tit"><p class="tit"><span onclick="">전체회원 10% 할인 쿠폰(~3월29일까지 사용)</span></p></div>
                                        </td>
                                        <td class="col-short-num">수동발급</td>

                                        <td class="col-long-num"><div>10%</div></td>
                                        <td class="col-long-num">10,000원</td>
                                        <td class="col-long-num">500,000원</td>
                                        <td>2020.03.29</td>
                                        <td class="col-long-num">
                                            <div class="insert-wrap">
                                                <div class="insert red">미사용</div>
                                                <div class="insert insert-input-btn"><input class="btn-default btn-32" type="button" value="회수"/></div>
                                            </div>
                                        </td>
                                    </tr> -->
                                    <!-- 1 // -->
                                </tbody>
                            </table>
                        </div>
                        <div class="pagination_container mt-3" id ="paging">
                            <div class="page_item arrow prev">«</div>
                            <div class="page_item active">1</div>
                            <!-- <div class="page_item ">2</div> -->
                            <div class="page_item arrow next">»</div>
                        </div>
                    </div>
                </form>
            </article>
        </div>
	</div>
    <div style ="display:none;">
        <table>
            <tr data-copy = "copy">
                <td class="col-num" data-attr="num"></td>
                <td class="col-short-num"><span class="c-pointer" data-attr="name"></span></td>
                <td class="col-short-num"><span class="c-pointer" data-attr="email"></span></td>
                <td class="col-tit">
                    <div class="table-tit"><p class="tit"><span data-attr="coupon_name"></span></p></div>
                </td>
                <td class="col-short-num" data-attr="issue_kind"></td>
                <td class="col-long-num"><div data-attr="discount_price"></div></td>
                <td class="col-long-num" data-attr="min_limited"></td>
                <td class="col-long-num" data-attr="max_discount_price"></td>
                <td data-attr="regdate"></td>
                <td class="col-long-num" data-attr="use">
                    <!-- <div class="insert insert-input-btn"><input class="btn-default btn-32" type="button" value="2020.03.24"/></div> -->
                    <!-- 버튼 클릭시 쿠폰을 사용한 주문내역 팝업 오픈 -->
                    <!-- <div class="insert-wrap">
                        <div class="insert red">미사용</div>
                        <div class="insert insert-input-btn"><input class="btn-default btn-32" type="button" value="회수"/></div>
                    </div> -->
                </td>
            </tr>
        </table>
    </div>
</body>
<!-- select2 -->
<link rel="stylesheet" type="text/css" href="<?php echo $this->project_admin_path;?>layout/select2/css/select2.min.css"/>
<link rel="stylesheet" type="text/css" href="common_css/adm/adm_select.css?<?php echo $version;?>"/>
<script type="text/javascript" src="<?php echo $this->project_admin_path;?>layout/select2/js/select2.full.min.js"></script>
<script type="text/javascript">
	$(document).ready(function() {
        $('.select-custom').select2({
            minimumResultsForSearch: -1
        });
    });
</script>
