<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<title>상품진열순서 변경</title>
	<!-- font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
	<link href='//spoqa.github.io/spoqa-han-sans/css/SpoqaHanSans-kr.css' rel='stylesheet' type='text/css'>

	<!-- css -->
	<?php include_once $this->dir."page/adm/inc/common_css.php"; ?>

	<!-- script -->
    <?php include_once $this->dir."page/adm/inc/common_js.php"; ?>
    <script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/menu3_pd_sort.js<?php echo $version;?>"></script>

	
</head>
<body>
	<div class="wrap">
        <?php include_once $dir."page/adm/include/adm_aside.php";?>
			<div class="bd">
				<article class="body-container">
					<div class="body-head"><h2>상품진열순서 변경</h2></div>
					<form class="form">
						<div class="body-box mb-3">
							<div class="box-table-container">
								<dl class="box-tbody">
									<dt class="box-th box-head"><p class="medium">카테고리 선택</p></dt>
									<dd class="box-td">
                                        <div class="insert-wrap">
                                            <div class="insert insert-select">
                                                <select class="select-custom" type="text" id="main_category" onchange="request_category_list(1, this.value)">
                                                    <option>대분류</option>
                                                </select>
                                            </div>
                                            <div class="insert insert-select" id="category1_view" style="display:none;">
                                                <select class="select-custom" type="text" id="category_1" onchange="request_category_list(2, this.value)">
                                                    <option>중분류</option>
                                                </select>
                                            </div>
                                            <div class="insert insert-select mt-1" id="category2_view" style="display:none;">
                                                <select class="select-custom" type="text" id="category_2" onchange="request_category_list(3, this.value)">
                                                    <option>소분류</option>
                                                </select>
                                            </div>
                                            <div class="insert insert-select mt-1" id="category3_view" style="display:none;">
                                                <select class="select-custom" type="text" id="category_3">
                                                    <option>세분류</option>
                                                </select>
                                            </div>
                                        </div>
                                        <!-- <div class="insert-wrap mt-1">
                                            <div class="insert insert-chk">
                                                <label class="check_label" for="test3">숨김상품 제외
                                                    <input type="radio" name="what" id="test3">
                                                    <span class="checkmark radio"></span>
                                                </label>
                                            </div>
                                            <div class="insert insert-chk">
                                                <label class="check_label" for="test4">품절상품 제외
                                                    <input type="radio" name="what" id="test4">
                                                    <span class="checkmark radio"></span>
                                                </label>
                                            </div>
                                        </div> -->
                                        <div class="insert-wrap mt-2">
                                            <div class="insert insert-input-btn"><input class="btn-primary" type="button" value="검색" onclick="search_product_category_relation()"/></div>
									        <!-- <div class="insert insert-input-btn"><input class="btn-default" type="button" value="초기화"/></div> -->
                                        </div>
                                    </dd>
								</dl>
							</div>
                        </div>
                        <div class="row p-relative">
                            <div class="col-md-11">
                                <div class="body-box">
                                    <!-- <div class="box-tit mb-3"><h3><b>12</b>개의 상품이 검색되었습니다.</h3></div> -->
                                    <div class="table-container">
                                        <table class="table2">
                                            <thead>
                                                <tr>
                                                    <th>번호</th>
                                                    <th class="col-img">이미지</th>
                                                    <th class="col-tit">상품명</th>
                                                    <th>판매가</th>
                                                    <th>판매</th>
                                                    <th>관심</th>
                                                    <th>담기</th>
                                                    <!-- <th>조회</th> -->
                                                </tr>
                                            </thead>
                                            <tbody data-wrap="wrap" id="wrap">
                                                <!-- <tr>
                                                    <td>1</td>
                                                    <td class="col-img">
                                                        <div class="table-thumb">
                                                            <img src="<?php echo $this->project_admin_path;?>images/sample.png" alt="상품이미지"/>
                                                        </div>
                                                    </td>
                                                    <td class="col-tit">
                                                        <div class="table-tit">
                                                            <p class="tit bold">제품타이틀입니다.</p>
                                                            <p class="ct mt-2">스마트폰 거치대 > 핑거밴드</p>
                                                        </div>
                                                    </td>
                                                    <td><div class="table-won">19,000</div></td>
                                                    <td><div class="table-count">12</div></td>
                                                    <td><div class="table-count">3</div></td>
                                                    <td><div class="table-count">21</div></td>
                                                    <td><div class="table-count">5,555</div></td>
                                                </tr> -->
                                                <!-- 1 // -->
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-1">
                                <div class="sort-control-container">
                                    <div class="body-box">
                                        <div class="mt-2">
                                            <div class="insert mb-1"><input type="text" class="input-32" id="move_count" value="1" onkeyup="lb.validate_number(this)"/></div>
                                            <div class="insert"><span class="controller-btn"><img src="<?php echo $this->project_admin_image_path;?>control-top-max.png" onclick="btn_top()"/>최상</span></div>
                                            <div class="insert"><span class="controller-btn"><img src="<?php echo $this->project_admin_image_path;?>control-top.png" onclick="btn_up()"/>위</span></div>
                                            <div class="insert"><span class="controller-btn"><img src="<?php echo $this->project_admin_image_path;?>control-bt.png" onclick="btn_down()"/>아래</span></div>
                                            <div class="insert"><span class="controller-btn"><img src="<?php echo $this->project_admin_image_path;?>control-bt-max.png" onclick="btn_end()"/>최하</span></div>
                                        </div>
                                    </div>
                                    <div class="sort-control-insert-wrap">
                                        <div class="insert insert-input-btn mt-1"><input class="btn-primary" type="button" value="적용하기" onclick="btn_save()"></div>
                                        <div class="insert insert-input-btn mt-1"><input class="btn-default" type="button" value="초기화" onclick="btn_init()"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
					</form>
				</article>
			</div>
	</div>
    <div style="display:none;">
        <table>
            <tr data-copy="copy">
                <td data-attr="num"></td>
                <td class="col-img">
                    <div class="table-thumb">
                        <img src="<?php echo $this->project_admin_image_path;?>sample.png" alt="상품이미지" data-attr="thumnail_file"/>
                    </div>
                </td>
                <td class="col-tit">
                    <div class="table-tit">
                        <p class="tit bold" data-attr="product_name">제품타이틀입니다.</p>
                    </div>
                </td>
                <td><div class="table-won" data-attr="price">19,000</div></td>
                <td><div class="table-count" data-attr="order_count">12</div></td>
                <td><div class="table-count" data-attr="wish_count">3</div></td>
                <td><div class="table-count" data-attr="basket_count">21</div></td>
                <!-- <td><div class="table-count">5,555</div></td> -->
            </tr>
        </table>
    </div>
</body>
<!-- select2 -->
<link rel="stylesheet" type="text/css" href="<?php echo $this->project_admin_path;?>layout/select2/css/select2.min.css"/>
<link rel="stylesheet" type="text/css" href="common_css/adm/adm_select.css?<?php echo $version;?>"/>
<script type="text/javascript" src="<?php echo $this->project_admin_path;?>layout/select2/js/select2.full.min.js"></script>
<script type="text/javascript">
	$(document).ready(function() {
        $('.select-custom').select2({
            minimumResultsForSearch: -1
        });
    });
</script>
</html>