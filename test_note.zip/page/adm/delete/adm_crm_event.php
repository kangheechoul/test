<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>이벤트 관리</title>
	<!-- font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
	<link href='//spoqa.github.io/spoqa-han-sans/css/SpoqaHanSans-kr.css' rel='stylesheet' type='text/css'>

	<!-- css -->
	<?php include_once $this->dir."page/adm/inc/common_css.php"; ?>

	<!-- script -->
	<?php include_once $this->dir."page/adm/inc/common_js.php"; ?>
	<script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/crm_event.js<?php echo $version;?>"></script>


</head>
<body>
	<div class="wrap">
        <?php include_once $dir."page/adm/include/adm_aside.php";?>
		<div class="bd">
			<article class="body-container">
				<div class="body-head"><h2>이벤트 관리</h2></div>
					<form class="form" id="form">
						<div class="body-out mb-3">
							<div class="out-tit-container">
								<h4 class="medium bold"><b id="total_count">0</b>개 검색되었습니다.</h4>
							</div>
							<div class="insert-wrap mb-1">
								<div class="insert insert-input-btn"><input class="btn-primary" id = "register_btn" type = "button" value = "등록하기"></div>
								<div class="insert insert-input-btn"><input class="btn-default" id = "del_btn" type = "button" value = "삭제"></div>
							</div>
						</div>
						<div class="row p-relative mt-2">
							<div class="col-md-12">
								<div class="body-box">
									<div class="table-container">
										<table class="table1">
											<thead>
												<tr>
													<th>
														<div class="insert insert-chk">
															<label class="check_label">
																<input type="checkbox" id = "all_checkbox" onclick="all_check(this)"/>
																<span class="checkmark"></span>
															</label>
														</div>
													</th>
													<th>번호</th>
													<th>썸네일</th>
													<th class="col-tit">제목</th>
													<th>등록일</th>
													<th>진행여부</th>
												</tr>
											</thead>
											<tbody data-wrap="wrap" id="wrap">

												<!-- 1 // -->
											</tbody>
										</table>
									</div>
									<div class="pagination_container mt-3" id = "paging">
										<!-- <div class="page_item arrow prev">«</div>
										<div class="page_item active">1</div>
										<div class="page_item ">2</div>
										<div class="page_item arrow next">»</div> -->
									</div>
								</div>
							</div>
						</div>
					</form>
			</article>
		</div>
	</div>

	<div style = "display:none;">
		<table>
			<tr data-copy="copy">
				<td>
					<div class="insert insert-chk">
						<label class="check_label">
							<input type="checkbox" data-attr="checkbox"/>
							<span class="checkmark"></span>
						</label>
					</div>
				</td>
				<td class="col-num" data-attr="num"></td>
				<td class="col-img">
					<div class="table-thumb">
						<img src="" data-attr="img" alt="이미지"/>
					</div>
				</td>
				<td class="col-tit">
					<div class="table-tit">
						<p class="tit"><span onclick="" data-attr="title"></span></p>
					</div>
				</td>
				<td class="col-long-num"><div class="table-date" data-attr="regdate">20.03.18</div></td>
				<td class="col-short-num">
					<div>
						<select class="select-custom" data-attr="event_state">
							<option value="1">진행</option>
							<option value="0">마감</option>
						</select>
					</div>
				</td>
			</tr>
		</table>
		
	</div>
</body>
<!-- select2 -->
<link rel="stylesheet" type="text/css" href="<?php echo $this->project_admin_path;?>layout/select2/css/select2.min.css"/>
<link rel="stylesheet" type="text/css" href="common_css/adm/adm_select.css?<?php echo $version;?>"/>
<script type="text/javascript" src="<?php echo $this->project_admin_path;?>layout/select2/js/select2.full.min.js"></script>
</html>