<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<title>취소/교환/환불사유 설정</title>
	<!-- font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
	<link href='//spoqa.github.io/spoqa-han-sans/css/SpoqaHanSans-kr.css' rel='stylesheet' type='text/css'>

	<!-- css -->
	<?php include_once $this->dir."page/adm/inc/common_css.php"; ?>

	<!-- script -->
	<?php include_once $this->dir."page/adm/inc/common_js.php"; ?>
	<script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/menu4_refund_reason.js<?php echo $version;?>"></script>
</head>
<body>
	<div class="wrap">
        <?php include_once $dir."page/adm/include/adm_menu4_aside.php";?>
			<div class="bd">
				<article class="body-container">
					<div class="body-head"><h2>취소/교환/환불사유 설정</h2></div>
					<form class="form">
						<div class="row">
							<div class="col-md-12">
							<div class="body-box mt-1">
									<ul class="row category-container">
										<li class="col-md-4">
											<div class="">
												<div class="box-table-container">
													<div>
														<div class="insert insert-select">
															<p class="mb-1 bold">취소사유 설정</p>
															<select class="select-list" multiple="multiple" size="4">
																<option value="독수리">독수리</option>
																<option value="매">매</option>
															</select>
														</div>
														<div class="insert-wrap mt-1">
															<div class="insert insert-input-btn"><input class="btn-default btn-32" type="button" value="선택삭제"/></div>
														</div>
													</div>
												</div>
												<!-- 카테고리 리스트 // -->
												<div class="box-table-container">
													<div class="mt-2" data-wrap = "cancel_input_wrap" id ="cancel_input_wrap">
														<div class="insert insert-input mb-1">
															<p class="mb-1 bold">취소사유<i class="i-lang">(한국어<img src="<?php echo $this->project_admin_path;?>images/i-kor.png" alt="kor"/>)</i></p>
															<input type="text" class="input-sm" id="main_category_input" disabled>
														</div>
														<div class="insert insert-input mb-1">
															<p class="mb-1 bold">취소사유<i class="i-lang">(영어<img src="<?php echo $this->project_admin_path;?>images/i-eng.png" alt="eng"/>)</i></p>
															<input type="text" class="input-sm" id="main_category_input" disabled>
														</div>
														<div class="insert insert-input">
															<p class="mb-1 bold">취소사유<i class="i-lang">(중국어<img src="<?php echo $this->project_admin_path;?>images/i-chn.png" alt="chn"/>)</i></p>
															<input type="text" class="input-sm" id="main_category_input" disabled>
														</div>
													</div>
													<div class="insert-wrap mt-2">
														<div class="insert insert-input-btn"><input class="btn-primary" type="button" value="등록"></div>
													</div>
												</div>
												<!-- 등록 // -->
											</div>
										</li>
                                        <!-- 취소사유 // -->
										<li class="col-md-4">
											<div class="">
												<div class="box-table-container">
													<div>
														<div class="insert insert-select">
															<p class="mb-1 bold">교환사유 설정</p>
															<select class="select-list" multiple="multiple" size="4">
																<option value="독수리">독수리</option>
																<option value="매">매</option>
															</select>
														</div>
														<div class="insert-wrap mt-1">
															<div class="insert insert-input-btn"><input class="btn-default btn-32" type="button" value="선택삭제"/></div>
														</div>
													</div>
												</div>
												<!-- 카테고리 리스트 // -->
												<div class="box-table-container">
													<div class="mt-2" data-wrap = "exchange_input_wrap" id ="exchange_input_wrap">
														<!-- <div class="insert insert-input mb-1">
															<p class="mb-1 bold">교환사유<i class="i-lang">(한국어<img src="<?php echo $this->project_admin_path;?>images/i-kor.png" alt="kor"/>)</i></p>
															<input type="text" class="input-sm" id="main_category_input" disabled>
														</div>
														<div class="insert insert-input mb-1">
															<p class="mb-1 bold">교환사유<i class="i-lang">(영어<img src="<?php echo $this->project_admin_path;?>images/i-eng.png" alt="eng"/>)</i></p>
															<input type="text" class="input-sm" id="main_category_input" disabled>
														</div>
														<div class="insert insert-input">
															<p class="mb-1 bold">교환사유<i class="i-lang">(중국어<img src="<?php echo $this->project_admin_path;?>images/i-chn.png" alt="chn"/>)</i></p>
															<input type="text" class="input-sm" id="main_category_input" disabled>
														</div> -->
													</div>
													<div class="insert-wrap mt-2">
														<div class="insert insert-input-btn"><input class="btn-primary" type="button" value="등록"></div>
													</div>
												</div>
												<!-- 등록 // -->
											</div>
										</li>
                                        <!-- 교환사유 // -->
										<li class="col-md-4">
											<div class="">
												<div class="box-table-container">
													<div>
														<div class="insert insert-select">
															<p class="mb-1 bold">환불사유 설정</p>
															<select class="select-list" multiple="multiple" size="4">
																<option value="매">매</option>
															</select>
														</div>
														<div class="insert-wrap mt-1">
															<div class="insert insert-input-btn"><input class="btn-default btn-32" type="button" value="선택삭제"/></div>
														</div>
													</div>
												</div>
												<!-- 카테고리 리스트 // -->
												<div class="box-table-container">
													<div class="mt-2" data-wrap = "refund_input_wrap" id ="refund_input_wrap">
														<!-- <div class="insert insert-input mb-1">
															<p class="mb-1 bold">환불사유<i class="i-lang">(한국어<img src="<?php echo $this->project_admin_path;?>images/i-kor.png" alt="kor"/>)</i></p>
															<input type="text" class="input-sm" id="main_category_input" disabled>
														</div>
														<div class="insert insert-input mb-1">
															<p class="mb-1 bold">환불사유<i class="i-lang">(영어<img src="<?php echo $this->project_admin_path;?>images/i-eng.png" alt="eng"/>)</i></p>
															<input type="text" class="input-sm" id="main_category_input" disabled>
														</div>
														<div class="insert insert-input">
															<p class="mb-1 bold">환불사유<i class="i-lang">(중국어<img src="<?php echo $this->project_admin_path;?>images/i-chn.png" alt="chn"/>)</i></p>
															<input type="text" class="input-sm" id="main_category_input" disabled>
														</div> -->
													</div>
													<div class="insert-wrap mt-2">
														<div class="insert insert-input-btn"><input class="btn-primary" type="button" value="등록"></div>
													</div>
												</div>
												<!-- 등록 // -->
											</div>
										</li>
                                        <!-- 취소사유 // -->
									</ul>
								</div>
							</div>
						</div>
						<!-- 카테고리 // -->
                    </form>
				</article>
			</div>
	</div>

	<div style = "display:none;">
		<div class="insert insert-input mb-1" data-copy="copy">
			<p class="mb-1 bold"><i data-attr="title">사유</i><i class="i-lang" data-attr="lang">(한국어<img src="<?php echo $this->project_admin_path;?>images/i-kor.png" alt="kor"/>)</i></p>
			<input type="text" class="input-sm" data-attr="reason">
		</div>
	</div>

</body>
<!-- select2 -->
<link rel="stylesheet" type="text/css" href="<?php echo $this->project_admin_path;?>layout/select2/css/select2.min.css"/>
<link rel="stylesheet" type="text/css" href="common_css/adm/adm_select.css?<?php echo $version;?>"/>
<script type="text/javascript" src="<?php echo $this->project_admin_path;?>layout/select2/js/select2.full.min.js"></script>

<!-- yd custom -->
<script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/custom.js"></script>

</html>