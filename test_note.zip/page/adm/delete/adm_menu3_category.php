<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<title>카테고리 설정</title>
	<!-- font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
	<link href='//spoqa.github.io/spoqa-han-sans/css/SpoqaHanSans-kr.css' rel='stylesheet' type='text/css'>

	<!-- css -->
	<?php include_once $this->dir."page/adm/inc/common_css.php"; ?>
	<!-- script -->
	<?php include_once $this->dir."page/adm/inc/common_js.php"; ?>
	<script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/menu3_category.js<?php echo $version;?>"></script>
	
</head>
<body>
	<div class="wrap">
        <?php include_once $dir."page/adm/include/adm_aside.php";?>
			<div class="bd">
				<article class="body-container">
					<div class="body-head"><h2>카테고리 설정</h2></div>
					<form class="form">
						<div class="row">
							<div class="col-md-12">
							<div class="body-box mt-1">
									<div class="box-tit"><h3>카테고리</h3></div>
									<ul class="row category-container">
										<li class="col-md-6" id="main_category_view">
											<div class="">
												<div class="box-table-container">
													<div>
														<div class="insert insert-select">
															<p class="mb-1 bold">대분류</p>
															<select class="select-list"size="6" id="main_category" onchange="request_category_list(1, this.value)">
																<!-- <option value="독수리">독수리</option>
																<option value="매">매</option>
																<option value="까치">까치</option>
																<option value="두루미">두루미</option>
																<option value="까마귀">까마귀</option>
																<option value="참새">참새</option>
																<option value="뻐꾸기">뻐꾸기</option>
																<option value="왕뿌리새">왕뿌리새</option> -->
															</select>
														</div>
														<div class="insert-wrap mt-1">
															<div class="insert insert-input-btn"><input class="btn-default btn-32" type="button" value="선택삭제"  disabled/></div>
														</div>
													</div>
												</div>
												<!-- 카테고리 리스트 // -->
												<div class="h-line mt-2"></div>
												<div class="box-table-container">
													<div class="mt-2">
														<div class="insert insert-input mb-1"> 
															<p class="mb-1 bold">카테고리명<i class="i-lang">(한국어<img src="<?php echo $this->project_admin_image_path;?>i-kor.png" alt="kor"/>)</i></p>
															<input type="text" class="input-sm" id="main_category_input_1" disabled>
														</div>
														<div class="insert insert-input mb-1">
															<p class="mb-1 bold">카테고리명<i class="i-lang">(영어<img src="<?php echo $this->project_admin_image_path;?>i-eng.png" alt="eng"/>)</i></p>
															<input type="text" class="input-sm" id="main_category_input_2" disabled>
														</div>
														<div class="insert insert-input">
															<p class="mb-1 bold">카테고리명<i class="i-lang">(중국어<img src="<?php echo $this->project_admin_image_path;?>i-chn.png" alt="chn"/>)</i></p>
															<input type="text" class="input-sm" id="main_category_input_3" disabled>
														</div>
													</div>
													<div class="insert-wrap mt-2">
														<div class="insert insert-input-btn"><input class="btn-primary" type="button" value="등록"  disabled></div>
													</div>
												</div>
												<!-- 등록 // -->
											</div>
										</li>
										<li class="col-md-6" id="category1_view" style="display:none;">
											<div class="">
												<div class="box-table-container">
													<div>
														<div class="insert insert-select">
															<p class="mb-1 bold">중분류</p>
															<select class="select-list"size="6" id="category_1" onchange="request_category_list(2, this.value)">
																<!-- <option value="독수리">독수리</option>
																<option value="매">매</option> -->
															</select>
														</div>
														<div class="insert-wrap mt-1">
															<div class="insert insert-input-btn"><input class="btn-default btn-32" type="button" value="선택삭제" onclick="delete_category(1)"/></div>
														</div>
													</div>
												</div>
												<!-- 카테고리 리스트 // -->
												<div class="h-line mt-2"></div>
												<div class="box-table-container">
													<div class="mt-2" data-wrap="category1_input_view">
														<!-- <div class="insert insert-input mb-1">
															<p class="mb-1 bold">카테고리명<i class="i-lang">(한국어<img src="<?php echo $this->project_admin_image_path;?>images/i-kor.png" alt="kor"/>)</i></p>
															<input type="text" class="input-sm" id="main_category_input">
														</div>
														<div class="insert insert-input mb-1">
															<p class="mb-1 bold">카테고리명<i class="i-lang">(영어<img src="<?php echo $this->project_admin_image_path;?>images/i-eng.png" alt="eng"/>)</i></p>
															<input type="text" class="input-sm" id="main_category_input">
														</div>
														<div class="insert insert-input">
															<p class="mb-1 bold">카테고리명<i class="i-lang">(중국어<img src="<?php echo $this->project_admin_image_path;?>images/i-chn.png" alt="chn"/>)</i></p>
															<input type="text" class="input-sm" id="main_category_input">
														</div> -->
													</div>
													<div class="insert-wrap mt-2">
														<div class="insert insert-input-btn"><input class="btn-primary" type="button" value="등록" onclick="add_category(1)"></div>
													</div>
												</div>
												<!-- 등록 // -->
											</div>
										</li>
										<li class="col-md-6" id="category2_view" style="display:none;">
											<div class="">
												<div class="box-table-container">
													<div>
														<div class="insert insert-select">
															<p class="mb-1 bold">소분류</p>
															<select class="select-list"size="6" id="category_2" onchange="request_category_list(3, this.value)">
																<!-- <option value="독수리">독수리</option>
																<option value="매">매</option>
																<option value="까치">까치</option>
																<option value="두루미">두루미</option>
																<option value="까마귀">까마귀</option>
																<option value="참새">참새</option>
																<option value="뻐꾸기">뻐꾸기</option>
																<option value="왕뿌리새">왕뿌리새</option> -->
															</select>
														</div>
														<div class="insert-wrap mt-1">
															<div class="insert insert-input-btn"><input class="btn-default btn-32" type="button" value="선택삭제" onclick="delete_category(2)"/></div>
														</div>
													</div>
												</div>
												<!-- 카테고리 리스트 // -->
												<div class="h-line mt-2"></div>
												<div class="box-table-container">
													<div class="mt-2" data-wrap="category2_input_view">
														<!-- <div class="insert insert-input mb-1">
															<p class="mb-1 bold">카테고리명<i class="i-lang">(한국어<img src="<?php echo $this->project_admin_image_path;?>images/i-kor.png" alt="kor"/>)</i></p>
															<input type="text" class="input-sm" id="main_category_input">
														</div>
														<div class="insert insert-input mb-1">
															<p class="mb-1 bold">카테고리명<i class="i-lang">(영어<img src="<?php echo $this->project_admin_image_path;?>images/i-eng.png" alt="eng"/>)</i></p>
															<input type="text" class="input-sm" id="main_category_input">
														</div>
														<div class="insert insert-input">
															<p class="mb-1 bold">카테고리명<i class="i-lang">(중국어<img src="<?php echo $this->project_admin_image_path;?>images/i-chn.png" alt="chn"/>)</i></p>
															<input type="text" class="input-sm" id="main_category_input">
														</div> -->
													</div>
													<div class="insert-wrap mt-2">
														<div class="insert insert-input-btn"><input class="btn-primary" type="button" value="등록" onclick="add_category(2)"></div>
													</div>
												</div>
												<!-- 등록 // -->
											</div>
										</li>
										<li class="col-md-6" id="category3_view" style="display:none;">
											<div class="">
												<div class="box-table-container">
													<div>
														<div class="insert insert-select">
															<p class="mb-1 bold">세분류</p>
															<select class="select-list"size="6" id="category_3">
																<!-- <option value="독수리">독수리</option>
																<option value="매">매</option>
																<option value="까치">까치</option>
																<option value="두루미">두루미</option>
																<option value="까마귀">까마귀</option>
																<option value="참새">참새</option>
																<option value="뻐꾸기">뻐꾸기</option>
																<option value="왕뿌리새">왕뿌리새</option> -->
															</select>
														</div>
														<div class="insert-wrap mt-1">
															<div class="insert insert-input-btn"><input class="btn-default btn-32" type="button" value="선택삭제" onclick="delete_category(3)"/></div>
														</div>
													</div>
												</div>
												<!-- 카테고리 리스트 // -->
												<div class="h-line mt-2"></div>
												<div class="box-table-container">
													<div class="mt-2" data-wrap="category3_input_view">
														<!-- <div class="insert insert-input mb-1">
															<p class="mb-1 bold">카테고리명<i class="i-lang">(한국어<img src="<?php echo $this->project_admin_image_path;?>images/i-kor.png" alt="kor"/>)</i></p>
															<input type="text" class="input-sm" id="main_category_input">
														</div>
														<div class="insert insert-input mb-1">
															<p class="mb-1 bold">카테고리명<i class="i-lang">(영어<img src="<?php echo $this->project_admin_image_path;?>images/i-eng.png" alt="eng"/>)</i></p>
															<input type="text" class="input-sm" id="main_category_input">
														</div>
														<div class="insert insert-input">
															<p class="mb-1 bold">카테고리명<i class="i-lang">(중국어<img src="<?php echo $this->project_admin_image_path;?>images/i-chn.png" alt="chn"/>)</i></p>
															<input type="text" class="input-sm" id="main_category_input">
														</div> -->
													</div>
													<div class="insert-wrap mt-2">
														<div class="insert insert-input-btn"><input class="btn-primary" type="button" value="등록" onclick="add_category(3)"></div>
													</div>
												</div>
												<!-- 등록 // -->
											</div>
										</li>
										
									</ul>
								</div>
							</div>
						</div>
						<!-- 카테고리 // -->
                    </form>
                    <!-- <div class="btn-container align-right mt-3"><button type="button" class="btn btn-primary">저장하기</button></div> -->
				</article>
			</div>
	</div>
	<div style="display:none">
		<div class="insert insert-input mb-1" data-copy="input_copy">
			<p class="mb-1 bold">카테고리명<i class="i-lang" data-attr="lang">(한국어<img src="<?php echo $this->project_admin_image_path;?>images/i-kor.png" alt="kor"/>)</i></p>
			<input type="text" class="input-sm" data-attr="input">
		</div>
	</div>
</body>
<!-- select2 -->
<link rel="stylesheet" type="text/css" href="<?php echo $this->project_admin_path;?>layout/select2/css/select2.min.css"/>
<link rel="stylesheet" type="text/css" href="common_css/adm/adm_select.css?<?php echo $version;?>"/>
<script type="text/javascript" src="<?php echo $this->project_admin_path;?>layout/select2/js/select2.full.min.js"></script>

<!-- yd custom -->
<script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/custom.js"></script>

</html>