<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>회원 상품Q&A</title>
	<!-- font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
	<link href='//spoqa.github.io/spoqa-han-sans/css/SpoqaHanSans-kr.css' rel='stylesheet' type='text/css'>

	<!-- css -->
	<?php include_once $this->dir."page/adm/inc/common_css.php"; ?>
    <!-- script -->
    <?php include_once $this->dir."page/adm/inc/common_js.php"; ?>
    <script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/popup_init.js<?php echo $version;?>"></script>
    <script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/popup_pd_question.js<?php echo $version;?>"></script>
   
</head>
<body>
	<div class="wrap" style="background-color:#e8edf3">
        <?php include_once $dir."page/adm/include/adm_member_header.php";?>
		<?php include_once $dir."page/adm/include/adm_member_aside.php";?>
        <div class="bd">
            <article class="body-container">
                <div class="body-head"><h2>상품Q&A</h2></div>
                <form class="form">
                    <div class="row">
                        <div class="col-md-7">
                            <div class="body-box">
                                <div class="table-container">
                                    <table class="table3">
                                        <thead>
                                            <tr>
                                                <th>번호</th>
                                                <th class="col-tit">상품명</th>
                                                <th class="col-tit">제목</th>
                                                <th>등록일</th>
                                                <th>답변일</th>
                                            </tr>
                                        </thead>
                                        <tbody data-wrap = "wrap" id = "wrap">
                                            <!-- <tr>
                                                <td class="col-num">2</td>
                                                <td class="col-tit">
                                                    <div>
                                                        <p class="tit"><span class="ellipsis c-pointer" onclick="">상품이 onclick 되어야합니다.</span></p>
                                                    </div>
                                                </td>
                                                <td class="col-tit">
                                                    <div>
                                                        <p class="tit"><span class="bold c-pointer ellipsis" onclick="">제목을 누르면 우측 상세페이지가 나타납니다.</span></p>
                                                    </div>
                                                </td>

                                                <td class="col-long-num">20.03.24  18:00:06</td>
                                                <td class="col-long-num">미답변</td>
                                            </tr>
                                            <tr class="current">
                                                <td class="col-num">1</td>
                                                <td class="col-tit">
                                                    <div>
                                                        <p class="tit"><span class="ellipsis c-pointer" onclick="">상품명이 들어갑니다.</span></p>
                                                    </div>
                                                </td>
                                                <td class="col-tit">
                                                    <div>
                                                        <p class="tit"><span class="bold c-pointer ellipsis" onclick="">제목 들어갑니다.</span></p>
                                                    </div>
                                                </td>
                                                <td class="col-long-num">20.03.24 18:00:06</td>
                                                <td class="col-long-num">20.03.24 18:12:06</td>
                                            </tr> -->
                                        </tbody>
                                    </table>
                                </div>
                                <div class="pagination_container mt-3" id = "paging">
                                    <!-- <div class="page_item arrow prev">«</div>
                                    <div class="page_item active">1</div>
                                    <div class="page_item ">2</div>
                                    <div class="page_item arrow next">»</div> -->
                                </div>
                            </div>
                        </div>
                        <div class="col-md-5">
                            <div class="body-box">
                                <div class="box-table-container box-table-container2">
                                    <div class="box-tit mb-1"><h3>질문</h3></div>
                                    <dl class="box-tbody">
                                        <dt class="box-th box-head">
                                            <p>상품</p>
                                        </dt>
                                        <dd class="box-td">
                                            <p class="c-pointer" onclick="" id = "d_product_name"></p>
                                        </dd>
                                    </dl>
                                    <dl class="box-tbody">
                                        <dt class="box-th box-head">
                                            <p>제목</p>
                                        </dt>
                                        <dd class="box-td">
                                            <p class="bold" id = "d_title"></p>
                                        </dd>
                                    </dl>
                                    <dl class="box-tbody">
                                        <dt class="box-th box-head">
                                            <p>등록일</p>
                                        </dt>
                                        <dd class="box-td">
                                            <p class="" id = "d_regdate"></p>
                                        </dd>
                                    </dl>
                                    <dl class="box-tbody">
                                        <dt class="box-th box-head">
                                            <p>문의내용</p>
                                        </dt>
                                        <dd class="box-td">
                                            <div class="insert insert-textarea">
                                                <textarea readonly  id = "d_content"></textarea>
                                            </div>
                                        </dd>
                                    </dl>
                                    <dl class="box-tbody">
                                        <dt class="box-th box-head">
                                            <p>첨부이미지</p>
                                        </dt>
                                        <dd class="box-td">
                                            <div data-wrap = "img_wrap" id = "img_wrap">
                                               
                                            </div>
                                            <!-- 이미지 1 // -->
                                            <p class="xsmall">이미지를 클릭하면 확대되어 나타납니다.</p>
                                        </dd>
                                    </dl>
                               </div>
                               <!-- 질문 // -->
                                <div class="box-table-container box-table-container2 mt-3">
                                    <div class="box-tit mb-1"><h3>답변</h3></div>
                                    <dl class="box-tbody">
                                        <dt class="box-th box-head">
                                            <p>답변일</p>
                                        </dt>
                                        <dd class="box-td">
                                            <p id = "d_answer_date"></p>
                                        </dd>
                                    </dl>
                                    <dl class="box-tbody">
                                        <dt class="box-th box-head">
                                            <p>답변내용</p>
                                        </dt>
                                        <dd class="box-td">
                                            <div class="insert insert-textarea">
                                                <textarea id = "d_answer"></textarea>
                                            </div>
                                        </dd>
                                    </dl>
                                </div>
                                <!-- 답변 // -->
                                <div class="insert-wrap mt-2 align-center">
                                    <div class="insert insert-input-btn"><input class="btn-primary" id = "answer_btn" type="button" value="완료"></div>
                                    <div class="insert insert-input-btn"><input class="btn-default" id = "refresh_btn" type="button" value="취소"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </article>
        </div>
    </div>
    
    <div style = "display : none;">
        <table>
            <tr data-copy = "copy">
                <td class="col-num" data-attr="num"></td>
                <td class="col-tit">
                    <div>
                        <p class="tit"><span class="ellipsis c-pointer" onclick="" data-attr="product"></span></p>
                    </div>
                </td>
                <td class="col-tit">
                    <div>
                        <p class="tit"><span class="bold c-pointer ellipsis" onclick="" data-attr="title"></span></p>
                    </div>
                </td>
                <td class="col-long-num" data-attr="regdate"></td>
                <td class="col-long-num" data-attr="answer_date"></td>
            </tr>
        </table>
        <div class="img-load" style="overflow: hidden;" data-copy = "img_copy">
            <img src="<?php echo $this->project_path;?>/images/sample.png" alt="img_load" data-attr="img">
        </div>
    </div>
</body>
</html>