<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>회원 정보</title>
	<!-- font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
	<link href='//spoqa.github.io/spoqa-han-sans/css/SpoqaHanSans-kr.css' rel='stylesheet' type='text/css'>

	<!-- css -->
	<link rel="stylesheet" type="text/css" href="common_css/adm/adm_reset.css?<?php echo $version;?>"/>
	<link rel="stylesheet" type="text/css" href="common_css/adm/adm_style.css?<?php echo $version;?>"/>
	<link rel="stylesheet" type="text/css" href="common_css/adm/adm_select.css?<?php echo $version;?>"/>
	<link rel="stylesheet" type="text/css" href="common_css/adm/adm_form.css?<?php echo $version;?>"/>
    <link rel="stylesheet" type="text/css" href="common_css/adm/adm_common.css?<?php echo $version;?>"/>

	<!-- script -->
    <?php include_once $this->dir."page/adm/inc/common_js.php"; ?>
    <script src="https://t1.daumcdn.net/mapjsapi/bundle/postcode/prod/postcode.v2.js"></script> 
    <script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/popup_init.js<?php echo $version;?>"></script>
    <script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/popup_info_personal.js<?php echo $version;?>"></script>
</head>
<body>
	<div class="wrap" style="background-color:#e8edf3">
		<?php include_once $dir."page/adm/include/adm_member_header.php";?>
		<?php include_once $dir."page/adm/include/adm_member_aside.php";?>
        <div class="bd">
            <article class="body-container">
                <div class="body-head"><h2>회원정보</h2></div>
                <form class="form" id = "user_form">
                    <div class="row">
                        <div class="col-md-8">
                            <div class="body-box">
                                <div class="box-table-container box-table-container2">
                                    <div class="box-tit mb-1"><h3>가입정보</h3></div>
                                    <dl class="box-tbody">
                                        <dt class="box-th box-head">
                                            <p>이름</p>
                                        </dt>
                                        <dd class="box-td">
                                            <div class="insert insert-input"><input class="input-xs" name = "user_name" type="text"/></div>
                                        </dd>
                                    </dl>
                                    <dl class="box-tbody">
                                        <dt class="box-th box-head">
                                            <p>이메일</p>
                                        </dt>
                                        <dd class="box-td">
                                            <p class="bold" id = "user_email"></p>
                                        </dd>
                                    </dl>
                                    <dl class="box-tbody">
                                        <dt class="box-th box-head">
                                            <p>새비밀번호</p>
                                        </dt>
                                        <dd class="box-td">
                                            <div class="insert insert-input"><input class="input-xs" autocomplete="off" name = "user_new_pw" type="password"/></div>
                                            <p class="mt-1 xsmall">시스템 암호화로 현재 비밀번호는 알 수 없습니다, 변경시에만 입력하세요.</p>
                                        </dd>
                                    </dl>
                                    <dl class="box-tbody">
                                        <dt class="box-th box-head">
                                            <p>새비밀번호 확인</p>
                                        </dt>
                                        <dd class="box-td">
                                            <div class="insert insert-input"><input class="input-xs" autocomplete="off" name = "user_new_pw_check" type="password"/></div>
                                        </dd>
                                    </dl>
                                    <dl class="box-tbody">
                                        <dt class="box-th box-head">
                                            <p>연락처</p>
                                        </dt>
                                        <dd class="box-td">
                                            <div class="insert insert-input"><input onkeydown='return onlyNumber(event)' onkeyup='removeChar(event)' class="input-sm" name = "phone" type="text"/></div>
                                        </dd>
                                    </dl>
                                    <!-- <dl class="box-tbody">
                                        <dt class="box-th box-head">
                                            <p>이메일</p>
                                        </dt>
                                        <dd class="box-td">
                                            <ul class="insert-wrap">
                                                <li class="insert insert-input"><input class="input-xs"  name = "email_id" type="text"/><span class="ml-1">@</span></li>
                                                <li class="insert insert-input"><input class="input-xs" name = "email_name" type="text"/></li>
                                                <li class="insert insert-select">
                                                    <select class="select-custom" id = "email_select">
                                                        <option value="직접입력">직접입력</option>
                                                        <option value="naver.com">naver.com</option>
                                                        <option value="gmail.com">gmail.com</option>
                                                        <option value="hanmail.net">hanmail.net</option>
                                                        <option value="nate.com">nate.com</option>
                                                    </select>
                                                </li>
                                            </ul>
                                        </dd>
                                    </dl> -->
                                    <dl class="box-tbody">
                                        <dt class="box-th box-head">
                                            <p>주소</p>
                                        </dt>
                                        <dd class="box-td">
                                            <ul class="insert-wrap">
                                                <li class="insert insert-input"><input class="input-xs" name = "post_code" type="text" readonly/></li>
                                                <li class="insert insert-input"><input  class="btn-default" name = "address_btn" type="button" value="주소검색"/></li>
                                            </ul>
                                            <div class="insert insert-input"><input class="input-lg" name = "address" type="text" readonly/></div>
                                            <div class="insert insert-input"><input class="input-lg" name = "detail_address" type="text" placeholder="상세주소 입력"/></div>
                                        </dd>
                                    </dl>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="body-box">
                                <div class="box-table-container box-table-container2">
                                    <div class="box-tit mb-1"><h3>이메일&문자메시지 수신관리</h3></div>
                                    <dl class="box-tbody">
                                        <dt class="box-th box-head">
                                            <p>이메일</p>
                                        </dt>
                                        <dd class="box-td">
                                            <div class="insert-wrap">
                                                <div class="insert insert-chk">
                                                    <label class="check_label" for="test1">수신
                                                        <input type="radio" name="email" id="test1">
                                                        <span class="checkmark radio"></span>
                                                    </label>
                                                </div>
                                                <div class="insert insert-chk">
                                                    <label class="check_label" for="test2">수신안함
                                                        <input type="radio" name="email" id="test2">
                                                        <span class="checkmark radio"></span>
                                                    </label>
                                                </div>
                                            </div>
                                        </dd>
                                    </dl>
                                    <dl class="box-tbody">
                                        <dt class="box-th box-head">
                                            <p>문자메시지</p>
                                        </dt>
                                        <dd class="box-td">
                                            <div class="insert-wrap">
                                                <div class="insert insert-chk">
                                                    <label class="check_label" for="test3">수신
                                                        <input type="radio" name="sms" id="test3">
                                                        <span class="checkmark radio"></span>
                                                    </label>
                                                </div>
                                                <div class="insert insert-chk">
                                                    <label class="check_label" for="test4">수신안함
                                                        <input type="radio" name="sms" id="test4">
                                                        <span class="checkmark radio"></span>
                                                    </label>
                                                </div>
                                            </div>
                                        </dd>
                                    </dl>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
                <div class="btn-container align-center mt-3"><button type="button" class="btn btn-primary" id ="save_btn">저장하기</button></div>
            </article>
        </div>
	</div>
</body>
<!-- select2 -->
<link rel="stylesheet" type="text/css" href="<?php echo $this->project_admin_path;?>layout/select2/css/select2.min.css"/>
<link rel="stylesheet" type="text/css" href="common_css/adm/adm_select.css?<?php echo $version;?>"/>
<script type="text/javascript" src="<?php echo $this->project_admin_path;?>layout/select2/js/select2.full.min.js"></script>

<!-- yd custom -->
<script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/custom.js"></script>
</html>