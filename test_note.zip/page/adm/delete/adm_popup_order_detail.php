<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>회원 상세주문서</title>
	<!-- font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
	<link href='//spoqa.github.io/spoqa-han-sans/css/SpoqaHanSans-kr.css' rel='stylesheet' type='text/css'>

	<!-- css -->
	<?php include_once $this->dir."page/adm/inc/common_css.php"; ?>
	<!-- script -->
	<?php include_once $this->dir."page/adm/inc/common_js.php"; ?>
	<script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/popup_init.js<?php echo $version;?>"></script>
	<script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/popup_order_detail.js<?php echo $version;?>"></script>
</head>
<body>
	<div class="modal user-modal" id="invoice_input_modal" style="display:none;">
		<div class="modal-wrap modal-md">
			<div class="modal-container">
				<!-- 모달 본문 -->
				<div class="modal-container-inner">
					<div class="modal-head bold">송장번호 입력</div>
					<div class="modal-body">
						<form class="form">
							<div class="body-box">
								<div class="box-table-container">
									<dl class="box-tbody">
										<dt class="box-th box-head"><p class="small">택배사</p></dt>
										<dd class="box-td">
											<ul class="insert-wrap">
												<li class="insert insert-input">
													<input class="input-sm" id = "courier_name" value = "한진택배" readonly type="text">
												</li>
											</ul>
										</dd>
									</dl>
									<dl class="box-tbody">
										<dt class="box-th box-head"><p class="small">송장번호</p></dt>
										<dd class="box-td">
											<ul class="inssert-wrap">
												<li class="insert insert-input">
													<input class="input-sm" id = "invoice_number" type="text" >
												</li>
											</ul>
										</dd>
									</dl>
								</div>
							</div>
						</form>
					</div>
					<ul class="btn-container align-right">
						<li><button type="button" class="btn btn-ghost" onclick = "close_invoice_input_modal();">취소</button></li>
						<li><button type="button" class="btn btn-primary" id = "request_invoice_number_btn">등록</button></li>
					</ul>
				</div>
				<!-- 모달 본문 // -->
			</div>
		</div>
	</div>
	<!-- 상태 상세보기 클릭 시 모달 -->
	<div class="modal user-modal" id = "state_regdate_modal" style = "display:none;">
		<div class="modal-wrap modal-xl">
			<div class="modal-container">
				<span class="modal-close" onclick ="state_regdate_modal_close()">&#10005;</span><!-- 모달 닫기 // -->
				<!-- 모달 본문 -->
				<div class="modal-container-inner">
					<div class="modal-head bold">상태</div>
					<div class="modal-body">
						<div class="table-container">
							<table class="table3">
								<thead>
									<tr>
										<th>이미지</th>
										<th class="col-tit">상품명</th>
										<th>판매가</th>
										<th>미입금</th>
										<th>입금완료</th>
										<th>배송준비중</th>
										<th>배송중</th>
										<th>배송완료</th>
									</tr>
								</thead>
								<tbody data-wrap ="state_wrap" id = "state_wrap">
									<!-- <tr>
										<td class="col-num" data-attr="num">1</td>
										<td class="col-img">
											<div class="table-thumb">
												<img src="IPIACOSMETIC/_uploads/thumnail_img/155776540583508.jpg" data-attr="img" alt="상품이미지">
											</div>
										</td>
										<td class="col-tit">
											<div class="table-tit">
												<p class="tit"><span onclick="" data-attr="product_name">히비스커스 크림(할인 없음, 재고 사용 안함 )</span></p>
												<p class="ct mt-2" data-attr="option">가격 있음</p>
											</div>
										</td>
										<td>117,000</td>
										<td><p>2020-06-20</p><p>18:00:42</p></td>
										<td><p>2020-06-20</p><p>18:00:42</p></td>
										<td><p>2020-06-20</p><p>18:00:42</p></td>
										<td></td>
										<td></td>
									</tr> -->
								</tbody>
							</table>
						</div>
					</div>
					<ul class="btn-container align-right">
						<li><button type="button" class="btn btn-primary" onclick="state_regdate_modal_close()">닫기</button></li>
					</ul>
				</div>
				<!-- 모달 본문 // -->
			</div>
		</div>
	</div>

	<!-- 송장번호에 담긴 상품 클릭 시 모달 -->
	<div class="modal user-modal" id = "invoice_modal" style = "display:none;">
		<div class="modal-wrap modal-xl">
			<div class="modal-container">
				<span class="modal-close" onclick ="invoice_modal_close()">&#10005;</span><!-- 모달 닫기 // -->
				<!-- 모달 본문 -->
				<div class="modal-container-inner">
					<div class="modal-head bold" id="cur_invoice_number">

					</div>
					<div class="modal-body">
						<div class="table-container">
							<table class="table3">
								<thead>
									<tr>
										<th>이미지</th>
										<th class="col-tit">상품명</th>
										<th>판매가</th>
										<th>상태</th>
									</tr>
								</thead>
								<tbody data-wrap="invoice_list_wrap" id= "invoice_list_wrap">
									<!-- <tr>
										<td class="col-img">
											<div class="table-thumb">
												<img src="IPIACOSMETIC/_uploads/thumnail_img/155776540583508.jpg" data-attr="img" alt="상품이미지">
											</div>
										</td>
										<td class="col-tit">
											<div class="table-tit">
												<p class="tit"><span onclick="" data-attr="product_name">히비스커스 크림(할인 없음, 재고 사용 안함 )</span></p>
												<p class="ct mt-2" data-attr="option">가격 있음</p>
											</div>
										</td>
										<td>117,000</td>
										<td></td>
									</tr> -->
								</tbody>
							</table>
						</div>
					</div>
					<ul class="btn-container align-right">
						<li><button type="button" class="btn btn-primary" onclick="invoice_modal_close()">닫기</button></li>
					</ul>
				</div>
				<!-- 모달 본문 // -->
			</div>
		</div>
	</div>
	<div class="wrap" style="background-color:#e8edf3">
		<?php include_once $dir."page/adm/include/adm_member_header.php";?>
		<?php include_once $dir."page/adm/include/adm_member_aside.php";?>
		<div class="bd">
			<article class="body-container">
				<div class="body-head"><h2>주문상품</h2></div>
				<form class="form">
					<div class="row">
						<div class="col-md-12">
						<div class="body-box mt-3">
								<div class="box-tit mb-2"><h3>주문정보</h3></div>
								<div class="box-table-container">
									<dl class="box-tbody">
										<dt class="box-th box-head">
											<p>주문번호</p>
										</dt>
										<dd class="box-td" id = "order_number">
											1234567890
										</dd>
									</dl>
									<dl class="box-tbody">
										<dt class="box-th box-head">
											<p>주문일시</p>
										</dt>
										<dd class="box-td" id = "order_regdate">20.03.24 18:00:56</dd>
									</dl>
									<dl class="box-tbody">
										<dt class="box-th box-head">
											<p>결제방법</p>
										</dt>
										<dd class="box-td">
											<div class="td-con1">
												<span id ="pay_type"><!-- 신용카드<b>(19,000원)<b> --></span>
												<!-- <span class="txt-alpha">적립금<b>(0원)<b></span> -->
											</div>
										</dd>
									</dl>
									<!-- <dl class="box-tbody">
										<dt class="box-th box-head">
											<p>카드정보</p>
										</dt>
										<dd class="box-td">
											<div class="td-con2">
												<span>카드정보 : <b>현대VISA (01개월)<b></span>
												<span>거래번호 : <b>ws_to2020032408291311135<b></span>
											</div>
										</dd>
									</dl> -->
									<dl class="box-tbody">
										<dt class="box-th box-head">
											<p>사용쿠폰</p>
										</dt>
										<dd class="box-td" id = "is_coupon">
											<table class="table3">
												<thead>
													<tr>
														<th class="col-tit">쿠폰명</th>
														<th>할인금액(율)</th>
														<th>사용기간</th>
														<th>쿠폰제한</th>
														<th>최대금액</th>
													</tr>
												</thead>
												<tbody data-wrap = "coupon_wrap" id = "coupon_wrap">
													<!-- <tr>
														<td class="col-tit">
															<div class="table-tit">
																<p class="tit">0% 할인쿠폰</p>
															</div>
														</td>
														<td class="col-long-num">0%</td>
														<td>2020.03.31~2020.03.31</td>
														<td class="col-long-num">
															<p class="tit">15,000원</p>
														</td>
														<td class="col-long-num">
															<p class="tit">200,000원</p>
														</td>
													</tr> -->
													<!-- 1 // -->
												</tbody>
											</table>
										</dd>
									</dl>
									<dl class="box-tbody">
										<dt class="box-th box-head">
											<p>상태<span class="min-con" onclick = "state_regdate_modal_open('all')">상세보기</span></p>
										</dt>
										<dd class="box-td">
											<div class="td-con3">
												<ul>
													<li class="td-con3-inner">
														<div class="load">
															<p class="load-tit">미입금</p>
															<p class="xsmall" id = "regdate"></p>
														</div>
													</li>
													<li class="td-con3-inner">
														<div class="load"><!-- 완료 되었을 때 class "load-blue" 추가 -->
															<p class="load-tit">입금완료</p>
															<p class="xsmall" id ="deposit_regdate"><!-- 20.03.24 16:44:56 --></p>
														</div>
													</li>
													<li class="td-con3-inner">
														<div class="load">
															<p class="load-tit">배송준비중</p>
															<p class="xsmall" id = "delivery_ready_regdate"></p>
															<!-- <p class="xsmall chking">(0)</p> -->
														</div>
													</li>
													<li class="td-con3-inner">
														<div class="load">
															<p class="load-tit">배송중</p>
															<p class="xsmall" id ="on_delivery_regdate"></p>
															<!-- <p class="xsmall chking">(0)</p> -->
														</div>
													</li>
													<li class="td-con3-inner">
														<div class="load">
															<p class="load-tit">배송완료</p>
															<p class="xsmall" id = "complete_regdate"></p>
														</div>
													</li>
												</ul>
											</div>
										</dd>
									</dl>
									<dl class="box-tbody">
										<dt class="box-th box-head">
											<p>배송완료일시</p>
										</dt>
										<dd class="box-td" id = "bill_complete_regdate">배송완료 전입니다.</dd><!-- 완료되었을 때 20.03.24 18:00:56 -->
									</dl>
								</div>
							</div>
							<!-- 기본정보 // -->
						</div>
					</div>
					<div class="row">
						<div class="col-md-6">
							<div class="body-box mt-3">
								<div class="box-tit mb-2"><h3>주문자 정보</h3></div>
								<div class="box-table-container">
									<dl class="box-tbody">
										<dt class="box-th box-head">
											<p>이름</p>
										</dt>
										<dd class="box-td" id ="orderer_name"></dd>
									</dl>
									<dl class="box-tbody">
										<dt class="box-th box-head">
											<p>연락처</p>
										</dt>
										<dd class="box-td" id ="orderer_phone"></dd>
									</dl>
									<dl class="box-tbody">
										<dt class="box-th box-head">
											<p>이메일</p>
										</dt>
										<dd class="box-td" id ="orderer_email"></dd>
									</dl>
								</div>
							</div>
						</div>
						<div class="col-md-6">
							<div class="body-box mt-3">
								<div class="box-tit mb-2"><h3>배송 정보</h3></div>
								<div class="box-table-container">
									<dl class="box-tbody">
										<dt class="box-th box-head">
											<p>송장번호</p>
										</dt>
										<dd class="box-td" id = "invoice_wrap" data-wrap="invoice_wrap">
										
										</dd>
									</dl>
									<dl class="box-tbody">
										<dt class="box-th box-head">
											<p>수령인</p>
										</dt>
										<dd class="box-td" id = "r_name"></dd>
									</dl>
									<dl class="box-tbody">
										<dt class="box-th box-head">
											<p>주소</p>
										</dt>
										<dd class="box-td">
											<div class="td-con2">
												<span id = "post_code">(우) 41586</span>
												<span id = "address">대구광역시 북구 호암로 20(칠성동2가, 성광우방타운)</span>
												<span id = "detail_address">110동1506호</span>
											</div>
										</dd>
									</dl>
									<dl class="box-tbody">
										<dt class="box-th box-head">
											<p>연락처</p>
										</dt>
										<dd class="box-td" id = "r_phone_number">01030215551</dd>
									</dl>
									<dl class="box-tbody">
										<dt class="box-th box-head">
											<p>배송메모</p>
										</dt>
										<dd class="box-td" id = "message">배송 전 문자 부탁드립니다.</dd>
									</dl>
								</div>
							</div>
						</div>
					</div>
					<div class="row mt-3">
						<div class="col-md-9">
							<div class="body-box">
								<div class="box-tab-container mb-2">
									<ul>
										<li id = "first" class="current"><a href="#1">일반</a></li>
										<li id = "second"><a href="#2">취소상품</a></li>
										<li id = "third"><a href="#3">환불상품</a></li>
										<li id = "fourth"><a href="#4">반품상품</a></li>
										<li id = "fifth"><a href="#5">교환상품</a></li>
									</ul>
								</div>
								<div class="table-container">
									<table class="table3">
										<thead>
											<tr>
												<th>
													<div class="insert insert-chk">
														<label class="check_label">
															<input type="checkbox" onchange="all_check(this);" id ="all_check_target_elems" />
															<span class="checkmark"></span>
														</label>
													</div>
												</th>
												<th>번호</th>
												<th>이미지</th>
												<th class="col-tit">상품명</th>
												<th>판매가</th>
												<th>상태</th>
											</tr>
										</thead>
										<tbody data-wrap="wrap" id = "wrap">
											
										</tbody>
										<tfoot>
											<tr class="col-total-tr">
												<td colspan="4" class="bold align-center">합계</td>
												<td><div class="table-won" id = "sum_product_price">0</div></td>
												<td></td>
											</tr>
										</tfoot>
									</table>
								</div>
								<div class="insert-wrap mt-1">
									<div class="insert insert-input-btn"><input class="btn-default btn-28" type="button" onclick = "change_process_state(this)" id = "cancel_btn" value="상품취소"></div>
									<div class="insert insert-input-btn"><input class="btn-default btn-28" type="button" onclick = "change_process_state(this)" id = "refund_btn" value="상품환불"></div>
									<div class="insert insert-input-btn"><input class="btn-default btn-28" type="button" onclick = "change_process_state(this)" id = "return_btn" value="상품반품"></div>
									<div class="insert insert-input-btn"><input class="btn-default btn-28" type="button" onclick = "change_process_state(this)" id = "exchange_btn" value="상품교환"></div>
								</div>
								<div class="insert-wrap mt-1">
									<div class="insert insert-input-btn"><input class="btn-primary btn-28" type="button" onclick = "change_delivery_state(this);" id = "unpaid_btn" value="미입금"></div>
									<div class="insert insert-input-btn"><input class="btn-primary btn-28" type="button" onclick = "change_delivery_state(this);" id = "deposit_btn" value="입금완료"></div>
									<div class="insert insert-input-btn"><input class="btn-primary btn-28" type="button" onclick = "change_delivery_state(this);" id = "delivery_ready_btn" value="배송준비중"></div>
									<div class="insert insert-input-btn"><input class="btn-primary btn-28" type="button" onclick = "change_delivery_state(this);" id = "on_delivery_btn" value="배송중"></div>
									<div class="insert insert-input-btn"><input class="btn-primary btn-28" type="button" onclick = "change_delivery_state(this);" id = "complete_btn" value="배송완료"></div>
								</div>
							</div>
						</div>
						<!-- 주문상품 // -->
						<div class="col-md-3">
							<div class="body-box">
								<div class="price-total-container">
									<dl class="price-body">
										<dt class="price-th">배송비</dt>
										<dd id = "delivery_price"></dd>
									</dl>
									<dl class="price-body price-total-body">
										<dt>총주문액</dt>
										<dd id = "total_order_price">19,000원</dd>
									</dl>
								</div>
								<div class="price-total-container">
									<dl class="price-body">
										<dt class="price-th">사용적립금</dt>
										<dd id = "use_point">- 0원</dd>
									</dl>
									<dl class="price-body">
										<dt class="price-th">쿠폰</dt>
										<dd id = "coupon_discount_price">- 0원</dd>
									</dl>
									<dl class="price-body">
										<dt class="price-th">등급</dt>
										<dd id = "grade_discount_price">- 0원</dd>
									</dl>
									<dl class="price-body price-total-body">
										<dt>할인금액</dt>
										<dd id = "total_discount_price">- 0원</dd>
									</dl>
								</div>
								<div class="price-total-container">
									<!-- <dl class="price-body">
										<dt class="price-th">구매적립금</dt>
										<dd id = "">190원</dd>
									</dl> -->
									<dl class="price-body price-total-body">
										<dt>적립금액</dt>
										<dd id = "give_point"></dd>
									</dl>
								</div>
								<div class="price-total-container">
									<dl class="price-body price-total-body">
										<dt>실결제금액</dt>
										<dd id ="total_purchase_price"></dd>
									</dl>
								</div>
							</div>
						</div>
						<!-- 결제금액 // -->
					</div>
				</form>
			</article>
		</div>
	</div>

	<div style = "display:none;">
		<table>
			<tr data-copy="copy">
				<td>
					<div class="insert insert-chk">
						<label class="check_label">
							<input type="checkbox" data-attr="checkbox"/>
							<span class="checkmark"></span>
						</label>
					</div>
				</td>
				<td class="col-num" data-attr="num">1</td>
				<td class="col-img">
					<div class="table-thumb">
						<img src="" data-attr="img" alt="상품이미지"/>
					</div>
				</td>
				<!-- <script>
					$(document).ready(function(){
						$(".table-thumb").mouseenter(function(){
							$(this).clone()
							.addClass("cloned")
							.appendTo(".table-thumb");
						});
						$(".table-thumb").mouseleave(function(){
							$(".table-thumb.cloned").remove();
						});
					});
				</script> -->
				<td class="col-tit">
					<div class="table-tit">
						<p class="tit"><span onclick="" data-attr="product_name"></span></p>
						<p class="ct mt-2" data-attr="option"></p>
					</div>
				</td>
				<td><div class="table-won" data-attr="product_price"></div></td>
				<td data-attr="state"></td>
			</tr>

			<tr data-copy = "coupon_copy">
				<td class="col-tit">
					<div class="table-tit">
						<p class="tit" data-attr="coupon_name"></p>
					</div>
				</td>
				<td class="col-long-num" data-attr="discount_price"></td>
				<td data-attr="use_date"></td>
				<td class="col-long-num">
					<p class="tit" data-attr="min_limited"></p>
				</td>
				<td class="col-long-num">
					<p class="tit" data-attr="max_discount_price"></p>
				</td>
			</tr>

			<tr data-copy = "state_copy">
				<td class="col-img">
					<div class="table-thumb">
						<img src="IPIACOSMETIC/_uploads/thumnail_img/155776540583508.jpg" data-attr="img" alt="상품이미지">
					</div>
				</td>
				<td class="col-tit">
					<div class="table-tit">
						<p class="tit"><span onclick="" data-attr="product_name">히비스커스 크림(할인 없음, 재고 사용 안함 )</span></p>
						<p class="ct mt-2" data-attr="option">가격 있음</p>
					</div>
				</td>
				<td data-attr="price">117,000</td>
				<td data-attr="regdate"></td>
				<td data-attr="deposit_regdate"></td>
				<td data-attr="delivery_ready_regdate"></td>
				<td data-attr="on_delivery_regdate"></td>
				<td data-attr="complete_regdate"></td>`
			</tr>
			<tr data-copy="invoice_list_copy">
				<td class="col-img">
					<div class="table-thumb">
						<img src="" data-attr="img" alt="상품이미지">
					</div>
				</td>
				<td class="col-tit">
					<div class="table-tit">
						<p class="tit"><span onclick="" data-attr="product_name"></span></p>
						<p class="ct mt-2" data-attr="option"></p>
					</div>
				</td>
				<td data-attr="product_price"></td>
				<td data-attr="regdate"></td>
			</tr>
		</table>
		<p data-copy="invoice_copy"><span data-attr="invoice_number">1234567890</span><span class="min-con" data-attr="invoice_btn">조회</span></p>
	</div>
</body>
</html>