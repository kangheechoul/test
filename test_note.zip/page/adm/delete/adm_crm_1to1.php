<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<title>1:1문의 관리</title>
	<!-- font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
	<link href='//spoqa.github.io/spoqa-han-sans/css/SpoqaHanSans-kr.css' rel='stylesheet' type='text/css'>

	<!-- css -->
	<?php include_once $this->dir."page/adm/inc/common_css.php"; ?>
	<link rel="stylesheet" type="text/css" href="common_css/adm/jquery-ui.min.css?<?php echo $version;?>"/>

	<!-- script -->
	<?php include_once $this->dir."page/adm/inc/common_js.php"; ?>
	<script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/jquery-ui.min.js<?php echo $version;?>"></script>
    <script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/datepicker-ko.js<?php echo $version;?>"></script>
	<script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/crm_1to1.js"></script>
</head>
<body>
	<div class="wrap">
        <?php include_once $dir."page/adm/include/adm_aside.php";?>
		<div class="bd">
			<article class="body-container">
				<div class="body-head"><h2>1:1문의 관리</h2></div>
				<form class="form">
					<div class="body-box mb-3">
						<div class="box-search-container">
							<div class="insert-wrap">
								<div class="insert insert-select">
									<select class="select-custom" id ="search_kind" type="text">
										<option value = "title">제목</option>
										<option value = "name">이름</option>
										<option value = "id">아이디</option>
									</select>
								</div>
								<div class="insert insert-input"><input class="input-lg" id = "keyword" type="text"/></div>
								<div class="insert insert-chk">
									<label class="check_label">상세검색
										<input type="checkbox" id = "detail_search_check">
										<span class="checkmark"></span>
									</label>
								</div>
								<!-- 상세검색을 check 하면 상세검색 전문이 나타납니다 // -->
							</div>
						</div>
						<!-- 상세검색 전문 -->
						<div class="box-table-container mt-3" id = "detail_search_content" style ="display:none;">
							<dl class="box-tbody">
								<dt class="box-th box-head"><p>기간</p></dt>
								<dd class="box-td">
									<ul class="insert-wrap">
										<li class="insert insert-chk">
											<label class="check_label" for="all_search">전체
												<input type="radio" id="all_search" value="all_search" name="condition">
												<span class="checkmark radio"></span>
											</label>
										</li>
										<li class="insert insert-chk">
											<label class="check_label" for="today">오늘
												<input type="radio" id="today" value="today" name="condition">
												<span class="checkmark radio"></span>
											</label>
										</li>
										<li class="insert insert-chk">
											<label class="check_label" for="1month">1개월
												<input type="radio" id="1month" value="1month" name="condition">
												<span class="checkmark radio"></span>
											</label>
										</li>
										<li class="insert insert-chk">
											<label class="check_label" for="3month">3개월
												<input type="radio" id="3month" value="3month" name="condition">
												<span class="checkmark radio"></span>
											</label>
										</li>
										<li class="insert insert-chk">
											<label class="check_label" for="6month">6개월
												<input type="radio" id="6month" value="6month" name="condition">
												<span class="checkmark radio"></span>
											</label>
										</li>
										<li class="insert insert-chk">
											<label class="check_label" for="year">1년
												<input type="radio" id="year" value="year" name="condition">
												<span class="checkmark radio"></span>
											</label>
										</li>
									</ul>
									<ul class="insert-wrap mt-1">
										<li class="insert insert-input datepick-wirte"><input class="input-32 input-xs" id = "start_date" type="text"/><i></i></li>
										<li class="insert">~</li>
										<li class="insert insert-input datepick-wirte"><input class="input-32 input-xs" id = "end_date" type="text"/><i></i></li>
									</ul>
								</dd>
							</dl>
							<dl class="box-tbody">
								<dt class="box-th box-head"><p>분류</p></dt>
								<dd class="box-td">
									<ul class="insert-wrap">
										<li class="insert">
											<select class="select-custom" id = "select_kind" type="text">
												<option value = "0">전체</option>
												<option value="1">구매/결제</option>
												<option value="2">주문문의</option>
												<option value="3">취소</option>
												<option value="4">교환/반품</option>
												<option value="5">환불</option>
												<option value="6">배송</option>
												<option value="7">계정</option>
												<option value="8">기타</option>
											</select>
										</li>
									</ul>
								</dd>
							</dl>
						</div>
						<!-- 상세검색 전문 // -->
						<div class="insert-wrap align-center mt-3">
							<div class="insert insert-input-btn"><input class="btn-primary" id = "select_btn" type="button" value="검색"/></div>
							<div class="insert insert-input-btn"><input class="btn-default" id = "init_btn" type="button" value="초기화"/></div>
						</div>
					</div>
					<div class="body-out mb-3">
						<div class="out-tab-container">
							<ul>
								<li class="current" id = "all"><a href="#1"></a></li>
								<li id = "second"><a href="#2"></a></li>
								<li id = "third"><a href="#3"></a></li>
							</ul>
						</div>
					</div>
					<div class="body-box">
						<div class="table-container">
							<table class="table3">
								<thead>
									<tr>
										<!-- <th>
											<div class="insert insert-chk">
												<label class="check_label">
													<input type="checkbox">
													<span class="checkmark"></span>
												</label>
											</div>
										</th> -->
										<th>번호</th>
										<th>분류</th>
										<th class="col-tit">주문번호</th>
										<th class="col-tit">제목</th>
										<th>이름</th>
										<th>아이디</th>
										<th>등록일</th>
										<th>답변일</th>
									</tr>
								</thead>
								<tbody data-wrap = "wrap" id = "wrap">
									<!-- <tr>
										<td>
											<div class="insert insert-chk">
												<label class="check_label">
													<input type="checkbox">
													<span class="checkmark"></span>
												</label>
											</div>
										</td>
										<td class="col-num">2</td>
										<td>기타</td>
										<td class="col-tit">
											<div>
												<p class="tit"><span class="ellipsis c-pointer" onclick="">상품이 onclick 되어야합니다.</span></p>
											</div>
										</td>
										<td class="col-tit">
											<div>
												<p class="tit"><span class="bold c-pointer ellipsis" onclick="">제목을 누르면 팝업이 나타납니다.</span></p>
											</div>
										</td>
										<td>하예든</td>
										<td>sample</td>
										<td class="col-long-num">20.03.24  18:00:06</td>
										<td class="col-long-num">미답변</td>
									</tr>
									<tr>
										<td>
											<div class="insert insert-chk">
												<label class="check_label">
													<input type="checkbox">
													<span class="checkmark"></span>
												</label>
											</div>
										</td>
										<td class="col-num">1</td>
										<td>취소신청</td>
										<td class="col-tit">
											<div>
												<p class="tit"><span class="ellipsis c-pointer" onclick="">상품명이 들어갑니다.</span></p>
											</div>
										</td>
										<td class="col-tit">
											<div>
												<p class="tit"><span class="bold c-pointer ellipsis" onclick="">제목 들어갑니다.</span></p>
											</div>
										</td>
										<td>이재영</td>
										<td>sampleid</td>
										<td class="col-long-num">20.03.24 18:00:06</td>
										<td class="col-long-num">20.03.24 18:12:06</td>
									</tr> -->
									<!-- 2 // -->
								</tbody>
							</table>
						</div>
						<div class="pagination_container mt-3" id = "paging">
							<!-- <div class="page_item arrow prev">«</div>
							<div class="page_item active">1</div>
							<div class="page_item ">2</div>
							<div class="page_item arrow next">»</div> -->
						</div>
					</div>
				</form>
			</article>
		</div>
	</div>
	<div style = "display:none">
		<table>
			<tr data-copy ="copy">
				<!-- <td>
					<div class="insert insert-chk">
						<label class="check_label">
							<input type="checkbox">
							<span class="checkmark"></span>
						</label>
					</div>
				</td> -->
				<td class="col-num" data-attr="num"></td>
				<td data-attr="kind">기타</td>
				<td class="col-tit">
					<div>
						<p class="tit"><span class="ellipsis c-pointer"  data-attr = "order_number">상품이 onclick 되어야합니다.</span></p>
					</div>
				</td>
				<td class="col-tit">
					<div>
						<p class="tit"><span class="bold c-pointer ellipsis" data-attr = "title">제목을 누르면 팝업이 나타납니다.</span></p>
					</div>
				</td>
				<td data-attr="user_name">하예든</td>
				<td data-attr="user_email">sample</td>
				<td class="col-long-num" data-attr="regdate">20.03.24  18:00:06</td>
				<td class="col-long-num" data-attr="answer_date">미답변</td>
			</tr>
		</table>
	</div>
</body>
<!-- select2 -->
<link rel="stylesheet" type="text/css" href="<?php echo $this->project_admin_path;?>layout/select2/css/select2.min.css"/>
<link rel="stylesheet" type="text/css" href="common_css/adm/adm_select.css?<?php echo $version;?>"/>
<script type="text/javascript" src="<?php echo $this->project_admin_path;?>layout/select2/js/select2.full.min.js"></script>
<script type="text/javascript">
	$(document).ready(function() {
        $('.select-custom').select2({
            minimumResultsForSearch: -1
        });
    });
</script>
