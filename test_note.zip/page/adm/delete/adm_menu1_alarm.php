<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<title>수신 이메일/번호 설정1111</title>
	<!-- font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
	<link href='//spoqa.github.io/spoqa-han-sans/css/SpoqaHanSans-kr.css' rel='stylesheet' type='text/css'>

	<!-- css -->
	<?php include_once $this->dir."page/adm/inc/common_css.php"; ?>

	<!-- script -->
	<?php include_once $this->dir."page/adm/inc/common_js.php"; ?>
	<script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/menu1_alarm.js<?php echo $version;?>"></script>
</head>
<body>
	<div class="wrap">
		<?php include_once $dir."page/adm/include/adm_aside.php";?>
			<div class="bd">
				<article class="body-container">
					<div class="body-head"><h2>관리자 알림설정</h2></div>
					<form class="form">
						<div class="body-box">
							<div class="box-table-container">
								<dl class="box-tbody">
									<dt class="box-th box-head"><p class="medium">등록된 이메일</p></dt>
									<dd class="box-td">
										<div class="insert insert-select">
											<select class="select-list" size="4" id="email_select">
												<!-- <option value="독수리">독수리</option>
												<option value="매">매</option>
												<option value="까치">까치</option>
												<option value="두루미">두루미</option>
												<option value="까마귀">까마귀</option>
												<option value="참새">참새</option>
												<option value="뻐꾸기">뻐꾸기</option>
												<option value="왕뿌리새">왕뿌리새</option> -->
											</select>
										</div>
										<div class="insert-wrap mt-1">
											<div class="insert insert-input-btn"><input class="btn-default btn-32" type="button" value="선택삭제" onclick="delete_email()"/></div>
										</div>
									</dd>
								</dl>
								<dl class="box-tbody">
									<dt class="box-th box-head"><p class="medium">이메일 등록</p></dt>
									<dd class="box-td">
										<ul class="insert-wrap">
											<li class="insert insert-input">
												<input class="input-sm" type="text" id="email_insert"/>
											</li>
											<li class="insert insert-input-btn">
												<input class="btn-primary" type="button" value="등록" onclick="add_email()"/>
											</li>
										</ul>
										<p class="mt-1 xsmall">'@'을 추가하여 입력하세요. ex) sample@gmail.com</p>
									</dd>
								</dl>
							</div>
						</div>
						<div class="body-box mt-3">
							<div class="box-table-container">
								<dl class="box-tbody">
									<dt class="box-th box-head"><p class="medium">등록된 휴대폰번호</p></dt>
									<dd class="box-td">
										<div class="insert insert-select">
											<select class="select-list" size="4" id="sms_select">
												<!-- <option value="독수리">독수리</option>
												<option value="매">매</option>
												<option value="까치">까치</option>
												<option value="두루미">두루미</option>
												<option value="까마귀">까마귀</option>
												<option value="참새">참새</option>
												<option value="뻐꾸기">뻐꾸기</option>
												<option value="왕뿌리새">왕뿌리새</option> -->
											</select>
										</div>
										<div class="insert-wrap mt-1">
											<div class="insert insert-input-btn"><input class="btn-default btn-32" type="button" value="선택삭제" onclick="delete_sms()"/></div>
										</div>
									</dd>
								</dl>
								<dl class="box-tbody">
									<dt class="box-th box-head"><p class="medium">휴대폰번호 등록</p></dt>
									<dd class="box-td">
										<ul class="insert-wrap">
											<li class="insert insert-input">
												<input class="input-sm" type="text" id="sms_insert"/>
											</li>
											<li class="insert insert-input-btn">
												<input class="btn-primary" type="button" value="등록" onclick="add_sms()"/>
											</li>
										</ul>
										<p class="mt-1 xsmall">ex) 01012345678 또는 010-1234-5678</p>
									</dd>
								</dl>
							</div>
						</div>
					</form>
				</article>
			</div>
	</div>

</body>
<!-- select2 -->
<link rel="stylesheet" type="text/css" href="<?php echo $this->project_admin_path;?>layout/select2/css/select2.min.css"/>
<link rel="stylesheet" type="text/css" href="common_css/adm/adm_select.css?<?php echo $version;?>"/>
<script type="text/javascript" src="<?php echo $this->project_admin_path;?>layout/select2/js/select2.full.min.js"></script>
<script type="text/javascript">

	$(document).ready(function() {
		$("select[class='select-custom']").select2();
	});

</script>
</html>