<aside class="adm_aside">
    <div class="adm_aside-top"></div>
    <div class="adm_aside-mid">
        <ul class="aside-depth">
            <li class="<?php $this->side_active('menu3_inquiry')?>"><a href="?ctl=move&param=adm&param1=menu3_inquiry">상품조회</a></li>
            <li class="<?php $this->side_active('menu3_pd_upload')?>"><a href="?ctl=move&param=adm&param1=menu3_pd_upload">상품등록</a></li>
            <li class="<?php $this->side_active('menu3_pd_sort')?>"><a href="?ctl=move&param=adm&param1=menu3_pd_sort">상품진열순서</a></li>
            <li class="<?php $this->side_active('menu3_category')?>"><a href="?ctl=move&param=adm&param1=menu3_category">카테고리 설정</a></li>
        </ul>
    </div>
    <div class="adm_aside-bt"></div>
</aside>
<!-- adm_aside끝 -->