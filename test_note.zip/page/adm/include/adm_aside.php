<aside class="adm_aside">
    <div class="adm_aside-top">
        <h1>
            <a href="#"><span></span></a>
        </h1>
    </div>
    <div class="adm_aside-mid">
        <ul class="aside-depth">
            <li><a href="?ctl=move&param=adm&param1=payment_list">예매 목록</a></li>
            <li><a href="?ctl=move&param=adm&param1=cost_list">요금 목록</a></li>
            <li><a href="?ctl=move&param=adm&param1=inquiry_list">고객문의 목록</a></li>
            <li><a href="javascript:void(0)">욕지도 소개</a>
                <ol>
                    <li><a href="?ctl=move&param=adm&param1=blog_list">게시글 목록</a></li>
                    <li><a href="?ctl=move&param=adm&param1=blog_create">게시글 작성</a></li>
                </ol>
            </li>
            <li><a href="javascript:void(0)">공지사항</a>
                <ol>
                    <li><a href="?ctl=move&param=adm&param1=recommend_list">공지사항 목록</a></li>
                    <li><a href="?ctl=move&param=adm&param1=recommend_create">공지사항 작성</a></li>
                </ol>
            </li>
        </ul>
    </div>
    <div class="adm_aside-bt"></div>
</aside>
<!-- adm_aside끝 -->