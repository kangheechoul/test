<aside class="adm_aside">
    <div class="adm_aside-top"></div>
    <div class="adm_aside-mid">
        <ul class="aside-depth">
            <li class="<?php $this->side_active('menu1_alarm')?>"><a href="?ctl=move&param=adm&param1=menu1_alarm">수신 이메일/번호 설정</a></li>
            <li class="<?php $this->side_active('menu1_info')?>"><a href="?ctl=move&param=adm&param1=menu1_info">쇼핑몰정보 설정</a></li>
            <li class="<?php $this->side_active('menu1_terms')?>"><a href="?ctl=move&param=adm&param1=menu1_terms&terms_idx=1">이용약관 설정</a></li>
            <li class="<?php $this->side_active('menu1_privacy')?>"><a href="?ctl=move&param=adm&param1=menu1_privacy&terms_idx=2">개인정보방침 설정</a></li>
            <li class="<?php $this->side_active('menu1_banner_main')?>"><a href="?ctl=move&param=adm&param1=menu1_banner_main">메인배너 관리</a></li>
            <!-- <li class="<?php $this->side_active('menu1_banner_sub1')?>"><a href="?ctl=move&param=adm&param1=menu1_banner_sub1">서브배너1 관리</a></li> -->
            <li class="<?php $this->side_active('menu1_banner_sub2')?>"><a href="?ctl=move&param=adm&param1=menu1_banner_sub2">서브배너 관리</a></li>
            <!-- <li class="<?php $this->side_active('menu1_banner_sub3')?>"><a href="?ctl=move&param=adm&param1=menu1_banner_sub3">서브배너3 관리</a></li> -->
        </ul>
    </div>
    <div class="adm_aside-bt"></div>
</aside>
<!-- adm_aside끝 -->