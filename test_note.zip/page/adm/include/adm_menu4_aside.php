<aside class="adm_aside">
    <div class="adm_aside-top"></div>
    <div class="adm_aside-mid">
        <ul class="aside-depth">
            <li class="<?php $this->side_active('menu4_orderlist')?>"><a href="?ctl=move&param=adm&param1=menu4_orderlist">주문내역</a></li>
            <li class="<?php $this->side_active('menu4_coupon')?>"><a href="?ctl=move&param=adm&param1=menu4_coupon">쿠폰사용 설정</a></li>
            <li class="<?php $this->side_active('menu4_shipping')?>"><a href="?ctl=move&param=adm&param1=menu4_shipping">배송정책 설정</a></li>
            <li class="<?php $this->side_active('menu4_shipping_completed')?>"><a href="?ctl=move&param=adm&param1=menu4_shipping_completed">자동 배송완료 설정</a></li>
            <li class="<?php $this->side_active('menu4_cancel')?>"><a href="?ctl=move&param=adm&param1=menu4_cancel">취소/환불/반품/교환내역</a></li>
            <!-- <li class="<?php $this->side_active('menu4_refund')?>"><a href="?ctl=move&param=adm&param1=menu4_refund">반품/교환처리 설정</a></li> -->
            <!-- <li class="<?php $this->side_active('menu4_refund_reason')?>"><a href="?ctl=move&param=adm&param1=menu4_refund_reason">취소/교환/환불사유 설정</a></li> -->
            <li class="<?php $this->side_active('menu4_cash_receipt')?>"><a href="?ctl=move&param=adm&param1=menu4_cash_receipt">현금영수증 관리</a></li>
        </ul>
    </div>
    <div class="adm_aside-bt"></div>
</aside>
<!-- adm_aside끝 -->