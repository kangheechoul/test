<header class="adm_mb_header">
    
</header>
<?php include_once $dir."page/adm/adm_alert_modal.php";?>
<?php include_once $dir."page/adm/include/adm_loading.php";?>
<!-- adm_header끝 -->