			<footer class="adm_footer adm_lang_en">
				<div class="adm_footer_copy">Copyright © 2019 LB contents. All rights reserved.</div>
			</footer>
			<!-- adm_footer끝  -->	