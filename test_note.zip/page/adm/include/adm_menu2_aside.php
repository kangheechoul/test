<aside class="adm_aside">
    <div class="adm_aside-top"></div>
    <div class="adm_aside-mid">
        <ul class="aside-depth">
            <li class="<?php $this->side_active('menu2_account')?>"><a href="?ctl=move&param=adm&param1=menu2_account">무통장입금계좌 설정</a></li>
           <!-- <li><a href="">현금영수증 설정</a></li> 사용예정 -->
        </ul>
    </div>
    <div class="adm_aside-bt"></div>
</aside>
<!-- adm_aside끝 -->