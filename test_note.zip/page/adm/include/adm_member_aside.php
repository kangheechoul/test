<aside class="adm_aside">
    <div class="mb_aside-top">
        <ul class="d-flex align-items-center justify-center flex-column">
            <li class="con-img"><img src="https://lbcontents.s3.ap-northeast-2.amazonaws.com/images/admin/profile.png" alt="profile_img"/></li>
            <li class="mt-1" id = "profile_name"><!-- 하예든(sample) --></li>
        </ul>
    </div>
    <div class="mb_aside-mid customer_aside-mid" id = "member_aside_elem">
        <ul class="aside-depth">
            <li class="<?php $this->side_active('popup_info_personal')?>"><a href="?ctl=move&param=adm&param1=popup_info_personal" id="link_popup_info_persnal">회원정보</a></li>
            <li class="<?php $this->side_active('popup_member')?>"><a href="?ctl=move&param=adm&param1=popup_member" id="link_popup_member">주문내역</a></li>
            <li class="<?php $this->side_active('popup_point')?>"><a href="?ctl=move&param=adm&param1=popup_point" id="link_popup_point">적립금내역</a></li>
            <li class="<?php $this->side_active('popup_coupon')?>"><a href="?ctl=move&param=adm&param1=popup_coupon" id="link_popup_coupon">쿠폰발급내역</a></li>
            <li class="<?php $this->side_active('popup_pd_question')?>"><a href="?ctl=move&param=adm&param1=popup_pd_question" id="link_popup_pd_question">상품Q&A</a></li>
            <li class="<?php $this->side_active('popup_1to1')?>"><a href="?ctl=move&param=adm&param1=popup_1to1" id="link_popup_1to1">1:1 문의내역</a></li>
            <li class="<?php $this->side_active('popup_review')?>"><a href="?ctl=move&param=adm&param1=popup_review" id="link_popup_review">상품후기</a></li>
        </ul>
    </div>
    <div class="adm_aside-bt"></div>
</aside>
<!-- adm_aside끝 -->