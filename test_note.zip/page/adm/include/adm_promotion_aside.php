<aside class="adm_aside">
    <div class="adm_aside-top"></div>
    <div class="adm_aside-mid">
        <ul class="aside-depth">
            <li class="<?php $this->side_active('promotion_coupon')?>"><a href="?ctl=move&param=adm&param1=promotion_coupon">쿠폰 관리</a></li>
            <li class="<?php $this->side_active('promotion_coupon_upload')?>"><a href="?ctl=move&param=adm&param1=promotion_coupon_upload">쿠폰 생성</a></li>
            <li class="<?php $this->side_active('promotion_coupon_download')?>"><a href="?ctl=move&param=adm&param1=promotion_coupon_download">쿠폰 발급내역</a></li>
        </ul>
    </div>
    <div class="adm_aside-bt"></div>
</aside>
<!-- adm_aside끝 -->