<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<title>블로그 게시글 작성</title>
	<!-- font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
	<link href='//spoqa.github.io/spoqa-han-sans/css/SpoqaHanSans-kr.css' rel='stylesheet' type='text/css'>

	<!-- css -->
	<?php include_once $this->dir."page/adm/inc/common_css.php"; ?>

	<!-- script -->
	<?php include_once $this->dir."page/adm/inc/common_js.php"; ?>
	<?php include_once $this->dir."page/adm/inc/summernote.php"; ?>
	<script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/blog_edit.js<?php echo $version;?>"></script>
	<style>
		.select-list{height:102px !important;}
	</style>

</head>
<body>
	<div class="wrap">
        <?php include_once $dir."page/adm/include/adm_aside.php";?>
		<div class="bd">
			<article class="body-container">
				<div class="body-head"><h2>블로그 게시글 수정</h2></div>
				<form class="form" id="form" onsubmit='return false;'>
					<div class="row">
						<!-- 좌 -->
						<div class="col-md-12">
							<div class="body-box mt-1">
								<div class="box-table-container">
									<dl class="box-tbody">
										<dt class="box-th box-head">
											<p>게시글 상태</p>
										</dt>
										<dd class="box-td">
											<div class="insert">
												<div class="insert-wrap">
													<div class="insert insert-chk">
														<label class="check_label" for="open">게시
															<input type="radio" id="open" value="1" name="state" checked/>
															<span class="checkmark radio"></span>
														</label>
													</div>
													<div class="insert insert-chk">
														<label class="check_label" for="hide">숨김
															<input type="radio" id="hide" value="0" name="state"/>
															<span class="checkmark radio"></span>
														</label>
													</div>
												</div>
											</div>
										</dd>
									</dl>
									<dl class="box-tbody">
										<dt class="box-th box-head">
											<p>제목</p>
										</dt>
										<dd class="box-td">
											<div class="insert insert-input">
												<input type="text" name="title" class="input-lg bg-gray"/>
											</div>
										</dd>
									</dl>
									<dl class="box-tbody">
										<dt class="box-th box-head">
											<p>부제목</p>
										</dt>
										<dd class="box-td">
											<div class="insert insert-input">
												<input type="text" name="subtitle" class="input-lg bg-gray"/>
											</div>
										</dd>
									</dl>
									<dl class="box-tbody">
										<dt class="box-th box-head">
											<p>썸네일 이미지</p>
										</dt>
										<dd class="box-td">
											<!-- 이미지 등록 버튼 -->
											<div class="img-upload img-upload-main" style="overflow: hidden;">
												
												<span class="btn-wrap">
													<button class="btn-img-upload" href="#"><strong></strong></button>
													<!-- <input type="file" name="thumnail_files[]" id="thumnail_file"> -->
												</span>	
												<label for="thumnail_file"></label>
											</div>
											<!-- 이미지 등록 버튼 // -->
											<!-- 이미지가 첨부될 시 옆에 나열됩니다 -->
											<div data-attr="img_elem" style = "display:inline-block" data-wrap="wrap">
												
											</div>
											<input type="file" name="thumnail_files[]" id="thumnail_file" onchange="file_check(this)">
											<!-- 이미지 1 // -->
											<p class="xsmall">jpg, png, gif 형식의 파일, 권장 사이즈 1920x<br>4MB 이하의 이미지 1장 첨부 가능</p>
										</dd>
									</dl>
								</div>
								<div class="insert insert-textarea mt-3">
									<div class = "summernote" style = "width:100%; height:654px;">
										<iframe class="iframe" scrolling="no" frameborder="0" style="width:100%; height:100%;" src="common_js/summernote-0.8.9-dist/dist/index.php" id="iframeEditor"></iframe>
									</div>
								</div>
							</div>
						</div>
					</div>
				</form>
				<div class="btn-container align-center mt-3">
					<button type="button" class="btn btn-default" onclick=''>취소</button>
					<button type="button" class="btn btn-primary ml-1" onclick="modify()">수정하기</button>
					<button type="button" class="btn btn-default" onclick='blog_delete()'>삭제</button>
				</div>
			</article>
		</div>
	</div>

	<div style="display:none;">
		<div class="img-upload" style="overflow: hidden;" data-copy = "img_copy">
			<img src="" data-attr="img" alt="img_upload"/>
			<span class="return-btn" style="display:none;" data-attr="btn_delete_cancel">취소</span>
			<button  data-attr="del_btn" class="delete-btn" type="button" style="display:none;"></button>
		</div>
	</div>
</body>
<!-- select2 -->
<link rel="stylesheet" type="text/css" href="<?php echo $this->project_admin_path;?>layout/select2/css/select2.min.css"/>
<link rel="stylesheet" type="text/css" href="common_css/adm/adm_select.css?<?php echo $version;?>"/>
<script type="text/javascript" src="<?php echo $this->project_admin_path;?>layout/select2/js/select2.full.min.js"></script>

<!-- yd custom -->
<!-- <script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/custom.js"></script> -->

</html>