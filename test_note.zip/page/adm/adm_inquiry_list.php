<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<title>고객문의 목록</title>
	<!-- font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
	<link href='//spoqa.github.io/spoqa-han-sans/css/SpoqaHanSans-kr.css' rel='stylesheet' type='text/css'>

	<!-- css -->
	<?php include_once $this->dir."page/adm/inc/common_css.php"; ?>

	<!-- script -->
	<?php include_once $this->dir."page/adm/inc/common_js.php"; ?>
	<script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/inquiry_list.js<?php echo $version;?>"></script>
</head>
<body>
	<div class="wrap">
        <?php include_once $dir."page/adm/include/adm_aside.php";?>
		<div class="bd">
			<article class="body-container">
				<div class="body-head"><h2>고객문의 목록</h2></div>
				<form class="form">
					<div class="body-box">
						<div class="table-container">
							<table class="table1">
								<thead>
									<tr>
										<th class="col-num">번호</th>
										<th class="col-long-num">회사명</th>
										<th class="col-long-num">담당자</th>
										<th class="col-long-num">연락처</th>
										<th class="col-tit">이메일</th>
										<th class="col-long-num">제작종류</th>
										<th class="col-num">목적</th>
										<th class="col-num">서비스확인</th>
										<th class="col-num">첨부파일</th>
										<th class="col-num">참고링크</th>
										<th class="col-long-num">희망가</th>
										<th class="col-long-num">등록일</th>
									</tr>
								</thead>
								<tbody id="wrap" data-wrap="wrap">
									<!-- <tr>
										<td class="col-num">1</td>
										<td class="col-tit"><div>SM Company</div></td>
										<td class="col-long-num"><div>홍길동</div></td>
										<td class="col-long-num"><div>01012345678</div></td>
										<td class="col-tit"><div>help@lbcontents.com</div></td>
										<td class="col-long-num"><div>홈페이지</div></td>
										<td class="col-num"><div class="table-tit"><span class="table-btn"><input class="btn-default btn-32" type="button" value="View"/></span></div></td>
										<td class="col-num"><div class="table-tit"><span class="table-btn"><input class="btn-default btn-32" type="button" value="View"/></span></div></td>
										<td class="col-num"><div class="table-tit"><span class="table-btn"><input class="btn-default btn-32" type="button" value="View"/></span></div></td>
										<td class="col-num"><div class="table-tit"><span class="table-btn"><input class="btn-default btn-32" type="button" value="View"/></span></div></td>
										<td><div class="col-long-num">500~1,000만원</div></td>
										<td><div class="col-long-num">2021.03.02</div></td>
									</tr> -->
									<!-- 1 // -->
								</tbody>
							</table>
						</div>
						<div class="pagination_container mt-3" id = "paging">
							<!-- <div class="page_item arrow prev">«</div>
							<div class="page_item active">1</div>
							<div class="page_item ">2</div>
							<div class="page_item arrow next">»</div> -->
						</div>
					</div>
				</form>
			</article>
		</div>
	</div>
	<div style="display:none">
		<table>
			<tr data-copy="copy">
				<td class="col-num" data-attr="idx">1</td>
				<td class="col-tit"><div data-attr="iq_company">SM Company</div></td>
				<td class="col-long-num"><div data-attr="iq_name">홍길동</div></td>
				<td class="col-long-num"><div data-attr="iq_hp">01012345678</div></td>
				<td class="col-tit"><div data-attr="iq_email">help@lbcontents.com</div></td>
				<td class="col-long-num"><div data-attr="iq_type">홈페이지</div></td>
				<td class="col-num"><div class="table-tit"><span class="table-btn"><input class="btn-default btn-32" type="button" value="View" data-attr="btn_purpose"/></span></div></td>
				<td class="col-num"><div class="table-tit"><span class="table-btn"><input class="btn-default btn-32" type="button" value="미확인" data-attr="btn_service"/></span></div></td>
				<td class="col-num"><div class="table-tit"><span class="table-btn"><input class="btn-default btn-32" type="button" value="다운" data-attr="btn_file"/></span></div></td>
				<td class="col-num"><div class="table-tit"><span class="table-btn"><input class="btn-default btn-32" type="button" value="복사" data-attr="btn_link"/></span></div></td>
				<td><div class="col-long-num" data-attr="iq_price">500~1,000만원</div></td>
				<td><div class="col-long-num" data-attr="iq_date">2021.03.02</div></td>
			</tr>
		</table>
	</div>
</body>
<!-- select2 -->
<link rel="stylesheet" type="text/css" href="<?php echo $this->project_admin_path;?>layout/select2/css/select2.min.css"/>
<link rel="stylesheet" type="text/css" href="common_css/adm/adm_select.css?<?php echo $version;?>"/>
<script type="text/javascript" src="<?php echo $this->project_admin_path;?>layout/select2/js/select2.full.min.js"></script>
<script type="text/javascript">
	$(document).ready(function() {
        $('.select-custom').select2({
            minimumResultsForSearch: -1
        });
    });
</script>
