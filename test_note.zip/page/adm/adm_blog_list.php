<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<title>블로그 리스트</title>
	<!-- font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
	<link href='//spoqa.github.io/spoqa-han-sans/css/SpoqaHanSans-kr.css' rel='stylesheet' type='text/css'>

	<!-- css -->
	<?php include_once $this->dir."page/adm/inc/common_css.php"; ?>

	<!-- script -->
	<?php include_once $this->dir."page/adm/inc/common_js.php"; ?>
	<script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/blog_list.js<?php echo $version;?>"></script>
	
</head>
<body>
	<div class="wrap">
        <?php include_once $dir."page/adm/include/adm_aside.php";?>
			<div class="bd">
				<article class="body-container">
					<div class="body-head"><h2>블로그 목록</h2></div>
					<form class="form">
						<div class="body-box mb-3">
							<div class="box-search-container">
								<div class="insert-wrap">
									<div class="insert insert-select">
										<select class="select-custom" type="text" id="search_type" name="search_type">
											<option value="1">제목</option>
											<option value="2">내용</option>
											<option value="3">상태</option>
										</select>
									</div>
									<div class="insert insert-input"><input class="input-lg" type="text" id="search_text" name="search_text"/><input type="text" style="display:none;"/></div>
								</div>
							</div>
							<div class="insert-wrap align-center mt-3">
								<div class="insert insert-input-btn"><input class="btn-primary" type="button" value="검색" id="btn_search"/></div>
								<div class="insert insert-input-btn"><input class="btn-default" type="button" value="초기화" onclick="location.reload()"/></div>
							</div>
						</div>
						<div class="body-box">
							<div class="table-container">
								<table class="table1">
									<thead>
										<tr>
											<th class="col-num">번호</th>
											<th>썸네일</th>
											<th class="col-long-num">상태</th>
											<th class="col-tit">제목</th>
											<th class="col-long-num">등록일</th>
										</tr>
									</thead>
									<tbody id="wrap" data-wrap="wrap">
										<!-- <tr>
											<td class="col-num">1</td>
											<td class="col-img">
												<div class="table-thumb">
													<img src="https://s3.ap-northeast-2.amazonaws.com/lbcontents/images/Gmask/158025056986203.jpg" alt="썸네일"/>
												</div>
											</td>
											<td class="col-long-num">
												<div>
													<select class="select-custom">
														<option value="">게시</option>
														<option value="">숨김</option>
													</select>
												</div>
											</td>
											<td class="col-tit">
												<div class="table-tit">
													<p class="tit"><span onclick="">제목입니다.</span></p>
													<p class="ct mt-2">부제목입니다.</p>
													<span class="table-btn"><input class="btn-default btn-32" type="button" value="수정"/></span>
												</div>
											</td>
											<td><div class="col-long-num">2021.03.02</div></td>
										</tr> -->
										<!-- 1 // -->
									</tbody>
								</table>
							</div>
							<div class="pagination_container mt-3" id = "paging">
								<!-- <div class="page_item arrow prev">«</div>
								<div class="page_item active">1</div>
								<div class="page_item ">2</div>
								<div class="page_item arrow next">»</div> -->
							</div>
						</div>
					</form>
				</article>
			</div>
	</div>
	<div style="display:none">
		<table>
			<tr data-copy="copy">
				<td class="col-num" data-attr="idx">1</td>
				<td class="col-img">
					<div class="table-thumb">
						<img src="https://s3.ap-northeast-2.amazonaws.com/lbcontents/images/Gmask/158025056986203.jpg" alt="썸네일" data-attr="thumnail_file_name"/>
					</div>
				</td>
				<td class="col-long-num">
					<div>
						<select class="" data-attr="state">
							<option value="1">게시</option>
							<option value="0">숨김</option>
						</select>
					</div>
				</td>
				<td class="col-tit">
					<div class="table-tit">
						<p class="tit" data-attr="title"><span onclick="">제목입니다.</span></p>
						<p class="ct mt-2" data-attr="sub_title">부제목입니다.</p>
						<span class="table-btn"><input class="btn-default btn-32" type="button" value="수정" data-attr="btn_modify"/></span>
					</div>
				</td>
				<td><div class="col-long-num" data-attr="regdate">2021.03.02</div></td>
			</tr>
		</table>
	</div>
</body>
<!-- select2 -->
<link rel="stylesheet" type="text/css" href="<?php echo $this->project_admin_path;?>layout/select2/css/select2.min.css"/>
<link rel="stylesheet" type="text/css" href="common_css/adm/adm_select.css?<?php echo $version;?>"/>
<script type="text/javascript" src="<?php echo $this->project_admin_path;?>layout/select2/js/select2.full.min.js"></script>
<script type="text/javascript">
	$(document).ready(function() {
        $('.select-custom').select2({
            minimumResultsForSearch: -1
        });
    });
</script>
