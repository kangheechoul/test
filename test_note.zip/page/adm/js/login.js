function login() {
    
    lb.ajax({
        type : "AjaxFormPost",
        list : {
            ctl : "Member",
            param1 : "request_admin_login",
            mb_id : document.getElementById("mb_id").value,
            mb_password : document.getElementById("mb_password").value,
        },
        action : "index.php",
        havior : function(result){
            console.log(result);
            result = JSON.parse(result);
            
            if(result.result == 1) {
                location.href="?ctl=move&param=adm&param1=user_list";
            }else{
                alert(result.message);
            }
        }
    });
}

function enterkey() {
    if(window.event.keyCode == 13){
        login();
    }
}