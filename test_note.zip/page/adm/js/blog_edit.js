$(document).ready(function () {
    var varUA = navigator.userAgent.toLowerCase(); //userAgent 값 얻기
    if (varUA.match('android') != null) {
        //안드로이드면 webviewReady()를 호출하기 때문에 아무것도안함
    } else if (varUA.indexOf("iphone") > -1 || varUA.indexOf("ipad") > -1 || varUA.indexOf("ipod") > -1) {
        //아이폰이면 webviewReady()를 호출하기 때문에 아무것도안함
    } else {
        //아이폰, 안드로이드 외 처리(PC웹)
        //webviewReady();
        
        document.querySelector('input[type=file]').setAttribute('accept', '.png,.jpg,.gif');

    }
});


var sum_note_value = null; //description 초기화객체

function iframeLoaded(sum_note) {
    sum_note_value = sum_note;
    response_blog_edit_view();
}

function response_blog_edit_view(){
    var blog_idx = data.blog_idx;
    lb.ajax({
        type : "JsonAjaxPost",
        list : {
            ctl:"Admin",
            param1:"request_blog_edit_view",
            idx:blog_idx,
        },
        action : lb.obj.address, //웹일경우 ajax할 주소
        response_method : "reponse_", //앱일경우 호출될 메소드
        havior : function(result){
            result = JSON.parse(result);
            if(result.result == "1") {
                var editValue = result.value[0];
                obj.elem.form.title.value=editValue.title;
                obj.elem.form.subtitle.value=editValue.sub_title;
                sum_note_value.innerHTML=editValue.content;
                init_thumnail_img(editValue.thumnail_file_name);
            }
        },
    });
}

function init_thumnail_img(img_data){
    var datas = [{thumnail_img_file_name: img_data}];
    lb.auto_view({
        wrap: "wrap",
        copy: "img_copy",
        attr: '["data-attr"]',
        json: datas,
        havior: add_thumnail_img,
    });
}

function add_thumnail_img(elem, data, name, copy_elem){
    if(copy_elem.getAttribute("data-copy") != ""){
        copy_elem.setAttribute("data-copy", "");
    }
    if(name == "img"){
        elem.src = "https://elasticbeanstalk-ap-northeast-2-038372400108.s3.ap-northeast-2.amazonaws.com/files/bada_soft/_uploads/blog_origin_thumnail_img/" + data.thumnail_img_file_name;
    }
}

function file_check(file) {
    path_point = file.value.lastIndexOf('.');
    file_point = file.value.substring(path_point + 1, file.length);
    file_type  = file_point.toLowerCase();
    if(file_type == 'jpg' || file_type == 'gif' || file_type == 'png') {

    } else {
        alert("이미지 파일만 선택할 수 있습니다.");
        file.value = "";
        return false;
    }
}

function modify(){

    lb.ajax({
        type : "AjaxFormPost",
        list : {
            ctl:"Admin",
            param1:"request_blog_edit_modify",
            content: sum_note_value.innerHTML,
            blog_idx: data.blog_idx,
        },
        elem : obj.elem.form,
        action : lb.obj.address, //웹일경우 ajax할 주소
        response_method : "reponse_", //앱일경우 호출될 메소드
        havior : function(result){
            //웹일 경우 호출될 메소드
            console.log(result);
            result = JSON.parse(result);
            if(result.result=="1") {
               location.href="?ctl=move&param=adm&param1=blog_list";
            }
            //response_blog_list(result);
        }
    });
}

function blog_delete() { //삭제
    lb.ajax({
        type : "AjaxFormPost",
        list : {
            ctl:"Admin",
            param1:"request_blog_edit_delete",
            blog_idx: data.blog_idx,
        },
        elem : obj.elem.form,
        action : lb.obj.address, //웹일경우 ajax할 주소
        response_method : "reponse_", //앱일경우 호출될 메소드
        havior : function(result){
            //웹일 경우 호출될 메소드
            console.log(result);
            result = JSON.parse(result);
            if(result.result=="1") {
               location.href="?ctl=move&param=adm&param1=blog_list";
            }
            //response_blog_list(result);
        }
    });
}