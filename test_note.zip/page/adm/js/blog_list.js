$(document).ready(function () {
    var varUA = navigator.userAgent.toLowerCase(); //userAgent 값 얻기
    if (varUA.match('android') != null) {
        //안드로이드면 webviewReady()를 호출하기 때문에 아무것도안함
    } else if (varUA.indexOf("iphone") > -1 || varUA.indexOf("ipad") > -1 || varUA.indexOf("ipod") > -1) {
        //아이폰이면 webviewReady()를 호출하기 때문에 아무것도안함
    } else {
        //아이폰, 안드로이드 외 처리(PC웹)
        webviewReady();
    }
    document.getElementById("btn_search").addEventListener("click", blog_list_search, false);
});

function webviewReady(){
    page_init();
}

function page_init(){
    $('.loading').fadeIn();
    $(obj.elem.paging).empty();
    obj.value.data = data;
   
    if(typeof(obj.value.data.word)!="undefined"){
        obj.value.word = obj.value.data.word;
    }

    obj.value.data.search_type = obj.elem.search_type.value;
    obj.value.data.search_text = obj.elem.search_text.value;

    var param = {
        ctl:"Admin",
        param1:"request_blog_list",
    }

    obj.page = {
        page_count :10,
        page_size : 10,
        move_page : obj.value.data.move_page,
        move_list : JSON.stringify(obj.value.data),
    }

    for(var key in obj.value.data){
        if(key=="word"){
            obj.elem.word.value = obj.value.data[key];
        }else if(key=="search_kind"){
            obj.elem.search_kind.value = obj.value.data[key];
        }
    }

    for(var key in param){
        obj.page[key]=param[key];
    }
    
    obj.fn.page_list({
        //wrap_array : Array("data-wrap"),
        page_num : {
            elem : obj.elem.paging,
            page_name : "move_page",
            prev_first : '<div class="page_item arrow prev">«</div>',
            prev_one : '<div class="page_item arrow prev">‹</div>',
            number_active : '<div class="page_item active"></div>',
            number : '<div class="page_item ">2</div>',
            next_one : '<div class="page_item arrow next">›</div>', 
            next_last : '<div class="page_item arrow next">»</div>'
        },
        havior : function(value){
            // console.log(value);
            $('.loading').fadeOut();
            init_list(value);
        }
    });
}


function init_list(datas){
    // console.log(data);
    //lb.getElem("total_count").innerHTML = obj.page.total_count;
    lb.clear_wrap(lb.getElem("wrap"));
    if(datas.length == 0){//데이터가 없을경우
        lb.getElem("wrap").innerHTML = '<tr><td colspan="11"  class="align-center table-nodata"><div class="table-nodata-con">등록된 내용이 없습니다.</div></td></tr>';
    }else{
        lb.auto_view({
            wrap: "wrap",
            copy: "copy",
            attr: '["data-attr"]',
            json: datas,
            havior: add_list,
            end : function() {
                $('.select-blog').select2({
                    minimumResultsForSearch: -1
                });
            }
        });
    }
}

function add_list(elem, data, name, copy_elem){
    if(copy_elem.getAttribute("data-copy") != ""){
        copy_elem.setAttribute("data-copy", "");
    }
    origin_path = "https://elasticbeanstalk-ap-northeast-2-038372400108.s3.ap-northeast-2.amazonaws.com/files/bada_soft/_uploads/blog_thumnail_img/";
    if(name == "thumnail_file_name"){
        //elem.src = obj.link.product_thumnail_orign_path + data.thumnail_file_name;
        elem.src =  origin_path + data.thumnail_file_name;
        $(elem.parentNode).mouseenter(function(){
            $(this).clone().addClass('cloned').appendTo(this);
        })
        $(elem.parentNode).mouseleave(function(){
            $(".cloned").remove();
        })
    }else if(name == "state"){ //
        var state = data["state"];
        elem.classList.add("select-blog");
        elem.value = state;
        elem.onchange = function(ev) {
            change_state(data.idx, elem.value);
        }
    }else if(name == "btn_modify"){
        elem.onclick = function(){
            location.href= "?ctl=move&param=adm&param1=blog_edit&blog_idx=" + data.idx;
        }
    }
    else{
        elem.innerHTML = data[name];
    }
}

function blog_list_search() {
    obj.value.data.move_page = 1;
    
    page_init();
}

function change_state(idx, state) {
    lb.ajax({
        type : "JsonAjaxPost",
        list : {
            ctl : "Blog",
            param1 : "request_blog_state_modify",
            idx : idx,
            state : state,
        },
        havior : function(result) {
            // console.log(result);
            result = JSON.parse(result);
            if(result.result == 0) {
                alert(result.message);
            }
        }
    });
}