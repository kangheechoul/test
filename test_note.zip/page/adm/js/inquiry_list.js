
$(document).ready(function () {
    var varUA = navigator.userAgent.toLowerCase(); //userAgent 값 얻기
    if (varUA.match('android') != null) {
        //안드로이드면 webviewReady()를 호출하기 때문에 아무것도안함
    } else if (varUA.indexOf("iphone") > -1 || varUA.indexOf("ipad") > -1 || varUA.indexOf("ipod") > -1) {
        //아이폰이면 webviewReady()를 호출하기 때문에 아무것도안함
    } else {
        //아이폰, 안드로이드 외 처리(PC웹)
        webviewReady();
    }
});

function webviewReady(){
    page_init();
}

function page_init(){
    $('.loading').fadeIn();
    $(obj.elem.paging).empty();
    obj.value.data = data;
    // console.log(obj.value.data);
   
    if(typeof(obj.value.data.word)!="undefined"){
        obj.value.word = obj.value.data.word;
    }
    
    var param = {
        ctl:"Inquiry",
        param1:"request_inquiry_list",
    }

    obj.page = {
        page_count :10,
        page_size : 10,
        move_page : obj.value.data.move_page,
        move_list : JSON.stringify(obj.value.data)
    }

    for(var key in obj.value.data){
        if(key=="word"){
            obj.elem.word.value = obj.value.data[key];
        }else if(key=="search_kind"){
            obj.elem.search_kind.value = obj.value.data[key];
        }
    }

    for(var key in param){
        obj.page[key]=param[key];
    }

    obj.fn.page_list({
        //wrap_array : Array("data-wrap"),
        page_num : {
            elem : obj.elem.paging,
            page_name : "move_page",
            prev_first : '<div class="page_item arrow prev">«</div>',
            prev_one : '<div class="page_item arrow prev">‹</div>',
            number_active : '<div class="page_item active"></div>',
            number : '<div class="page_item ">2</div>',
            next_one : '<div class="page_item arrow next">›</div>', 
            next_last : '<div class="page_item arrow next">»</div>'
        },
        havior : function(value){
            $('.loading').fadeOut();
            init_list(value);
        }
    });
}

function init_list(datas){
    //lb.getElem("total_count").innerHTML = obj.page.total_count;
    lb.clear_wrap(lb.getElem("wrap"));
    if(datas.length == 0){//데이터가 없을경우
        lb.getElem("wrap").innerHTML = '<tr><td colspan="11"  class="align-center table-nodata"><div class="table-nodata-con">등록된 내용이 없습니다.</div></td></tr>';
    }else{
        lb.auto_view({
            wrap: "wrap",
            copy: "copy",
            attr: '["data-attr"]',
            json: datas,
            havior: add_list,
        });
    }
}

function add_list(elem, data, name, copy_elem){
    if(copy_elem.getAttribute("data-copy") != ""){
        copy_elem.setAttribute("data-copy", "");
    }

    if(name=="btn_purpose") {
        elem.onclick = function() {
            purpose_popup(data["iq_purpose"]);
        }
    }else if(name=="btn_service") {
        if(data["iq_service"] == "1") {
            elem.parentNode.innerHTML = "확인";
        }else{
            elem.onclick = function(ev) {
                service_check(ev, data["idx"]);
            }
        }
    }else if(name=="btn_file") {
        elem.onclick = function() {
            if(data["iq_file"]) {
                file_download(data["iq_file"], data["iq_file"], 1);
            }else{
                alert("파일이 없습니다.");
            }
        }
    }else if(name=="btn_link") {
        elem.onclick = function() {
            copy_link(data["iq_link"]);
        }
    }else if(name=="iq_type") {
        console.log(data[name]);
        if(data[name] == "1") {
            elem.innerHTML = "홈페이지";    
        }else if(data[name] == "2") {
            elem.innerHTML = "쇼핑몰";    
        }else if(data[name] == "3") {
            elem.innerHTML = "어플리케이션";    
        }else{
            elem.innerHTML = data[name];    
        }
    }else if(name=="iq_price") {
        if(data[name] == "1") {
            elem.innerHTML = "100만원 이하";    
        }else if(data[name] == "2") {
            elem.innerHTML = "100~200만원";    
        }else if(data[name] == "3") {
            elem.innerHTML = "200~300만원";    
        }else if(data[name] == "4") {
            elem.innerHTML = "300~500만원";   
        }else if(data[name] == "5") {
            elem.innerHTML = "500~1000만원";   
        }else if(data[name] == "6") {
            elem.innerHTML = "1000만원 이상";   
        }else{
            elem.innerHTML = data[name];    
        }
    }else {
        elem.innerHTML = data[name];
    }
}

function purpose_popup(purpose) { // popup view 생성하여 열기
    pop = window.open("","목적 View", "width=500,height=500,left=200,top=100");
    new_div = document.createElement("div");
    new_div.innerHTML = "<pre>"+purpose+"</pre>";
    pop.document.body.appendChild(new_div);
}


function service_check(ev, idx) {
    var parent = ev.currentTarget.parentNode;
    lb.ajax({
        type: "JsonAjaxPost",
        list: {
            ctl: "Inquiry",
            param1: "request_inquiry_service_check",
            idx:idx,
        },
        havior:function(result) {
            result = JSON.parse(result);
            if(result.result == "1") {
                parent.innerHTML = "확인";
            }else{
                gu.alert({
                    description : result.message, //내용(string 문자열)
                    title : null,  //제목(string 문자열) 
                    response_method : null //확인버튼을 눌럿을경우 호출될 메소드function 이름(string 문자열) 
                });
            }
        }
    });
}

//real_name : 파일이 다운되는 실제이름 , filename : uploads폴더에 등록된 파일명
//type : 외부파일인지 내부파일인지 구분(0 : 내부파일, 1:외부파일)
function file_download(real_name, file_name, type) {
    //업로드된 파일의 위치
    file_url =  "https://elasticbeanstalk-ap-northeast-2-038372400108.s3.ap-northeast-2.amazonaws.com/files/bada_soft/_uploads/inquiry_file/" + file_name;
    lb.ajax({
        type: "post",
        list: {
            ctl: "Inquiry",
            param1: "file_download",
            download_type: type,
            realname: real_name,
            url: file_url
        },
        address: "index.php"
    });
}

function copy_link(link) { // 링크 복사
    var t = document.createElement("textarea");
    document.body.appendChild(t);
    t.value = link;
    t.select();

    document.execCommand("copy");
    document.body.removeChild(t);
    alert("복사되었습니다.")
}