$(document).ready(function () {
    document.querySelector('input[type=file]').setAttribute('accept', '.png,.jpg,.gif');
});

var sum_note_value = null; //description 초기화객체

function iframeLoaded(sum_note) {
    sum_note_value = sum_note;
}

function save(){
    lb.ajax({
        type : "AjaxFormPost",
        list : {
            ctl:"Admin",
            param1:"request_recommend_reg",
            content: sum_note_value.innerHTML,
        },
        elem : obj.elem.form,
        action : lb.obj.address, //웹일경우 ajax할 주소
        response_method : "reponse_", //앱일경우 호출될 메소드
        havior : function(result){
            //웹일 경우 호출될 메소드
            console.log(result);
            result = JSON.parse(result);
            response_recommend_list(result);
        }
    });
}

function response_recommend_list(result){
    if(result.result == "1"){
        location.href="?ctl=move&param=adm&param1=recommend_list";
    }else{
        gu.alert({
            description : result.message, //내용(string 문자열) 
            title : null,  //제목(string 문자열) 
            response_method : null //확인버튼을 눌럿을경우 호출될 메소드function 이름(string 문자열) 
        });
    }
}

function file_check(file) {
    path_point = file.value.lastIndexOf('.');
    file_point = file.value.substring(path_point + 1, file.length);
    file_type  = file_point.toLowerCase();
    if(file_type == 'jpg' || file_type == 'gif' || file_type == 'png') {

    } else {
        alert("이미지 파일만 선택할 수 있습니다.");
        file.value = "";
        return false;
    }
}