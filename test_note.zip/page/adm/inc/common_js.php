<script>
    var data = <?php echo $data;?>;
</script>
<script type="text/javascript" src="common_js/jquery.js<?php echo $version;?>"></script>
<script type="text/javascript" src="<?php echo $this->project_admin_path;?>js/common.js<?php echo $version;?>"></script>
<script>
    obj.link = <?php echo json_encode($this->file_path->get_path(),JSON_UNESCAPED_UNICODE);?>;
</script>
<script type="text/javascript" src="common_js/lb.js<?php echo $version;?>"></script>
<script type="text/javascript" src="common_js/gu.js<?php echo $version;?>"></script>