<link rel="stylesheet" type="text/css" href="<?php echo $this->project_admin_path;?>css/adm_reset.css<?php echo $version;?>"/>
<link rel="stylesheet" type="text/css" href="<?php echo $this->project_admin_path;?>css/adm_style.css<?php echo $version;?>"/>
<link rel="stylesheet" type="text/css" href="<?php echo $this->project_admin_path;?>css/adm_select.css<?php echo $version;?>"/>
<link rel="stylesheet" type="text/css" href="<?php echo $this->project_admin_path;?>css/adm_form.css<?php echo $version;?>"/>
<link rel="stylesheet" type="text/css" href="<?php echo $this->project_admin_path;?>css/adm_common.css<?php echo $version;?>"/>
<link rel="stylesheet" type="text/css" href="<?php echo $this->project_admin_path;?>css/adm_modal.css<?php echo $version;?>"/>
<!-- <link rel="shortcut icon" href="https://lbcontents.s3.ap-northeast-2.amazonaws.com/images/IPIACOSMETIC/favicon.ico" type="image/x-icon"> -->