<link href="common_js/summernote-0.8.9-dist/dist/summernote-lite.css" rel="stylesheet"/>
<script src="common_js/summernote-0.8.9-dist/dist/summernote-lite.js"></script>