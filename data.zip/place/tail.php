<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

// if(defined('G5_THEME_PATH')) {
    // require_once(G5_THEME_PATH.'/tail.php');
    // return;
// }

if (G5_IS_MOBILE) {
    include_once(G5_MOBILE_PATH.'/tail.php');
    return;
}

$sql = "select * from {$g5['place_table']} where mb_id = '{$member['mb_id']}'";
$row = sql_fetch($sql);

?>
</div>
<link rel="stylesheet" href="<?php echo G5_URL; ?>/css/footer.css">
<footer>
	<div class="container">
		<ul class="footer-menu flex-sb">
			<li><a href="<?php echo get_pretty_url('content', 'company'); ?>">회사소개</a></li>
            <li><a href="<?php echo get_pretty_url('content', 'provision'); ?>">서비스이용약관</a></li>
            <li><a href="<?php echo get_pretty_url('content', 'privacy'); ?>">개인정보처리방침</a></li>
            <li><a href="<?php echo get_device_change_url(); ?>">모바일버전</a></li>
			<?php if ($is_admin) {  ?>
			<li><a href="<?php echo G5_ADMIN_URL ?>/shop_admin/" target="_self">관리자</a></li>
			<?php } ?>
			<?php if ($row) {  ?>
			<li><a href="<?php echo G5_URL ?>/place/" target="_self">관리자</a></li>
			<?php } ?>
		</ul>
		<div class="line1"></div>
		<ul class="footer-info footer-pc">
			<li><?php echo $default['de_admin_company_name']; ?> | 대표자 : <?php echo $default['de_admin_company_owner']; ?> | <?php echo $default['de_admin_company_addr']; ?> | 사업자등록번호 <?php echo $default['de_admin_company_saupja_no']; ?></li>
			<li>통신판매업 신고번호 : <?php echo $default['de_admin_tongsin_no']; ?> | 대표번호 <?php echo $default['de_admin_company_tel']; ?></li>
		</ul>
		<ul class="footer-info footer-mobile">
			<li>(주)<?php echo $default['de_admin_company_name']; ?> | 대표자 : <?php echo $default['de_admin_company_owner']; ?></li>
			<li>대표번호 <?php echo $default['de_admin_company_tel']; ?></li>
			<li>사업자등록번호 <?php echo $default['de_admin_company_saupja_no']; ?></li>
			<li><?php echo $default['de_admin_company_addr']; ?></li>
			<li>통신판매업 신고번호 : <?php echo $default['de_admin_tongsin_no']; ?></li>
			<?php if ($default['de_admin_buga_no']) echo '<li>부가통신사업신고번호 : '.$default['de_admin_buga_no'].'</li>'; ?>
		</ul>
		<p class="copy m-b-10 m-t-20">© 0000. All Rights Reserved.</p>
	</div>
</footer>
<?php
if(G5_DEVICE_BUTTON_DISPLAY && !G5_IS_MOBILE) { ?>
<?php
}

if ($config['cf_analytics']) {
    echo $config['cf_analytics'];
}
?>

<!-- } 하단 끝 -->

<script>
$(function() {
    // 폰트 리사이즈 쿠키있으면 실행
    font_resize("container", get_cookie("ck_font_resize_rmv_class"), get_cookie("ck_font_resize_add_class"));
});
</script>

<?php
include_once(G5_PATH."/tail.sub.php");
?>