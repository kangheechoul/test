<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

$mb_id = $member['mb_id'];
if ($is_admin == 'super') $mb_id = $_GET['mb_id'];

$sql = "select * from {$g5['place_table']} where mb_id = '$mb_id'";
$row = sql_fetch($sql);
if (!$row['mb_id']) alert('접근권한이 없습니다.', G5_URL);

if ($is_admin == 'super') {
	$url1 = "&mb_id=$mb_id";
	$url2 = "?mb_id=$mb_id";
}

if (G5_IS_MOBILE) {
    include_once(G5_THEME_MOBILE_PATH.'/head.php');
    return;
}

include_once(G5_PATH.'/head.sub.php');

include_once(G5_LIB_PATH.'/latest.lib.php');
include_once(G5_LIB_PATH.'/outlogin.lib.php');
include_once(G5_LIB_PATH.'/poll.lib.php');
include_once(G5_LIB_PATH.'/visit.lib.php');
include_once(G5_LIB_PATH.'/connect.lib.php');
include_once(G5_LIB_PATH.'/popular.lib.php');

echo '<link rel="stylesheet" href="'.G5_URL.'/css/place.css">'.PHP_EOL;
?>

    <header>
		<h3><a href="<?php echo G5_URL ?>/place/<?php echo $url3?>" style="color:#ffffff;">administrator</a></h3>
        <nav>
            <ul class="menu-list flex-sb">
				<li><a href="./popuplist.php?pl_id=<?php echo $row['pl_id']?><?php echo $url1 ?>" class="pop_btn">팝업관리</a></li>
				<li><a href="./sale1.php?pl_id=<?php echo $row['pl_id']?><?php echo $url1 ?>" class="pop_btn">매출관리</a></li>
				<li><a href="./orderlist.php?pl_id=<?php echo $row['pl_id']?><?php echo $url1 ?>" class="pop_btn">주문관리</a></li>
				<li><a href="<?php echo G5_BBS_URL ?>/logout.php" class="log_btn" >LOGOUT</a></li>
				<li><a href="<?php echo G5_URL ?>" class="tnb_shop" target="_blank" title="쇼핑몰 바로가기"><i class="xi-shop" style="font-size:20px;"></i></a></li>
			</ul>
			
        </nav>
    </header>

    <div class="top">
        <i class="xi-caret-up-square-o"></i>
    </div>
	<div class="containerd">
		<div style="height:100px;"></div>
