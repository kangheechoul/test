<?php
include_once('./_common.php');

define('_INDEX_', true);
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

include_once('./head.php');

$sql = "select * from {$g5['place_table']} where mb_id = '$mb_id' order by pl_id desc";
$res = sql_query($sql);
// 요일
$dayOfTheWeek = date('w',mktime(0,0,0,date('m'),date('d'),date('Y')));
// 이번달 주차
$w = ceil((date('w', mktime(0,0,0, date('m'), 1, date('Y'))) + date('d')) / 7);

$day = "";
$week = "";
if ($dayOfTheWeek == 1) $day = "월";
if ($dayOfTheWeek == 2) $day = "화";
if ($dayOfTheWeek == 3) $day = "수";
if ($dayOfTheWeek == 4) $day = "목";
if ($dayOfTheWeek == 5) $day = "금";
if ($dayOfTheWeek == 6) $day = "토";
if ($dayOfTheWeek == 7) $day = "일";

if ($w == "1") $week = "첫째주";
if ($w == "2") $week = "둘째주";
if ($w == "3") $week = "셋째주";
if ($w == "4") $week = "넷째주";
?>
<style>
th{background-color:#000;color:#fff}
.menu-list li:nth-child(1) a,.menu-list li:nth-child(2) a,.menu-list li:nth-child(3) a{visibility:hidden}
</style>
<link rel="stylesheet" href="<?php echo G5_URL ?>/css/place.css">
<div>
	<div class="place_head">
		<div class="place_head_l">
			<h2 class="title"><지점관리></h2>
		</div>
	</div>
	<div style="overflow-y:auto;">
	
		<?php for ($i = 0; $row = sql_fetch_array($res); $i++) { 
		
			$pl_time = $row['pl_time'];
			$pl_expire_time = $row['pl_expire_time'];
			
			if ($pl_time < 10) $pl_time = '0'.$pl_time;
			if ($pl_expire_time < 10) $pl_expire_time = '0'.$pl_expire_time;
			$pl_time = $pl_time.":00";
			$pl_expire_time = $pl_expire_time.":00";
		?>
		<div class="place_box">
			<div class="place_content">
				<div style="margin-bottom:9px;"><h2 style="font-weight:600"><<?php echo $row['pl_name'] ?>></h2></div>
				<div style="margin-bottom:15px;overflow-y:auto;">
					<div style="float:left;width:70%;">
						<div id="map_<?php echo $i ?>" style="width:90%;height:250px;margin:auto;"></div>
					</div>
					<div style="float:left;width:30%;">
						<div style="overflow-y:auto;"><a href="<?php echo G5_URL ?>/place/popuplist.php?pl_id=<?php echo $row['pl_id']?><?php echo $url1 ?>" class="pl_btn">팝업관리</a></div>
						<div style="overflow-y:auto;"><a href="<?php echo G5_URL ?>/place/sale1.php?pl_id=<?php echo $row['pl_id']?><?php echo $url1 ?>" class="pl_btn">매출관리</a></div>
						<div style="overflow-y:auto;"><a href="<?php echo G5_URL ?>/place/orderlist.php?pl_id=<?php echo $row['pl_id']?><?php echo $url1 ?>" class="pl_btn">주문관리</a></div>
						<br>
						<div style="border:1px solid #ddd;padding:5px;">
							<div style="text-align:left;">영업시간 : <?php echo $pl_time ?> ~ <?php echo $pl_expire_time ?></div>
							<br>
							<div style="text-align:left;">휴무일 : <?php echo $row['pl_period'] ?> <?php echo $row['pl_week'] ?></div>
							<br>
							<div style="text-align:left;">전화번호 : <?php echo $row['pl_hp'] ?></div>
							<br>
							<div style="text-align:left;">주소 : (<?php echo $row['pl_zip'] ?>) <?php echo $row['pl_addr1'] ?> <?php echo $row['pl_addr2'] ?></div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<script>
		var mapContainer = document.getElementById('map_<?php echo $i ?>'), // 지도를 표시할 div 
			mapOption = {
				center: new kakao.maps.LatLng(<?php echo $row['pl_latitude'] ?>, <?php echo $row['pl_longitude'] ?>), // 지도의 중심좌표
				level: 3 // 지도의 확대 레벨
			};  

			// 지도를 생성합니다    
			var map = new kakao.maps.Map(mapContainer, mapOption); 

			var coords = new kakao.maps.LatLng(<?php echo $row['pl_latitude'] ?>, <?php echo $row['pl_longitude'] ?>);

			// 결과값으로 받은 위치를 마커로 표시합니다
			var marker = new kakao.maps.Marker({
				map: map,
				position: coords
			});

			// 인포윈도우로 장소에 대한 설명을 표시합니다
			var infowindow = new kakao.maps.InfoWindow({
				content: '<div style="width:150px;text-align:center;padding:6px 0;"><?php echo $row['pl_name'] ?></div>'
			});
			infowindow.open(map, marker);

			// 지도의 중심을 결과값으로 받은 위치로 이동시킵니다
			map.setCenter(coords);
		</script>
		<?php }?>
		<?php if ($i == 0) {?>
		<div>
			<td colspan="6">자료가 없습니다.</td>
		</div>
		<?php } ?>
	</div>
</div>

<?php include_once('./tail.php'); ?>