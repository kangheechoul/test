<?php
include_once('../common.php');

include ('../head.php');
?>
    <title>매장안내</title>
<script type="text/javascript" src="<?= G5_EX_URL."/js/map.js"?>"></script>
	
<script src="//dapi.kakao.com/v2/maps/sdk.js?appkey=<?= $config['cf_kakao_rest_key']?>&libraries=services"></script>
<body>
    <div class="wrap">
        <section>
            <div class="container store">
                <h2 class="title text-center">매장안내</h2>
                <p class="s-title text-center">나와 가까운 매장찾기</p>
                <div class="row mt-4">
                    <div class="col-lg-4 col-md-4 col-sm-12 left">
                    
                        <ul class="nav nav-tabs" id="myTab" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link active" onclick = "$('#type').val('1')" id="store-address-tab" 
                                data-bs-toggle="tab" 
                                data-bs-target="#store-address" type="button" role="tab" aria-controls="store-address" aria-selected="true">지역검색</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" onclick = "$('#type').val('2')" id="store-name-tab" data-bs-toggle="tab" data-bs-target="#store-name" type="button" role="tab" aria-controls="store-name" aria-selected="false">매장명</button>
                            </li>
                        </ul>
                        
                        <input type = "hidden" id = "type" name = "type" value = "1">
                        <div class="tab-content" id="myTabContent">
                            <ul class="tab-pane fade show active" id="store-address" role="tabpanel" aria-labelledby="store-address-tab">	
                                <li class="insert-sel d-flex justify-content-between">
                                    <select name="address1" id="address1">
                                    </select>
                                    <select name="address2" id="address2">
                                    </select>
                                    <button type="button" class="btn search1 btn-dark" id = "map_se1" onclick = "map_list();"><i class="material-icons">search</i></button>
                                </li>
                            </ul>
                           
                            
                            
                            <ul class="tab-pane fade" id="store-name" role="tabpanel" aria-labelledby="store-name-tab">
                                <li class="insert-in d-flex justify-content-between">
                                    <input type="text" id = "str" name = "str" onkeyup = "enter()" value = "">
                                    <button type="button" class="btn search1 btn-dark" id = "map_se2" onclick = "map_list()"><i class="material-icons">search</i></button>
                                </li>
                                
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-8 col-md-8 col-sm-12">
                        <div class="map" id = "map" style="width:100%;height:100%"></div>
                    </div>
                </div>
            </div>
            
            <script>
			
			function enter()
			{
				if(window.event.keyCode == "13")
				{
					$('#map_se2').click();
				}
			}
            
            var pl_list = new Array();
            var mapContainer = document.getElementById('map'), // 지도를 표시할 div 
            mapOption = { 
                center: new kakao.maps.LatLng(33.450701, 126.570667), // 지도의 중심좌표
                level: 3 // 지도의 확대 레벨
            };

        	// 지도를 표시할 div와  지도 옵션으로  지도를 생성합니다
        	var map = new kakao.maps.Map(mapContainer, mapOption);
        	map_list();
        	
            function map_list()
            {
				var addr1 = $('#address1').val();
				var addr2 = $('#address2').val();
				var type = $('#type').val();
				var str = $('#str').val();

				$.ajax({
					url : "./controllor/place_list.php",
					type : "POST",
					dataType : "json",
					data : {
						addr1 : addr1,
						addr2 : addr2,
						type : type,
						str : str
						},
					success : function(result)
					{
						if(type == 1)
						{
							var parent = $('#store-address');
						}
						else
						{
							var parent = $('#store-name');
						}

						if(result[0] != "0")
						{
							var count = result.length;
							$('li[name="place"]').remove();
							for(var i = 0; i < count; i++)
							{
								var li = ' <li class="insert" name = "place">';
									li += '<input type="hidden" id ="pl_id'+i+'" name = "pl_id'+i+'" value = "'+result[i][0]+'">';
									li += '<input type="hidden" id ="pl_lat'+i+'" name = "pl_lat'+i+'" value = "'+result[i][4]+'">';
									li += '<input type="hidden" id ="pl_lon'+i+'" name = "pl_lon'+i+'" value = "'+result[i][5]+'">';
									li += '<a href = "javascript:pl_view('+result[i][4]+','+result[i][5]+')">';
                                    li += '<h4 class="title">'+result[i][1]+'</h4>';
                                    li += '<p class="sm-title">주소 : '+result[i][2]+'</p>';
                                    li += '<p class="sm-title">Tel : '+result[i][3]+'</p>';
                                    li += '<div class="btn-wrap mt-2">';
                                   	li += '<a class="btn btn-secondary" href="javascript:modal('+result[i][0]+');">상세보기</a>';
                                    li += '</div>';
                                	li += '</li>';
								parent.append(li);

								var obj = {title : result[i][1],latlng : new kakao.maps.LatLng(result[i][4],result[i][5]), id : result[i][0], content : result[i][6], lat : result[i][4], lng : result[i][5]};
								pl_list.push(obj);
							}
							//맵 전체에 마커표시
							pl_maker();
							//첫번째 맵에 화면 이동
							pl_view(result[0][4],result[0][5]);
						}
						else
						{
							alert("해당 자료가 없습니다");
						}
					}
					});
            }

            //var imageSrc = "https://t1.daumcdn.net/localimg/localimages/07/mapapidoc/markerStar.png"; 
            var imageSrc = "<?= G5_DATA_URL?>/icon/mark.png"; 

			
            
            function pl_maker()
            {
            	 for (var i = 0; i < pl_list.length; i ++) {
                     
                     // 마커 이미지의 이미지 크기 입니다
                     var imageSize = new kakao.maps.Size(28, 39); 
                     
                     // 마커 이미지를 생성합니다    
                     var markerImage = new kakao.maps.MarkerImage(imageSrc, imageSize); 
                     
                     // 마커를 생성합니다
                     var marker = new kakao.maps.Marker({
                         position: pl_list[i].latlng, // 마커를 표시할 위치
                         title : pl_list[i].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                         image : markerImage // 마커 이미지 
                     });

					marker.setMap(map);

     	             var content = '<div class="marker-info" style="top:-80px;height:auto;background-color:#fff;border:1px solid cornflowerblue;border-radius:5px;text-align:center; padding:5px 15px;">'
             			+'<span style="font-size:16px; display:block;font-weight:600;">'+pl_list[i].title+'</span>'
             			+'<span style="font-size:14px">'+pl_list[i].content+'</span>'
             			+'</div>';

     	            	 // 커스텀 오버레이를 생성합니다
     	     	          var customOverlay = new kakao.maps.CustomOverlay({
     	     	              position: pl_list[i].latlng,
     	     	              content: content   
     	     	          });
     	    
     	     	          // 커스텀 오버레이를 지도에 표시합니다
     	     	          customOverlay.setMap(map);
     	          // 커스텀 오버레이가 표시될 위치입니다 
     	         
    
     	         
	            	
 	            	// 마커 위에 인포윈도우를 표시합니다. 두번째 파라미터인 marker를 넣어주지 않으면 지도 위에 표시됩니다
 	            	
 	           
                 }
            	  // 커스텀 오버레이를 지도에 표시합니다
            }
            
			function pl_view(lat,lon)
			{
				    // 이동할 위도 경도 위치를 생성합니다 
				    var moveLatLon = new kakao.maps.LatLng(lat, lon);
				    // 지도 중심을 이동 시킵니다
				    map.setCenter(moveLatLon);
			}

            </script>
            
            <div class="modal-wrap" id = "modal">
                <div class="modals" id = "pl_info">
                    <h2 class="title text-center"><span id ="pl_name">부산 일광점 </span><span id="close" class="small-text-right"><i class="material-icons">close</i></span></h2>
                    <div class="row mt-4" >
                        <div class="col-lg-6 col-md-6 col-sm-12">
                            <table class="table table-borderless" >
                                <tr>
                                    <th>전화번호</th>
                                    <td id = "pl_hp">051 - 721 - 9009</td>
                                </tr>
                                <tr>
                                    <th>주소</th>
                                    <td id = "pl_addr">부산광역시 기장군 일광면 해빛로 17</td>
                                </tr>
                                <tr>
                                    <th>영업시간</th>
                                    <td id = "pl_time">10:00 ~ 20:00</td>
                                </tr>
                                <tr>
                                    <th>특이사항</th>
                                    <td id = "pl_content"></td>
                                </tr>
                            </table>
                        </div>
                        
                        <div class="col-lg-6 col-md-6 col-sm-12">
                            <div class="map" id = "pl_map" style = "width:100%;height:100%"></div>
                        </div>
                        
                        <div class="col-12 mt-4" id = "pl_img">
                            <img src="./img/interior-item1.jpg" alt="">
                            <img src="./img/interior-item1.jpg" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
    <script src="./vendor/jquery/jquery.min.js"></script>
    <script type="text/javascript">


    $('#modal').click(function(e) 
    	    {
	    		if($(e.target).hasClass("modal-wrap")) 
	    		{
	    	    	 $('#close').click();
	    	    } 
	    	});

    $('#close').click(function() 
    	    {
	    		$('html, body').css({'overflow': 'visible', 'height': '100%'});
	    	});
    
	    
    function modal(pl_id)
    {
    	
		$.ajax({
			url : "./controllor/place_info.php",
			type : "POST",
			dataType : "JSON",
			data : {
					pl_id : pl_id
				}, 
			success : function (result)
			{
				$('body').css("overflow", "hidden");
				$('#pl_name').text(result['pl_name']);
				$('#pl_hp').text(result['pl_hp']);
				$('#pl_addr').text(result['pl_addr1']+result['pl_addr3']+result['pl_addr2']);
				$('#pl_time').text(result['pl_time'] +' ~ '+ result['pl_expire_time']);
				$('#pl_content').text(result['pl_content']);

				var img_list = "";
				for(var i = 1; i <= 5; i++)
				{
					if(result['pl_img'+i] != "")
					{
						img_list += '<img src="<?= G5_DATA_URL?>/place/'+result['pl_img'+i]+'" alt="">'
					}
				}
				$('#pl_img').html(img_list);				

				$('.modal-wrap').fadeIn(500);
				
				var mapContainer = document.getElementById('pl_map'); // 지도를 표시할 div 
	            var mapOption = { 
	                center: new kakao.maps.LatLng(result['pl_latitude'], result['pl_longitude']), // 지도의 중심좌표
	                level: 5 // 지도의 확대 레벨
	            };

	        	// 지도를 표시할 div와  지도 옵션으로  지도를 생성합니다
	        	var pl_map = new kakao.maps.Map(mapContainer, mapOption);
	        	
                
  	            var iwPosition = new kakao.maps.LatLng(result['pl_latitude'],result['pl_longitude']); //인포윈도우 표시 위치입니다
  	            
  	          	var imageSize = new kakao.maps.Size(24, 35); 
  	          	var markerImage = new kakao.maps.MarkerImage(imageSrc, imageSize); 

  	          var marker = new kakao.maps.Marker({
                  map: pl_map, // 마커를 표시할 지도
                  position: iwPosition, // 마커를 표시할 위치
                  title : result['pl_name'], // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                  image : markerImage // 마커 이미지 
              });
              
  	        var pl_content = '<div class="marker-info" style="top:-80px;height:auto;background-color:#fff;border:1px solid cornflowerblue;border-radius:5px;text-align:center; padding:5px 15px;">'
     			+'<span style="font-size:16px; display:block;font-weight:600;">'+result['pl_name']+'</span>'
     			+'<span style="font-size:14px">'+result['pl_content']+'</span>'
     			+'</div>';

	            	 // 커스텀 오버레이를 생성합니다
	     	          var pl_customOverlay = new kakao.maps.CustomOverlay({
	     	              position: iwPosition,
	     	              content: pl_content   
	     	          });
	    
	     	          // 커스텀 오버레이를 지도에 표시합니다
	     	          pl_customOverlay.setMap(pl_map);
  	            	
  	            	$('html, body').css({'overflow': 'hidden', 'height': '100%'});
			}
			});
    }
    
    
        $(document).ready(function(){
            $('#myBtn').click(function(){
                $('.modal-wrap').fadeIn(2000);
            });
            $('#close').click(function(){
                $('.modal-wrap').fadeOut();
            });

        });
    </script>
    <script src="./vendor/bootstrap/js/bootstrap.bundle.min.js"></script>    
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.6.0/dist/umd/popper.min.js" integrity="sha384-KsvD1yqQ1/1+IA7gi3P0tyJcT3vR+NdBTt13hSJ2lnve8agRGXTTyNaBYmCR/Nwi" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.min.js" integrity="sha384-nsg8ua9HAw1y0W1btsyWgBklPnCUAFLuTMS2G72MMONqmOymq585AcH49TLBQObG" crossorigin="anonymous"></script>   
</body>
<?php include ('../tail.php');?>