<?php
include_once('../../common.php');

$addr1 = $_REQUEST['addr1'];
$addr2 = $_REQUEST['addr2'];

$str = $_REQUEST['str'];
$type = $_REQUEST['type'];

$sql = "select * from {$g5['place_table']} where";

if($type == 1)
{
    $where = " pl_addr1 like '{$addr1}%' and pl_addr1 like '%{$addr2}%'";
}
else
{
    $where = " pl_addr1 like '%{$str}%' or pl_addr2 like '%{$str}%' or pl_addr3 like '%{$str}%'";
}

$sql .= $where;

$res = sql_query($sql);

for($i= 0; $row = sql_fetch_array($res); $i++)
{
    $result[$i][0] = $row['pl_id'];
    $result[$i][1] = $row['pl_name'];
    $result[$i][2] = $row['pl_addr1'].$row['pl_addr3'].$row['pl_addr2'];
    $result[$i][3] = $row['pl_hp'];
    $result[$i][4] = $row['pl_latitude'];
    $result[$i][5] = $row['pl_longitude'];
    $result[$i][6] = $row['pl_content'];
}
if($i == 0)
{
    $result[0] = "0";
}


echo json_encode($result, true);

?>