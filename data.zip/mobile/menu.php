<?php 
include_once('./_common.php');
include_once (G5_MOBILE_PATH.'/includepage/menu_head.php');

include_once('./head.php');
$it_id = $_REQUEST['it_id'];


$m_it_sql = "select * from {$g5['g5_shop_item_table']} where it_id = '{$it_id}'";
$m_it_row = sql_fetch($m_it_sql);

$m_it_maker = $m_it_row['it_maker'];


$it_maker_arr = explode('),', $m_it_maker);

$it_recipe = $m_it_row['it_img10'];

$deli_guid_sql = "select * from {$g5['content_table']} where co_id = 'delivery_guid'";

$deli_guid_row = sql_fetch($deli_guid_sql);

$deli_guid = $deli_guid_row['co_mobile_content'];

$url = explode('?',$_SERVER['HTTP_REFERER']);

$back_url = $url[0]."?ca_id=".$_REQUEST['ca_id']."&tab=".$_GET['tab'];

?>
<script> 
history.pushState(null, null, '');

//data, title, url 의 값이 들어가게 됩니다. 비워두면 이벤트 발생의 플래그 정도로 사용 할 수 있습니다. 
//기존페이지 이외에 입력한 URL로 페이지가 하나 더 만들어지는 것을 알 수 있습니다. 
window.onpopstate = function(event) 
{
	//뒤로가기 이벤트를 캐치합니다.
	location.href = "<?php echo $back_url?>";
	// pushState로 인하여 페이지가 하나 더 생성되기 떄문에 한번에 뒤로가기 위해서 뒤로가기를 한번 더 해줍니다. 
};

 </script>

<body>

    <div class="wrap">
        <section class="sec_1 menu-info">
            <div class="container">
                 <div class="img_box m-b-10">
                    <img src="<?= G5_DATA_URL.'/item/'.$m_it_row['it_img1']?>" alt="<?= $m_it_row['it_name']?>">
                </div>
                <div class="info">
                    <ul>
                        <li class="bd-b"><h3><?= $m_it_row['it_name']?></h3></li>
                        <li>
                            <dl>
                                <dt>조리시간</dt>
                                <dd><?= $m_it_row['it_cook_time']?> 분</dd>
                            </dl>
                        </li>
                        <li>
                            <dl>
                                <dt>조리량</dt>
                                <dd><?= $m_it_row['it_inbun']?> 인분</dd>
                            </dl>
                        </li>
                        <li class="bd-b">
                            <dl>
                                <dt>조리난이도</dt>
                                <dd><?php for($i = 0; $i <$m_it_row['it_level']; $i++ )echo ' <i class="material-icons">star</i>'?></dd>
                            </dl>
                        </li>
                        <li>
                            <dl>
                                <dt>유통기한</dt>
                                <dd><?= $m_it_row['it_expire_date']?></dd>
                            </dl>
                        </li>
                        <li>
                            <dl>
                                <dt>보관방법</dt>
                                <dd><?= $m_it_row['it_storage']?></dd>
                            </dl>
                        </li>
                        <li class="bd-b">
                            <dl>
                                <dt>주문방법</dt>
                                <!-- <dd>상품 주문은 MIMICOOK 전용 앱을 설치 후 주문 가능합니다.</dd> -->
								<dd>배달의 민족 또는 쿠팡이츠에서 주문 가능합니다.</dd>
                            </dl>
                        </li>
						<li class="bd-b">
							<dl>
								<dt>판매가격</dt>
								<dd><?= number_format($m_it_row['it_price'])?> 원</dd>
							</dl>
						</li>
                    </ul>
                </div>
                </div>
                </section>
                <section class="sec_2 m-t-30 menu-info2">
                    <div class="container">
                <nav>
                    <div class="nav nav-tabs" id="nav-tab" role="tablist">
                      <a class="nav-item nav-link active" id="nav-1-tab" data-toggle="tab" href="#nav-1" role="tab" aria-controls="nav-1" aria-selected="true">원산지표시</a>
                      <a class="nav-item nav-link" id="nav-2-tab" data-toggle="tab" href="#nav-2" role="tab" aria-controls="nav-2" aria-selected="false">레시피</a>
                      <a class="nav-item nav-link" id="nav-3-tab" data-toggle="tab" href="#nav-3" role="tab" aria-controls="nav-3" aria-selected="false">배송정보</a>
                    </div>
                </nav>
                  <div class="tab-content m-b-70" id="nav-tabContent">
                    <div class="tab-pane fade show active" id="nav-1" role="tabpanel" aria-labelledby="nav-1-tab">
                        <table class="table">
                            <thead>
                        <colgroup>
							<col width="20%">
							<col width="30%">
							<col width="20%">
							<col width="30%">
						</colgroup>
                                <tr>
                                    <th>재료</th>
                                    <th>원산지</th>
                                    <th>공통양념</th>
                                    <th>원산지</th>
                                </tr>
                            </thead>
                            <tbody>
                          <?php 
                          $it_maker_tmp = $m_it_row['it_maker'];
						  
						  $it_maker_arr = explode('),',$it_maker_tmp);
                            for($i = 0; $i < count($it_maker_arr); $i++)
                            {
                                $tmp = explode('(',$it_maker_arr[$i]);
                                $it_maker[$i][0] = $tmp[0];
                                $it_maker[$i][1] = str_replace(')','',$tmp[1]);
                            }
                            $it_origin_tmp = $m_it_row['it_origin'];
                            $it_origin_arr = explode('),',$it_origin_tmp);
                            
                            for($i = 0; $i < count($it_origin_arr); $i++)
                            {
                                $tmp = explode('(',$it_origin_arr[$i]);
                                $it_origin[$i][0] = $tmp[0];  
                                $it_origin[$i][1] = str_replace(')','',$tmp[1]);
                            }
                            
                            if(count($it_origin) > count($it_maker))
                            {
                                $len = count($it_origin);
                            }
                            else
                            {
                                $len = count($it_maker);
                            }
                            
                            for($i = 0; $i < $len; $i++)
                            {
                                
                                ?>
                                <tr>
                                <td><?= $it_maker[$i][0]?></td>
                                <td><?= $it_maker[$i][1]?></td>
                                <td><?= $it_origin[$i][0]?></td>
                                <td><?= $it_origin[$i][1]?></td>                                
                            	</tr>
                            	<?php      
                            }
                            ?>
                                	    
                             <!--    <tr>
                                    <td>김치</td>
                                    <td>고추가루(국내산),배추(국내산)</td>
                                </tr>
                                <tr>
                                    <td>고기</td>
                                    <td>돼지고기(국내산)</td>
                                </tr> -->
                                
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="tab-pane fade m-b-70" id="nav-2" role="tabpanel" aria-labelledby="nav-2-tab">
                         <img src="<?= G5_DATA_URL."/item/{$it_recipe}"?>" alt="<?= $m_it_row['it_name']?>" style="width: 100%;">
                    </div>
                    
                    <div class="tab-pane fade m-b-70" id="nav-3" role="tabpanel" aria-labelledby="nav-3-tab">
                        <?= $deli_guid?>
                    </div>
                    
                    <script>
					$('#nav-3 > div > div > img').css('width', '100%');
                    </scripT>
                    
                  </div>
            </div>
        </section>
        <?php include_once G5_MOBILE_PATH.'/includepage/include_menu.php';?>
</body>

