<?php 
include_once('../_common.php');


?>
<!-- 기본 -->
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximim-scale=1.0, minimum-scal=1.0, user-scalable=no">
    <link rel="stylesheet" href="<?= G5_MOBILE_URL?>/vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?= G5_MOBILE_URL?>/css/reset.css">
    <link rel="stylesheet" href="<?= G5_MOBILE_URL?>/css/util.css">
    <link rel="stylesheet" href="<?= G5_MOBILE_URL?>/css/index.css">
 	<link rel="stylesheet" href="<?= G5_MOBILE_URL?>/css/swiper.min.css">
    
    <script src="<?= G5_MOBILE_URL?>/vendor/jquery/jquery-3.2.1.min.js"></script>

    <link rel="stylesheet" href="<?= G5_MOBILE_URL?>/css/style.css">
	<link rel="stylesheet" href="<?= G5_MOBILE_URL?>/css/menulist.css">
    
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
      rel="stylesheet">
      
      
       <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    </head>
