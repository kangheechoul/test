    <div class="tabs flex-l">
      <a id="notice" href="<?= G5_MOBILE_URL?>/my_notice_list.php">공지사항</a>
      <a id="event" href="<?= G5_MOBILE_URL?>/my_event_list.php">이벤트</a>
	  <a id="faq" href="<?= G5_MOBILE_URL?>/my_faq.php">자주하는 질문</a>
    </div>

<script>
        $(function(){
            const queryString = window.location.pathname
            if(queryString == '/mobile/my_notice_list.php'){
              $('#notice').addClass('active')
            }else if(queryString == '/mobile/my_event_list.php'){
              $('#event').addClass('active')
            }else if(queryString == '/mobile/my_faq.php'){
              $('#faq').addClass('active')
            }
        });
</script>

