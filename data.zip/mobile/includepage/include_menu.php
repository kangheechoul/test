	<div class="btn_wrap flex-sb" id = "menu_bar"> 
        <a class="at" id="home" href="<?php echo G5_MOBILE_URL?>"><i class="material-icons">home<span>Home</span></i></a>
        <a class="at" id="store" href="<?php echo G5_MOBILE_URL?>/store.php"><i class="material-icons">storefront<span>매장안내</span></i></a>
        <a class="at" id="search" href="<?php echo G5_MOBILE_URL?>/search.php"><i class="material-icons">search<span>검색</span></i></a>
        <a class="at" id="customer" href="<?php echo G5_MOBILE_URL?>/frenchise.php"><i class="material-icons">support_agent<span>창업안내</span></i></a>
    </div>
    <div style= "height:65px;background:#f1f1f1e0">
    </div>
       <script>
        $(function(){
            const queryString = window.location.pathname
            if(queryString == '/mobile/search.php'){
                $('#search').addClass('active');
            }else if(queryString == '/mobile/'){
                $('#home').addClass('active');
            }else if(queryString == '/mobile/store.php'){
                $('#store').addClass('active');
            }else if(queryString == '/mobile/frenchise.php'){
                $('#customer').addClass('active');
            }else if(queryString == '/mobile/index.php'){
				$('#home').addClass('active');
			}
        });
        
		/* $('#menu_bar').css('position', 'fixed');
	    $('#menu_bar').css('bottom', '0');
	    $('#menu_bar').css('left', '0');
	    $('#menu_bar').css('z-index', '10');
	    $('#menu_bar').css('width', '100%');
	    $('#menu_bar').css('height', 'auto');  */
	    
        </script>


        
