<?php
include_once('./_common.php');
include_once (G5_MOBILE_PATH.'/includepage/menu_head.php');

include_once(G5_MOBILE_PATH.'/head.php');

$cf = get_qa_config();

$sql = "select * from {$g5['content_table']} where co_id = 'agree_use'";
$row = sql_fetch($sql);

?>

<title><?= $cf['qa_title']?></title>
<body>
    <div class="wrap">
        <header id="head"></header>
        <section class="sec_1 customer">
		<!--
            <div class="container">
            <nav>
                <div class="row row-col-2 text-center">
                    <a href="<?= G5_MOBILE_URL?>/franchise.php" class="col">창업시스템</a>
                    <a href="<?= G5_MOBILE_URL?>/franchise_write.php" class="col active"><?= $cf['qa_title']?></a>
                </div>
            </nav>
            </div>
		-->
            <div class="container write">
				<div id="qa_information">
				
				<!-- db에서 불러와야할듯 -->
					<h3><?= $row['co_subject']?></h3>
					<?= $row['co_mobile_content']?>
					
					
					
					<label for="qa_agree" class="frm_info"><input type="checkbox" name="qa_agree" id="qa_agree" class=""><span>위 개인정보 수집 및 활용에 동의합니다.</span></label>
				</div>
                <form action="./qawrite_update.php" id = "qa_form" method="POST" enctype='multipart/form-data'>
                <input type="hidden" name="w" value="<?php echo $w ?>">
					<ul class="row">
					
						<li class="col-12">
							<dt>이름</dt><dd><input name = "qa_name" id="qa_name" type="text" placeholder="이름" value =""></dd>
						</li>
						
						<li class="col-12">
							<dt>이메일</dt><dd><input name = "qa_email" id="qa_email" type="email" placeholder="이메일" value = ""></dd>
						</li>
						
						<li class="col-12">
							<dt>휴대폰</dt><dd><input name = "qa_hp" id="qa_hp" type="text" placeholder="ex) 010-1234-5678" value = ""></dd>
						</li>
						
						<li class="col-12">
							<dt>창업희망지역</dt><dd><input name = "qa_area" id="qa_area" type="text" placeholder="창업희망지역 ex) 부산" value = ""></dd>
						</li>
						
						<li class="col-12">
							<dt>예상창업비용</dt><dd><input name = "qa_cost" id= "qa_cost" type="text" placeholder="예상창업비용(숫자만)" value= ""></dd>
						</li>
						
						<li class="col-12">
							<dt>제목</dt><dd><input name = "qa_subject" id= "qa_subject" type="text" placeholder="제목" value= ""></dd>
						</li>
						
						<li class="col-12">
							<dt>내용</dt><dd><textarea name="qa_content" id="qa_content" rows="10"></textarea></dd>
						</li>
					</ul>
					
                    <input class="btn w-full bg-gr" type = "button" onclick = "qa()" value = "문의하기">
                </form>
            </div>
        </section>
    </div>
</body>

<script>

function qa()
{
	var email_re,hp_re,text_re,num_re;

	email_re = /^[-A-Za-z0-9_]+[-A-Za-z0-9_.]*[@]{1}[-A-Za-z0-9_]+[-A-Za-z0-9_.]*[.]{1}[A-Za-z]{1,5}$/;
	hp_re = /^\d{2,3}-\d{3,4}-\d{4}$/;
	//text_re = /[a-z0-9]|[ \[\]{}()<>?|`~!@#$%^&*-_+=,.;:\"'\\]/g
	text_re = /^[가-힣\s]+$/;
	name_re = /^[가-힣]+$/;
	num_re = /^[0-9]/g;

	if($("input:checkbox[name=qa_agree]").is(":checked") == false)
	{
		alert('개인정보 수집 및 활용동의를 체크해주세요');
		$('#qa_agree').focus();
		return false;
	}
	else if(name_re.test($('#qa_name').val()) == false || $('#qa_name').val() == "")
	{
		alert('이름을 바로 작성해주세요');
		$('#qa_name').focus();
		return false;
	}
	else if(hp_re.test($('#qa_hp').val()) == false || $('#qa_hp').val() == "")
	{
		alert('전화번호 형식을 맞춰주세요');
		$('#qa_hp').focus();
		return false;
	}
	else if(text_re.test($('#qa_area').val()) == false || $('#qa_area').val() == "")
	{
		alert('창업희망지역을 바로 작성해주세요');
		$('#qa_area').focus();
		return false;
	}
	else
	{
		qa_form.submit();
	}
}

</script>



<?php include_once G5_MOBILE_PATH.'/includepage/include_menu.php';?>