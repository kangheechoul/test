<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximim-scale=1.0, minimum-scal=1.0, user-scalable=no">
    <link rel="stylesheet" href="<?= G5_MOBILE_URL?>/vendor/bootstrap/css/bootstrap.css">
    <script src="<?= G5_MOBILE_URL?>/vendor/jquery/jquery-3.2.1.min.js"></script>
    
	<link rel="stylesheet" href="<?= G5_MOBILE_URL?>/css/reset.css">
    
    <link rel="stylesheet" href="<?= G5_MOBILE_URL?>/css/head.css">
 	<!-- <link rel="stylesheet" href="<?= G5_MOBILE_URL?>/css/index.css"> -->
 	<link rel="stylesheet" href="<?= G5_MOBILE_URL?>/css/review.css">
 	<link rel="stylesheet" href="<?= G5_MOBILE_URL?>/css/util.css">
 	
 	<link rel="stylesheet" href="<?= G5_MOBILE_URL?>/css/swiper.min.css">
	<!-- <link rel="stylesheet" href="<?= G5_MOBILE_URL?>/css/style.css"> -->
	<link rel="stylesheet" href="<?= G5_MOBILE_URL?>/css/style1.css">
    <!-- font -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

    <!-- bootstrap -->
    <script src="<?= G5_MOBILE_URL?>/vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="<?= G5_MOBILE_URL?>/vendor/bootstrap/js/popper.min.js"></script>
    
     <!-- swiper -->
    <script src="<?= G5_MOBILE_URL?>/vendor/swiper/swiper.min.js"></script>
    <script src="<?= G5_MOBILE_URL?>/js/swiper_slide.js"></script>
</head>