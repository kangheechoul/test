<?php
define('_INDEX_', true);
include_once('./_common.php');
//if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

/* if(defined('G5_THEME_PATH')) {
    require_once(G5_THEME_PATH.'/index.php');
    return;
} */
//$_SESSION['ss_is_mobile'] = 1;

unset($_SESSION['ss_is_mobile']);

include_once(G5_MOBILE_PATH.'/head.php');
?>

<div class="wrap">
<!-- 메인화면 최신글 시작 -->
	<?php include_once G5_MOBILE_PATH.'/banner.php';?>
	
	<?php include_once G5_MOBILE_PATH.'/index_item.php'?>
	
	<?php include_once G5_MOBILE_PATH.'/m_content.php'?>
	
	
</div>

<?php include_once G5_MOBILE_PATH.'/includepage/include_menu.php';?>
<style>

</style>
<div id="kakao-talk-channel-chat-button"></div>

<script src="//developers.kakao.com/sdk/js/kakao.min.js"></script>
<script type='text/javascript'>
  //<![CDATA[
    // 사용할 앱의 JavaScript 키를 설정해 주세요.
    Kakao.init('<?php echo $config["cf_kakao_rest_key"]?>');
    // 카카오톡 채널 1:1채팅 버튼을 생성합니다.
    Kakao.Channel.createChatButton({
      container: '#kakao-talk-channel-chat-button',
      channelPublicId: '<?php echo $config["cf_kakao_channel_code"]?>' // 카카오톡 채널 홈 URL에 명시된 id로 설정합니다.
    });
  //]]>
</script>

<!-- 메인화면 최신글 끝 -->
<?php
//include_once(G5_MOBILE_PATH.'/tail.php');
?>