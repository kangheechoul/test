<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

if(defined('G5_THEME_PATH')) {
    require_once(G5_THEME_PATH.'/head.php');
    return;
} 
include_once('./_common.php');

include_once(G5_LIB_PATH.'/latest.lib.php');
include_once(G5_LIB_PATH.'/outlogin.lib.php');
include_once(G5_LIB_PATH.'/poll.lib.php');
include_once(G5_LIB_PATH.'/visit.lib.php');
include_once(G5_LIB_PATH.'/connect.lib.php');
include_once(G5_LIB_PATH.'/popular.lib.php');

$version = date("Y-m-d H:i:s");

?>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximim-scale=1.0, minimum-scal=1.0, user-scalable=no">
    <link rel="stylesheet" href="<?= G5_MOBILE_URL?>/vendor/bootstrap/css/bootstrap.min.css">
    <script src="<?= G5_MOBILE_URL?>/vendor/jquery/jquery-3.2.1.min.js"></script>
    
    <!-- <link rel="stylesheet" href="<?= G5_MOBILE_URL?>/css/style.css"> -->
    
    <!-- <link rel="stylesheet" href="<?= G5_MOBILE_URL?>/css/head.css"> -->
    
 	<link rel="stylesheet" href="<?= G5_MOBILE_URL?>/css/index.css?version=<?= $version?>">
 	
 	<link rel="stylesheet" href="<?= G5_MOBILE_URL?>/css/reset.css?version">
 	
 	<link rel="stylesheet" href="<?= G5_MOBILE_URL?>/css/util.css?version">
 	
 	<link rel="stylesheet" href="<?= G5_MOBILE_URL?>/css/swiper.min.css?version">
 	<?php 
 	if(!strpos($_SERVER['REQUEST_URI'], "admin") || !strpos($_SERVER['REQUEST_URI'], "adm"))
 	{
 	  ?>
 	  <link rel="stylesheet" href="<?= G5_MOBILE_URL?>/css/style1.css?version">
 	  <?php     
 	}
 	?>
 	<meta property="og:image" content="<?= G5_URL?>/img/mimicook-logo.png">

    <!-- font -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

    <!-- bootstrap -->
    <script src="<?= G5_MOBILE_URL?>/vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="<?= G5_MOBILE_URL?>/vendor/bootstrap/js/popper.min.js"></script>
    
     <!-- swiper -->
    <script src="<?= G5_MOBILE_URL?>/vendor/swiper/swiper.min.js"></script>
    <script src="<?= G5_MOBILE_URL?>/js/swiper_slide.js"></script>
    
    <!-- bootstrap -->
    <script src="<?= G5_MOBILE_URL?>/vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="<?= G5_MOBILE_URL?>/vendor/bootstrap/js/popper.min.js"></script>
<title>미미쿡</title>    
</head>

<body>
<?php

if(defined('_INDEX_')) { // index에서만 실행
    include G5_MOBILE_PATH.'/newwin.inc.php'; // 팝업레이어
}

$m_cate_sql = "select * from {$g5['g5_shop_category_table']} where length(ca_id) = 2";

$m_cate_res = sql_query($m_cate_sql);


function get_mshop_category($ca_id, $len)
{
    global $g5;
    
    $sql = " select ca_id, ca_name from {$g5['g5_shop_category_table']}
                where ca_use = '1' ";
    if($ca_id)
        $sql .= " and ca_id like '$ca_id%' ";
        $sql .= " and length(ca_id) = '$len' order by ca_order, ca_id ";
        
        return $sql;
}
$mshop_categories = get_shop_category_array(true);
?>
					<script>

					function search_enter()
					{
						if(window.event.keyCode == "13")
						{
							search();
						}
					}
					function search()
					{
						location.href = "<?= G5_SHOP_URL."/search.php?q="?>"+ $('#search_text').val();
					}

					</script>
<header>
	<nav>
		<div class="logo-wrap"><a class="logo" href="<?php echo G5_MOBILE_URL ?>"><img src="<?= G5_MOBILE_URL?>/img/mimicook-logo.png" alt="logo"></a></div>
		
		<div class="bottom_head">
            <ul class="flex-sb">
            	
							<li>
								<a id="brand_info" href="<?php echo G5_MOBILE_URL ?>/brand_info.php">브랜드 소개</a>		
							</li>
							<li>
								<a id="interior" href="<?php echo G5_MOBILE_URL ?>/interior.php">인테리어</a>		
							</li>
							<li>
								<a id="company" href="<?php echo G5_MOBILE_URL ?>/company.php">회사 소개</a>		
							</li>
							<li>
								<a id="category" href="<?php echo G5_MOBILE_URL ?>/category.php">미미쿡 메뉴</a>		
							</li>
            </ul>
        </div>
	</nav>
</header>

<script>
        $(function(){
            const queryString = window.location.pathname
            if(queryString == '/mobile/brand_info.php'){
                $('#brand_info').addClass('active');
            }else if(queryString == '/mobile/interior.php'){
				$('#interior').addClass('active');
			}else if(queryString == '/mobile/company.php'){
				$('#company').addClass('active');
			}else if(queryString == '/mobile/category.php'){
				$('#category').addClass('active');
			}
        });
	    
</script>
