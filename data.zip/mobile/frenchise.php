<?php 
include_once('../common.php');

include_once(G5_MOBILE_PATH.'/head.php');
?>

    <title>창업안내</title>

<body>
    <div class="wrap">
        <section>
            <div class="container fren">
                <h2 class="title">창업안내</h2>
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-12 mb-4">
                        <h2 class="title under-line">1인 운영 가능</h2>
                        <p class="s-title">무인 키오스크 도입으로 1인 영업 및 24시간 운영이 가능하여 수익률 극대화를 
                            창출할 수 있습니다.</p>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 mb-4">
                        <h2 class="title under-line">창업 비용에 대한 낮은 부담감</h2>
                        <p class="s-title">10평 내외의 소형 평수로 창업이 가능하므로 소자본 투자로 창업 비용에 대한
                            부담감을 줄여드립니다.</p>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12">
                        <h2 class="title under-line">밀키트, 가정 간편식 시장의 성장</h2>
                        <p class="s-title">한식뿐만 아니라 양식, 중식 등 다양한 메뉴로 전 세대를 아우르며 또한
                            가정에서 구현하기 힘든 메뉴의 지속적인 개발로 급속도로 성장하는 가정
                            간편식 시장에 발맞춰 나갈 수 있습니다.</p>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12">
                        <h2 class="title under-line">점주의 자존감을 높여줄 인테리어</h2>
                        <p class="s-title">일반 반찬가게의 평이한 인테리어가 아닙니다.</p>
                        <p class="s-title">
                            쇼핑하는 고객에겐 품격을 높여주고, 평생의 일터인 점주에겐 안락함을 주는
                            감성적인 인테리어를 선사해 드립니다.</p>
                    </div>
                </div>
            </div>
            <div class="container frenchise">
                <h2 class="title">창업비용<span class="small-text-right">(단위 : 만원)</span></h2>
                <div class="row">
                    <div class="col-lg-12">
                        <table class="table">
                            <colgroup>
                                <col width="15%">
                                <col width="75%">
                                <col width="10%">
                            </colgroup>
                            <tr>
                                <td>가맹비</td>
                                <td>상표등록권, 경영지원, 영업보호, 소멸성 1회 (계약 해지시 소멸), 신규 양도, 양수시 발생</td>
                                <td>300</td>
                            </tr>
                            <tr>
                                <td>교육비</td>
                                <td>운영 방법, 제품관리 및 손질 방법, 오픈 전 지정 매장에서 교육 또는 오프라인 매장에서 교육</td>
                                <td>150</td>
                            </tr>
                            <tr>
                                <td>BI용품</td>
                                <td>유니폼, 할인스티커, 각종 POP, 디스플레이 용품</td>
                                <td>100</td>
                            </tr>
                            <tr>
                                <td>가맹비</td>
                                <td>
                                    <span class="d-block">실내 내부공사 및 홀-주방 집기 일체</span>
                                    <span class="d-block">(목공, 전기, 조명, 도장, 금속, 타일, 내부 지정 가구, 전면간판, 홀 냉장고, 주방 기물 일체)</span>
                                    <span class="d-block">*실면적 9~11평까지 동일금액, 이상은 별도 협의</span>
                                </td>
                                <td>3,900</td>
                            </tr>
                            <tr class="bg-red">
                                <th class="bt-t-n">합계</th>
                                <th colspan="2" class="bt-t-n text-right">4,450(부가세 별도)</th>
                            </tr>
                        </table>
                        <dl class="d-flex justify-content-start sm-text">
                            <dt style="width: 100px;">※ 별도공사</dt>
                            <dd>외부 공사, 에어컨, 철거, 전기승합, 전기온수기, 무인키오스크(선택)</dd>
                        </dl>
                        <dl class="sm-text">
                            <dt></dt>
                        </dl>
                    </div>
                </div>
            </div>
            <div class="container frenchise">
                <h2 class="title">수익률 분석<span class="small-text-right">(단위 : 만원)</span></h2>
                <div class="row">
                    <div class="col-12">
                        <table class="table text-center">
                            <colgroup>
                                <col width="20%">
                                <col width="20%">
                                <col width="20%">
                                <col width="20%">
                                <col width="20%">
                            </colgroup>
                            <tr>
                                <th class="text-center">월매출</th>
                                <th class="text-center">2,000</th>
                                <th class="text-center">2,500</th>
                                <th class="text-center">3,000</th>
                                <th class="text-center">비고</th>
                            </tr>
                            <tr>
                                <td>납품 재료비 50%</td>
                                <td>1,000</td>
                                <td>1,250</td>
                                <td>1,500</td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>전기세, 수도세</td>
                                <td>30</td>
                                <td>30</td>
                                <td>30</td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>로열티(정액제)</td>
                                <td>30</td>
                                <td>30</td>
                                <td>30</td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>기타 지출</td>
                                <td>70</td>
                                <td>70</td>
                                <td>70</td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>소계</td>
                                <td>1,130</td>
                                <td>1,380</td>
                                <td>1,630</td>
                                <td></td>
                            </tr>
                            <tr class="bg-red">
                                <th class="text-center">수익</th>
                                <th class="text-center">870</th>
                                <th class="text-center">1,120</th>
                                <th class="text-center">1,370</th>
                                <th></th>
                            </tr>
                        </table>
                        <dl class="sm-text">
                            <dt>※ 상기 수익률에 임대료는 제외되어 있습니다.</dt>
                        </dl>
                        <dl class="sm-text">
                            <dt>※ 인건비는 점주 1인 운영 가능 매장이므로 포함되어 있지 않습니다.</dt>
                        </dl>
                    </div>
                </div>
				<div class="btn-wrap text-center mt-4">
					<a class="btn bg-red" style="width:200px;" href="<?php echo G5_MOBILE_URL ?>/frenchise_write.php">가맹신청</a>
				</div>
            </div>
        </section>
		<?php include_once G5_MOBILE_PATH.'/m_content.php'?>
    </div>

    <script src="./vendor/jquery/jquery.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function(){

            $(window).resize(function(){
                let ww = window.outerWidth;
                if(ww <= 767){
                    $('.fren .col-sm-12').addClass('mb-4');
					$('dl').removeClass('d-flex');
                }
            });
        });
    </script>
    <script src="./vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
<?php include_once G5_MOBILE_PATH.'/includepage/include_menu.php';?>