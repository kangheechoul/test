<section>
 <?php 
 include_once('./_common.php');
$ca_id1 = "1009"; 
$ca_id2 = "";

$i = 0;

$order_by = " order by ca_id";

$limit = " limit 5";

$menu_count = str_replace(" limit ", "", $limit);

$main_cate_sql = "select * from {$g5['g5_shop_category_table']} where length(ca_id) = 4 {$order_by}{$limit}" ;
$main_cate_res = sql_query($main_cate_sql);

 ?>
 
 <!-- container-1 -->
            <div class="container index">
                <div class="row">
                    <div class="col-lg-4  col-md-4 d-flex flex-column justify-content-center">
                        <p class="s-title">지금 바로 요리, 시작하세요</p>
                        <h2 class="title">COOK, NOW</h2>
                        <p class="mb-2">미미쿡은 50여 가지 한식, 중식, 양식 등의 밀키트 제품과
                            20여 가지의 냉동제품을 갖춘 오프라인 밀키트 매장입니다.
                        </p>
                        <p>요리에 필요한 식재료와 자체 개발 소스,
                            간단한 조리법을 제공함으로써 누구나 언제, 어디서든
                            빠르고 쉽게 맛있는 요리를 완성할 수 있습니다.
                        </p>
                    </div>
                    <div class="col-lg-8 col-md-8 img-box"><img src="<?= G5_URL?>/img/slogun.jpg" alt=""></div>
                </div>
            </div>
            <!-- container-2 -->
            <div class="container hover">
                <h2 class="title text-center">미미쿡 감성</h2>
                <p class="s-title text-center under-line">미미쿡과 함께 감성적 분위기를 내보세요</p>
                <div class="row mt-4">
                    <div class="col-lg-4 col-md-4 col-sm-12">
                        <img src="<?= G5_URL?>/img/item-1.jpg" alt="">
                        <ul>
                            <li>#미미쿡</li>
                            <li>#캠핑장 요리</li>
                            <li>#간편 요리</li>
                        </ul>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-12">
                        <img src="<?= G5_URL?>/img/item-2.jpg" alt="">
                        <ul>
                            <li>#미미쿡</li>
                            <li>#홈파티</li>
                            <li>#집콕 요리</li>
                        </ul>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-12">
                        <img src="<?= G5_URL?>/img/item-3.jpg" alt="">
                        <ul>
                            <li>#미미쿡</li>
                            <li>#외식하기 싫은 날</li>
                            <li>#혼자서도 잘 먹어요</li>
                        </ul>
                    </div>
                </div>
            </div>
 <script>
	$(document).ready(function(){
		$(window).resize(function(){                
            let ww = window.outerWidth
            if(ww <= 800){                    
            $('.img-box').addClass('mt-4');
            }
        });
	});
 </script>
</section>