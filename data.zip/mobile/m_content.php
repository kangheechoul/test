<?php 
        
        $content_code = "company";
        
        $company_sql = "select * from {$g5['g5_shop_default_table']}";
        $default = sql_fetch($company_sql);

    ?>
    <footer>
<div class="text-center">
    <p class="s-title">MIMICOOK APP</p>
    <a class="app-download" href="javascript:location.href='<?php echo $config['cf_app_url']?>';"><img src="<?= G5_URL?>/img/playstore.png" alt="playstore"></a>
    <ul class="d-flex justify-content-center">
      <li><a href="<?= G5_MOBILE_URL."/company.php"?>">회사소개</a></li>
            <li><a href="<?= G5_MOBILE_URL."/company.php"?>">서비스이용약관</a></li>
            <li><a href="<?= G5_MOBILE_URL."/company.php"?>">개인정보처리방침</a></li>
    </ul>
    <div class="d-flex justify-content-center">
        <p class="mr-3">Tel <span class="point"><?= $default['de_admin_company_tel']; ?></span></p>
        <p>Email <span class="point"><?= $default['de_admin_info_email']?></span></p>
    </div>
    <div>
        <p>
            <span>법인명(상호) : <?= $default['de_admin_company_name']?> |</span>
            <span>사업자등록번호 : <?= $default['de_admin_company_saupja_no']?> </span>            
        </p>
        <p>
            <span>통신판매업 신고 번호 : <?= $default['de_admin_tongsin_no']?></span>
        </p>
        <p>
            <span>주소 : <?= $default['de_admin_company_addr']?> |</span>
            <span>대표 : <?= $default['de_admin_company_owner']?></span>
        </p>
    </div>
    <span class="copy-right">© MIMICOOK. ALL RIGHTS RESERVED</span>
</div>
</footer>

<!--      <footer class = "footer">
    	<div id = "info">
        <?= $company_row['co_content']?>
        </div>
        <script>

        $('.app-download > img').attr('src', '<?= G5_URL."/img/playstore.png"?>');
        
 		$('#info > ul').css('padding' , '7px');
		
		var len = $('#info > ul > li').length;

		for(var i = 0; i < len; i++)
		{
			$('#info > ul > li').eq(i).css('margin-bottom', '10px');
		} 
 */
        </script>
	</footer>
	-->