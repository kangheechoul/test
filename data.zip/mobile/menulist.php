<?php 
include_once('./_common.php');
include_once (G5_MOBILE_PATH.'/includepage/menu_head.php');

include_once('./_head.php');

unset($_SESSION['ss_is_mobile']);

    $cate = $_REQUEST['ca_id'];
    
    $m_cate_sql = "select * from {$g5['g5_shop_category_table']} where ca_id like '{$cate}%' and length(ca_id) = 4";
    
    $m_cate_res = sql_query($m_cate_sql);
    
    
?>
<style>
nav{scroll-behavior: smooth;}
</style>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/lozad/dist/lozad.min.js"></script>
<body>
<div class="wrap">
<input type= "hidden" id="back_num" value = "0">
   <section class="sec-2">
            <nav id="cate_scroll">
                <div class="nav nav-tabs" id="nav-tab" role="tablist">
                
               	<?php 
               	for($i = 0;$m_cate_row = sql_fetch_array($m_cate_res);$i++)
               	{
               	    $m_list_cate[$i] = $m_cate_row['ca_id'];
                ?>
                <a class="nav-link<?php if($i== 0)echo " active";?>" id="nav-<?=$i+1?>-tab" data-bs-toggle="tab" href="javascript:self(<?= $i+1?>)" role="tab" aria-controls="nav-<?=$i+1?>" aria-selected="<?php if($i==0)echo"true";else echo "false";?>"><?= $m_cate_row['ca_name']?></a>
                <?php               	    
               	}
               	?>
                </div>
            </nav>
         
            <script>

        		
            
				var auto = 0;
				var len = $('#nav-tab > a').length;
				
				for(var i = 0; i < len; i++)
				{
					var width = $('#nav-tab > a').eq(i).css('width').replace('px','').replace(' ', '');
					auto += Number(width);
				}
            
				$('#nav-tab').css('width', auto+30);
            
                function self(num)
                {
    				var a_len = $('#nav-tab > a').length;

    				var width = ($('#nav-tab').css('width').replace("px","") - $('#cate_scroll').css('width').replace("px", "")) / a_len;

					var tmp = 0;
    				
                     for(var i = 1; i <= a_len ; i++)
                    {
    					if(i != num)
    					{
    						$('#nav-'+i+'-tab').attr('class', 'nav-link');
    						$('#nav-'+i).attr('class', 'tab-pane fade');
    						$('#nav-'+i).attr('aria-selected', 'false');
    						if(i < num)
    						{
    							tmp += Number($('#nav-'+i+'-tab').css("width").replace("px",""));
        					}
    					}
                    }
    				$('#nav-'+num+'-tab').attr('class', 'nav-link active');
    				$('#nav-'+num).attr('class', 'tab-pane fade show active');
    				$('#nav-'+num).attr('aria-selected', 'true');
    				$('#back_num').val(num);

    				$('#cate_scroll').scrollLeft(tmp-width*2);
                }

				function menu_go(it_id)
				{
					location.href = "<?php echo G5_MOBILE_URL."/menu.php?it_id="?>"+it_id+"&ca_id=<?php echo $cate?>&tab="+$('#back_num').val();
				}

				<?php
		        		if(isset($_GET['tab']))
		        		{
		        		   echo "window.onload=function(){self(".($_GET['tab']).")}
                                ";
		        		}
		        		    
		        		    ?>
                </script>

            <div class="container min-h-f" >
            
            <?php 
            if($i == 0)
            {
                ?>
                	<i class="material-icons" style="font-size: 50px; text-align:center; width:100%; position:absolute; top:50%;">storefront</i>
               	    <p style= "text-align:center;width:100%;margin:0 auto; position:absolute; top:60%;">자료가 없습니다</p>
               	    <?php 
               	}
            ?>
                <div class="tab-content" id="nav-tabContent">
                
                	<?php 
                	for($j = 0; $j < count($m_list_cate); $j++)
                	{
                	    $m_cate = $m_list_cate[$j];
                	    $m_list_sql = "select * from {$g5['g5_shop_item_table']} where ca_id = '{$m_cate}' or ca_id2 = '{$m_cate}' or ca_id3 = '{$m_cate}'";
                	    
                	    $m_list_res = sql_query($m_list_sql);
                	    ?>
                	    <div class="tab-pane fade<?php if($_GET['tab'] == $j) echo " show active"; else if($j==0) echo " show active"?>" id="nav-<?= $j+1?>" role="tabpanel" aria-labelledby="nav-<?= $j+1?>-tab">
                	    	<ul class="row row-col-2">
                	    <?php 
                	    for($k = 0; $m_list_row = sql_fetch_array($m_list_res); $k++)
                	    {
                	        ?>
                    	        <li class="col-6 menu">
                                    <a href="javascript:menu_go(<?php echo $m_list_row['it_id']?>)">
                                        <div class="img_box">
                                             <img data-src="<?= G5_DATA_URL."/item/".$m_list_row['it_img1']?>" alt="메뉴이미지" class="lozad" />
                                        </div>
                                        <h4><?= $m_list_row['it_name']?></h4>
                                        <ul class="w-full" style="overflow:hidden;">
                                            <li><span>- 조리 : <?= $m_list_row['it_cook_time']?>분 , <?= $m_list_row['it_inbun']?>인분, <!-- 난이도 :<?php for($k = 0; $k < $m_list_row['it_level'];$k++) echo '<i class="material-icons">star</i>'; ?> --></span></li>
                                        </ul>
										<h5 class="price"><?= number_format($m_list_row['it_price'])?> 원</h5>
                                    </a>
                                </li>
                	        <?php 
                	    }
                        if($k == 0)
                        {
                            ?>
                            	<i class="material-icons" style="font-size: 50px; text-align:center; width:100%;">storefront</i>
			               	    <p style="width:100%; text-align:center;">자료가 없습니다</p>
                            <?php    
                        }
                	    ?>
                	    	</ul>
                	    </div>
                	    <?php 
                	}
                	?>
                </div>
            </div>
               <?php 
            if(isset($_REQUEST['choice']))
            {
                $choice = $_REQUEST['choice'] +1;
                echo "
                <script>
                self({$choice});
                $('#nav-{$choice}-tab').focus();
                </script>";
                
            }
            
            ?>
        </section>
        <?php include_once G5_MOBILE_PATH.'/includepage/include_menu.php';?>
		</div>
		<script>
		const observer = lozad();
    	observer.observe();

		</script>
        </body>