<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

if (G5_IS_MOBILE) {
    include_once(G5_THEME_MOBILE_PATH.'/head.php');
    return;
}
include_once(G5_PATH.'/head.sub.php');


// if(G5_COMMUNITY_USE === false) {
    // define('G5_IS_COMMUNITY_PAGE', true);
    // include_once(G5_THEME_SHOP_PATH.'/shop.head.php');
    // return;
// }

include_once(G5_LIB_PATH.'/latest.lib.php');
include_once(G5_LIB_PATH.'/outlogin.lib.php');
include_once(G5_LIB_PATH.'/poll.lib.php');
include_once(G5_LIB_PATH.'/visit.lib.php');
include_once(G5_LIB_PATH.'/connect.lib.php');
include_once(G5_LIB_PATH.'/popular.lib.php');

/* echo '<link rel="stylesheet" href="'.G5_URL.'/css/header-1.css">'.PHP_EOL; */

$url = strip_tags($_GET['url']);
// url 체크
check_url_host($url);

$login_url        = login_url($url);
$login_action_url = G5_HTTPS_BBS_URL."/login_check.php";

$is_login = '<li class="log-in" id="log-in"><a href="javascript:" class="log-in menu-icon">LOGIN</a></li>';
$s_login = '<div class="log-in"><a href="javascript:$(\'.limiter\').show()">LOGIN</a></div>';
if ($is_member) {
	$is_login = '<li class="log-in"><a href="'.G5_BBS_URL.'/logout.php" class="log-in menu-icon">LOGOUT</a></li>';
	$s_login = '<div class="log-in"><a href="'.G5_BBS_URL.'/logout.php">LOGOUT</a></div>';
}

$self_url = G5_BBS_URL."/login.php";

//새창을 사용한다면
if( G5_SOCIAL_USE_POPUP ) {
    $self_url = G5_SOCIAL_LOGIN_URL.'/popup.php';
}

function get_mshop_category($ca_id, $len)
{
    global $g5;

    $sql = " select ca_id, ca_name from {$g5['g5_shop_category_table']}
                where ca_use = '1' ";
    if($ca_id)
        $sql .= " and ca_id like '$ca_id%' ";
    $sql .= " and length(ca_id) = '$len' order by ca_order, ca_id ";

    return $sql;
    
}

$mshop_categories = get_shop_category_array('10','4');
?>
<link rel="canonical" href="https://mimicook.kr/index.php">
<link rel="shortcut icon" href="https://mimicook.kr/mimicook.ico">
<style>
.sub-menu-box{
display:none;
}
</style>
<?php if(defined('_INDEX_')) { // index에서만 실행
        include G5_BBS_PATH.'/newwin.inc.php'; // 팝업레이어
		$mAgent = array("iPhone","iPod","Android","Blackberry", 
			"Opera Mini", "Windows ce", "Nokia", "sony" );
		$chkMobile = false;
		for($i=0; $i<sizeof($mAgent); $i++){
			if(stripos( $_SERVER['HTTP_USER_AGENT'], $mAgent[$i] )){
				$chkMobile = true;
				break;
			}
		}

 } ?>
    <header>
	<!--
		<div class="header-wrap">
			<div class="top-head">
			<a href="<?php echo G5_URL; ?>" class="logo"><img src="<?php echo G5_URL; ?>/img/mimicook-logo.png" alt="logo"></a>
			<a href="<?php echo G5_BBS_URL; ?>/board.php?bo_table=notice" class="head_small">고객센터</a>
				<!-- <ul class="menu-icon-wrap">
					 <?php echo $is_login; ?>
					<li></li>
				</ul> -->
			<!--</div>
		</div>
		-->
		<nav>
			<div class="logo-wrap"><a class="logo" href="<?php echo G5_URL; ?>"><img src="<?php echo G5_URL; ?>/img/mimicook-logo.png" alt="logo"></a></div>
					<div class="menu-wrap">
						<ul class="d-flex justify-content-between">
							<li>
								<a href="<?php echo G5_EX_URL ?>/brand_info.php">브랜드</a>
							</li>
						<?php
							$i = 0;
							foreach($mshop_categories as $cate1){
							if( empty($cate1) ) continue;
							$mshop_ca_row = $cate1['text'];
						?>
							<li>
								<a href="<?php echo $mshop_ca_row['url']; ?>"><!-- <i class="material-icons menu-icon">menu</i> -->메뉴</a>
								<?php 
								
									$li_content = '<div class="sub-menu-box">';
									$j=0;

									foreach($cate1 as $key=>$cate2){
										if( empty($cate2) || $key === 'text' ) continue;
										
										$mshop_ca_row2 = $cate2['text'];
										if($j == 0)
											$li_content .= '<ul class="sub_cate sub_cate1">';
										$li_content .= '<li class="cate_li_2">';
										$li_content .= '<a href="'.$mshop_ca_row2['url'].'">'.get_text($mshop_ca_row2['ca_name']).'</a>';
										$li_content .= '</li>';
										$j++;
									}

									if($j > 0)
										$li_content .= '</ul>';
									$li_content .= '</div>';

									echo $li_content;
								?>
							</li>
						<?php }?>
							<li>
								<a href="<?php echo G5_EX_URL ?>/interior.php">인테리어</a>
							</li>
							
							<!-- 
							<li>
								<a href="<?php echo G5_BBS_URL ?>/board.php?bo_table=notice">고객센터</a>
								<div class="sub-menu-box">
									<ul class="sub_cate sub_cate1">
										<li class="cate_li_2"><a href="<?php echo G5_BBS_URL ?>/board.php?bo_table=notice">공지사항</a></li>
										<li class="cate_li_2"><a href="<?php echo G5_BBS_URL ?>/board.php?bo_table=event">이벤트</a></li>
										<!-- <li class="cate_li_2"><a href="<?php echo G5_BBS_URL ?>/faq.php?bo_table=eee">자주하는질문</a></li> 
									</ul>
								</div>							
							</li>
							 -->
							 <li>
								<a href="<?php echo G5_EX_URL ?>/company.php">회사 소개</a>
							</li>
							
							<li>
								<a href="<?php echo G5_EX_URL ?>/frenchise.php">창업안내</a>
							</li>
							
							<li>
								<a href="<?php echo G5_EX_URL ?>/store.php">매장안내</a>
							</li>
						</ul>
						<a class="search" id="h-search" href="javascript:;"><i class="material-icons">search</i></a>
					</div>
					
					
					<!-- 공통 검색란 -->
					<div class="search-wrap">
						<label>
							<input type="text" id = "search_text" name = "search_text" onkeyup = "search_enter()" value = "">
							<button id = "search_btn" onclick = "search()"><i class="material-icons">search</i></button>
						</label>
					</div>

					<script>

					function search_enter()
					{
						if(window.event.keyCode == "13")
						{
							search();
						}
					}

						
					function search()
					{
						location.href = "<?= G5_SHOP_URL."/search.php?q="?>"+ $('#search_text').val();
					}

					</script>
		</nav>
    </header>

    <div class="top">
        <i class="xi-caret-up-min"></i>
    </div>
	
	<script>
		$(document).ready(function(){
    
    $( '.top' ).click( function() {
	$( 'html, body' ).animate( { scrollTop : 0 }, 400 );
		return false;
	} );
    
	$('#h-search').click(function(){
		$('.search-wrap').stop().slideToggle(100);
	});
    
	});
	</script>
	<!-- <div class="containerd">
		<div class="con_bin_top"></div> -->
