<?php
include_once('./_common.php');

define('_INDEX_', true);
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

include_once('./head.php');

 if(G5_IS_MOBILE)
{
    header("location:".G5_MOBILE_URL);
}
echo '<link rel="stylesheet" href="'.G5_URL.'/css/style1.css">'.PHP_EOL;
/* echo '<link rel="stylesheet" href="'.G5_URL.'/css/index.css">'.PHP_EOL; */
echo '<link rel="stylesheet" href="'.G5_URL.'/css/popUp.css">'.PHP_EOL;
?>
<div id = "pop"></div>

    <div class="wrap">
	
        <!-- 쇼핑몰 배너 시작 { -->
		<?php echo display_banner('메인'); ?>
		
		<!-- } 쇼핑몰 배너 끝 -->
		
		<section>
            <!-- container-1 -->
            <div class="container">
            
            
                <div class="row">
                    <div class="col-lg-4  col-md-4 d-flex flex-column justify-content-center">
                        <p class="s-title">지금 바로 요리, 시작하세요</p>
                        <h2 class="title mb-4">COOK, NOW</h2>
                        <p class="mb-2">미미쿡은 50여 가지 한식, 중식, 양식 등의 밀키트 제품과
                            20여 가지의 냉동제품을 갖춘 오프라인 밀키트 매장입니다.
                        </p>
                        <p>요리에 필요한 식재료와 자체 개발 소스,
                            간단한 조리법을 제공함으로써 누구나 언제, 어디서든
                            빠르고 쉽게 맛있는 요리를 완성할 수 있습니다.
                        </p>
                    </div>
                    <div class="col-lg-8 col-md-8 img-box"><img src="./img/slogun.jpg" alt=""></div>
                </div>
            </div>
            <!-- container-2 -->
            <div class="container hover">
                <h2 class="title text-center">미미쿡 감성</h2>
                <p class="s-title text-center under-line">미미쿡과 함께 감성적 분위기를 내보세요</p>
                <div class="row mt-4">
                    <div class="col-lg-4 col-md-4 col-sm-12">
                        <img src="<?= G5_URL?>/img/item-1.jpg" alt="">
                        <ul>
                            <li>#미미쿡</li>
                            <li>#캠핑장 요리</li>
                            <li>#간편 요리</li>
                        </ul>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-12">
                        <img src="<?= G5_URL?>/img/item-2.jpg" alt="">
                        <ul>
                            <li>#미미쿡</li>
                            <li>#홈파티</li>
                            <li>#집콕 요리</li>
                        </ul>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-12">
                        <img src="<?= G5_URL?>/img/item-3.jpg" alt="">
                        <ul>
                            <li>#미미쿡</li>
                            <li>#외식하기 싫은 날</li>
                            <li>#혼자서도 잘 먹어요</li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>
		
		
		
		
       
	</div>
       
<script>
		
		function setCookie(name, value, expiredays) {
			var days = expiredays;
			if (days) {
				var date = new Date();
				date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
				var expires = "; expires=" + date.toGMTString();
			} else {
				var expires = "";
			}
			document.cookie = name + "=" + value + expires + "; path=/";
		}

		function GetCookie(name) {
			var value = null,
				search = name + "=";
			if (document.cookie.length > 0) {
				var offset = document.cookie.indexOf(search);
				if (offset != -1) {
					offset += search.length;
					var end = document.cookie.indexOf(";", offset);
					if (end == -1) end = document.cookie.length;
					value = unescape(document.cookie.substring(offset, end));
				}
			}
			return value;
		}
		
</script>
<script>
if (navigator.geolocation) { // GPS를 지원하면
    navigator.geolocation.getCurrentPosition(function(position) {
		var latitude = position.coords.latitude;
		var longitude = position.coords.longitude;
		
		$.ajax({
			url : "./ajax.geolocation.php",
			type: "post",
			data: "latitude=" + latitude + "&longitude=" + longitude,
			success:function(data) {
				document.getElementById('pop').innerHTML = data;
						
				$(".btnClose").each(function(index) {
					$(this).on("click", function() {
						if ($(this).parent().find("input[type=checkbox]").is(":checked")) { // 체크박스가 선택되어 있다면,
							setCookie("close_" + $(this).parent().parent().find("input[type=hidden][class=po_id]").val(), "yes", 1); // close cookie를 yes 값으로 저장합니다.
							// cookie 이름 : close
							// cookie 값 : yes
						}
						$(this).parent().parent().hide();
					});
				});
				
				$(".po_id").each(function(index, item) {
					if (GetCookie("close_" + $(item).val()) == "yes") { // 화면 로딩 시에 close cookie 값이 yes이면,
						$(item).parent().hide(); // 팝업을 닫습니다.
					} else {
						$(item).parent().show(); // 아니라면 팝업을 열어줍니다.
						//$(".popup").addClass("active");
					}
				});

			}
		});
		
    }, function(error) {
      console.error(error);
    }, {
      enableHighAccuracy: false,
      maximumAge: 0,
      timeout: Infinity
    });
} else {
	alert('GPS를 지원하지 않습니다');
}

</script>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js" integrity="sha384-q2kxQ16AaE6UbzuKqyBE9/u/KzioAlnx2maXQHiDX9d4/zp8Ok3f+M7DPm+Ib6IU" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.min.js" integrity="sha384-pQQkAEnwaBkjpqZ8RU1fF1AKtTcHJwFl3pblpTlHXybJjHpMYo79HY3hIi4NKxyj" crossorigin="anonymous"></script>
<?php include_once('./tail.php'); ?>