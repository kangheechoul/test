<?php
$menu["menu600"] = array (
    array('600000', '지점관리', G5_ADMIN_URL.'/shop_admin/placelist.php', 'place'),
    array('600100', '지점관리', G5_ADMIN_URL.'/shop_admin/placelist.php', 'place',1),
);
?>