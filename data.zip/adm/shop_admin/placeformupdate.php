<?php
$sub_menu = '600100';
include_once('./_common.php');

print_r($_REQUEST);


auth_check($auth[$sub_menu], "w");

check_admin_token();

if(!$_POST['mb_id'])
    alert('지점아이디를 입력해 주십시오.');

if(!$_POST['pl_name'])
    alert('지점명을 입력해 주십시오.');

if(!$_POST['pl_addr1'])
    alert('지점주소를 입력해 주십시오.');

if(!$_POST['pl_boss'])
    alert('지점대표를 입력해 주십시오.');

if(!$_POST['pl_hp'])
    alert('지점전화를 입력해 주십시오.');

    
    // 파일정보
    if($w == "u") {
        $sql = " select pl_img1, pl_img2, pl_img3, pl_img4, pl_img5
                from {$g5['place_table']}
                where pl_id = '$pl_id' ";
        $file = sql_fetch($sql);
        
        $pl_img1    = $file['pl_img1'];
        $pl_img2    = $file['pl_img2'];
        $pl_img3    = $file['pl_img3'];
        $pl_img4    = $file['pl_img4'];
        $pl_img5    = $file['pl_img5'];
    }
    
    $pl_img_dir = G5_DATA_PATH.'/place';
    
    if ($pl_img1_del) {
        $file_img1 = $pl_img_dir.'/'.$pl_img1;
        @unlink($file_img1);
        delete_item_thumbnail(dirname($file_img1), basename($file_img1));
        $pl_img1 = '';
    }
    if ($pl_img2_del) {
        $file_img2 = $pl_img_dir.'/'.$pl_img2;
        @unlink($file_img2);
        delete_item_thumbnail(dirname($file_img2), basename($file_img2));
        $pl_img2 = '';
    }
    if ($pl_img3_del) {
        $file_img3 = $pl_img_dir.'/'.$pl_img3;
        @unlink($file_img3);
        delete_item_thumbnail(dirname($file_img3), basename($file_img3));
        $pl_img3 = '';
    }
    if ($pl_img4_del) {
        $file_img4 = $pl_img_dir.'/'.$pl_img4;
        @unlink($file_img4);
        delete_item_thumbnail(dirname($file_img4), basename($file_img4));
        $pl_img4 = '';
    }
    
    if ($pl_img5_del) {
        $file_img5 = $pl_img_dir.'/'.$pl_img5;
        @unlink($file_img5);
        delete_item_thumbnail(dirname($file_img5), basename($file_img5));
        $pl_img5 = '';
    }
    
    if ($_FILES['pl_img1']['name']) {
        if($w == 'u' && $pl_img1) {
            $file_img1 = $pl_img_dir.'/'.$pl_img1;
            @unlink($file_img1);
            delete_item_thumbnail(dirname($file_img1), basename($file_img1));
        }
        $pl_img1 = pl_img_upload($_FILES['pl_img1']['tmp_name'], $_FILES['pl_img1']['name'], $pl_img_dir.'/'.$pl_id);
    }
    
    if ($_FILES['pl_img2']['name']) {
        if($w == 'u' && $pl_img2) {
            $file_img2 = $pl_img_dir.'/'.$pl_img2;
            @unlink($file_img2);
            delete_item_thumbnail(dirname($file_img2), basename($file_img2));
        }
        $pl_img2 = pl_img_upload($_FILES['pl_img2']['tmp_name'], $_FILES['pl_img2']['name'], $pl_img_dir.'/'.$pl_id);
    }
    if ($_FILES['pl_img3']['name']) {
        if($w == 'u' && $pl_img3) {
            $file_img3 = $pl_img_dir.'/'.$pl_img3;
            @unlink($file_img3);
            delete_item_thumbnail(dirname($file_img3), basename($file_img3));
        }
        $pl_img3 = pl_img_upload($_FILES['pl_img3']['tmp_name'], $_FILES['pl_img3']['name'], $pl_img_dir.'/'.$pl_id);
    }
    if ($_FILES['pl_img4']['name']) {
        if($w == 'u' && $pl_img4) {
            $file_img4 = $pl_img_dir.'/'.$pl_img4;
            @unlink($file_img4);
            delete_item_thumbnail(dirname($file_img4), basename($file_img4));
        }                                        
        $pl_img4 = pl_img_upload($_FILES['pl_img4']['tmp_name'], $_FILES['pl_img4']['name'], $pl_img_dir.'/'.$pl_id);
    }
    if ($_FILES['pl_img5']['name']) {
        if($w == 'u' && $pl_img5) {
            $file_img5 = $pl_img_dir.'/'.$pl_img5;
            @unlink($file_img5);
            delete_item_thumbnail(dirname($file_img5), basename($file_img5));
        }
        $pl_img5 = pl_img_upload($_FILES['pl_img5']['tmp_name'], $_FILES['pl_img5']['name'], $pl_img_dir.'/'.$pl_id);
    }
    
    

$sql = "select mb_id from {$g5['member_table']} where mb_id = '{$_POST['mb_id']}'";
$row = sql_fetch($sql);
if ($row['mb_id'] != $_POST['mb_id'])
	alert('존재하지 않는 아이디입니다.'.$row['mb_id']);

$week = "";

for($i = 0; $i < count($_POST['pl_week']); $i++) {
	if($week != "") $week .= ",";
	$week .= $_POST['pl_week'][$i];
}

$pl_time = $_POST['pl_time'].":".$_POST['pl_time_m'];
$pl_expire_time = $_POST['pl_expire_time'].":".$_POST['pl_expire_time_m'];

if ($_POST['w'] == "") {

  
    
	$sql = "insert {$g5['place_table']} set 
				mb_id = '{$_POST['mb_id']}',
				pl_name = '{$_POST['pl_name']}', 
				pl_zip = '{$_POST['pl_zip']}', 
				pl_addr1 = '{$_POST['pl_addr1']}', 
				pl_addr2 = '{$_POST['pl_addr2']}', 
				pl_addr3 = '{$_POST['pl_addr3']}', 
				pl_addr_jibeon = '{$_POST['pl_addr_jibeon']}', 
				pl_boss = '{$_POST['pl_boss']}', 
				pl_hp = '{$_POST['pl_hp']}',
				pl_time = '{$pl_time}',
				pl_expire_time = '{$pl_expire_time}',
				pl_period = '{$_POST['pl_period']}',
				pl_week = '$week',
				pl_latitude = '{$_POST['pl_latitude']}',
				pl_longitude = '{$_POST['pl_longitude']}',
                pl_content = '{$_POST['pl_content']}',
                pl_img1 = '{$pl_img1}',
                pl_img2 = '{$pl_img2}',
                pl_img3 = '{$pl_img3}',
                pl_img4 = '{$pl_img4}',
                pl_img5 = '{$pl_img5}'";

	$result = sql_query($sql, false);
	
	$sql = "select pl_id from {$g5['place_table']} order by pl_id desc limit 1";
	$row = sql_fetch($sql);
	$pl_id = $row['pl_id'];
} else {
	
	$sql = "update {$g5['place_table']} set 
				mb_id = '{$_POST['mb_id']}',
				pl_name = '{$_POST['pl_name']}', 
				pl_zip = '{$_POST['pl_zip']}', 
				pl_addr1 = '{$_POST['pl_addr1']}', 
				pl_addr2 = '{$_POST['pl_addr2']}', 
				pl_addr3 = '{$_POST['pl_addr3']}', 
				pl_addr_jibeon = '{$_POST['pl_addr_jibeon']}', 
				pl_boss = '{$_POST['pl_boss']}', 
				pl_hp = '{$_POST['pl_hp']}',
				pl_time = '{$pl_time}',
				pl_expire_time = '{$pl_expire_time}',
				pl_period = '{$_POST['pl_period']}',
				pl_week = '$week',
				pl_latitude = '{$_POST['pl_latitude']}',
				pl_longitude = '{$_POST['pl_longitude']}',
                pl_content = '{$_POST['pl_content']}',
                pl_img1 = '{$pl_img1}',
                pl_img2 = '{$pl_img2}',
                pl_img3 = '{$pl_img3}',
                pl_img4 = '{$pl_img4}',
                pl_img5 = '{$pl_img5}'
			where pl_id = '{$_POST['pl_id']}'";
	$result = sql_query($sql, false);
	
	$sql = "update {$g5['popup_table']} set 
				pl_name = '{$_POST['pl_name']}'
			where pl_id = '{$_POST['pl_id']}'";
	
	sql_query($sql);
	
	$pl_id = $_POST['pl_id'];
}
if (!$result)
	alert('오류발생');
else
	goto_url('./placeform.php?w=u&pl_id='.$pl_id);
	

?>