<?php
$sub_menu = '600100';
include_once('./_common.php');

auth_check($auth[$sub_menu], "r");

$g5['title'] = '지점현황';
include_once (G5_ADMIN_PATH.'/admin.head.php');

$sql = "select * from {$g5['place_table']} order by pl_id desc";
$result = sql_query($sql);


$colspan = 6;
?>
<div class="local_ov">
    <span class="btn_ov01"><span class="ov_txt">전체 </span><span class="ov_num"> <?php echo number_format($total_count) ?> 개</span></span>
</div>
<form name="fsearch" id="fsearch" class="local_sch01 local_sch" method="get">

<select name="sfl" title="검색대상">
    <option value="pl_name"<?php echo get_selected($_GET['sfl'], "pl_name"); ?>>지점명</option>
    <option value="pl_boss"<?php echo get_selected($_GET['sfl'], "pl_boss"); ?>>지점대표</option>
    <option value="pl_addr"<?php echo get_selected($_GET['sfl'], "pl_addr"); ?>>지점주소</option>
    <option value="pl_hp"<?php echo get_selected($_GET['sfl'], "pl_hp"); ?>>지점전화</option>
</select>
<label for="stx" class="sound_only">검색어<strong class="sound_only"> 필수</strong></label>
<input type="text" name="stx" value="<?php echo $stx ?>" id="stx" required class="required frm_input">
<input type="submit" class="btn_submit" value="검색">
</form>



<form name="fcouponlist" id="fcouponlist" method="post" action="./placelist_delete.php" >
<input type="hidden" name="sst" value="<?php echo $sst; ?>">
<input type="hidden" name="sod" value="<?php echo $sod; ?>">
<input type="hidden" name="sfl" value="<?php echo $sfl; ?>">
<input type="hidden" name="stx" value="<?php echo $stx; ?>">
<input type="hidden" name="page" value="<?php echo $page; ?>">
<input type="hidden" name="token" value="">

<div class="tbl_head01 tbl_wrap">
    <table>
    <caption><?php echo $g5['title']; ?></caption>
    <thead>
    <tr>
        <th scope="col">
            <label for="chkall" class="sound_only">지점 전체</label>
            <input type="checkbox" name="chkall" value="1" id="chkall" onclick="check_all(this.form)">
        </th>
        <th scope="col">지점아이디</th>
        <th scope="col">지점명</th>
        <th scope="col">지점주소</th>
        <th scope="col">지점대표</th>
        <th scope="col">지점전화</th>
        <th scope="col">영업시간</th>
        <th scope="col">휴무일</th>
        <th scope="col">팝업관리</th>
        <th scope="col">매출현황</th>
        <th scope="col">주문관리</th>
        <th scope="col">수정</th>
    </tr>
    </thead>
    <tbody>
    <?php
    for ($i=0; $row=sql_fetch_array($result); $i++) {
        $bg = 'bg'.($i%2);
    ?>

    <tr class="<?php echo $bg; ?>">
        <td class="td_chk">
            <input type="hidden" id="pl_id_<?php echo $i; ?>" name="pl_id[<?php echo $i; ?>]" value="<?php echo $row['pl_id']; ?>">
            <input type="checkbox" id="chk_<?php echo $i; ?>" name="chk[]" value="<?php echo $i; ?>" title="내역선택">
        </td>
        <td class="td_id"><?php echo $row['mb_id']; ?></td>
        <td class="td_name"><?php echo $row['pl_name'] ?></td>
        <td class="td_addr"><?php echo $row['pl_addr1'] ?> <?php echo $row['pl_addr2'] ?></td>
        <td class="td_boss"><?php echo $row['pl_boss'] ?></td>
        <td class="td_hp"><?php echo $row['pl_hp'] ?></td>
        <td class="td_time"><?php echo $row['pl_time'] ?>~<?php echo $row['pl_expire_time'] ?></td>
        <td class="td_week"><?php echo $row['pl_week'] ?></td>
        <td class="td_pop"><a class="btn btn_02" href="<?php echo G5_URL ?>/place/popuplist.php?mb_id=<?php echo $row['mb_id'] ?>&pl_id=<?php echo $row['pl_id']?>">팝업관리</a></td>
        <td class="td_pop"><a class="btn btn_02" href="<?php echo G5_URL ?>/place/sale1.php?mb_id=<?php echo $row['mb_id'] ?>&pl_id=<?php echo $row['pl_id']?>">매출현황</a></td>
        <td class="td_pop"><a class="btn btn_02" href="<?php echo G5_URL ?>/place/orderlist.php?mb_id=<?php echo $row['mb_id'] ?>&pl_id=<?php echo $row['pl_id']?>">주문관리</a></td>
		<td class="td_update"><a class="btn btn_02" href="./placeform.php?w=u&pl_id=<?php echo $row['pl_id']?>">수정</a></td>
    </tr>

    <?php
    }

    if ($i == 0)
        echo '<tr><td colspan="'.$colspan.'" class="empty_table">자료가 없습니다.</td></tr>';
    ?>
    </tbody>
    </table>
</div>
<div class="btn_fixed_top">
     <input type="submit" name="act_button" value="선택삭제" onclick="document.pressed=this.value" class="btn btn_02">
   <a href="./placeform.php" id="coupon_add" class="btn btn_01">지점 추가</a> 
</div>

</form>

<?php
include_once (G5_ADMIN_PATH.'/admin.tail.php');
?>
