<?php
$sub_menu = '600100';
include_once('./_common.php');

auth_check($auth[$sub_menu], "w");

$g5['title'] = '지점관리';

if ($w == 'u') {
    $html_title = '지점 수정';

    $sql = " select * from {$g5['place_table']} where pl_id = '$pl_id' ";
    $pl = sql_fetch($sql);
    if (!$pl['pl_id']) alert('등록된 자료가 없습니다.');
}
else
{
    $html_title = '지점 입력';
}

$pl_time_tmp = explode(':', $pl['pl_time']);

$pl_time_h = $pl_time_tmp[0];
$pl_time_i = $pl_time_tmp[1];

$pl_expire_time_tmp = explode(':', $pl['pl_expire_time']);

$pl_expire_time_h = $pl_expire_time_tmp[0];
$pl_expire_time_i = $pl_expire_time_tmp[1];


include_once (G5_ADMIN_PATH.'/admin.head.php');

//add_javascript(G5_POSTCODE_JS, 0);    //다음 주소 js
?>
<script src="http://dmaps.daum.net/map_js_init/postcode.v2.js"></script>
<form name="fplaceform" action="./placeformupdate.php" enctype="MULTIPART/FORM-DATA" method="post" onsubmit="return form_check(this);">
<input type="hidden" name="w" value="<?php echo $w; ?>">
<input type="hidden" name="cp_id" value="<?php echo $cp_id; ?>">
<input type="hidden" name="sst" value="<?php echo $sst; ?>">
<input type="hidden" name="sod" value="<?php echo $sod; ?>">
<input type="hidden" name="sfl" value="<?php echo $sfl; ?>">
<input type="hidden" name="stx" value="<?php echo $stx; ?>">
<input type="hidden" name="page" value="<?php echo $page;?>">
<input type="hidden" name="pl_id" value="<?php echo $pl_id; ?>">

<div class="tbl_frm01 tbl_wrap">
    <table>
    <caption><?php echo $g5['title']; ?></caption>
    <colgroup>
        <col class="grid_4">
        <col>
    </colgroup>
    <tbody>
	<tr>
        <th scope="row"><label for="mb_id">지점아이디</label></th>
        <td>
            <input type="text" name="mb_id" value="<?php echo $pl['mb_id']; ?>" id="mb_id" required class="required frm_input" size="50">
        </td>
    </tr>
    <tr>
        <th scope="row"><label for="pl_name">지점명</label></th>
        <td>
            <input type="text" name="pl_name" value="<?php echo $pl['pl_name']; ?>" id="pl_name" required class="required frm_input" size="50">
        </td>
    </tr>
	<tr>
        <th scope="row"><label for="pl_boss">지점대표</label></th>
        <td>
            <input type="text" name="pl_boss" value="<?php echo $pl['pl_boss']; ?>" id="pl_boss" required class="required frm_input" size="50">
        </td>
    </tr>
	<tr>
        <th scope="row"><label for="pl_hp">지점전화</label></th>
        <td>
            <input type="text" name="pl_hp" value="<?php echo $pl['pl_hp']; ?>" id="pl_hp" required class="required frm_input" size="50">
        </td>
    </tr>
	<tr>
        <th scope="row"><label for="pl_hp">영업시간</label></th>
        <td>
            <select name="pl_time">
			<?php for($i = 1; $i <= 24; $i++) {
			    if($i < 10) $i = "0".$i;
			    ?>
				<option value="<?php echo $i ?>" <?php if ($i == $pl_time_h) echo "selected=selected"; ?>><?php echo $i ?></option>
			<?php } ?>
			</select> 
			<select name ="pl_time_m">
			<?php 
			for($i = 0; $i <= 50; $i+= 10)
			{			    
			    if($i < 10) $i = "0".$i;
                ?>
                <option value = "<?= $i?>" <?php if ($i == $pl_time_i) echo "selected=selected";?>><?= $i?></option>
                <?php 			    
			}
			?>
			</select>
			~ 
			<select name="pl_expire_time">
			<?php for($i = 1; $i <= 24; $i++) { 
			    if($i < 10) $i = "0".$i;
			    ?>
				<option value="<?php echo $i ?>" <?php if ($i == $pl_expire_time_h) echo "selected=selected"; ?>><?php echo $i ?></option>
			<?php } ?>
			</select>
			<select name ="pl_expire_time_m">
			<?php 
			for($i = 0; $i <= 50; $i+= 10)
			{
			    if($i < 10) $i = "0".$i;
                ?>
                <option value = "<?= $i?>" <?php if ($i == $pl_expire_time_i) echo "selected=selected";?>><?= $i?></option>
                <?php 			    
			}
			?>
			</select>
        </td>
    </tr>
    
    <?php for($i=1; $i<=5; $i++) { ?>
        <tr>
            <th scope="row"><label for="pl_img<?php echo $i; ?>"><?php echo "이미지 ".$i;?></label></th>
            <td>
                <input type="file" name="pl_img<?php echo $i; ?>" id="pl_img<?php echo $i; ?>">
                <?php 
                if ($w == 'u' && ($pl['pl_img'.$i] != "" || $pl['pl_img'.$i] != null)) 
                {
                    ?>
                    <img src = "<?= G5_DATA_URL."/place/".$pl['pl_img'.$i]?>" style = "width:50px;height:50px">
                    <input type="checkbox" name="pl_img<?php echo $i; ?>_del" id="pl_img<?php echo $i; ?>_del" value="1">삭제
                    <?php 
                }
                ?>
            </td>
        </tr>
        <?php } ?>

	<tr>
		<th scope="row"><label for="pl_content">특이사항</label></th>
		<td><input type ="text" id = "pl_content" name = "pl_content" value = "<?= $pl['pl_content']?>" required class="required frm_input" size="50">
	</tr>
    
    
	<tr>
        <th scope="row"><label for="pl_hp">휴무일</label></th>
        <td>
			<select name="pl_period">
				<option value="없음" <?php if ($pl['pl_period'] == "없음") echo "selected=selected"; ?>>없음</option>
				<option value="매주" <?php if ($pl['pl_period'] == "매주") echo "selected=selected"; ?>>매주</option>
				<option value="첫째주" <?php if ($pl['pl_period'] == "첫째주") echo "selected=selected"; ?>>첫째주</option>
				<option value="둘째주" <?php if ($pl['pl_period'] == "둘째주") echo "selected=selected"; ?>>둘째주</option>
				<option value="셋째주" <?php if ($pl['pl_period'] == "셋째주") echo "selected=selected"; ?>>셋째주</option>
				<option value="넷째주" <?php if ($pl['pl_period'] == "넷째주") echo "selected=selected"; ?>>넷째주</option>
				<option value="첫째주,둘째주" <?php if ($pl['pl_period'] == "첫째주,둘째주") echo "selected=selected"; ?>>첫째주,둘째주</option>
				<option value="둘째주,셋째주" <?php if ($pl['pl_period'] == "둘째주,셋째주") echo "selected=selected"; ?>>둘째주,셋째주</option>
				<option value="셋째주,넷째주" <?php if ($pl['pl_period'] == "셋째주,넷째주") echo "selected=selected"; ?>>셋째주,넷째주</option>
				<option value="첫째주,셋째주" <?php if ($pl['pl_period'] == "첫째주,셋째주") echo "selected=selected"; ?>>첫째주,셋째주</option>
				<option value="첫째주,넷째주" <?php if ($pl['pl_period'] == "첫째주,넷째주") echo "selected=selected"; ?>>첫째주,넷째주</option>
				<option value="둘째주,넷째주" <?php if ($pl['pl_period'] == "둘째주,넷째주") echo "selected=selected"; ?>>둘째주,넷째주</option>
			</select>
            <input type="checkbox" name="pl_week[]" id="pl_mon" value="월" <?php if (strpos($pl['pl_week'], '월') !== false) echo "checked=checked"; ?>><label for="pl_mon">월</label>
            <input type="checkbox" name="pl_week[]" id="pl_tue" value="화" <?php if (strpos($pl['pl_week'], '화') !== false) echo "checked=checked"; ?>><label for="pl_tue">화</label>
            <input type="checkbox" name="pl_week[]" id="pl_wed" value="수" <?php if (strpos($pl['pl_week'], '수') !== false) echo "checked=checked"; ?>><label for="pl_wed">수</label>
            <input type="checkbox" name="pl_week[]" id="pl_thu" value="목" <?php if (strpos($pl['pl_week'], '목') !== false) echo "checked=checked"; ?>><label for="pl_thu">목</label>
            <input type="checkbox" name="pl_week[]" id="pl_fri" value="금" <?php if (strpos($pl['pl_week'], '금') !== false) echo "checked=checked"; ?>><label for="pl_fri">금</label>
            <input type="checkbox" name="pl_week[]" id="pl_sat" value="토" <?php if (strpos($pl['pl_week'], '토') !== false) echo "checked=checked"; ?>><label for="pl_sat">토</label>
            <input type="checkbox" name="pl_week[]" id="pl_sun" value="일" <?php if (strpos($pl['pl_week'], '일') !== false) echo "checked=checked"; ?>><label for="pl_sun">일</label>
        </td>
    </tr>
	<tr>
        <th scope="row"><label for="pl_addr">지점주소</label></th>
        <td>
			
			<label for="pl_zip" class="sound_only">우편번호</label>
            <input type="text" name="pl_zip" value="<?php echo $pl['pl_zip']; ?>" id="pl_zip" class="frm_input readonly" size="5" maxlength="6">
            <button type="button" class="btn_frmline" onclick='javascript:sample4_execDaumPostcode();'>우편번호검색</button> <br>
            <input type="text" name="pl_addr1" value="<?php echo $pl['pl_addr1'] ?>" id="pl_addr1" class="frm_input readonly" size="60">
            <label for="pl_addr1">기본주소</label><br>
            <input type="text" name="pl_addr2" value="<?php echo $pl['pl_addr2'] ?>" id="pl_addr2" class="frm_input" size="60">
            <label for="pl_addr2">상세주소</label>
            <br>
            <input type="text" name="pl_addr3" value="<?php echo $pl['pl_addr3'] ?>" id="pl_addr3" class="frm_input" size="60">
            <label for="pl_addr3">참고항목</label>
            <input type="hidden" name="pl_addr_jibeon" value="<?php echo $pl['pl_addr_jibeon']; ?>"><br>
            <input type="hidden" name="pl_latitude" id="pl_latitude" value="<?php echo $pl['pl_latitude']; ?>"><br>
            <input type="hidden" name="pl_longitude" id="pl_longitude" value="<?php echo $pl['pl_longitude']; ?>"><br>
        </td>
    </tr>
    </tbody>
    </table>
</div>

<div class="btn_fixed_top">
    <a href="./placelist.php" class="btn btn_02">목록</a>
    <input type="submit" value="확인" class="btn_submit btn" accesskey="s">
</div>

</form>
<div id="map" style="width:100%;height:350px;"></div>

<script type="text/javascript" src="//dapi.kakao.com/v2/maps/sdk.js?appkey=<?php echo $config['cf_kakao_rest_key'] ?>&libraries=services"></script>
<script>
function getgeo() {
	var mapContainer = document.getElementById('map'), // 지도를 표시할 div 
		mapOption = {
			center: new kakao.maps.LatLng(33.450701, 126.570667), // 지도의 중심좌표
			level: 3 // 지도의 확대 레벨
		};  

		// 지도를 생성합니다    
		var map = new kakao.maps.Map(mapContainer, mapOption); 

		// 주소-좌표 변환 객체를 생성합니다
		var geocoder = new kakao.maps.services.Geocoder();

		// 주소로 좌표를 검색합니다
		geocoder.addressSearch($("#pl_addr1").val(), function(result, status) {

		// 정상적으로 검색이 완료됐으면 
		if (status === kakao.maps.services.Status.OK) {

			var coords = new kakao.maps.LatLng(result[0].y, result[0].x);
			$("#pl_latitude").val(result[0].y);
			$("#pl_longitude").val(result[0].x);

			// 결과값으로 받은 위치를 마커로 표시합니다
			var marker = new kakao.maps.Marker({
				map: map,
				position: coords
			});

			// 인포윈도우로 장소에 대한 설명을 표시합니다
			var infowindow = new kakao.maps.InfoWindow({
				content: '<div style="width:150px;text-align:center;padding:6px 0;">' + $("#pl_name").val() + '</div>'
			});
			infowindow.open(map, marker);

			// 지도의 중심을 결과값으로 받은 위치로 이동시킵니다
			map.setCenter(coords);
		} 
	});
}
getgeo();
</script>
<script>
    //본 예제에서는 도로명 주소 표기 방식에 대한 법령에 따라, 내려오는 데이터를 조합하여 올바른 주소를 구성하는 방법을 설명합니다.
    function sample4_execDaumPostcode() {
        new daum.Postcode({
            oncomplete: function(data) {
                // 팝업에서 검색결과 항목을 클릭했을때 실행할 코드를 작성하는 부분.

                // 도로명 주소의 노출 규칙에 따라 주소를 조합한다.
                // 내려오는 변수가 값이 없는 경우엔 공백('')값을 가지므로, 이를 참고하여 분기 한다.
                var fullRoadAddr = data.roadAddress; // 도로명 주소 변수
                var extraRoadAddr = ''; // 도로명 조합형 주소 변수

                // 법정동명이 있을 경우 추가한다. (법정리는 제외)
                // 법정동의 경우 마지막 문자가 "동/로/가"로 끝난다.
                //if(data.bname !== '' && /[동|로|가]$/g.test(data.bname)){
                //   extraRoadAddr += data.bname;
                //}
                // 건물명이 있고, 공동주택일 경우 추가한다.
                if(data.buildingName !== '' ){
                   extraRoadAddr += (extraRoadAddr !== '' ? ', ' + data.buildingName : data.buildingName);
                }
                // 도로명, 지번 조합형 주소가 있을 경우, 괄호까지 추가한 최종 문자열을 만든다.
                if(extraRoadAddr !== ''){
                    extraRoadAddr = ' (' + extraRoadAddr + ')';
                }
                // 도로명, 지번 주소의 유무에 따라 해당 조합형 주소를 추가한다.
                if(fullRoadAddr !== ''){
                    fullRoadAddr += extraRoadAddr;
                }
				console.log(data);

                // 우편번호와 주소 정보를 해당 필드에 넣는다.
                document.getElementById('pl_zip').value = data.zonecode; //5자리 새우편번호 사용
                document.getElementById('pl_addr1').value = fullRoadAddr;
//                 document.getElementById('ac_add2').value = data.jibunAddress;
                // 사용자가 '선택 안함'을 클릭한 경우, 예상 주소라는 표시를 해준다.
//                 if(data.autoRoadAddress) {
//                     //예상되는 도로명 주소에 조합형 주소를 추가한다.
//                     var expRoadAddr = data.autoRoadAddress + extraRoadAddr;
//                     document.getElementById('guide').innerHTML = '(예상 도로명 주소 : ' + expRoadAddr + ')';

//                 } else if(data.autoJibunAddress) {
//                     var expJibunAddr = data.autoJibunAddress;
//                     document.getElementById('guide').innerHTML = '(예상 지번 주소 : ' + expJibunAddr + ')';

//                 } else {
//                     document.getElementById('guide').innerHTML = '';
//                 }
// 				alert('\''+fullRoadAddr+'\'나머지 주소를 입력하세요');
				$('#pl_addr2').focus();
				getgeo();
            }
        }).open();
    }
</script>
<?php
include_once (G5_ADMIN_PATH.'/admin.tail.php');
?>