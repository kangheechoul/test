<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

// if(defined('G5_THEME_PATH')) {
    // require_once(G5_THEME_PATH.'/tail.php');
    // return;
// }

if (G5_IS_MOBILE) {
    include_once(G5_MOBILE_PATH.'/tail.php');
    return;
}

$sql = "select * from {$g5['place_table']} where mb_id = '{$member['mb_id']}'";
$row = sql_fetch($sql);

?>
</div>
<link rel="stylesheet" href="<?php echo G5_URL; ?>/css/footer.css">
<footer>
<div class="text-center">
    <p class="s-title">MIMICOOK APP</p>
    <a class="app-download" href="<?= $config['cf_app_url']?>"><img src="<?= G5_URL?>/img/playstore.png" alt="playstore"></a>
    <ul class="d-flex justify-content-center">
      <!-- <li><a href="<?php echo get_pretty_url('content', 'company'); ?>">회사소개</a></li> -->
      <li><a href="<?= G5_EX_URL."/company.php" ?>">회사소개</a></li>
            <li><a href="<?php echo get_pretty_url('content', 'provision'); ?>">서비스이용약관</a></li>
            <li><a href="<?php echo get_pretty_url('content', 'privacy'); ?>">개인정보처리방침</a></li>
            <?php if ($is_admin) {  ?>
			<li><a href="<?php echo G5_ADMIN_URL ?>/shop_admin/" target="_self">관리자</a></li>
			<?php } ?>
			<?php if ($row) {  ?>
			<li><a href="<?php echo G5_URL ?>/place/" target="_self">관리자</a></li>
			<?php } ?>
    </ul>
    <div class="d-flex justify-content-center">
        <p class="mr-3">Tel <span class="point"><?= $default['de_admin_company_tel']; ?></span></p>
        <p>Email <span class="point"><?= $default['de_admin_info_email']?></span></p>
    </div>
    <div>
        <p>
            <span>법인명(상호) : <?= $default['de_admin_company_name']?> |</span>
            <span>사업자등록번호 : <?= $default['de_admin_company_saupja_no']?> </span>            
        </p>
        <p>
            <span>통신판매업 신고 번호 : <?= $default['de_admin_tongsin_no']?></span>
        </p>
        <p>
            <span>주소 : <?= $default['de_admin_company_addr']?> |</span>
            <span>대표 : <?= $default['de_admin_company_owner']?></span>
        </p>
    </div>
    <span class="copy-right">© MIMICOOK. ALL RIGHTS RESERVED</span>
</div>
</footer>
<?php
if(G5_DEVICE_BUTTON_DISPLAY && !G5_IS_MOBILE) { ?>
<?php
}

if ($config['cf_analytics']) {
    echo $config['cf_analytics'];
}
?>

<!-- } 하단 끝 -->

<script>
$(function() {
    // 폰트 리사이즈 쿠키있으면 실행
    font_resize("container", get_cookie("ck_font_resize_rmv_class"), get_cookie("ck_font_resize_add_class"));
});
</script>

<?php
include_once(G5_PATH."/tail.sub.php");
?>