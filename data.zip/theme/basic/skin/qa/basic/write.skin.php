<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

// add_stylesheet('css 구문', 출력순서); 숫자가 작을 수록 먼저 출력됨
add_stylesheet('<link rel="stylesheet" href="'.$qa_skin_url.'/style.css">', 0);
?>

<section id="bo_w">
    <h2>1:1문의 작성</h2>
    <!-- 게시물 작성/수정 시작 { -->
    <form name="fwrite" id="fwrite" action="<?php echo $action_url ?>" onsubmit="return fwrite_submit(this);" method="post" enctype="multipart/form-data" autocomplete="off">
    <input type="hidden" name="w" value="<?php echo $w ?>">
    <input type="hidden" name="qa_id" value="<?php echo $qa_id ?>">
    <input type="hidden" name="sca" value="<?php echo $sca ?>">
    <input type="hidden" name="stx" value="<?php echo $stx ?>">
    <input type="hidden" name="page" value="<?php echo $page ?>">
    <?php
    $option = '';
    $option_hidden = '';
    $option = '';

    if ($is_dhtml_editor) {
        $option_hidden .= '<input type="hidden" name="qa_html" value="1">';
    } else {
        $option .= "\n".'<input type="checkbox" id="qa_html" name="qa_html" onclick="html_auto_br(this);" value="'.$html_value.'" '.$html_checked.'>'."\n".'<label for="qa_html">html</label>';
    }

    echo $option_hidden;
    ?>

    <div class="form_01">
		<h1 class="title">가맹점신청</h1>
		<div id="qa_information">
		<!-- db값 -->
			<h3>개인정보 수집 및 활용동의</h3>
			<ul>
				<li>
					<p>1. 개인정보의 수집 및 이용 목적</p>
					<p>가맹 관련 문의 확인 및 답변을 위한 연락통지, 처리결과 통보 등을 목적으로 개인정보를 처리합니다.</p>
				</li>
				<li>
					<p>2. 처리하는 개인정보 항목</p>
					<p>- 필수항목 : 이름, 연락처 (접속 IP 정보, 쿠키, 서비스 이용 기록, 접속 로그)</p>
					<p>- 선택항목 : 이메일</p>
				</li>
				<li>
					<p>3. 개인정보의 처리 및 보유 기간</p>
					<p>① 법령에 따른 개인정보 보유.이용기간 또는 정보주체로부터 개인정보를 수집 시에 동의 받은 개인정보 보유, 이용기간 내에서 개인정보를 처리, 보유합니다.</p>
					<p>② 개인정보의 보유 기간은 5년입니다.</p>
				</li>
			</ul>
			<!-- // -->
			<input type="checkbox" name="qa_agree" id="qa_agree" class="">
            <label for="qa_agree" class="frm_info"><span></span>위 개인정보 수집 및 활용에 동의합니다.</label>
		</div>
        <ul class = "row">
		<!--
            <?php if ($category_option) { ?>
            <li class="bo_w_select write_div">
                <label for="qa_category" class="sound_only">분류<strong>필수</strong></label>
                <select name="qa_category" id="qa_category" required >
                    <option value="">분류를 선택하세요</option>
                    <?php echo $category_option ?>
                </select>
            </li>
            <?php } ?>
		-->
			<li class="col-lg-6">
                <label for="qa_subject" class="sound_only">이름<strong class="sound_only">필수</strong></label>
				<input type="text" name="qa_name" value="" id="qa_name" required class="frm_input full_input required" size="30" maxlength="255" placeholder="이름">        
            </li>
		
            <li class="col-lg-6">
                <label for="qa_email" class="sound_only">이메일<strong class="sound_only">필수</strong></label>
                <input type="text" name="qa_email" value="" id="qa_email" <?php echo $req_email; ?> class="<?php echo $req_email.' '; ?>frm_input full_input email" size="50" maxlength="100" placeholder="이메일">
				<input type="checkbox" name="qa_email_recv" id="qa_email_recv" value="1" checked style ="display: none">
            </li/>

            <?php if ($is_hp) { ?>
            <li class="col-lg-6">
                <label for="qa_hp" class="sound_only">휴대폰<strong class="sound_only">필수</strong></label>
                <input type="text" name="qa_hp" value="" id="qa_hp" <?php echo $req_hp; ?> class="<?php echo $req_hp.' '; ?>frm_input full_input required" size="30" placeholder="휴대폰">
                <?php if($qaconfig['qa_use_sms']) { ?>
                <input type="checkbox" name="qa_sms_recv" id="qa_sms_recv" value="1" <?php if($write['qa_sms_recv']) echo 'checked="checked"'; ?>  class="selec_chk">
                <!-- <label for="qa_sms_recv" class="frm_info"><span></span>답변등록 SMS알림 수신</label> -->
                <?php } ?>
            </li>
            <?php } ?>

			<li class="col-lg-6">
                <label for="qa_area" class="sound_only">창업희망지역<strong class="sound_only">필수</strong></label>
				<input type="text" name="qa_area" value="" id="qa_area" required class="frm_input full_input required" size="30" placeholder="창업희망지역">        
            </li>
			
			<li class="col-lg-6">
                <label for="" class="sound_only">예상창업비용</label>
				<input type="text" name="qa_cost" value="" id="qa_cost"  class="frm_input full_input" size="30" placeholder="예상창업비용">        
            </li>
            
            <li class="col-lg-6">
                <label for="qa_subject" class="sound_only">제목<strong class="sound_only">필수</strong></label>
				<input type="text" name="qa_subject" value="" id="qa_subject" class="frm_input full_input required" size="30" maxlength="255" placeholder="제목">        
            </li>

            <li class="col-lg-12 <?php echo $is_dhtml_editor ? $config['cf_editor'] : ''; ?>">
                <label for="qa_content" class="sound_only">내용<strong class="sound_only">필수</strong></label>
                    <?php echo $editor_html; // 에디터 사용시는 에디터로, 아니면 textarea 로 노출 ?>
                
            </li>
          
            <?php if ($option) { ?>
            <li>
                옵션
                <?php echo $option; ?>
            </li>
            <?php } ?>
<!--
            <li class="bo_w_flie">
                <div class="file_wr">
                    <label for="bf_file_1" class="lb_icon"><i class="fa fa-download" aria-hidden="true"></i><span class="sound_only"> 파일 #1</span></label>
                    <input type="file" name="bf_file[1]" id="bf_file_1" title="파일첨부 1 :  용량 <?php echo $upload_max_filesize; ?> 이하만 업로드 가능" class="frm_file">
                    <?php if($w == 'u' && $write['qa_file1']) { ?>
                    <input type="checkbox" id="bf_file_del1" name="bf_file_del[1]" value="1"> <label for="bf_file_del1"><?php echo $write['qa_source1']; ?> 파일 삭제</label>
                    <?php } ?>
                </div>
            </li>

            <li class="bo_w_flie">
                <div class="file_wr">
                    <label for="bf_file_2" class="lb_icon"><i class="fa fa-download" aria-hidden="true"></i><span class="sound_only"> 파일 #2</span></label>
                    <input type="file" name="bf_file[2]" id="bf_file_2" title="파일첨부 2 :  용량 <?php echo $upload_max_filesize; ?> 이하만 업로드 가능" class="frm_file">
                    <?php if($w == 'u' && $write['qa_file2']) { ?>
                    <input type="checkbox" id="bf_file_del2" name="bf_file_del[2]" value="1"> <label for="bf_file_del2"><?php echo $write['qa_source2']; ?> 파일 삭제</label>
                    <?php } ?>
                </div>
            </li>
-->
        </ul>
    </div>
    
    <div class="btn_confirm write_div">
        <a href="<?php echo $list_href; ?>" class="btn_cancel btn">취소</a>
        <button type="submit" id="btn_submit" accesskey="s" class="btn_submit btn">작성완료</button>
    </div>
    
    </form>

    <script>
	$('#qa_content').text('');

	
    
    function html_auto_br(obj)
    {
        if (obj.checked) {
            result = confirm("자동 줄바꿈을 하시겠습니까?\n\n자동 줄바꿈은 게시물 내용중 줄바뀐 곳을<br>태그로 변환하는 기능입니다.");
            if (result)
                obj.value = "2";
            else
                obj.value = "1";  
        }
        else
            obj.value = "";
    }
 
    function fwrite_submit(f)
    {
        <?php //echo $editor_js; // 에디터 사용시 자바스크립트에서 내용을 폼필드로 넣어주며 내용이 입력되었는지 검사함   ?>
       	var email_re,hp_re,text_re,num_re;

    	email_re = /^[-A-Za-z0-9_]+[-A-Za-z0-9_.]*[@]{1}[-A-Za-z0-9_]+[-A-Za-z0-9_.]*[.]{1}[A-Za-z]{1,5}$/;
    	hp_re = /^\d{2,3}-\d{3,4}-\d{4}$/;
    	//text_re = /[a-z0-9]|[ \[\]{}()<>?|`~!@#$%^&*-_+=,.;:\"'\\]/g
    	text_re = /^[가-힣\s]+$/;
    	name_re = /^[가-힣]+$/;
    	num_re = /^[0-9]/g;

    	if($("input:checkbox[name=qa_agree]").is(":checked") == false)
    	{
    		alert('개인정보 수집 및 활용동의를 체크해주세요');
    		$('#qa_agree').focus();
    		return false;
    	}
    	else if(name_re.test($('#qa_name').val()) == false || $('#qa_name').val() == "")
    	{
    		alert('이름을 바로 작성해주세요');
    		$('#qa_name').focus();
    		return false;
    	}
    	else if(hp_re.test($('#qa_hp').val()) == false || $('#qa_hp').val() == "")
    	{
    		alert('전화번호 형식을 맞춰주세요');
    		$('#qa_hp').focus();
    		return false;
    	}
    	else if(text_re.test($('#qa_area').val()) == false || $('#qa_area').val() ="")
    	{
    		alert('창업희망지역을 바로 작성해주세요');
    		$('#qa_area').focus();
    		return false;
    	}
        
        var subject = "";
        var content = "";
        $.ajax({
            url: g5_bbs_url+"/ajax.filter.php",
            type: "POST",
            data: {
                "subject": f.qa_subject.value,
                "content": f.qa_content.value
            },
            dataType: "json",
            async: false,
            cache: false,
            success: function(data, textStatus) {
                subject = data.subject;
                content = data.content;
            }
        });

        if (subject) {
            alert("제목에 금지단어('"+subject+"')가 포함되어있습니다");
            f.qa_subject.focus();
            return false;
        }

        if (content) {
            alert("내용에 금지단어('"+content+"')가 포함되어있습니다");
            if (typeof(ed_qa_content) != "undefined")
                ed_qa_content.returnFalse();
            else
                f.qa_content.focus();
            return false;
        }

        <?php if ($is_hp) { ?>
        var hp = f.qa_hp.value.replace(/[0-9\-]/g, "");
        if(hp.length > 0) {
            alert("휴대폰번호는 숫자, - 으로만 입력해 주십시오.");
            return false;
        }
        <?php } ?>

        document.getElementById("btn_submit").disabled = "disabled";

        return true;
    }

 
    </script>
</section>
<!-- } 게시물 작성/수정 끝 -->