<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

if (G5_IS_MOBILE) {
    include_once(G5_THEME_MOBILE_PATH.'/head.php');
    return;
}

include_once(G5_PATH.'/head.sub.php');

// if(G5_COMMUNITY_USE === false) {
    // define('G5_IS_COMMUNITY_PAGE', true);
    // include_once(G5_THEME_SHOP_PATH.'/shop.head.php');
    // return;
// }

include_once(G5_LIB_PATH.'/latest.lib.php');
include_once(G5_LIB_PATH.'/outlogin.lib.php');
include_once(G5_LIB_PATH.'/poll.lib.php');
include_once(G5_LIB_PATH.'/visit.lib.php');
include_once(G5_LIB_PATH.'/connect.lib.php');
include_once(G5_LIB_PATH.'/popular.lib.php');

echo '<link rel="stylesheet" href="'.G5_URL.'/css/header-1.css">'.PHP_EOL;

$url = strip_tags($_GET['url']);

// url 체크
check_url_host($url);

$login_url        = login_url($url);
$login_action_url = G5_HTTPS_BBS_URL."/login_check.php";

$is_login = '<li class="log-in" id="log-in"><a href="javascript:" class="log-in menu-icon">LOGIN</a></li>';
$s_login = '<div class="log-in"><a href="javascript:$(\'.limiter\').show()">LOGIN</a></div>';
if ($is_member) {
	$is_login = '<li class="log-in"><a href="'.G5_BBS_URL.'/logout.php" class="log-in menu-icon">LOGOUT</a></li>';
	$s_login = '<div class="log-in"><a href="'.G5_BBS_URL.'/logout.php">LOGOUT</a></div>';
}

$self_url = G5_BBS_URL."/login.php";

//새창을 사용한다면
if( G5_SOCIAL_USE_POPUP ) {
    $self_url = G5_SOCIAL_LOGIN_URL.'/popup.php';
}

function get_mshop_category($ca_id, $len)
{
    global $g5;

    $sql = " select ca_id, ca_name from {$g5['g5_shop_category_table']}
                where ca_use = '1' ";
    if($ca_id)
        $sql .= " and ca_id like '$ca_id%' ";
    $sql .= " and length(ca_id) = '$len' order by ca_order, ca_id ";

    return $sql;
}

$mshop_categories = get_shop_category_array(true);
?>
<style>
.sub-menu-box{
display:none;
}
</style>
<?php if(defined('_INDEX_')) { // index에서만 실행
	include G5_BBS_PATH.'/newwin.inc.php'; // 팝업레이어
 } ?>
    <header>
		<div class="header-wrap">
			<div class="top-head">
			<a href="<?php echo G5_URL; ?>" class="logo"><img src="<?php echo G5_URL; ?>/img/mimicook-logo.png" alt="logo"></a>
			<a href="<?php echo G5_SHOP_URL; ?>/cart.php" class="head_small">고객센터</a>
				<!-- <ul class="menu-icon-wrap">
					 <?php echo $is_login; ?>
					<li></li>
				</ul> -->
			</div>
		</div>
		<nav>
			<div class="bottom-head">
				

					<div class="menu2">
						<ul class="menu-list flex-sb">
						<?php
							$i = 0;
							foreach($mshop_categories as $cate1){
							if( empty($cate1) ) continue;

							$mshop_ca_row = $cate1['text'];
						?>
							<li>
								<a href="<?php echo $mshop_ca_row['url']; ?>"><?php echo get_text($mshop_ca_row['ca_name']); ?></a>
								<?php 
									$li_content = '<div class="sub-menu-box">';

									$j=0;

									foreach($cate1 as $key=>$cate2){
										if( empty($cate2) || $key === 'text' ) continue;
										
										$mshop_ca_row2 = $cate2['text'];
										if($j == 0)
											$li_content .= '<ul class="sub_cate sub_cate1">';
										$li_content .= '<li class="cate_li_2">';
										$li_content .= '<a href="'.$mshop_ca_row2['url'].'">'.get_text($mshop_ca_row2['ca_name']).'</a>';
										$li_content .= '</li>';
										$j++;
									}

									if($j > 0)
										$li_content .= '</ul>';
									$li_content .= '</div>';

									echo $li_content;
								?>
							</li>
						<?php }?>
							<li>
								<a href="https://mimicook.kr/shop/list.php?ca_id=30">이벤트</a>
								<div class="sub-menu-box"></div>							
							</li>
							<li>
								<a href="<?php echo G5_BBS_URL ?>/board.php?bo_table=notice">공지사항</a>
								<div class="sub-menu-box"></div>							
							</li>
						</ul>
					</div>
					
					<div class="search">
						<label>
							<input type="text">
							<button><i class="material-icons">search</i></button>
						</label>
					</div>

				<div class="m-menu-btn"><i class="xi-bars"></i></div>
			</div>
		</nav>
        
		
    </header>

	<div class="m-menu-bg">
		<div class="m-menu">
		<div class="close-btn"><i class="xi-hamburger-back"></i></div>
		<div class="back-btn">Back</div>

		
		<ul class="mo-menu">
			<?php
				$j = 0;
				foreach($mshop_categories as $cate1){
				if( empty($cate1) ) continue;
					$mshop_ca_row1 = $cate1['text'];
					$ca_name = get_text($mshop_ca_row1['ca_name']);
					$xeicon = '';
					$href = 'javascript:';
					foreach($cate1 as $key=>$cate2){
						if( empty($cate2) || $key === 'text' ) continue;
						else $xeicon = '<i class="xi-angle-right-min"></i>';
					}
					if ($xeicon == '') $href = $mshop_ca_row1['url'];
					
				$j++;
			?>
			<li class="sub"><a href="<?php echo $href ?>"><?php echo $ca_name ?><?php echo $xeicon ?></a></li>
			<?php }?>
			<!-- 
			<li class="sub"><a href="javascript:">고객센터</a></li>
			<li class="sub"><a href="javascript:">회사소개</a></li>
			-->
		</ul>
		<?php
			$i = 0;
			foreach($mshop_categories as $cate1){
				if( empty($cate1) ) continue;

				$mshop_ca_row1 = $cate1['text'];
// 				if($i == 0) {
					$li_content .= '<ul class="mo-sub-menu">';
					$li_content .= '<div class="mo-sub-menu-title">'.$mshop_ca_row1['ca_name'].'</div>';
					$li_content .= '<div class="line"></div>';
// 				}

				$j=0;

				foreach($cate1 as $key=>$cate2){
					if( empty($cate2) || $key === 'text' ) continue;

					$mshop_ca_row2 = $cate2['text'];
					if($j == 0)
						$li_content .= '<ul class="sub_cate sub_cate1">';
					$li_content .= '<li class="cate_li_2">';
					$li_content .= '<a href="'.$mshop_ca_row2['url'].'">'.get_text($mshop_ca_row2['ca_name']).'</a>';
					$li_content .= '</li>';
					$j++;
				}
				if($j > 0) {
					$li_content .= '</ul>';
				}
				$i++;
				$li_content .= '</ul>';
			}   // end for
			$li_content .= '<ul class="mo-sub-menu" data-index="0">
								<div class="mo-sub-menu-title">고객센터</div>
								<div class="line"></div>';
			$li_content .= $add_sub1;
			$li_content .= '</ul>
							<ul class="mo-sub-menu" data-index="0">
								<div class="mo-sub-menu-title">회사소개</div>
								<div class="line"></div>';
			$li_content .= $add_sub2;
			$li_content .= '</ul>';
				
				
			if($i == 0)
				$li_content = '<p class="no-cate">등록된 분류가 없습니다.</p>';

			echo $li_content;
		?>

		<div class="log-in-wrap">
			<span><?php if ($is_member) { echo $member['mb_name'].'님 반갑습니다.'; } else { ?>로그인 해주세요<? } ?></span>
			<?php echo $s_login ?>
		</div>
    </div>

    </div>

    <div class="limiter" style="display:none;">
		<div class="container-login100">
			<div class="wrap-login100 p-l-55 p-r-55 p-t-65 p-b-54">
				<form class="login100-form validate-form" name="flogin" action="<?php echo $login_action_url ?>" onsubmit="return flogin_submit(this);" method="post">
					<input type="hidden" name="url" value="<?php echo $login_url ?>">

				    <span class="close"><i class="xi-close"></i></span>
					<span class="login100-form-title p-b-49">
						Login
					</span>

					<div class="wrap-input100 validate-input m-b-23" data-validate = "Username is reauired">
						<span class="label-input100">Username</span>
						<input type="text" name="mb_id" id="login_id" required class="input100 required" size="20" maxLength="20" placeholder="아이디">
						<span class="focus-input100" data-symbol="&#xf206;"></span>
					</div>

					<div class="wrap-input100 validate-input" data-validate="Password is required">
						<span class="label-input100">Password</span>
						<input type="password" name="mb_password" id="login_pw" required class="input100 required" size="20" maxLength="20" placeholder="비밀번호">
						<span class="focus-input100" data-symbol="&#xf190;"></span>
					</div>

					<div class="text-right p-t-8 p-b-31">
						<a href="<?php echo G5_BBS_URL ?>/password_lost.php" target="_blank" id="login_password_lost">정보찾기</a>
					</div>

					<div class="container-login100-form-btn">
						<div class="wrap-login100-form-btn">
							<div class="login100-form-bgbtn"></div>
							<button type="submit" class="login100-form-btn">
								로그인
							</button>
						</div>
					</div>

					<div class="txt1 text-center p-t-54 p-b-20">
						<span>
							SNS 간편로그인
						</span>
					</div>

					<div class="flex-c-m">
					<?php
					// 소셜로그인 사용시 소셜로그인 버튼
					@include_once(get_social_skin_path().'/social_login.skin.php');
					?>
					</div>

					<div class="flex-col-c p-t-20">
						<a href="<?php echo G5_URL ?>/bbs/register.php" class="txt2 sign-btn">
							회원가입
						</a>
					</div>
				</form>
			</div>
		</div>
	</div>

    <div class="top">
        <i class="xi-caret-up-min"></i>
    </div>
	
	<script>
		$(document).ready(function(){
    
    $( '.top' ).click( function() {
	$( 'html, body' ).animate( { scrollTop : 0 }, 400 );
	return false;
} );
    
    
    
});
	</script>
	<div class="containerd">
		<div class="con_bin_top"></div>
