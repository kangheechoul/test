<?php
include_once('./_common.php');
include_once('./head.sub.php');

/* if(G5_IS_MOBILE) {
 header('location:'.G5_THEME_MOBILE_PATH.'/head.php');
 return;
 } */

unset($_SESSION['ss_is_mobile']);


//ss_cart_id = 2020122308565307
//2020122314474926
?>
<link rel="stylesheet" href="<?php echo G5_APP_URL ?>/css/style.css">
<link rel="stylesheet" href="<?php echo G5_APP_URL ?>/css/swiper.min.css">
<script src="<?php echo G5_APP_URL ?>/vendor/swiper/swiper.min.js"></script>
<script src="<?php echo G5_APP_URL ?>/js/swiper_slide.js"></script>


<body>
	
    <div class="wrap">
         <div class="head flex-c-m"><img src="<?php echo G5_APP_URL ?>/img/mimicook-logo.png" alt="logo"></div>
        
        <section class="index sec_1">
            <div class="swiper-container swiper-container1">
                <div class="swiper-wrapper">
                <?php 
                $bn_sql = "select * from {$g5['g5_shop_banner_table']} where bn_device = 'mobile'";   
                $bn_res = sql_query($bn_sql);
                
                for($i = 0; $ba_row = sql_fetch_array($bn_res); $i++)
                {
                    ?>
                    <div class="swiper-slide banner<?= $i?>"><img src="<?php echo G5_DATA_URL ?>/banner/<?= $ba_row['bn_id']?>" alt="1024x680"></div>
                    <?php 
                }
                ?>
                </div>
			<div class="swiper-pagination"></div>
            </div>
			<div class="container">
            <h3 class="title"><a href="<?= G5_APP_URL?>">FEAURED PRODUCTS<i class="material-icons">keyboard_arrow_right</i></a></h3>
            <script>
			$('.title > a ').attr('left', '1%');

            </script>
            <nav>
                <div class="nav nav-tabs" id="nav-tab" role="tablist">
                
                <?php 
                
                $ca_id1 = "1009";
                $ca_id2 = "";
                
                $i = 0;
                
                $order_by = " order by ca_id";
                
                $limit = " limit 5";
                
                $menu_count = str_replace(" limit ", "", $limit);
                
                $main_cate_sql = "select * from {$g5['g5_shop_category_table']} where length(ca_id) = 4 {$order_by}{$limit}" ;
                $main_cate_res = sql_query($main_cate_sql);
                
                for($i = 0; $main_cate_row = sql_fetch_array($main_cate_res); $i++)
                {
                    if($i != 0)
                    {
                        $ca_id2 .= $main_cate_row['ca_id'];
                        if($i < $menu_count -1)
                        {
                            $ca_id2 .= ",";
                        }
                    ?>
                    <a class="nav-link<?php if ($i == 1) echo " active"?>" id="nav-<?= $i?>-tab" data-bs-toggle="tab" href="javascript:self(<?= $i?>)" role="tab" aria-controls="nav-<?= $i?>" aria-selected="<?php if($i == 1) echo "true"; else echo "false";?>"><?= $main_cate_row['ca_name']?></a>
                    <?php
                    }
                }
                ?>
                </div>
            </nav>
            
            <script>

            
            function self(num)
            {
				var a_len = $('#nav-tab > a').length;

				
                 for(var i = 1; i <= a_len ; i++)
                {
					if(i != num)
					{
						$('#nav-'+i+'-tab').attr('class', 'nav-link');
						$('#nav-'+i).attr('class', 'tab-pane fade');
						$('#nav-'+i).attr('aria-selected', 'false');
					}
                }
				$('#nav-'+num+'-tab').attr('class', 'nav-link active');
				$('#nav-'+num).attr('class', 'tab-pane fade show active');
				$('#nav-'+num).attr('aria-selected', 'true');
            }

            </script>
            
              <div class="tab-content" id="nav-tabContent">
              <?php
              $main_list_cate = explode(",", $ca_id2);
              
              for($i = 0; $i< count($main_list_cate); $i++)
              {
                  $main_list_sql = "select * from {$g5['g5_shop_item_table']} where ca_id = '{$ca_id1}' and ca_id2= '{$main_list_cate[$i]}' or ca_id3='{$main_list_cate[$i]}' order by it_hit limit 4";
                  
                  /* $main_list_sql = "select *, it.it_id as it_id ,avg(is_score) as star, count(is_score) as count from {$g5['g5_shop_item_table']} as it left join {$g5['g5_shop_item_use_table']} as us on it.it_id=us.it_id 
                  where it.ca_id = '{$main_list_cate[$i]}' or it.ca_id2= '{$main_list_cate[$i]}' or it.ca_id3='{$main_list_cate[$i]}' group by us.it_id order by it.it_hit desc limit 4"; */
                  
                  $main_list_res = sql_query($main_list_sql);
                  ?>
                  
                  <div class="tab-pane fade<?php if ($i == 0) echo " show active";?>" id="nav-<?= $i+1?>" role="tabpanel" aria-labelledby="nav-<?= $i+1?>-tab">

                  <?php   
                  for($j = 0; $main_list_row = sql_fetch_array($main_list_res); $j++)
                  {
                        ?>
                        	<div class="col-6 menu show <?= $main_list_row['ca_id'].$main_list_row['ca_id2'].$main_list_row['ca_id3']?>" id= "<?php echo "item".$j;?>">
        							<a href="javascript:location.href='./menu.php?it_id=<?= $main_list_row['it_id']?>';" >
                                <div class="img_box">
                                      <!-- <img alt="메뉴 이미지" src="<?php  //echo G5_APP_URL."/img/".$it_img;?>"> -->
                                    <!-- <img src="<?= G5_DATA_URL."/item/".$main_list_row['it_img1']?>" alt="메뉴이미지"/> -->
                                    <?php echo get_it_thumbnail($main_list_row['it_img1'], 167.500);?>
                                    <input type = "hidden" id = "pop" value = <?php echo $main_list_row['it_hit'];?>/>
                                </div>
                            	
                            	<h4 id= "it_name" name ="it_name"><?php echo $main_list_row['it_name']; ?></h4> <h5><?= number_format($main_list_row['it_price'])?>원</h5>
        						 <div class="sit_star">
                               	<?php 
                               	
                               	for($k = 0; $k < $main_list_row['it_use_avg']; $k++)
                               	{
                               	?>
                               	    <i class="material-icons">star_rate</i>
                               	<?php 
                               	}
                               	echo sprintf('%0.1f', $main_list_row['it_use_avg']);
                               	if($main_list_row['it_use_cnt']== 0)
                               	{
                               	 ?>
                               	 <span style="color:#909090; padding-left:5px;">(0)</span></p>
                               	 <?php    
                               	}
                               	else
                               	{
                               	    ?>
                               	    <span style="color:#909090;">(<?= $main_list_row['it_use_cnt']?>)</span></p>
                               	    <?php 
                               	}
                               	?>
                               	</div>
        							</a>
                            </div>
                        <?php 
                  }
                  ?>
                  </div>
                  <?php 
              }
              ?>
              </div>
			  </div>
			  <!-- <img style="width:100%; margin-top:5px;" src="<?php echo G5_APP_URL ?>" alt=""> -->
        </section>
		
        
        <script>
		var len = $('h3[name="it_name"]').length;

		for(var i = 0; i  < len; i++)
		{
			if($('h3[name="it_name"]').eq(i).text().length > 15)
			{
				$('h3[name="it_name"]').eq(i).text($('h3[name="it_name"]').eq(i).text().substring(0,15) + "..");
			}			
			
		}
		
        </script>
		
		<?php 
		
		$content_sql = "select * from {$g5['g5_shop_default_table']}";
		$default = sql_fetch($content_sql);
		?>
		<footer id = "footer" style= "margin-bottom:25px">
        <div class="text-center">
            <ul class="d-flex justify-content-center">
              <li><a href="<?= G5_APP_URL."/company.php"?>">회사소개</a></li>
                    <li><a href="<?= G5_APP_URL."/info.php?info_type=provision"?>">서비스이용약관</a></li>
                    <li><a href="<?= G5_APP_URL."/info.php?info_type=privacy"?>">개인정보처리방침</a></li>
            </ul>
            <div class="d-flex justify-content-center">
                <p class="mr-3" style="padding-right:5px">Tel <span class= "point1"><?= $default['de_admin_company_tel'];?></span></p>
                <p>Email <span class ="point1"><?= $default['de_admin_info_email']?></span></p>
            </div>
            <div>
                <p>
                    <span>법인명(상호) : <?= $default['de_admin_company_name']?> |</span>
                    <span>사업자등록번호 : <?= $default['de_admin_company_saupja_no']?> </span>            
                </p>
                <p>
                    <span>통신판매업 신고 번호 : <?= $default['de_admin_tongsin_no']?></span>
                </p>
                <p>
                    <span>주소 : <?= $default['de_admin_company_addr']?> |</span>
                    <span>대표 : <?= $default['de_admin_company_owner']?></span>
                </p>
            </div>
            <span class="copy-right">© MIMICOOK. ALL RIGHTS RESERVED</span>
        </div>
        </footer>
<?php include_once('./tail.php'); ?>
