<?php
include_once('./_common.php');
include_once('./head.sub.php');

?>
<link rel="stylesheet" href="<?php echo G5_APP_URL ?>/css/review.css">
<script src="<?php echo G5_APP_URL ?>/js/star_rating.js"></script>
<body>
    <div class="wrap">
      	<div class="head flex-c-m">
            <h2>문의하기</h2>
        </div>
        <section class="sec_1 sizefull pos-relative">
                <div class="container min-h-f text-center">
                    <h3 class="title">문의접수 되었습니다.</h3>
                    <button class="btn bg-gr" onclick="location.href='<?= G5_APP_URL?>'">홈페이지로 이동</button>
                </div>
               
                
        </section>
    </div>
<?php include_once('./tail.php'); ?>
