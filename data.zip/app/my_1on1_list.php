<?php
include_once('./_common.php');
include_once('./head.sub.php');
?>
<link rel="stylesheet" href="<?php echo G5_APP_URL ?>/css/mypage.css">
<link rel="stylesheet" href="<?php echo G5_APP_URL ?>/css/delivery.css">
<body>
    <div class="wrap">
        <div class="head flex-c-m">
            <a href="<?php echo G5_APP_URL."/my_home.php"?>" class="back_btn" id="cancel"><i class="material-icons">arrow_back_ios</i></a>
            <h2>1:1문의</h2>
        </div>
        <section class="sec_1">
            <div class="container min-h-100 my_ul">
                <ul class="row">
                    <li class="col-12">
                        <a href="<?php echo G5_APP_URL ?>/my_faq.php">
                            자주 묻는 질문<span class="arrow">></span>
                        </a>
                    </li>
                    <li class="col-12">
                        <a href="<?php echo G5_APP_URL ?>/my_1on1_write.php">
                            문의하기<span class="arrow">></span>
                        </a>
                    </li>
                </ul>
            </div>
        </section>
    </div>
	
	<?php include_once('./tail.php'); ?>
