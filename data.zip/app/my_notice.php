<?php
include_once('./_common.php');
include_once('./head.sub.php');
?>
<link rel="stylesheet" href="<?php echo G5_APP_URL ?>/css/mypage.css">
<link rel="stylesheet" href="<?php echo G5_APP_URL ?>/css/delivery.css">
<body>
    <div class="wrap">
        <div class="head flex-c-m">
            <a href="javascript:" class="back_btn" id="cancel"><i class="material-icons">arrow_back_ios</i></a>
            <h2>공지사항</h2>
        </div>
        
        <section class="sec_1">
            <div class="container min-h-100 my_ul">
                <ul class="row">
                    
                    <?php 
                    
                    $wr_id = $_GET['wr_id'];
                    
                    $sql = "select * from g5_write_notice where wr_parent = '".$wr_id."' order by wr_id asc"; //g5_write_notice";
                	
                    $res = sql_query($sql);
                	
                    for ($i = 0; $row = sql_fetch_array($res); $i++) 
                    {
                        //게시글 
                        if($i == 0)
                        {
                            ?>
                           	<li class="col-12" >
                            <a href="javascript:;">
                                <?php echo $row['wr_subject'];?>
                                <span class="date"><?php echo $row['wr_datetime'];?></span>
                                <!-- <span class="name-admin"><?php echo "작성자 : ".$row['mb_id'];?></span> -->
                            </a>
                            </li>
                        	<li class="board">
                            <?php 
                            echo $row['wr_content'];
                            ?>
                        	</li>
                            <?php 
                        }
                       
                            //댓글들 
                            if($i != 0)
                            {
                            ?>
                            <!-- 
                            <li class="border-b border-g p-t-10 p-b-10" >
                                
                                </li>
                            <li class="notice m-t-10" >
                            <a href="#none">
                                    <span class="date font-07em col-g dis-block"><?php echo $row['wr_datetime'];?></span>
                                    <span class="date font-07em col-g dis-block"><?php echo "작성자 : ".$row['mb_id'];?></span>
                                </a>
                            <?php 
                            echo "<div style = 'background:#eaeaea; padding:7px;border-radius:10px'>";
                            echo $row['wr_content'];
                            echo "</div>";
                            ?>
                       		</li>-->
                            <?php 
                            }
                    }
                	?>
                </ul>
            </div>
        </section>
    </div>

<?php include_once('./tail.php'); ?>