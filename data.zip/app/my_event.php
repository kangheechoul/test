<?php
include_once('./_common.php');
include_once('./head.sub.php');

$ev_id = $_REQUEST['ev_id'];


$evitemsql = "select *,ev.ev_id as id from {$g5['g5_shop_event_table']} as ev left join {$g5['g5_shop_event_item_table']} as ev_it on ev.ev_id = ev_it.ev_id where ev.ev_id = '".$ev_id."'"; 
$evitemrow = sql_fetch($evitemsql);


?>
<link rel="stylesheet" href="<?php echo G5_APP_URL ?>/css/mypage.css">
<body>
    <div class="wrap">
        <div class="head flex-c-m">
            <a href="javascript:;" class="back_btn" id="cancel"><i class="material-icons">arrow_back_ios</i></a>
            <h2>이벤트</h2>
        </div>
        <section class="sec_1">
            <div class="container min-h-100 my_ul">
                <ul class="row">

                    <li class="col-12">
                        <a  href="./menu.php?it_id=<?= $evitemrow['it_id']?>">
                            <?= $evitemrow['ev_subject']?>
                            <span class="date font-07em col-g dis-block"><?php if($evitemrow['ev_use'] == 1) echo "진행중인 이벤트"; else "종료된 이벤트";?></span>
                        </a>
                    </li>
                    
                    
                    <li class="board">
						<img src="<?php echo G5_DATA_URL."/event/".$evitemrow['id']."_h"?>" onerror="$(this).css('display','none');" alt="이벤트  상단베너">
						<img src="<?php echo G5_DATA_URL."/event/".$evitemrow['id']."_t"?>" onerror="$(this).css('display','none');" alt="이벤트  하단베너">
						
						<?php
						if($evitemrow['ev_head_html'] != "")
						{
						  echo $evitemrow['ev_head_html']; 
						}
						if($evitemrow['ev_tail_html'] != "")
						{
						    echo $evitemrow['ev_tail_html'];
						}
						?>
                    </li>
                    
                    <?php                     
                    if($evitemrow['it_id'] != "")
                    {
                        ?>
                        <li class="col-12 text-center">
                        <a class="btn w-full bg-gr" style="color:#fff;" href="./menu.php?it_id=<?= $evitemrow['it_id']?>">
                            주문하러가기
                        </a>
                    	</li>
                        <?php 
                    }
                ?>
                    
                </ul>
            </div>
        </section>
    </div>
    <?php include_once('./tail.php'); ?>

