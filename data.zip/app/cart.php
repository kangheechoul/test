<?php
include_once('./_common.php');
include_once('./head.sub.php');

if ($is_member == "")
{
    echo "<script>
        alert('로그인해주세요','".G5_APP_URL."/login.php');
</script>";
    
}

//ss_cart_id = 세션에 유지(로그인시 생긴다)

$cartsql = "select * from {$g5['g5_shop_cart_table']} where od_id = '".$_SESSION['ss_cart_id']."' and ct_status = '주문'";
$cartres = sql_query($cartsql);

?>
<link rel="stylesheet" href="<?php echo G5_APP_URL ?>/css/order.css">
<style>
.col-12 {margin-bottom:10px; border-bottom:2px solid #efefef}
li h5{padding-top:10px}


</style>
<body>
    <div class="wrap">
       <form id = "payment_form" name = "payment_form" action= "./order.php" method= "POST">
    	<!-- <input type = "hidden" id = "deliprice" name = "deliprice" value = "<?php if($_REQUEST['type'] == "delivery") echo 2000; else echo 0; ?>"> -->
            <div class="head flex-c-m">
            <a href="javascript:location.href='./menu_list.php'" class="back_btn"><i class="material-icons">arrow_back_ios</i></a>
            	<h2>주문하기</h2>
        	</div>
        	
        
        <script>
        function cart_delete(it_id)
        {
    		$.ajax({
				url : "./controllor/cart_del.php",
				type : "POST",
				data: {
						it_id : it_id
					},
					success : function(data)
					{
						alert('삭제완료');
						$('section #'+it_id).remove();
						allprice();
						var od_qty = Number($("#od_qty").text()-1);
						$("#od_qty").text(od_qty);
						$("input[name='od_qty']").val(od_qty);
					}    
    
    			});
        }

        </script>
		
		<section class="sec_1">
		<div class="container">
			<ul class="row">
        <?php 
        
        for($i = 0; $cartrow = sql_fetch_array($cartres);$i++)
        {
            ?>   
            
                <li class="col-12 price" id = "<?= $cartrow['it_id']?>">
                    <h5 id = "menuname<?= $i?>"><?= $cartrow['it_name'];?><span class="float-r"><i class="material-icons" onclick = "cart_delete('<?= $cartrow['it_id']?>');">close</i></span></h5>
                    <span class="date">* <?= $cartrow['it_name']. " : " . number_format($cartrow['ct_price'])." 원"; ?></span>
                    <?php
                    $io_id = "";
                    $io_price = "";
                    $io_all_price = 0;
                        if($cartrow['ct_option'] != "")
                        {
                            $io = explode(';', $cartrow['ct_option']);
                            
                            for($j = 0 ; $j < count($io)-1; $j++)
                            {
                                $io_ex = explode(':', $io[$j]);
                                $io_id .= $io_ex[1].";";
                                $io_price .= $io_ex[2].";";
                            }
                            $io_id_ex = explode(';', $io_id);
                            $io_price_ex = explode(';', $io_price);
                            for($j = 0; $j < count($io_id_ex)-1;$j++)
                            {
                                ?>
                            	<span class="date">* <?= $io_id_ex[$j]. " : " . number_format($io_price_ex[$j])." 원";?></span>    
                                <?php 
                                $io_all_price += $io_price_ex[$j];
                            }
                        }
                    ?>
                    
                    <div class="innter flex-sb-m">
                        <dl class="flex-sb-m">
                            <dt>
                            	<input type= "hidden" id = "it_id<?= $i?>" name = "it_id[]" value = "<?= $cartrow['it_id']?>">
                            	<input type= "hidden" id = "it_name<?= $i?>" name = "it_name[]" value = "<?= $cartrow['it_name']?>">
                            	<input type= "hidden" id = "ct_id<?= $i?>" name = "ct_id[]" value = "<?= $cartrow['ct_id']?>"> 
                            	<input type = "hidden" id = "ct_price<?= $i?>" name = "ct_price[]" value = "<?= $cartrow['ct_price']?>">
                            	<input type = "hidden" id = "ct_qty<?= $i?>" name = "ct_qty[]" value = "<?= $cartrow['ct_qty']?>">
                            	<input type= "hidden" id = "ct_option<?= $i?>" name = "ct_option[]" value ="<?= $cartrow['ct_option']?>">
                            	<input type = "hidden" id = "io_all_price<?= $i?>" name = "io_all_price[]" value= "<?= $io_all_price?>">
                                <input type ="hidden" id = "ct_all_price<?= $i?>" name = "ct_all_price[]" value = "<?= $cartrow['ct_price']*$cartrow['ct_qty'] + $cartrow['io_price']?>">
                                <p class="font-1em" id = "ct_view_price<?= $i?>"><?= number_format($cartrow['ct_price']*$cartrow['ct_qty']+$cartrow['io_price'])?></p>
                                
                            </dt>
                            <dd class="flex-sb-m">
                                <button type="button" onClick="decrease(<?= $i?>)" style="border: none; background-color: transparent; font-size: 1.5em;">-</button>
                                <p class="font-1em"><a id="clicks<?= $i?>" name = "clicks[]" class="m-r-20 m-l-20"><?= $cartrow['ct_qty'];?></a></p>
                                <button type="button" onClick="increase(<?= $i?>)" style="border: none; background-color: transparent; font-size: 1.5em;">+</button>
                            </dd>
                            
                        </dl>
                    </div>
                </li>
            
            <?php 
        }
        ?>
		</ul>
		</div>
		<div class="container">
                <dl class="flex-sb-m">
                    <dt>
                        총 주문금액
                    </dt>
                    <dd id = "ct_all_view_price">
                        원
                    </dd>
                </dl>
                
                <?php 
                if($_REQUEST['type'] == "delivery")
                {
                    ?>
                		<dl class="flex-sb-m">
                    <dt>
                     		   배달비
                    </dt>
                    <dd>
                        2,000 원
                    </dd>
                </dl>    
                    <?php 
                }
                ?>
                
                <dl class="flex-sb-m">
                    <dt>
                        결제 금액
                    </dt>
                    <dd id = "ct_pay_price">
                         원
                    </dd>
                </dl>
            </div>
       		</section>
            
        	<input type= "hidden" value ="<?= $i?>" name= "od_qty">
			</form>
        <button class="btn btn-red" onclick="form_submit()"><span class="cir" id = "od_qty"><?=$i?></span> <span id ="last_payment"></span>원 주문</button>
		
       	</div>
		
        
        <script>
        var menucount = $('.price').length;
        var it_id = new Array();
		var it_name = new Array();
		var ct_qty = new Array();
		var ct_price = new Array();

		function form_submit()
		{
			if(Number($('#last_payment').text()) != 0)
			{
				payment_form.submit();
			}
			else
			{
				alert("상품이 없습니다");
			}
		}
		

        $(window).on("beforeunload", function(){
        	for(var i = 0; i < menucount; i++)
    		{
    			it_id[i] = $('input[name="it_id[]"]').eq(i).val();
    			it_name[i] = $('input[name="it_name[]"]').eq(i).val();
    			ct_qty[i] = $('input[name="ct_qty[]"]').eq(i).val();
    			ct_price[i] = $('input[name="ct_price[]"]').eq(i).val();
    		}
            $.ajax({
                url : "./controllor/cart_update.php",
                type : "POST",
                data : {
						it_id : JSON.stringify(it_id),
						it_name : JSON.stringify(it_name),
						ct_qty : JSON.stringify(ct_qty),
						ct_price :JSON.stringify(ct_price)
                    },
                success : function(result)
                {
                }
                });
        });
        				
						allprice();
						function allprice()
						{
							
							for(var i = 0; i < menucount; i++)
							{
								var ct_price = Number($('#ct_price' + i).val());
								var io_price = Number($('#io_all_price' + i).val());
								var ct_qty = Number($('#ct_qty'+i).val());
								var item_price = Number(ct_price * ct_qty) + Number(io_price);
								$('#ct_all_price'+i).val(item_price);
								$('#ct_view_price'+i).text(item_price.toLocaleString() + " 원");
							}
							set_pay();
						}


						function set_pay()
						{
							var price = 0;
							for(var i = 0; i < menucount; i++)
							{
								if($('#ct_all_price'+i).length)
								{
    								price += Number($('#ct_all_price'+i).val());
								}
							}
							
							//var deliprice = Number($('#deliprice').val());

							$('#ct_all_view_price').text(price.toLocaleString() + " 원");
							$('#ct_view_price').text(price.toLocaleString() + " 원");
							$('#ct_pay_price').text(price.toLocaleString() + " 원");
							$('#last_payment').text(price.toLocaleString());
							
						}

				         
                        function increase(num) 
                        {
							var ct_price = Number($('#ct_price' + num).val());
							var io_price = Number($('#io_all_price' + num).val());
							var ct_qty = Number($('#ct_qty'+num).val());
							
							let clicks = Number($('#clicks'+num).text());
                            clicks += 1;

                            var item_price = Number(ct_price * clicks) + io_price;
                            $('#clicks' + num).text(clicks);
                            $('#ct_qty' + num).val(clicks);
							$('#ct_all_price'+num).val(item_price);
							$('#ct_view_price'+num).text(item_price.toLocaleString() + " 원");
							set_pay();
                        }
                        
                        function decrease(num) 
                        {
                        	var ct_price = Number($('#ct_price' + num).val());
							var io_price = Number($('#io_all_price' + num).val());
							var ct_qty = Number($('#ct_qty'+num).val());
							
                        	let clicks = Number($('#clicks'+num).text());
                        	
                            if(clicks <= 1){
                                clicks = 1;
                                alert('최소주문은 1인분 입니다.');
                            }
                            else
                            {
                                clicks -= 1;
                                var item_price = Number(ct_price * clicks) + io_price;
                                $('#clicks' + num).text(clicks);
                                $('#ct_qty' + num).val(clicks);
    							$('#ct_all_price'+num).val(item_price);
    							$('#ct_view_price'+num).text(item_price.toLocaleString() + " 원");
    							set_pay();
                            }
                            
                        }
                    </script>
        
        
        
