<?php
include_once('./_common.php');
include_once('./head.sub.php');
$login_action_url = G5_APP_URL."/login_check.php";

// KAKAO LOGIN
$sql = "select * from {$g5['config_table']}";
$row = sql_fetch($sql);
define('KAKAO_CLIENT_ID', $row['cf_kakao_rest_key']);
define('KAKAO_CLIENT_SECRET', $row['cf_kakao_client_secret']); // 필수 아님
define('KAKAO_CALLBACK_URL', G5_APP_URL."/controllor/login_kakao.php"); // 콜백URL

// 카카오 로그인 접근토큰 요청 예제
$kakao_state = md5(microtime() . mt_rand()); // 보안용 값
$_SESSION['kakao_state'] = $kakao_state;
$kakao_apiURL = "https://kauth.kakao.com/oauth/authorize?client_id=".KAKAO_CLIENT_ID."&redirect_uri=".urlencode(KAKAO_CALLBACK_URL)."&client_secret=".KAKAO_CLIENT_SECRET."&response_type=code&state=".$kakao_state;

define('NAVER_CLIENT_ID', $row['cf_naver_clientid']);
define('NAVER_CLIENT_SECRET', $row['cf_naver_secret']);
define('NAVER_CALLBACK_URL', G5_APP_URL.'/controllor/login_naver.php'); 

$naver_state = md5(microtime() . mt_rand());
$_SESSION['naver_state'] = $naver_state;
$naver_apiURL = "https://nid.naver.com/oauth2.0/authorize?response_type=code&client_id=".NAVER_CLIENT_ID."&redirect_uri=".urlencode(NAVER_CALLBACK_URL)."&state=".$naver_state;

?>
<style>
.easy-login button{width:50% !important}
label {padding-left:0px !important}

</style>

<link rel="stylesheet" href="<?php echo G5_APP_URL ?>/css/mypage.css">
<body>
    <div class="wrap">
        <div class="head flex-c-m">
            <a href="javascript:" class="back_btn" id="cancel"><i class="material-icons">arrow_back_ios</i></a>
            <h2>로그인</h2>
        </div>

        <section class="sec_1">
            <div class="container min-h-f log_in">
                <div class="logo-wrap">
                    <img src="<?php echo G5_APP_URL ?>/img/mimicook-logo.png" alt="logo">
                </div>

                <div class="row">
                    <form name="flogin" action="<?php echo $login_action_url ?>" onsubmit="return flogin_submit(this);" method="post">
						<div class="col-12"><input type="text" name="mb_id" placeholder="아이디 입력"></div>
                        <div class="col-12"><input type="password" name="mb_password" placeholder="비밀번호 입력"></div>
                        <div class="col-12 check_wrap flex-sb-m">
                        
                        <label for="auto_login"><input type="checkbox" id="auto" onchange = "ch()" checked>자동 로그인</label>
                        <input type ="hidden" id="auto_login" name="auto_login" value = "on">
							
                            <script>
							function ch()
							{
								if($('#auto').is(':checked',true))
								{
									$('#auto_login').val('');
								}
								else
								{
									$('#auto_login').val('on');
								}
							}
                            </script>
                             <?php
                            //소셜로그인 사용시 소셜로그인 버튼
                            //@include_once(get_social_skin_path().'/social_login.skin.php');
                            ?>
							
							<div class="find flex-sb-m">
                                <a href="<?php echo G5_APP_URL ?>/find_id.php" class="m-r-10">아이디 찾기</a>
                                <a href="<?php echo G5_APP_URL ?>/find_pw.php">비밀번호 찾기</a>
                            </div>
						</div>
						
						<!-- 
                        <div class="inner flex-sb-m">
                            <input type="checkbox" id="login" class="check">
                            <label for="login">
                                자동 로그인
                                <i class="material-icons">check_box_outline_blank</i>
                                <i class="material-icons">check_box</i>
                            </label>

                            <div class="find flex-sb-m">
                                <a href="<?php echo G5_APP_URL ?>/find_id.php" class="m-r-10">아이디 찾기</a>
                                <a href="<?php echo G5_APP_URL ?>/find_pw.php">비밀번호 찾기</a>
                            </div>
                        </div>
                        -->
                        <div class="col-12"><button class="btn btn-block btn-secondary">로그인</button></div>
                        
                        
                    </form>
                    <div class="easy-login flex-sb-m m-t-20 m-b-10">
                            <button onclick = "naver()"><img src="<?php echo G5_APP_URL ?>/img/i-naver.png" alt="네이버">로그인</button>
                            <button onclick = "kakao()"><img src="<?php echo G5_APP_URL ?>/img/i-kakao.png" alt="카카오">로그인</button>
                            <!-- <button onclick = "google()"><img src="<?php echo G5_APP_URL ?>/img/i-google.png" alt="구글">로그인</button> -->
                        </div>
                        
                        <a href="<?php echo G5_APP_URL ?>/join.php" class="new">mimicook이 처음이신가요?<span class="col-r">회원가입</span></a>
                </div>
            </div>
        </section>
    </div>
    <script>
  /*   function google()
    {
    	location.href="https://accounts.google.com/o/oauth2/auth?client_id="+
    	"639928072119-ir8u45bo3br948irsqlcup2vr813l1v3.apps.googleusercontent.com"+
    	"&redirect_uri="+
    	"https://mimicook.kr/app/login_google.php" +
    	"&response_type=code&scope=https://www.googleapis.com/auth/userinfo.email&approval_prompt=force&access_type=offline";
    } */

    function kakao()
    {
		location.href = "<?=$kakao_apiURL;?>";
    }

    function naver()
    {
		location.href ="<?= $naver_apiURL?>";
    }
    
   
</script>

	
<?php include_once('./tail.php'); ?>
