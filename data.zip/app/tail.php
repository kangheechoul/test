<?php 
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가
?>
<div class="btn_wrap flex-sb-m">
	<a id="home" href="<?php echo G5_APP_URL ?>"><i class="material-icons">home<span>Home</span></i></a>
	<a id="search" href="<?php echo G5_APP_URL ?>/search.php"><i class="material-icons">search<span>검색</span></i></a>
	<a id="list" href="<?php echo G5_APP_URL ?>/menu_list.php"><i class="material-icons">list<span>메뉴리스트</span></i></a>
	<a id="pick" href="<?php echo G5_APP_URL ?>/pick_list.php"><i class="material-icons">star<span>찜</span></i></a>
	<a id="my" href="<?php echo G5_APP_URL ?>/my_home.php"><i class="material-icons">face<span>My</span></i></a>
</div>

<?php
include_once(G5_PATH."/tail.sub.php");
?>

<script>
        $(function(){
            const queryString = window.location.pathname
            if(queryString == '/app/search.php'){
                $('#search').addClass('active')
            }else if(queryString == '/app/'){
                $('#home').addClass('active')
            }else if(queryString == '/app/menu_list.php'){
                $('#list').addClass('active')
            }else if(queryString == '/app/pick_list.php'){
                $('#pick').addClass('active')
            }else if(queryString == '/app/my_home.php'){
                $('#my').addClass('active')
            }
        });
</script>