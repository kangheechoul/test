<?php
include_once('./_common.php');
include_once('./head.sub.php');

if ($is_member == "")
{
    echo "<script>
        alert('로그인해주세요','".G5_APP_URL."/login.php');
</script>";
    
}

$mb_id = $_SESSION['ss_mb_id'];

$memsql = "select * from {$g5['member_table']} where mb_id = '".$mb_id."'";
$memrow = sql_fetch($memsql);

?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="<?php echo G5_APP_URL ?>/css/mypage.css">
<body>
    <div class="wrap">
        <div class="head flex-c-m">
            <a href="<?php echo G5_APP_URL ?>/my_1on1_list.php" class="back_btn" id="cancel"><i class="material-icons">arrow_back_ios</i></a>
            <h2>문의하기</h2>
        </div>
        
        <section class="sec_1">
			<div class="container">
            <nav>
                <div class="row row-col-2 text-center">
                    <a href="<?php echo G5_APP_URL ?>/my_1on1_write.php" class="col active">1:1 문의하기</a>
                    <a href="<?php echo G5_APP_URL ?>/my_my_1on1.php" class="col">나의 문의내역</a>
                </div>
            </nav>
            </div>
			
            <div class="container write">
                <form action="./controllor/my_1on1_write_submit.php" method="POST" enctype='multipart/form-data'>
                	<input type= "hidden" id = "img_check" name = "img_check" value = "1">
                	<input name = "qa_hp" id="qa_hp" type="hidden" value ="<?= $memrow['mb_hp']?>">
					<ul class="row">
						<li class="col-12">
							<dt>이름</dt><dd><input name = "qa_name" id="qa_name" type="text" placeholder="이름" value ="<?= $memrow['mb_name']?>"></dd>
						</li>
						<li class="col-12">
							<dt>이메일</dt><dd><input name = "qa_email" id="qa_email" type="email" placeholder="이메일" value = "<?= $memrow['mb_email']?>"></dd>
						</li>
						<li class="col-12">
							<dt>상담분류</dt>
							<dd>
								<select name="type" id="type" onchange ="typechange();">
                                    <option value="">선택안함</option>
                                    <option value="제품">제품</option>
                                    <option value="배송관련">배송관련</option>
                                    <option value="주문관련">주문관련</option>
                                </select>
							</dd>
						</li>
						<li class="col-12">
							<dt>제목</dt><dd><input name = "qa_subject" id= "qa_subject" type="text" placeholder="제목을 입력하세요" value= ""></dd>
						</li>
						<li class="col-12">
							<dt>내용</dt><dd><textarea name="qa_content" id="qa_content" rows="10"></textarea></dd>
						</li>
						<li class="col-12">
							<dt>파일첨부</dt>
							<div class="img-upload img-upload-main" style="overflow: hidden;">
                                            <span class="btn-wrap">
                                                <button class="btn-img-upload" href="#"><strong><i class="material-icons">camera_alt</i></strong></button>
                                                <input type="file" id="upload" name="qa_img" multiple="">
                                            </span> 				
                                            <label for="upload"></label>
                                        </div>
							<dd class="img-upload" style="overflow: hidden;">
                                <img id="productimg_temp" onerror="this.style.display='none'" alt="img_upload"/>
                                <button class="delete-btn" type="button"><i class="material-icons">close</i></button>
							</dd>
							<span class="dis-block font-07em">이미지 파일(GIF, PNG, JPG)을 기준으로 이미지당 10MB 이하, 최대 3개까지 등록 가능합니다.</span>
						</li>
					</ul>
					
                    <button class="btn w-full bg-gr" type = "submit" onclick = "this.form.submit()">문의하기</button>
                </form>
            </div>
        </section>
    </div>

    <script>

    
    $('input[name=qa_img]').on("change",handleImgfile);
    
    function handleImgfile(e)
    {
			var files = e.target.files;
			var filesArr = Array.prototype.slice.call(files);

			filesArr.forEach(function(f) {
				if(!f.type.match("image.*")){
					alert("확장자는 이미지 확장자만 가능합니다.");
					return;
				}

				sel_file=f;

				var reader = new FileReader();
				reader.onload = function(e) {
					$("#productimg_temp").attr("src",e.target.result);
				}
				$("#productimg_temp").show();
				reader.readAsDataURL(f);
			});
	}

    </script>