<?php 
include_once('./_common.php');

$mb_id = $_SESSION['ss_mb_id'];
$it_id = $_REQUEST['it_id'];


$sql = "select * from {$g5['g5_shop_cart_table']} where mb_id = '{$mb_id}' and it_id = '{$it_id}' and ct_status != '주문' and ct_status != '취소'";
$res = sql_query($sql);
$row = sql_num_rows($res);

echo $row;

?>