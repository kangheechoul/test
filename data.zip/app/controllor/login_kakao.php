<?php 
include_once('./_common.php');
include_once('../head.sub.php');
session_start(); 

// KAKAO LOGIN 

$sql = "select * from {$g5['config_table']}";
$row = sql_fetch($sql);


define('KAKAO_CLIENT_ID', $row['cf_kakao_rest_key']); 
define('KAKAO_CLIENT_SECRET', $row['cf_kakao_client_secret']); // 필수 아님 
define('KAKAO_CALLBACK_URL', G5_APP_URL."/controllor/login_kakao.php");
if ($_SESSION['kakao_state'] != $_GET['state']) 
{
    // 오류가 발생하였습니다. 잘못된 경로로 접근 하신것 같습니다
    echo "<script>alert('잘못된 경로로 접근','".G5_APP_URL."/login.php');</script>";
    //echo "<script>location.href='".G5_APP_URL."/login.php';</script>";
}
    if ($_GET["code"]) { 
        //사용자 토큰 받기 
        $code = $_GET["code"]; 
        $params = sprintf( 'grant_type=authorization_code&client_id=%s&redirect_uri=%s&client_secret=%s&code=%s', KAKAO_CLIENT_ID, KAKAO_CALLBACK_URL, KAKAO_CLIENT_SECRET,$code);
        $TOKEN_API_URL = "https://kauth.kakao.com/oauth/token"; 
        $opts = array( 
            CURLOPT_URL => $TOKEN_API_URL, 
            CURLOPT_SSL_VERIFYPEER => false, 
            CURLOPT_SSLVERSION => 1, // TLS 
            CURLOPT_POST => true, 
            CURLOPT_POSTFIELDS => $params, 
            CURLOPT_RETURNTRANSFER => true, 
            CURLOPT_HEADER => false ); 
        
        $curlSession = curl_init(); 
        curl_setopt_array($curlSession, $opts); 
        $accessTokenJson = curl_exec($curlSession); 
        curl_close($curlSession); 
        $responseArr = json_decode($accessTokenJson, true); 
        $_SESSION['kakao_access_token'] = $responseArr['access_token']; 
        $_SESSION['kakao_refresh_token'] = $responseArr['refresh_token']; 
        $_SESSION['kakao_refresh_token_expires_in'] = $responseArr['refresh_token_expires_in']; 
        //사용자 정보 가저오기 
        $USER_API_URL= "https://kapi.kakao.com/v2/user/me"; 
        $opts = array( 
            CURLOPT_URL => $USER_API_URL, 
            CURLOPT_SSL_VERIFYPEER => false, 
            CURLOPT_SSLVERSION => 1, 
            CURLOPT_POST => true, 
            CURLOPT_POSTFIELDS => false, 
            CURLOPT_RETURNTRANSFER => true, 
            CURLOPT_HTTPHEADER => array( "Authorization: Bearer " . $responseArr['access_token'] ) ); 
        
            $curlSession = curl_init(); 
            curl_setopt_array($curlSession, $opts); 
            $accessUserJson = curl_exec($curlSession); 
            curl_close($curlSession); 
            $me_responseArr = json_decode($accessUserJson, true); 
            if ($me_responseArr['id']) 
            { 
                // 회원아이디(kakao_ 접두사에 네이버 아이디를 붙여줌) 
                $mb_uid = 'kakao_'.$me_responseArr['id']; 
                $mb_token = $responseArr['access_token'];
                // 회원가입 DB에서 회원이 있으면(이미 가입되어 있다면) 토큰을 업데이트 하고 로그인함
                
                $sql = "select * from {$g5['member_table']} where mb_id = '{$mb_uid}';";
                $res = sql_query($sql);
                $row = sql_num_rows($res);
                
                if ($row > 0) 
                { 
                    // 멤버 DB에 토큰값 업데이트
                    $sql = "UPDATE {$g5['memeber_table']} SET mb_token = '{$mb_token}' where mb_id = '{$mb_uid}';";
                    sql_query($sql);
                    
                    $_SESSION['ss_mb_id'] = $mb_uid;
                    list($microtime,$timestamp) = explode(' ',microtime());
                    $time = $timestamp.substr($microtime, 2, 3);
                    $_SESSION['ss_cart_id'] = date('YmdHis').substr($time,10,2);
                    echo "<script>alert('로그인 하셨습니다','".G5_APP_URL."');</script>";
                    //echo "<script>location.replace('".G5_APP_URL."')</script>";
                    
                } // 회원정보가 없다면 회원가입 
                else 
                { 
                    // 회원아이디 $mb_uid // properties 항목은 카카오 회원이 설정한 경우만 넘겨 받습니다. 
                    /* $mb_nickname = $me_responseArr['properties']['nickname']; // 닉네임 
                    $mb_profile_image = $me_responseArr['properties']['profile_image']; // 프로필 이미지
                    $mb_thumbnail_image = $me_responseArr['properties']['thumbnail_image']; // 프로필 이미지
                    $mb_email = $me_responseArr['kakao_account']['email']; // 이메일 $mb_gender = 
                    $me_responseArr['kakao_account']['gender']; // 성별 female/male 
                    $mb_age = $me_responseArr['kakao_account']['age_range']; // 연령대
                    $mb_birthday = $me_responseArr['kakao_account']['birthday']; // 생일 // 멤버 DB에 토큰과 회원정보를 넣고 로그인 */ 
                    
                    $mb_nick = $me_responseArr['kakao_account']['profile']['nickname'];
                    
                    $_SESSION['join_nick'] = $mb_nick;
                    $_SESSION['join_token'] = $mb_token;
                    $_SESSION['join_id'] = $mb_uid;
                    list($microtime,$timestamp) = explode(' ',microtime());
                    $time = $timestamp.substr($microtime, 2, 3);
                    $_SESSION['ss_cart_id'] = date('YmdHis').substr($time,10,2);
                    
                    $sns = "1";
                    echo "<script>alert('카카오로 회원가입','".G5_APP_URL."/join.php?sns={$sns}')</script>";
                    //echo "<script>location.replace('".G5_APP_URL."/join.php?sns={$sns}')</script>";
                    
                }
            } 
            else 
            {
                // 회원정보를 가져오지 못했습니다. 
                echo "<script>alert('회원정보를 가져오지 못했습니다','".G5_APP_URL."/join.php');</script>";
                //echo "<script>location.replace('".G5_APP_URL."/join.php')</script>";
            } 
    }


