<?php 
include_once('./_common.php');
include_once('../head.sub.php');

$it_id = $_POST['it_id'];
$it_name = $_POST['it_name'];
$it_price = $_POST['it_price'];
$it_qty = $_POST['it_qty'];
$item_option = $_POST['item_option'];

$tab = $_REQUEST['tab'];
$io_id = "";
$io_price = "";

$mb_id = $_SESSION['ss_mb_id'];
$od_id = $_SESSION['ss_cart_id'];

$check_sql = "select * from {$g5['g5_shop_cart_table']} where od_id = '{$od_id}' and mb_id = '{$mb_id}' and it_id = '{$it_id}' and ct_status ='주문'";
$check_res = sql_query($check_sql);
$check_row = sql_num_rows($check_res);

//이미 있는 아이템인지 검사
// 있을떄
if($check_row > 0)
{
    echo "<script>alert('장바구니에 있습니다' ,'../menu_list.php?tab=$tab')</script>";
    
}
else
{
    if($item_option != "")
    {
        $item_option_len = explode(';', $item_option);
        
        for($i = 0; $i < count($item_option_len)-1; $i++)
        {
            $io = explode(':',$item_option_len[$i]);
            $io_id .= $io[1].";";//이름
            $io_price += $io[2];//가격
        }
    }
    
    $nowtime = date("Y-m-d H:i:s");
    //사이드 메뉴가 여러개일시 정리 방법 필요
    
    //여러개 일시  -> it_id:io_id:io_price;
    
    $addcartsql = "insert into {$g5['g5_shop_cart_table']}
    (od_id, mb_id, it_id, it_name, ct_status, ct_price, ct_option, ct_qty, io_id, io_price, ct_time,ct_ip) value
    ('{$_SESSION['ss_cart_id']}', '{$_SESSION['ss_mb_id']}', '{$it_id}', '{$it_name}', '주문', '{$it_price}',
    '{$item_option}', '{$it_qty}', '{$io_id}', '{$io_price}', '{$nowtime}','$_SERVER[REMOTE_ADDR]')";
    
    
    sql_query($addcartsql);
    echo "<script>alert('장바구니에 추가하였습니다.','../menu_list.php?tab=$tab')</script>";
}

?>