<?php
include_once('./_common.php');
include_once('../head.sub.php');

$zip1 = $_REQUEST['addzip1'];
$zip2 = $_REQUEST['addzip2'];
$addr1 = $_REQUEST['addaddr1'];
$addr2 = $_REQUEST['addaddr2'];
$addr3 = $_REQUEST['addaddr3'];
$addr_jibeon = $_REQUEST['addjibeon'];

$checkaddrsql = "select * from {$g5['member_table']} where mb_id = '".$_SESSION['ss_mb_id']."'";
$checkaddrrow = sql_fetch($checkaddrsql);

    $addr_count_check_sql = "select * from {$g5['g5_shop_order_address_table']} where mb_id= '".$_SESSION['ss_mb_id']."'";
    $addr_count_check_res = sql_query($addr_count_check_sql);
    $addr_count_check_row = sql_num_rows($addr_count_check_res);
    
    
    if($addr_count_check_row > 5)
    {
        echo "<script>alert('주소5개가 이미 저장되어 있습니다.','../my_home.php');</script>";
    }
    else
    {
        $mem_addr_add_sql = "insert into {$g5['g5_shop_order_address_table']}
(mb_id, ad_name, ad_tel, ad_hp, ad_zip1, ad_zip2, ad_addr1, ad_addr2, ad_addr3, ad_jibeon)
 value ('{$_SESSION['ss_mb_id']}', '{$checkaddrrow['mb_name']}', '{$checkaddrrow['mb_tel']}', '{$checkaddrrow['mb_hp']}', '{$zip1}', '{$zip2}',
'{$addr1}', '{$addr2}', '{$addr3}', '{$addr_jibeon}')";
        
         if(sql_query($mem_addr_add_sql) === TRUE)
        {
            echo "<script>alert('주소등록이 완료되었습니다.','../my_home.php');</script>";
        }
        else
        {
            //echo "Error: " . $sql . "<br>" . $conn->error;
        } 
    }

?>