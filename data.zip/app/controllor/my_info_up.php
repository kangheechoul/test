<?php 
include_once('./_common.php');

$type = $_REQUEST['type'];
$pass = $_REQUEST['pass'];
$mb_id = $_REQUEST['id'];
$mb_email = $_REQUEST['email'];

$sql = "select * from {$g5['member_table']} where mb_id = '{$mb_id}';";
$row = sql_fetch($sql);

if(!check_password($pass, $row['mb_password']))
{
    echo "0";
}
else 
{
    if($type == "info")
    {
        $mb_nick = $_REQUEST['nick'];
        
        $nick_sql = "select * from {$g5['member_table']} where mb_nick = '{$mb_nick}';";
        $nick_res = sql_query($nick_sql);
        $nick_row = sql_num_rows($nick_res);
        
        if($nick_row > 0)
        {
            echo "1";
        }
        else
        {
                $nick_sql = "UPDATE {$g5['member_table']} SET mb_nick = '{$mb_nick}' where mb_id = '{$mb_id}'";
                sql_query($nick_sql);
                echo "2";
        }
    }
    
    if($type == "pass")
    {
        $new_pass = $_REQUEST['new_pass'];
        $new_repass = $_REQUEST['new_repass'];
        
        if($new_pass == $new_repass)
        {
            $new_pass = get_encrypt_string($new_pass);
            
            $pass_sql = "UPDATE {$g5['member_table']} SET mb_password = '{$new_pass}' where mb_id = '{$mb_id}'";
            sql_query($pass_sql);
            echo "3";
        }
        else
        {
            echo "4";
        }
    }
}
    


?>