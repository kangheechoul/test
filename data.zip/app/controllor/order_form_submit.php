        <script type="text/javascript">
            function cancelTid()
            {
                var form = document.frm;

                var win = window.open('', 'OnLine', 'scrollbars=no,status=no,toolbar=no,resizable=0,location=no,menu=no,width=600,height=400');
                win.focus();
                form.action = "http://walletpaydemo.inicis.com/stdpay/cancel/INIcancel_index.jsp";
                form.method = "post";
                form.target = "OnLine";
                form.submit();
            }
        </script>
<?php
        require_once('./stdpay/libs/INIStdPayUtil.php');
        require_once('./stdpay/libs/HttpClient.php');
        header('Content-Type: text/html; charset=utf-8');
        
        include_once('./_common.php');
        include_once('../head.sub.php');
        
            $util = new INIStdPayUtil();
            
            
            
            $merchantData = urldecode($_REQUEST['P_NOTI']);
            
            $info = array();
            
            $a = explode('&', $merchantData);
            $i = 0;
            while ($i < count($a)) {
                $b = split('=', $a[$i]);
                
                $info[htmlspecialchars(urldecode($b[0]))] = htmlspecialchars(urldecode($b[1]));
                $i++;
            }
            
            list($microtime,$timestamp) = explode(' ',microtime());
            $time = $timestamp.substr($microtime, 2, 3);
            
            
            $_SESSION['ss_mb_id'] = $info['mb_id'];
            $_SESSION['ss_cart_id'] = date('YmdHis').substr($time,10,2);
            $_SESSION['ss_mb_key'] = $info['mb_key'];
            
            try {
                //#############################
                // 인증결과 파라미터 일괄 수신
                //#############################
                //		$var = $_REQUEST["data"];
                
                //#####################
                // 인증이 성공일 경우만
                //#####################
                
                //모바일 결제 성공
                if($_POST['P_STATUS'] === '00')
                {
                    
                    $ch = curl_init();
                    
                    curl_setopt($ch, CURLOPT_URL, $_POST['P_REQ_URL']);
                    
                    curl_setopt($ch, CURLOPT_POST, true);
                    
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    
                    curl_setopt($ch, CURLOPT_POSTFIELDS, 'P_MID=INIpayTest&P_TID='.$_POST['P_TID']) ; // 여기 수정
                    
                    $result = curl_exec($ch);
                    
                    $result = iconv("EUC-KR", "UTF-8", $result);
                    
                    parse_str($result, $info);
                    
                    $info['mb_id'] = str_replace("mb_id=", "" , $info['P_NOTI']);
                    
                    /*  foreach($info as $key=>$value)
                     {
                     echo $key . " : " . $value . "<br>";
                     } */
                    
                    if($info['P_STATUS'] == 00)
                    {
                        
                        if($info['P_TYPE'] == "CARD")
                        {
                            $info['od_settle_case'] = "카드";
                            $info['od_bank_account'] = $info['P_FN_NM']." ".$info['P_CARD_NUM'];
                            $info['od_misu'] = "0";
                            $info['od_status'] = "입금";
                            $info['od_receipt_price'] = $info['od_cart_price'] + $info['od_delivery_pay'];
                            
                        }
                        else if($info['P_TYPE'] == "VBANK")
                        {
                            $info['od_settle_case'] = "무통장";
                            $info['od_bank_account'] = $info['P_FN_NM']."|".$info['P_VACT_NUM']."|".$info['P_VACT_NAME'];
                            $info['od_status'] = "주문";
                            $info['od_misu'] = $info['od_cart_price']+$info['od_delivery_pay'];
                            $info['od_receipt_price'] = "0";
                        }
                        else if($info['P_TYPE'] == "BANK")
                        {
                            $info['od_settle_case'] = "계좌이체";
                            $info['od_bank_account'] = $info['P_FN_NM'];
                            $info['od_misu'] = "0";
                            $info['od_status'] = "입금";
                            $info['od_receipt_price'] = $info['od_cart_price'] + $info['od_delivery_pay'];
                        }
                        
                        
                        $sql = "
INSERT INTO {$g5['g5_shop_order_table']} (od_id, mb_id, od_name, od_email, od_hp, od_zip1, od_zip2, od_addr1, od_addr2,od_addr3,
od_addr_jibeon, od_deposit_name, od_memo, od_cart_count, od_cart_price, od_misu, od_status, od_time, od_pwd, od_ip, pl_id, od_it_list,od_it_option,od_delivery_pay
,od_settle_case, od_tax_mny, od_vat_mny, od_bank_account,od_receipt_price, od_send_cost, od_type, od_sale_price)
VALUE (
'{$info['od_id']}','{$info['mb_id']}','{$info['od_name']}','{$info['od_email']}','{$info['od_hp']}','{$info['od_zip1']}','{$info['od_zip2']}',
'{$info['od_addr1']}','{$info['od_addr2']}','{$info['od_addr3']}','{$info['od_addr_jibeon']}','{$info['od_name']}','{$info['od_memo']}','{$info['od_cart_count']}'
,'{$info['od_cart_price']}','{$info['od_misu']}','{$info['od_status']}','{$info['od_time']}','{$info['od_pwd']}','{$info['od_ip']}','{$info['pl_id']}', '{$info['od_it_list']}','${info['od_it_option']}','{$info['od_delivery_pay']}'
,'{$info['od_settle_case']}', '{$info['od_tax_mny']}', '{$info['od_vat_mny']}', '{$info['od_bank_account']}', '{$info['od_receipt_price']}', '{$info['od_delivery_pay']}', '{$info['od_type']}', '{$info['od_sale_price']}');";
                        
                        sql_query($sql);
                        
                        //cart 업데이트 (옵션은 중간 수정 불가로 수정 필요 x)
                        
                        $od_it_list = explode(';',$info['od_it_list']);
                        
                        $cart_up_sql = "UPDATE {$g5['g5_shop_cart_table']} SET";
                        
                        
                        $ini_sql = "INSERT INTO {$g5['g5_shop_inicis_log_table']}
                    (oid, P_TID, P_MID, P_AUTH_DT, P_STATUS, P_TYPE, P_OID, P_FN_NM, P_AUTH_NO, P_AMT, P_RMESG1)
                    VALUE
                    ('{$info['od_id']}','{$info['P_TID']}','{$info['P_MID']}','{$info['P_AUTH_DT']}','{$info['P_STATUS']}',
                    '{$info['P_TYPE']}','{$info['P_OID']}','{$info['P_FN_NM']}','{$info['P_AUTH_NO']}','{$info['P_AMT']}','{$info['P_RMESG1']}')";
                        
                        sql_query($ini_sql);
                        
                        //개수를 업데이트
                        $case = array('ct_qty');
                        
                        $status = "입금";
                        
                        //무통장입금일 경우 상태 업데이트 필요 x
                        if($info['P_TYPE'] != "VBANK")
                        {
                            $case[] = 'ct_status';
                        }
                        
                        for($j = 0; $j < count($case); $j++)
                        {
                            $case_sql .= " {$case[$j]} = CASE it_id ";
                            
                            for($i = 0; $i < count($od_it_list)-1; $i++)
                            {
                                $it_list_tmp = explode(':',$od_it_list[$i]);
                                
                                $list_id = $it_list_tmp[0];
                                $list_name = $it_list_tmp[1];
                                $list_price = $it_list_tmp[2];
                                $list_qty = $it_list_tmp[3];
                                if($case[$j] == "ct_qty")
                                {
                                    $case_sql .= "WHEN '{$list_id}' THEN '{$list_qty}' ";
                                }
                                if($case[$j] == "ct_status")
                                {
                                    $case_sql .= "WHEN '{$list_id}' THEN '{$status}' ";
                                }
                            }
                            
                            $case_sql .= " end";
                            if($j != count($case)-1)
                            {
                                $case_sql .= ",";
                            }
                        }
                        
                        $cart_up_sql .= $case_sql;
                        
                        $where = " where od_id = '{$info['od_id']}' and mb_id = '{$info['mb_id']}';";
                        
                        
                        $cart_up_sql .= $where;
                        
                        sql_query($cart_up_sql);
                        
                        echo "<script>alert('결제에 성공했습니다','../order_result.php?od_id={$info['od_id']}')</script>";
                        //echo "<script>location.replace('../order_result.php?od_id={$info['od_id']}')</script>";
                    }
                    else
                    {
                        echo "<script>alert('결제에 실패했습니다','../menu_list.php')</script>";
                        //echo "<script>location.replace('../menu_list.php')</script>";
                    }
                    
                    curl_close($ch);
                }
                else
                {
                    //#############
                    // 인증 실패시
                    //#############
                    //echo "<br/>";
                    //echo "####인증실패####";
                    $_SESSION['ss_cart_id'] = $info['od_id'];
                    echo "<script>alert('결제에 실패했습니다','../menu_list.php')</script>";
                    //echo "<script>location.replace('../menu_list.php')</script>";
                    //echo "<script>history.back();</script>";
                    //                echo "<pre>" . var_dump($_REQUEST) . "</pre>";
                }
            } catch (Exception $e) {
                $s = $e->getMessage() . ' (오류코드:' . $e->getCode() . ')';
                //          echo $s;
            }
            
        
        
?>