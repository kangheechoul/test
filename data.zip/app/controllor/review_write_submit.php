<?php 
include_once('./_common.php');
include_once('../head.sub.php');

$mb_id = $_SESSION['ss_mb_id'];

$mb_sql = "select * from {$g5['member_table']} where mb_id = '{$mb_id}';";

$mb_row = sql_fetch($mb_sql);

$mb_nick = $mb_row['mb_nick'];
$it_id = $_REQUEST['it_id'];
$is_name = $_REQUEST['is_name'];
$is_score = $_REQUEST['is_score'];
$is_time = $_REQUEST['is_time'];
$is_content = $_REQUEST['is_content'];
$is_img_check = $_REQUEST['is_img_check'];


//새 이미지 사용
if($is_img_check != "0")
{
    if ($_FILES['is_img']['name']) {
        
        $uploads_dir = "../data/review/";
        $allowed_ext = array('jpg','jpeg','png','gif');
        $target_file = $uploads_dir . basename($_FILES["is_img"]["name"]);
        $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
        for($i = 0; $i < sizeof($allowed_ext); $i++) {
            if($imageFileType == $allowed_ext[$i]) {
                $uploadOk = 1;
            }
        }
        if(!$uploadOk) {
            
            echo "<script>alert('이미지 파일 형식이 아닙니다. (적용가능 형식 : jpg, jpeg, png, gif)');</script>";
            exit;
        }
        
        if(!is_dir($uploads_dir)) {
            mkdir($uploads_dir);
        }
        //그냥 파일명
        $img_file_name = $_FILES['is_img']['name'];
        
        //파일명 추출을 위한 배열 생성
        $file_type_check = explode('.',$img_file_name);
        
        for($i = 0; $i < count($file_type_check)-1; $i++){
            $real_filename .= $file_type_check[$i];
        }
        
        $i = 0;
        while($exists_flag != 1) {
            if(!file_exists($uploads_dir.$real_filename.'['.$i.'].'.$imageFileType)) {
                $exists_flag = 1;
                $is_img = $real_filename.'['.$i.'].'.$imageFileType;
            }
            $i++;
        }
        move_uploaded_file($_FILES['is_img']['tmp_name'], $uploads_dir.$is_img);
        $is_img = "/review/$is_img";
        
    }
}


$insertsql = "INSERT INTO {$g5['g5_shop_item_use_table']} (it_id, mb_id,mb_nick, is_name, is_score, is_content, is_time, is_img)
    VALUE('{$it_id}', '{$mb_id}', '{$mb_nick}','{$is_name}', '{$is_score}', '{$is_content}', '{$is_time}', '{$is_img}')";

sql_query($insertsql);


$item_sql = "select * from {$g5['g5_shop_item_table']} where it_id = '{$it_id}'";
$item_row = sql_fetch($item_sql);

//추가된 값 적용 후
$cnt = $item_row['it_use_cnt'];

$avg = $item_row['it_use_avg'];

$re_avg = $avg * $cnt;

$re_avg = $re_avg + $is_score;

$re_cnt = $cnt + 1;

$re_avg = $re_avg / $re_cnt;


$it_up_sql = "UPDATE {$g5['g5_shop_item_table']} SET it_use_cnt = '{$re_cnt}', it_use_avg = '{$re_avg}' where it_id = '{$it_id}'";

if(sql_query($it_up_sql) === TRUE)
{
    echo "<script>alert('리뷰를 작성하였습니다.','../review_result.php')</script>";
    //echo "<script>location.replace('../review_result.php')</script>";
}
else
{
    echo "<script>alert('리뷰 작성 실패','".G5_APP_URL."')</script>";
    //echo "<script>location.replace('".G5_APP_URL."')</script>";
}

?>