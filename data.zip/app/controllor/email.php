<?php 
include_once('./_common.php');

$type = $_REQUEST['type'];
$email = $_REQUEST['email'];

function GenerateString($length)
{
    //    $characters  = "0123456789";
    //    $characters .= "abcdefghijklmnopqrstuvwxyz";
    $characters .= "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    //$characters .= "_";
    
    $string_generated = "";
    
    $nmr_loops = $length;
    while ($nmr_loops--)
    {
        $string_generated .= $characters[mt_rand(0, strlen($characters) - 1)];
    }
    
    return $string_generated;
}

$check_email=preg_match("/^[_\.0-9a-zA-Z-]+@([0-9a-zA-Z][0-9a-zA-Z-]+\.)+[a-zA-Z]{2,6}$/i", $email);

if($check_email==true)
{
    $code = GenerateString(4);
    
    if($type == "id")
    {
        $text = "인증코드";
    }
    else
    {
        $text = "임시 비밀번호";
    }
    
    $to = $email;
    
    $subject = "mimicook 메일 인증";
    
    $contents = "{$text} : ".$code." 를 입력해주세요";
    
    $headers = "From: mimicook\n";
    
    $data['check'] = mail($to, $subject, $contents, $headers);
    
  
    if($data['check'])
    {
        $data['result'] = "1";
        $data['code'] = $code; 
        $data['msg'] = $text."를 발송하였습니다.";
        
        if($type == "pw")
        {
            $pass = get_encrypt_string($code);
            $sql = "UPDATE {$g5['member_table']} SET mb_password = '{$pass}' where mb_email = '{$email}'";
            sql_query($sql);
        }
    }
    else
    {
        $data['result'] = "2";
        $data['msg'] = $text." 발송 실패";
    }
}
else
{
    $data['result'] = "3";
    $data['msg'] = "이메일을 확인해주세요";
}

echo json_encode($data);


?>