<?php 
include_once('./_common.php');

$mb_id = $_SESSION['ss_mb_id'];
$od_id = $_SESSION['ss_cart_id'];

$it_id = $_REQUEST['it_id'];


$sql = "DELETE FROM {$g5['g5_shop_cart_table']} where od_id = '{$od_id}' and  mb_id = '{$mb_id}' and it_id = '{$it_id}'";

if(sql_query($sql) == TRUE)
{
    echo 0;
}
else 
{
    echo 1;    
}

?>