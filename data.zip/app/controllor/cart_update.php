<?php 
include_once('./_common.php');

$it_id = json_decode(str_replace("\\","",$_REQUEST['it_id']) , true);

$it_name = json_decode(str_replace("\\","",$_REQUEST['it_name']) , true);

$ct_qty = json_decode(str_replace("\\","",$_REQUEST['ct_qty']) , true);

$ct_price = json_decode(str_replace("\\","",$_REQUEST['ct_price']) , true);


//상품들의 가격 더하기
for($i = 0; $i < count($it_id); $i++)
{
    $it_list .= $it_id[$i].":".$it_name[$i].":".$ct_price[$i].":".$ct_qty[$i].";";
}

//cart 업데이트 (옵션은 중간 수정 불가로 수정 필요 x)

$od_it_list = explode(';',$it_list);

$cart_up_sql = "UPDATE {$g5['g5_shop_cart_table']} SET";

//개수를 업데이트
$case = array('ct_qty');

for($j = 0; $j < count($case); $j++)
{
    $case_sql .= " {$case[$j]} = CASE it_id ";
    
    for($i = 0; $i < count($od_it_list)-1; $i++)
    {
        $it_list_tmp = explode(':',$od_it_list[$i]);
        
        $list_id = $it_list_tmp[0];
        $list_name = $it_list_tmp[1];
        $list_price = $it_list_tmp[2];
        $list_qty = $it_list_tmp[3];
        
        $case_sql .= "WHEN '{$list_id}' THEN '{$list_qty}' ";
        
    }
    $case_sql .= " end";
    if($j != count($case)-1)
    {
        $case_sql .= ",";
    }
}

$cart_up_sql .= $case_sql;

$where = " where od_id = '{$_SESSION['ss_cart_id']}' and mb_id = '{$_SESSION['ss_mb_id']}';";

$cart_up_sql .= $where;

sql_query($cart_up_sql);

?>










