<?php 
include_once('./_common.php');
include_once('../head.sub.php');

$mb_id = $_SESSION['ss_mb_id'];
$qa_name = $_REQUEST['qa_name'];
$qa_email = $_REQUEST['qa_email'];
$qa_hp = $_REQUEST['qa_hp'];
$type = $_REQUEST['type'];
$qa_subject = $_REQUEST['qa_subject'];
$qa_conten = $_REQUEST['qa_content'];

$img_check = $_REQUEST['img_check'];

//새 이미지 사용
if($img_check != "0")
{
    if ($_FILES['qa_img']['name']) {
        
        
        $uploads_dir = "../data/1on1/";
        $allowed_ext = array('jpg','jpeg','png','gif');
        $target_file = $uploads_dir . basename($_FILES["qa_img"]["name"]);
        $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
        for($i = 0; $i < sizeof($allowed_ext); $i++) {
            if($imageFileType == $allowed_ext[$i]) {
                $uploadOk = 1;
            }
        }
        if(!$uploadOk) {
            echo "<script>alert('이미지 파일 형식이 아닙니다. (적용가능 형식 : jpg, jpeg, png, gif)');</script>";
            exit;
        }
        
        if(!is_dir($uploads_dir)) {
            mkdir($uploads_dir);
        }
        //그냥 파일명
        $img_file_name = $_FILES['qa_img']['name'];
        
        //파일명 추출을 위한 배열 생성
        $file_type_check = explode('.',$img_file_name);
        
        for($i = 0; $i < count($file_type_check)-1; $i++){
            $real_filename .= $file_type_check[$i];
        }
        
        $i = 0;
        while($exists_flag != 1) {
            if(!file_exists($uploads_dir.$real_filename.'['.$i.'].'.$imageFileType)) {
                $exists_flag = 1;
                $qa_img = $real_filename.'['.$i.'].'.$imageFileType;
            }
            $i++;
        }
        move_uploaded_file($_FILES['qa_img']['tmp_name'], $uploads_dir.$qa_img);
        $qa_img = "/1on1/$qa_img";
        
    }
}

$qa_datetime = date('Y-m-d H:i:s');
$qa_id_sql = "select qa_id from {$g5['qa_content_table']} order by qa_id desc limit 1";
$qa_id_row = sql_fetch($qa_id_sql);

$qa_num_sql = "select MIN(qa_num) as qa_num from {$g5['qa_content_table']}";
$qa_num_row = sql_fetch($qa_num_sql);

$qa_id = $qa_id_row['qa_id'] + 1;

$qa_num = $qa_num_row['qa_num']-1;

$qainsql = "insert into {$g5['qa_content_table']} (mb_id, qa_name, qa_email, qa_hp, qa_subject, qa_content, qa_datetime, qa_parent, qa_related, qa_num,qa_file1)
value ('{$mb_id}', '{$qa_name}', '{$qa_email}', '{$qa_hp}', '{$qa_subject}', '{$qa_conten}', '{$qa_datetime}', '{$qa_id}','{$qa_id}','{$qa_num}','{$qa_img}')";
if(sql_query($qainsql) === TRUE)
{
    echo "<script>alert('문의를 작성하였습니다.','../my_1on1_write_result.php')</script>";
    //echo "<script>location.replace('../my_1on1_write_result.php')</script>";
}
else
{
    echo "<script>alert('문의 작성 실패','".G5_APP_URL."')</script>";
    //echo "<script>location.replace('".G5_APP_URL."')</script>";
}
?>