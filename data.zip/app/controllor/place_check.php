<?php 
include_once('./_common.php');
$pl_id = $_REQUEST['pl_id'];



$ym = date('Ym');
$today = date('d');
$week_no = 1;
for( $i = 1; $i < $today; $i++ )
{
    $ts = mktime(0, 0, 0, date('n'), $i, date('Y'));
    if( date('w', $ts) == 0 )
    {
        $week_no++;
    } 
}

switch($week_no)
{
    case 1 : $week_no = "첫째주";break;
    case 2 : $week_no = "둘째주";break;
    case 3 : $week_no = "셋째주";break;
    case 4 : $week_no = "넷째주";break;
    
}
$day = date('Y-m-d');

$week_arr= Array('일','월','화','수','목','금','토');

$week_day  = $week_arr[date('w',strtotime($day))];

$time = date('H:i');

//쉬는 매장 목록
$pl_off = array();
//영업시간이 아닌 매장 목록
$pl_ready = array();

$pl_list = json_decode($_REQUEST['pl_list']);

for($i = 0; $i < count($pl_list); $i++)
{
    if($i != count($pl_list))
    {
        $sql_in .= "'".$pl_list[$i][7]."',";    
    }
    else
    {
        $sql_in .= "'".$pl_list[$i][7]."'";    
    }
}

$sql = "select * from {$g5['place_table']} where pl_id = '$pl_id'";
$row = sql_fetch($sql);

    //주의 쉬는날 구하기
    if(strpos($row['pl_period'], $week_no) !== false)
    {
        if(strpos($row['pl_week'], $week_day) !== false)
        {
            //쉬는날
            $pl_off[] = $row['pl_id'];
            echo "1";
        }
    }
    else
    {
        if(strtotime($row['pl_time']) < strtotime($time) && strtotime($time) < strtotime($row['pl_expire_time']) )
        {
            //영업중
            echo "0";
        }
        else
        {
            //영업 준비중
            $pl_ready[] = $row['pl_id'];
            echo "2";
        }
        
    }
?>

