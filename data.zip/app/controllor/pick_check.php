<?php 
include_once('./_common.php');

$it_id = $_REQUEST['id'];
$pick = $_REQUEST['pick'];

$picksql = "select * from {$g5['g5_shop_wish_table']} where mb_id = '".$_SESSION['ss_mb_id']."' and it_id = '"."$it_id"."'";
$pickres = sql_query($picksql);
$pickrow = sql_fetch_array($pickres);

$pickrowcount = sql_num_rows($pickres);

//데이터베이스 찜목록에 있는지 먼저 확인
//따로 확인할 컬럼이 없어 찜 해제하면 찜 시간을 0000-00-00 00:00:00 으로 바꾸기
$nowtime = date("Y-m-d H:i:s");

//시간이 0000-00-00 00:00:00 이 아니면 찜이 되어있는것
//목록에 없거나 시간이 0000-00-00 00:00:00 이면 찜이 되어있지 않은것
    //찜 목록에 없음 찜에 추가해야함 -> result = 찜 하기 (insert)
    
    //찜 해제 되어있음 - > 찜 하기
    
    //찜 되어있음  -> 찜 해제하기

$result['data'] = "";
if($pick == "rgb(255, 255, 34)") //찜 해제
{
    $pickupsql = "update {$g5['g5_shop_wish_table']} set wi_time = '0000-00-00 00:00:00' where mb_id = '".$_SESSION['ss_mb_id']."' and it_id = '".$it_id."'";
    $pickupres = sql_query($pickupsql);
    
    
    $result['data'] = "rgb(100,100,100)";
}
else// 찜하기
{
    if($pickrowcount == 0)
    {
        //찜 목록에 없음 찜에 추가해야함 -> result = 찜 하기 (insert)
        $pickinsql = "insert into {$g5['g5_shop_wish_table']} (mb_id, it_id, wi_time) value ('{$_SESSION['ss_mb_id']}', '{$it_id}', '{$nowtime}')";
        $pickinres = sql_query($pickinsql);
        $result['data'] = "rgb(255, 255, 34)"; 
    }
    else
    {
        $pickupsql = "update {$g5['g5_shop_wish_table']} set wi_time = '{$nowtime}' where mb_id = '".$_SESSION['ss_mb_id']."' and it_id = '".$it_id."'";
        $pickupres = sql_query($pickupsql);
        $result['data'] = "rgb(255, 255, 34)"; 
    }
}
/* else
{
    $pickupsql = "update {$g5['g5_shop_wish_table']} set wi_time = '0000-00-00 00:00:00' where mb_id = '".$_SESSION['ss_mb_id']."' and it_id = '".$it_id."'";
    $pickupres = sql_query($pickupsql);
    
    $result['data'] = "";
} */
   
echo json_encode($result);
?>