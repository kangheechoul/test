<?php 
include_once('./_common.php');


$num = $_REQUEST['num'];

$sql = "DELETE FROM {$g5['g5_shop_order_address_table']} WHERE ad_id = '{$num}'";


if(sql_query($sql) === TRUE)
{
    echo "삭제에 성공하였습니다";
}
else
{
    echo "삭제에 실패하였습니다";
}

?>