<?php 
include_once('./_common.php');

$od_no = $_REQUEST['od_id'];

//이니시스 환불 //
$sql = "select * from {$g5['g5_shop_inicis_log_table']} where oid = '{$od_no}'";
$row = sql_fetch($sql);

if($row['NOTI_TID'] != "")
{
    $tid = $row['P_TID'];
}
    

//step1. 요청을 위한 파라미터 설정
//키 변경 필요
//$key = "ItEQKi3rY7uvDS8l";  // INIpayTest 의 테스트 key
$key = "MkqiU3gaOSvdfVhZ";  // INIpayTest 의 테스트 key
$type = "Refund";
$paymethod = $row['rl_paymethod'];
$timestamp = date("YmdHis");
$clientIp = $row['mb_ip'];
$mid = "movmakecom";
//$tid = $row['rl_tid']; // 40byte 승인 TID 입력
$msg = "거래취소요청";

$hashData = hash("sha512",$key.$type.$paymethod.$timestamp.$clientIp.$mid.$tid); // hash 암호화

//step2. key=value 로 post 요청

$data = array(
    'type' => $type,
    'paymethod' => $row['rl_paymethod'],
    'timestamp' => $timestamp,
    'clientIp' => $row['mb_ip'],
    'mid' => "movmakecom",
    'tid' => $row['rl_tid'],
    'msg' => $msg,
    'hashData' => $hashData
);
if($paymethod == 'Vacct' || $paymethod == 'VBANK' || $paymethod == 'MOBILE' || $paymethod == 'HPP')
{
    $data['refundAcctNum'] = $row['rl_bank_num'];
    $data['refundBankCode'] = $row['rl_bank'];
    $data['refundAcctName'] = $row['rl_name'];
}


$url ="https://iniapi.inicis.com/api/v1/refund";  // 전송 URL

$ch = curl_init();                                                   //curl 초기화
curl_setopt($ch, CURLOPT_URL, $url);                        // 전송 URL 지정하기
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);     //요청 결과를 문자열로 반환
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);      //connection timeout 10초
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));       //POST data
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded; charset=utf-8')); // 전송헤더 설정
curl_setopt($ch, CURLOPT_POST, 1);                          // post 전송

$response = curl_exec($ch);
curl_close($ch);

$result = json_decode($response, true);

?>