<?php 
include_once('./_common.php');
include_once('../head.sub.php');
session_start();

// KAKAO LOGIN

$sql = "select * from {$g5['config_table']} where cf_title='시작'";
$row = sql_fetch($sql);


define('GOOGLE_CLIENT_ID', "639928072119-ir8u45bo3br948irsqlcup2vr813l1v3.apps.googleusercontent.com");
define('GOOGLE_CLIENT_SECRET', "HfKcEDst7Q3CPV6eZ8EJQxqb"); // 필수 아님
define('GOOGLE_CALLBACK_URL', G5_APP_URL."/login_google.php");

if ($_GET["code"]) {
    //사용자 토큰 받기
    $code = $_GET["code"];
    $params = sprintf( 'grant_type=authorization_code&client_id=%s&redirect_uri=%s&client_secret=%s&code=%s', GOOGLE_CLIENT_ID, GOOGLE_CALLBACK_URL, GOOGLE_CLIENT_SECRET,$code);
    $TOKEN_API_URL = "https://accounts.google.com/o/oauth2/token";
    $opts = array(
        CURLOPT_URL => $TOKEN_API_URL,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSLVERSION => 1, // TLS
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $params,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HEADER => false );
    $curlSession = curl_init();
    curl_setopt_array($curlSession, $opts);
    $accessTokenJson = curl_exec($curlSession);
    curl_close($curlSession);
    $responseArr = json_decode($accessTokenJson, true);
    $_SESSION['google_access_token'] = $responseArr['access_token'];
    $_SESSION['google_refresh_token'] = $responseArr['refresh_token'];
    $_SESSION['google_expires_in'] = $responseArr['expires_in'];
    
    
    //사용자 정보 가저오기
    $USER_API_URL= "https://www.googleapis.com/oauth2/v3/userinfo";
    $opts = array(
        CURLOPT_URL => $USER_API_URL,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSLVERSION => 1,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => false,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => array( "Authorization: Bearer " . $responseArr['access_token'] ) );
    
    $curlSession = curl_init();
    curl_setopt_array($curlSession, $opts);
    $accessUserJson = curl_exec($curlSession);
    curl_close($curlSession);
    $me_responseArr = json_decode($accessUserJson, true);
    
    if ($responseArr['expires_in'])
    {
        // 회원아이디(kakao_ 접두사에 네이버 아이디를 붙여줌)
        $mb_uid = 'google_'.$responseArr['expires_in'];
        $mb_token = $responseArr['access_token'];
        // 회원가입 DB에서 회원이 있으면(이미 가입되어 있다면) 토큰을 업데이트 하고 로그인함
        
        $sql = "select * from {$g5['member_table']} where mb_id = '{$mb_uid}';";
        $res = sql_query($sql);
        $row = sql_num_rows($res);
        
        if ($row > 0)
        { // 멤버 DB에 토큰값 업데이트
            $sql = "UPDATE {$g5['memeber_table']} SET mb_token = '{$mb_token}' where mb_id = '{$mb_uid}';";
            sql_query($sql);
            
            $_SESSION['ss_mb_id'] = $mb_uid;
            list($microtime,$timestamp) = explode(' ',microtime());
            $time = $timestamp.substr($microtime, 2, 3);
            $_SESSION['ss_cart_id'] = date('YmdHis').substr($time,10,2);
            echo "<script>alert('로그인 하셨습니다','".G5_APP_URL."');</script>";
            
        } // 회원정보가 없다면 회원가입
        else
        {
            $mb_nick = $me_responseArr['email'];
            
            $_SESSION['join_email'] = $mb_nick;
            $_SESSION['join_token'] = $mb_token;
            $_SESSION['join_id'] = $mb_uid;
            
            $sns = "1";
            echo "<script>alert('구글로 회원가입','".G5_APP_URL."/join.php?sns={$sns}')</script>";
            
        }
    }
    else
    {
        // 회원정보를 가져오지 못했습니다.
        echo "<script>alert('회원정보를 가져오지 못했습니다','".G5_APP_URL."/join.php');</script>";
    }
}




?>

