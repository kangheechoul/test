<?php
include_once('./_common.php');
include_once('./head.sub.php');

$faqsql = "select * from {$g5['faq_table']}";
$faqres = sql_query($faqsql);

?>
<link rel="stylesheet" href="<?php echo G5_APP_URL ?>/css/mypage.css">
<body>
    <div class="wrap">
        <div class="head flex-c-m">
            <a href="javascript:" class="back_btn" id="cancel"><i class="material-icons">arrow_back_ios</i></a>
            <h2>자주 묻는 질문</h2>
        </div>
        <section class="sec_1">
            <div class="container faq">

                <div id="btnContainer1" class="row row-col-3">
                    <button class="col-4 btn active" onclick="filterSelection('all')"> 전체</button>
                    <button class="col-4 btn" onclick="filterSelection('orders')"> 주문접수</button>
                    <button class="col-4 btn" onclick="filterSelection('ordercheck')">주문확인</button>
                    <button class="col-4 btn" onclick="filterSelection('cancel')">취소/변경</button>
                    <button class="col-4 btn" onclick="filterSelection('use')"> 이용문의</button>
                    <button class="col-4 btn" onclick="filterSelection('pay')"> 결제</button>
                </div>
                <ul class="row">
                <?php
                
                for($i = 0;  $faqrow = sql_fetch_array($faqres); $i++)
                {
                    $faqtype = "all";
                    switch ($faqrow['fm_id'])
                    {
                        case "1" : {$faqtype = "all";  break; }
                        
                        case "2" : {$faqtype = "orders";  break;}
                        
                        case "3" : {$faqtype = "ordercheck";  break;}
                        
                        case "4" : {$faqtype = "cancel"; break;}
                        
                        case "5" : {$faqtype = "use"; break;}
                        
                        case "6" : {$faqtype = "pay"; break;}
                        
                        default : {$faqtype = "all"; break;}
                    }
                    
                    ?>                    
                    <li class="col-12 board-list faq-list <?= $faqtype?>">
                        <dt class="faq_list_q flex-l-m">
                            <i>Q.&nbsp;</i>
                            <div class="faq-list-q-con"><span class="c-red bold"><?= $faqrow['fa_subject']?></span></div>
                            <span class="i-arrow"><i class="matetial-icons"></i></span>
                        </dt>
                        <dd class="faq_list_a dis-none">
                            <i class="float-l">A.&nbsp;</i>
                            <div><span><?= $faqrow['fa_content']?></span></div>
                        </dd>
                    </li>
                    <?php 
                }
                ?>
                  
                </ul>
            </div>
        </section>
    </div>
    <?php include_once('./tail.php'); ?>
    <script>
        $(document).ready(function(){
            
            $('.faq_list_a').each(function(index){
                $(this).attr('data-index',index);
            });
            $('.board-list > .i-arrow').each(function(index){
                $(this).attr('data-index',index);
        });
            $('.board-list').each(function(index){
                $(this).attr('data-index',index);
            }).click(function(){
                var p = $(this).attr('data-index');
                $('.board-list > .i-arrow[data-index='+p+']').toggleClass("open");
                $('.faq_list_a[data-index='+p+']').toggle(300);
            });
        });
        </script>

<script>
    //filter
    filterSelection("all")
    function filterSelection(c) {
      var x, i;
      x = document.getElementsByClassName("board-list");
      if (c == "all") c = "";
      for (i = 0; i < x.length; i++) {
        w3RemoveClass(x[i], "show");
        if (x[i].className.indexOf(c) > -1) w3AddClass(x[i], "show");
      }
    }
    
    function w3AddClass(element, name) {
      var i, arr1, arr2;
      arr1 = element.className.split(" ");
      arr2 = name.split(" ");
      for (i = 0; i < arr2.length; i++) {
        if (arr1.indexOf(arr2[i]) == -1) {element.className += " " + arr2[i];}
      }
    }
    
    function w3RemoveClass(element, name) {
      var i, arr1, arr2;
      arr1 = element.className.split(" ");
      arr2 = name.split(" ");
      for (i = 0; i < arr2.length; i++) {
        while (arr1.indexOf(arr2[i]) > -1) {
          arr1.splice(arr1.indexOf(arr2[i]), 1);     
        }
      }
      element.className = arr1.join(" ");
    }
    
    // Add active class to the current button (highlight it)
    var btnContainer = document.getElementById("btnContainer1");
    var btns = btnContainer.getElementsByClassName("btn");
    for (var i = 0; i < btns.length; i++) {
      btns[i].addEventListener("click", function(){
        var current = document.getElementsByClassName("active");
        current[0].className = current[0].className.replace(" active", "");
        this.className += " active";
      });
    }
    
     function menu(c)
                {
                	if(c == "all")
                	{
                		var result = "전체";
                		return result;
                	}
                	else if(c == "orders")
                	{
                		var result = "주문접수";
                		return result;
                	}
                	else if(c == "ordercheck")
                	{
                		var result = "주문확인";
                		return result;
                	}
                	else if(c == "cancle")
                	{
                		var result = "취소/변경";
                		return result;
                	}
                	else if(c == "use")
                	{
                		var result = "이용문의";
                		return result;
                	}
                	else if(c == "pay")
                	{
                		var result = "결제";
                		return result;
                	}
                }
    
    
    </script>