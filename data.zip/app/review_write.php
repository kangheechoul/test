<?php
include_once('./_common.php');
include_once('./head.sub.php');

if ($is_member == "")
{
    echo "<script>
         alert('로그인해주세요','".G5_APP_URL."/login.php');
</script>";
    
}

?>
<link rel="stylesheet" href="<?php echo G5_APP_URL ?>/css/review.css">
<script src="<?php echo G5_APP_URL ?>/js/star_rating.js"></script>
<body>
    <div class="wrap">
        <div class="head">
            <a href="javascript:" class="back_btn" id="cancel"><i class="material-icons">arrow_back_ios</i></a>
			<a href = "javascript:starcount();" class="enter_btn">다음</a>
     <!-- <a href="<?php // echo G5_APP_URL ?>/review_write2.php" class="enter_btn">다음</a> -->      
        </div>
        
        <form id= "review_write2" name = "review_write2" action = "./review_write2.php" method="post">
        <input type = "hidden" id = "it_id" name = "it_id" value ="<?= $_REQUEST['it_id']?>">
        <input type = "hidden" id = "it_name" name = "it_name" value ="<?= $_REQUEST['it_name']?>">
        <input type = "hidden" id= "star" name = "star" value =""> 
        </form>
        
        <script>
        
        	function starcount()
        	{
        		var starrate = 0;
        		for(var i = 1; i <= 5; i++)
        		{
        			var color = $( "#star"+i ).css("color");
        			var red = 'rgb(253, 198, 0)';
        			
        			if(color == red)
        			{
        				starrate++;
        			}
        		}
        		$('#star').val(starrate);
        		review_write2.submit();
        		
        	}
        </script>
        <section class="sec_1 pos-relative">
                <div class="container min-h-f text-center">
                    <h3 class="title">식사는 어떠셨나요?</h3>
                    <p><?= $_REQUEST['it_name']?></p>

                    <div class="review" data-rate="3">
                        <i class="material-icons" id = "star1" style= "color:rgb(253,198,0)">star</i>
                        <i class="material-icons" id = "star2">star</i>
                        <i class="material-icons" id = "star3">star</i>
                        <i class="material-icons" id = "star4">star</i>
                        <i class="material-icons" id = "star5">star</i>
                    </div>
                </div>
        </section>
    </div>

<?php include_once('./tail.php'); ?>