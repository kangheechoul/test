<?php
// 이 파일은 새로운 파일 생성시 반드시 포함되어야 함
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가
?>
<!doctype html>
<html lang="ko">
<head>
<title>mimicook</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximim-scale=1.0, minimum-scal=1.0, user-scalable=no">
<script src="<?php echo G5_APP_URL ?>/vendor/jquery/jquery-3.2.1.min.js"></script>
<link rel="stylesheet" href="<?php echo G5_APP_URL ?>/vendor/bootstrap/css/bootstrap.css">
<link rel="stylesheet" href="<?php echo G5_APP_URL ?>/css/reset.css">
<link rel="stylesheet" href="<?php echo G5_APP_URL ?>/css/util.css">

<link rel="stylesheet" href="<?php echo G5_APP_URL ?>/css/style.css?version=1.1">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<script>
// 자바스크립트에서 사용하는 전역변수 선언
var g5_url       = "<?php echo G5_URL ?>";
var g5_bbs_url   = "<?php echo G5_BBS_URL ?>";
var g5_is_member = "<?php echo isset($is_member)?$is_member:''; ?>";
var g5_is_admin  = "<?php echo isset($is_admin)?$is_admin:''; ?>";
var g5_is_mobile = "<?php echo G5_IS_MOBILE ?>";
var g5_bo_table  = "<?php echo isset($bo_table)?$bo_table:''; ?>";
var g5_sca       = "<?php echo isset($sca)?$sca:''; ?>";
var g5_editor    = "<?php echo ($config['cf_editor'] && $board['bo_use_dhtml_editor'])?$config['cf_editor']:''; ?>";
var g5_cookie_domain = "<?php echo G5_COOKIE_DOMAIN ?>";
var g5_shop_url = "<?php echo G5_SHOP_URL; ?>";
<?php if(defined('G5_IS_ADMIN')) { ?>
var g5_admin_url = "<?php echo G5_ADMIN_URL; ?>";
<?php } ?>
</script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<div class="alert_wrap" id = "alert" style = "display:none">
	<div class="text_box"><span id = "alert_content">text영역</span></div>
    <button class="btn" onclick = "alert_close()" id = "alert_close">확인</button>
</div>
<div class='backLayer' style='' > </div>

<script>
$(document).ready(function() {
	$("#cancel").click(function(){
		history.go(-1)();
	});
});

function alert(content,url)
{
	$('#alert_content').text(content);
	$('#alert').show();

	var width = $(window).width(); 
	var height = $(window).height() + 20; //화면을 가리는 레이어의 사이즈 조정

	
	 $(".backLayer").width(width); 
	 $(".backLayer").height(height); //화면을 가리는 레이어를 보여준다 (0.5초동안 30%의 농도의 투명도) 
	 $(".backLayer").fadeTo(300, 0.5); //팝업 레이어 보이게
	  
	 var loadingDivObj = $("#loadingDiv");
	  
	 loadingDivObj.css("top", $(document).height()/2-150); 
	 loadingDivObj.css("left",$(document).width()/2-150); 
	 loadingDivObj.fadeIn(300);
	console.log(url);
	 $('#alert_close').on("click", function(){
		if(url != undefined)
		{
			location.replace(url);
			alert_close();
		}
		else
		{
			alert_close();
		}
		 });
	 
	 setTimeout(function() 
		{ 
		 if(url != undefined)
			{
				location.replace(url);
				alert_close();
			}
			else
			{
				alert_close();
			}
		}, 10000);
}

function alert_close()
{
	console.log('끔');
	$('#alert').hide();	

	$("#loadingDiv").fadeOut(300); 
	$(".backLayer").fadeOut(1000); 
}




</script>
</head>