<?php
include_once('./_common.php');
include_once('./head.sub.php');

?>

<link rel="stylesheet" href="<?php echo G5_APP_URL ?>/css/mypage.css">

<body>
    <div class="wrap">
        <div class="head flex-c-m">
            <a href="javascript:" class="back_btn" id="cancel"><i class="material-icons">arrow_back_ios</i></a>
            <h2>공지사항</h2>
        </div>
        <section class="sec_1">
            <div class="container min-h-100 my_ul">
                <ul class="row">
                	
                	<?php 
                    
                    $sql = "select * from g5_write_notice where wr_id = wr_parent"; //g5_write_notice";
                	
                    $res = sql_query($sql);
                	
                    for ($i = 0; $row = sql_fetch_array($res); $i++) 
                    {
                        
                        ?>
                        <!-- 디비(g5_write_notice)를 불러와서 반복문을 띄워야함 -->
                   		<!-- 주소는 ?wr_id = wr_id값 -->
                        <li class="col-12">
                        <a href="<?php echo G5_APP_URL ?>/my_notice.php?wr_id=<?php echo $row['wr_id']; ?>">
                        <?php echo $row['wr_subject']; ?><span class="arrow">></span>
                        <span class="date"><?php echo $row['wr_datetime'];?></span>
                        </a>
                        </li>
                        
                        <?php 
                    }
                	
                	?>
                    
                </ul>
            </div>
        </section>
    </div>

<?php include_once('./tail.php'); ?>