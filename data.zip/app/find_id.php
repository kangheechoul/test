<?php
include_once('./_common.php');
include_once('./head.sub.php');
?>
<link rel="stylesheet" href="<?php echo G5_APP_URL ?>/css/login.css">
<body>
    <div class="wrap">
        <div class="head flex-c-m">
            <a href="javascript:" class="back_btn" id="cancel"><i class="material-icons">arrow_back_ios</i></a>
            <h2>아이디 찾기</h2>
        </div>

        <section class="sec_1">
            <div class="container">
				<div class="row">
                <h4 class="title">이메일 입력</h4>
                <div class="col-12 m-b-5 inner flex-sb-m">
                    <input type="text" id= "email" class="m-r-5" placeholder="이메일">
                    <button class="btn bg-gr" style="width:150px; font-size:14px; letter-spacing:-1px;" onclick = "mail()" >인증번호 받기</button>
                </div>
				<div class="col-12">
                <input type= "hidden" id = "code" value = "">
                <input type="text" id= "code_check" placeholder="4자리 인증번호">
				</div>
				<div class = "col-12">
                <span class="date m-t-10">인증번호가 도착하지 않았을 경우 인증번호 받기 버튼을 다시 눌러주세요</span>
				</div>
                <button class="btn m-t-10 bg-gr" onclick="code_check()">아이디 찾기</button>
				</div>
			</div>
            <form id = "email_submit" method="POST" action ="./find_id_result.php">
            <input type= "hidden" id="ok_email" name= "email" value = "">
            </form>
            
        </section>
    </div>
    
    <script>

    function code_check()
    {
		if($('#code').val() == $('#code_check').val() && $('#code_check').val() != "")
		{
			alert('인증에 성공하셨습니다');
			$('#ok_email').val($('#email').val());
			email_submit.submit();
		}
    }
    
	function mail()
	{
		var email = $('#email').val();

		if(email == "")
		{
			alert('이메일을 입력해주세요');
		}
		else
		{
			$.ajax({
				url : "./controllor/email.php",
				type : "POST",
				dataType: "JSON",
				data : {
					email : email,
					type : "id"
					},
				success : function(data)
				{
					if(data['result'] == '1')
					{
						alert(data['msg']);
						$('#code').val(data['code']);
					}
					else if (data['result'] == '2')
					{
						alert(datadata['msg']);
					}
					else
					{
						alert(datadata['msg']);
					}		
					
				}
				});
		}
	}

    </script>

<?php include_once('./tail.php'); ?>