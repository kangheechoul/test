<?php
include_once('./_common.php');
include_once('./head.sub.php');
?>
<link rel="stylesheet" href="<?php echo G5_APP_URL ?>/css/login.css">
<body>
    <div class="wrap">
        <div class="head flex-c-m">
            <a href="javascript:" class="back_btn" id="cancel"><i class="material-icons">arrow_back_ios</i></a>
            <h2>비밀번호 찾기</h2>
        </div>

        <section class="sec_1">
            <div class="container min-h">
			<div class="row">
			<div class="col-12">
                <input type="email" id = "email" name = "email" placeholder="가입한 이메일 주소 입력">
                <input type ="hidden" id = "code" name = "code" value ="">
			</div>
			<div class="col-12">
                <span class="date m-t-10">입력하신 이메일 주소로 비밀번호 재설정 메일이 발송됩니다.</span>
                <span class="date m-t-10">소셜 계정 회원은 비밀번호 찾기가 불가능합니다.</span>
			</div>
                <button class="btn btn-block m-t-10 bg-gr" onclick = "mail()">이메일 발송 하기</button>
			</div>
            </div>
        </section>
    </div>

<script>

function mail()
{
	var email = $('#email').val();

	if(email == "")
	{
		alert('이메일을 입력해주세요');
	}
	else
	{
		$.ajax({
			url : "./controllor/email.php",
			type : "POST",
			dataType: "JSON",
			data : {
				email : email,
				type : "pw"
				},
			success : function(data)
			{
				if(data['result'] == '1')
				{
					alert(data['msg'],"./login.php");
					//location.replace("./login.php");
				}
				else if (data['result'] == '2')
				{
					alert(datadata['msg']);
				}
				else
				{
					alert(datadata['msg']);
				}		
				
			}
			});
	}
}

</script>>
<?php include_once('./tail.php'); ?>