<?php
include_once('./_common.php');
include_once('./head.sub.php');

if($_SESSION['ss_mb_id'] != "admin")
{
}


if($_REQUEST['mb_name'] != "")
{
    $memsql = "select * from {$g5['member_table']} where mb_name like '%".$_REQUEST['mb_name']."%'";
    $memres = sql_query($memsql);
}

?>
<link rel="stylesheet" href="<?php echo G5_APP_URL ?>/css/mypage.css">
<body>
    <div class="wrap">
        <div class="head flex-c-m">
            <a href="javascript:" class="back_btn" id="cancel"><i class="material-icons">arrow_back_ios</i></a>
            <h2>회원 검색</h2>
        </div>
        
        <section class="sec_1">
			<div class="con-wrap p-t-10">
                <div class="head flex-c-m">
           			<div class="sear_box flex-col-c w-80">
                		<div class="flex-c-m">
                    		<input type="text" id = "searchname" placeholder="회원이름을 입력해 주세요">
                    		<button class="btn search-btn btn-sm btn-dark" onclick = "memsear();"><i class="material-icons">search</i></button>
                		</div>
            		</div>
                 </div>  
           </div>
           <script>
           		function memsear()
           		{
           			var memname = document.getElementById('searchname').value;
           			if(memname == "")
           			{
           				alert("이름을 적어주세요");
           			}
           			else
           			{
						window.location = "<?= G5_APP_URL?>/memcheck.php?mb_name=" + memname;
           			}
           		
           		}
           </script>
           <ul class="flex-sb-m my_btn">
           						<li class="flex-col-c-m" style="width:15%">
                                	<span class="font-08em">번호</span>
                                </li>
                                <li class="flex-col-c-m">
                                    <span class="font-08em">이름</span>
                                </li>
                                <li class="flex-col-c-m">
                                    <span class="font-08em">닉네임</span>
                                </li>
                                <li class="flex-col-c-m">
                                    <span class="font-08em">아이디</span>
                                </li>
                                <li class="flex-col-c-m">
                                    <span class="font-08em">생일</span>
                                </li>
                                <li class="flex-col-c-m">
                                    <span class="font-08em">전화번호</span>
                                </li>
			</ul>
         
        </section>
        
        <!-- 검색된 회원  -->
        
        
        <section class="sec_2">
        
		<?php 
		
		if($_REQUEST['mb_name'] == "")
		{
            echo "<h3>회원이름을 검색해주세요</h3>";		    
		}
		else 
		{
    		for($i = 0; $memrow = sql_fetch_array($memres); $i++)
    		{
                ?>		    
    				<a href="#">
                        <div style = "padding:3px">
                            <ul class="flex-sb-m my_btn">
                            	<li class="flex-col-c-m" style="width:15%">
                                	<span class="font-08em"><?= $memrow['mb_no']?></span>
                                </li>
                                <li class="flex-col-c-m">
                                    <span class="font-08em"><?= $memrow['mb_name']?></span>
                                </li>
                                <li class="flex-col-c-m">
                                    <span class="font-08em"><?= $memrow['mb_nick']?></span>
                                </li>
                                <li class="flex-col-c-m">
                                    <span class="font-08em"><?= $memrow['mb_id']?></span>
                                </li>
                                <li class="flex-col-c-m">
                                    <span class="font-08em"><?= $memrow['mb_birth']?></span>
                                </li>
                                <li class="flex-col-c-m">
                                    <span class="font-08em"><?= $memrow['mb_hp']?></span>
                                </li>
                                
                        	</ul>
                        </div>
                     </a>		    
    		    <?php 
    		}
		}
		?>        
        </section>
      
    </div>