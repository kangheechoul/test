<?php
include_once('./_common.php');
include_once('./head.sub.php');
?>
<link rel="stylesheet" href="<?php echo G5_APP_URL ?>/css/mypage.css">
<script src="<?php echo G5_APP_URL ?>/js/star_rating.js"></script>
<body>
    <div class="wrap">
        <div class="head">
            <a href="javascript:" class="back_btn" id="cancel"><i class="material-icons">arrow_back_ios</i></a>
            <a href = "javascript:reviewsend();" id = "enter_btn" class="enter_btn">작성하기</a>
            <span id = "end_btn" style= "display:none"class="enter_btn">작성로딩중</span>
            <!-- <a href="<?php echo G5_APP_URL ?>" class="enter_btn">완료</a> -->
        </div>
        
        <section class="sec_1">
            <form id = "review_form" name = "review_form" action = "./review_write_submit.php" method = "POST" enctype='multipart/form-data'>
            <input type = "hidden" id = "is_img_check" name = "is_img_check" value = "1">
            <input type = "hidden" id = "it_id" name = "it_id" value = "<?= $_REQUEST['it_id'];?>">
            <input type = "hidden" id = "mb_id" name = "mb_id" value = "<?= $_SESSION['ss_mb_id']?>">
            <input type = "hidden" id = "is_name" name = "is_name" value = "<?= $_REQUEST['it_name']?>">
            <input type = "hidden" id = "is_score" name = "is_score" value = "<?= $_REQUEST['star']?>">
            <input type = "hidden" id = "is_time" name = "is_time" value = "<?php echo date("Y-m-d H:i:s");?>">
            <div class="container min-h-f">
                <h4 class="title"><?= $_REQUEST['it_name'] ?></h4>

                    <div class="review" data-rate="3">
                    <?php 
                        for($i = 0; $i < $_REQUEST['star']; $i++)
                        {
                            ?>
			                        <i class="material-icons" style ="color:#fdb600;">star</i>                            
                            <?php 
                        }
                    ?>
                    </div>

                    <div class="col-12 text_a">
                        <textarea name="is_content" style ="width: 100%" id="is_content" rows="10" placeholder="리뷰를 작성해 주세요."></textarea>
                    </div>
                    
                    
                    <div class="col-12 flex-l">
                    <div class="img-upload img-upload-main" style="overflow: hidden;">
                        <span class="btn-wrap">
                            <button class="btn-img-upload" href="#"><strong><i class="material-icons">camera_alt</i></strong></button>
                            <input type="file" id="upload" name="is_img" multiple="">
                        </span> 				
                        <label for="upload"></label>
                    </div>
                    
                    
                    <!-- 이미지 추가 버튼 // -->
                    <!-- 이미지가 첨부될 시 옆에 나열됩니다 -->
                    <div class="img-upload" style="overflow: hidden;">
                        <img id="productimg_temp" onerror="this.style.display='none'" alt="img_upload"/>
                        <button class="delete-btn" type="button"><i class="material-icons">close</i></button>
                    </div>
                    
                    
                </div>
            </div>
			</form>
        </section>
        
        
        
        <script>

        $('input[name=is_img]').on("change",handleImgfile);
        
        function handleImgfile(e)
        {
    			var files = e.target.files;
    			var filesArr = Array.prototype.slice.call(files);
    
    			filesArr.forEach(function(f) {
    				if(!f.type.match("image.*")){
    					alert("확장자는 이미지 확장자만 가능합니다.");
    					return;
    				}
    
    				sel_file=f;
    
    				var reader = new FileReader();
    				reader.onload = function(e) {
    					$("#productimg_temp").attr("src",e.target.result);
    				}
    				$("#productimg_temp").show();
    				reader.readAsDataURL(f);
    			});
    	}

     /*    $('#enter_btn').click(function (e) {
    		e.preventDefault();
    	}); */
        
        function reviewsend()
        {
            $('#enter_btn').css('display','none');
            $('#end_btn').css('display','block');
            $('#review_form').submit();
       	}
        </script>
        
        
    </div>

