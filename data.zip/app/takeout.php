<?php
include_once('./_common.php');
include_once('./head.sub.php');

$placesql = "select * from g5_place";
$placeres = sql_query($placesql);

echo "";
//위도와 경도를 구해서 배열에 넣었다
echo "<script>var arr = new Array(); var comparearr = new Array(); comparearr[0] = ['','','','',''];</script>";

for($i = 0; $placerow = sql_fetch_array($placeres); $i++)
{
    echo "<script>
          arr[{$i}] = ['{$placerow['pl_name']}',{$placerow['pl_latitude']},{$placerow['pl_longitude']}, '{$placerow['pl_addr1']}', '{$placerow['pl_hp']}',{$placerow['pl_id']}];
</script>";
}

if($_REQUEST['type'] == "search")
{
        
}

?>
<link rel="stylesheet" href="<?php echo G5_APP_URL ?>/css/delivery.css">
<script src="//dapi.kakao.com/v2/maps/sdk.js?appkey=5ffa686b7d0b3e7e180621208bc36e39&libraries=services"></script>
<script src="https://t1.daumcdn.net/mapjsapi/bundle/postcode/prod/postcode.v2.js"></script>
<body>
    <div class="wrap">
    <input type = "hidden" id = "type" value = "<?= $_REQUEST['type']?>">
        <div class="head flex-c-m">
            <a href="<?php echo G5_APP_URL ?>" class="back_btn" id="cancel"><i class="material-icons">arrow_back_ios</i></a>
            <h4>주변 매장 검색</h4>
        </div>
        <div class="container-f">
            <form action="">
                <div class="sear_address_wrap">
                    <div class="sear_box flex-col-c">
                        <div class="flex-c-m">
                            <input type="text" id = "mapsearch" placeholder="지도, 도로명, 건물명을 입력하세요." onclick = "sample3_execDaumPostcode();">
                            <button class="btn search-btn btn-sm btn-dark" onclick = "sample3_execDaumPostcode();"><i class="material-icons">search</i></button>
                            
                        </div>
                        
                    </div>
                </div>
            </form>
        </div>
        
<!-- 타입1 -->
<input type="hidden" id="zip" value = "<?= $_REQUEST['zip1']?>">

<!-- 타입2 -->
<input type="hidden" id="zip" value = "<?= $_REQUEST['zip2']?>">

<!-- 주소1 -->
<input type="hidden" id="addr1" value = "<?= $_REQUEST['addr1']?>">

<!-- 주소3 -->
<input type="hidden" id="addr3" value = "<?= $_REQUEST['addr3']?>">

<!-- 우편번호 -->
<input type="hidden" id="ad_jibeon" value = "<?= $_REQUEST['ad_jibeon']?>">
        
<div id="wrap" style="display:none;border:1px solid;width:95%;height:65%;margin:5px 3%;">
<img src="//t1.daumcdn.net/postcode/resource/images/close.png" id="btnFoldWrap" style="cursor:pointer;position:absolute;right:0px;top:-1px;z-index:1" onclick="foldDaumPostcode()" alt="접기 버튼">
</div>
        
        
        <script>
     // 우편번호 찾기 찾기 화면을 넣을 element
    var zib = document.getElementById('zip');
    var addr1 = document.getElementById('addr1');
    var addr3 = document.getElementById('addr3');
    var ad_jibeon = document.getElementById('ad_jibeon');

	function search()
	{
		var map = document.getElementById('mapsearch').value;
		sample3_execDaumPostcode();
		
		if(map == "")
		{
			alert('주소를 검색하여 주세요'); 
		}
		else
		{
			location.href="./takeout.php?type=search&ad_jibeon=" + ad_jibeon.value + "&zip=" + zip.value + "&addr1=" + addr1.value + "&addr3=" + addr3.value;	
		}		
	}
	
    // 우편번호 찾기 찾기 화면을 넣을 element
    var element_wrap = document.getElementById('wrap');
    
    function foldDaumPostcode()
     {
        // iframe을 넣은 element를 안보이게 한다.
        element_wrap.style.display = 'none';
    }

    function sample3_execDaumPostcode() {
    	
        // 현재 scroll 위치를 저장해놓는다.
        var currentScroll = Math.max(document.body.scrollTop, document.documentElement.scrollTop);
        document.getElementById('btnFoldWrap').style.top = "";
        new daum.Postcode({
            oncomplete: function(data) {
                // 검색결과 항목을 클릭했을때 실행할 코드를 작성하는 부분.
			
                // 각 주소의 노출 규칙에 따라 주소를 조합한다.
                // 내려오는 변수가 값이 없는 경우엔 공백('')값을 가지므로, 이를 참고하여 분기 한다.
                var addr = ''; // 주소 변수
                var extraAddr = ''; // 참고항목 변수

                //사용자가 선택한 주소 타입에 따라 해당 주소 값을 가져온다.
                if (data.userSelectedType === 'R') { // 사용자가 도로명 주소를 선택했을 경우
                    addr = data.roadAddress;
                    ad_jibeon.value = "R";
                } else { // 사용자가 지번 주소를 선택했을 경우(J)
                    addr = data.jibunAddress;
                    ad_jibeon.value = "J";
                }

                // 사용자가 선택한 주소가 도로명 타입일때 참고항목을 조합한다.
                if(data.userSelectedType === 'R'){
                    // 법정동명이 있을 경우 추가한다. (법정리는 제외)
                    // 법정동의 경우 마지막 문자가 "동/로/가"로 끝난다.
                    if(data.bname !== '' && /[동|로|가]$/g.test(data.bname)){
                        extraAddr += data.bname;
                    }
                    // 건물명이 있고, 공동주택일 경우 추가한다.
                    if(data.buildingName !== '' && data.apartment === 'Y'){
                        extraAddr += (extraAddr !== '' ? ', ' + data.buildingName : data.buildingName);
                    }
                    // 표시할 참고항목이 있을 경우, 괄호까지 추가한 최종 문자열을 만든다.
                    if(extraAddr !== ''){
                        extraAddr = ' (' + extraAddr + ')';
                    }
                    // 조합된 참고항목을 해당 필드에 넣는다.
                    addr3.value = extraAddr;
                
                } else {
                    addr3.value = '';
                }

                // 우편번호와 주소 정보를 해당 필드에 넣는다.
                zip.value = data.zonecode;
                addr1.value = addr;
                
               	document.getElementById('mapsearch').value = addr1.value;
                
                search();
                
                // iframe을 넣은 element를 안보이게 한다.
                // (autoClose:false 기능을 이용한다면, 아래 코드를 제거해야 화면에서 사라지지 않는다.)
                element_wrap.style.display = 'none';

                // 우편번호 찾기 화면이 보이기 이전으로 scroll 위치를 되돌린다.
                document.body.scrollTop = currentScroll;
            },
            // 우편번호 찾기 화면 크기가 조정되었을때 실행할 코드를 작성하는 부분. iframe을 넣은 element의 높이값을 조정한다.
            onresize : function(size) {
                element_wrap.style.height = size.height+'px';
            },
            width : '100%',
            height : '100%'
        }).embed(element_wrap);


			
        // iframe을 넣은 element를 보이게 한다.
        element_wrap.style.display = 'block';
    }

        </script>
        
        
        <section class="sec_1">
            <div class="container">
                <div id="map" style="width:100%;height:500px;"></div>
                <p class="info m-t-10">현재위치에서 <span class="col-r">2km</span> 이내 매장만 가능하며 바로결제, 방문결제 선택이 가능합니다.</p>
                <ul>
                	<div id="distance"></div>
                	<!-- 
                    <li class="m-b-10">
                        <a href="#none">
                            <div class="address bg-g-ea">
                                <h4>해운대점<span class="col-r">0.0km</span></h4>
                                <p>부산광역시 해운대구 000 000</p>
                                <p>051-000-0000</p>
                            </div>
                        </a>
                    </li>
                    <li class="m-b-10">
                        <a href="#none">
                            <div class="address bg-g-ea">
                                <h4>해운대점<span class="col-r">0.0km</span></h4>
                                <p>부산광역시 해운대구 000 000</p>
                                <p>051-000-0000</p>
                            </div>
                        </a>
                    </li>
                     -->
                </ul>
            </div>
        </section>
    </div>

  <script>
  
 // 주소-좌표 변환 객체를 생성합니다
var geocoder = new kakao.maps.services.Geocoder();

 		var type = document.getElementById('type').value;
 		var searchadd = document.getElementById('addr1').value;
 		
			if(type == "search")
			{
				geocoder.addressSearch(searchadd, function(result, status) {
				    
			        // 정상적으로 검색이 완료됐으면 
			         if (status === kakao.maps.services.Status.OK) 
			         {
                    
                        var mapContainer = document.getElementById("map");
                        var coordXY   = document.getElementById("coordXY");
                        var distanceGap  = document.getElementById("distance");

                             //var x = 35.85659647224101;    // 현재 GPS x좌표
                             //var y = 128.53115388420585;  // 현재 GPS y좌표
                             
                             var radius = 2000;  // 반경 미터(m), 2km
                             
                             var latlngyo = new kakao.maps.LatLng(result[0].y, result[0].x);
                             var mapOption =
                                  {
                                   center: latlngyo, // 지도의 중심좌표
                                   level: 3      // 지도의 확대 레벨
                                  };
                             
                             var map = new kakao.maps.Map(mapContainer, mapOption); // 지도를 생성합니다
                             
                             var circle = new kakao.maps.Circle({
                                 map: map,
                                 center : latlngyo,
                                 radius: radius,
                                 strokeWeight: 2,
                                 strokeColor: '#FF0000',
                                 fillColor: '#D3D5BF',
                                 fillOpacity: 0.5
                             });
                             
                             var marker = new kakao.maps.Marker({
                              position: latlngyo, // 마커의 좌표
                              title: "마커1",
                              map: map          // 마커를 표시할 지도 객체
                             });
                             
                             var markerTmp;      // 마커
                             var polyLineTmp;    // 두지점간 직선거리
                             var distanceArr = new Array();
                             var distanceStr = "";
                             
                             for (var i=0;i<arr.length;i++) 
                             {
                                 polyLineTmp = new kakao.maps.Polyline({
                                     map: map,
                                     path: [
                                         latlngyo, new kakao.maps.LatLng(arr[i][1],arr[i][2])
                                     ],
                                     strokeWeight: 2,   
                                     strokeColor: '#ff1122',
                                		strokeOpacity: 0.8,
                                 });
                             
                             	//2km 이하만 배열에 담는다 (2000 = 2km)
                             	if(polyLineTmp.getLength() <= 2000)
                             	{
                                 	distance[i] = polyLineTmp.getLength();  // 도보의 시속은 평균 4km/h 이고 도보의 분속은 67m/min입니다    
                                 	
                                    	markerTmp = new kakao.maps.Marker({
                                         position: new kakao.maps.LatLng(arr[i][1],arr[i][2]),
                                         title: arr[i][0],
                                         map:map
                                     });

                                     	// 인포윈도우로 장소에 대한 설명을 표시합니다
                                		var infowindow = new kakao.maps.InfoWindow
                                 	({
                                     	content: '<div style="width:150px;text-align:center;padding:6px 0;">'+ arr[i][0] + '</div>',
                                 	});
                                 	
                                     infowindow.open(map, markerTmp);
                                 	
                             	}
                             	else
                             	{
                             		polyLineTmp.setMap(null); // 지도에서 제거한다
                             	}
                             	
                             
                                 //distanceStr += arr[i][0] + " : "  +  parseFloat(distance[i] / 1000).toFixed(2) + " km <br>";
                                 
                                 
                                 
                             	comparearr[i] = [arr[i][0], parseFloat(distance[i] / 1000).toFixed(2), arr[i][3], arr[i][4],arr[i][5]];
                             }

							for(var i = 0; i < comparearr.length; i++)
							{
								if(isNaN(comparearr[i][1]))
								{
									comparearr.splice(i,1);
								}
							}
                             
                            comparearr.sort(function(a, b) 
                            {
       						return a[1] - b[1];
     						});
     						
                             
                             // 인포윈도우로 장소에 대한 설명을 표시합니다
                             var infowindowaa = new kakao.maps.InfoWindow
                             ({
                                 content: '<div style="width:150px;text-align:center;padding:6px 0;">검색위치</div>'
                             });
                             
                             infowindowaa.open(map, marker);
                             
     		                map.setCenter(latlngyo);
                             for(var j=0;j<comparearr.length;j++)
                             {
                             	if(comparearr[j][1] <= 2) //차이가 2키로 이하일때 추가
                             	{
                             		
                            		distanceStr += '<li class="m-b-10"><a href="./menu_list.php?type=take&pl_id='+comparearr[j][4]+'"><div class="address bg-g-ea"><h4>' + comparearr[j][0] + '<span class="col-r">'+ comparearr[j][1] +'km</span></h4><p> ' + comparearr[j][2] + '</p><p>' + comparearr[j][3] + '</p></div></a></li>';
                                 	if(comparearr[j][1] == 0)
                                 	{
                                 		infowindowaa.setContent('<div style="width:150px;text-align:center;padding:6px 0;">근처</div>');
                                    }
                             		//distanceStr += '<li class="m-b-10"><a href="./menu_list.php?type=take&pl_id='+comparearr[j][4]+'"><div class="address bg-g-ea"><h4>' + comparearr[j][0] + '<span class="col-r">'+ comparearr[j][1] +'km</span></h4><p> ' + comparearr[j][2] + '</p><p>' + comparearr[j][3] + '</p></div></a></li>';
                             		
                             	}
                             }
                             if(distanceStr == "")
                             {
                             	distanceStr = "<h3>근처에 지점이 없습니다.</h3>";
                             }
                            
                             distanceGap.innerHTML = distanceStr;
			         }
			      });
			}
			else
			{
				if (navigator.geolocation) {
				    
	                // GeoLocation을 이용해서 접속 위치를 얻어옵니다
	                navigator.geolocation.getCurrentPosition(function(position) {
			//var x = AppInterface.getGPSLatitude(); // 위도
    	 //	var y = AppInterface.getGPSLongitude(); // 경도
	                    
	                   var x = position.coords.latitude, // 위도
	                        y = position.coords.longitude; // 경도
	                    
	                        var mapContainer = document.getElementById("map");
	                        var coordXY   = document.getElementById("coordXY");
	                        var distanceGap  = document.getElementById("distance");

	                             //var x = 35.85659647224101;    // 현재 GPS x좌표
	                             //var y = 128.53115388420585;  // 현재 GPS y좌표
	                             var radius = 2000;  // 반경 미터(m), 2km
	                             
	                             var latlngyo = new kakao.maps.LatLng(x, y);
	                             
	                             var mapOption =
	                                  {
	                                   center: latlngyo, // 지도의 중심좌표
	                                   level: 3      // 지도의 확대 레벨
	                                 
	                                  };
	                             
	                             var map = new kakao.maps.Map(mapContainer, mapOption); // 지도를 생성합니다
	                             
	                             var circle = new kakao.maps.Circle({
	                                 map: map,
	                                 center : latlngyo,
	                                 radius: radius,
	                                 strokeWeight: 2,
	                                 strokeColor: '#FF0000',
	                                 fillColor: '#D3D5BF',
	                                 fillOpacity: 0.5
	                             });
	                             
	                             
	                             var marker = new kakao.maps.Marker({
	                              position: latlngyo, // 마커의 좌표
	                              title: "마커1",
	                              map: map          // 마커를 표시할 지도 객체
	                             });
	                             
	                             var markerTmp;      // 마커
	                             var polyLineTmp;    // 두지점간 직선거리
	                             var distanceArr = new Array();
	                             var distanceStr = "";
	                             
	                             
	                             for (var i=0;i<arr.length;i++) 
	                             {
	                                 polyLineTmp = new kakao.maps.Polyline({
	                                     map: map,
	                                     path: [
	                                         latlngyo, new kakao.maps.LatLng(arr[i][1],arr[i][2])
	                                     ],
	                                     strokeWeight: 2,   
	                                     strokeColor: '#ff1122',
	                                		strokeOpacity: 0.8,
	                                 });
	                             
	                             	//2km 이하만 배열에 담는다 (2000 = 2km)
	                             	if(polyLineTmp.getLength() <= 2000)
	                             	{
	                                 	distance[i] = polyLineTmp.getLength();  // 도보의 시속은 평균 4km/h 이고 도보의 분속은 67m/min입니다    
	                                    	markerTmp = new kakao.maps.Marker({
	                                         position: new kakao.maps.LatLng(arr[i][1],arr[i][2]),
	                                         title: arr[i][0],
	                                         map:map
	                                     });
	                                     
	                                     	// 인포윈도우로 장소에 대한 설명을 표시합니다
	                                		var infowindow = new kakao.maps.InfoWindow
	                                 	({
	                                     	content: '<div style="width:150px;text-align:center;padding:6px 0;">'+ arr[i][0] + '</div>',
	                                 	});
	                                 	
	                                     infowindow.open(map, markerTmp);
	                                 	
	                             	}
	                             	else
	                             	{
	                             		polyLineTmp.setMap(null); // 지도에서 제거한다
	                             	}
	                             	comparearr[i] = [arr[i][0], parseFloat(distance[i] / 1000).toFixed(2), arr[i][3], arr[i][4], arr[i][5]];
	                             
	                                 //distanceStr += arr[i][0] + " : "  +  parseFloat(distance[i] / 1000).toFixed(2) + " km <br>";
	                             }

	                             for(var i = 0; i < comparearr.length; i++)
	 							{
	 								if(isNaN(comparearr[i][1]))
	 								{
	 									comparearr.splice(i,1);
	 								}
	 							}
	                            comparearr.sort(function(a, b) {
	       						return a[1] - b[1];
	     						})
	                             
	                             // 인포윈도우로 장소에 대한 설명을 표시합니다
	                             var infowindowaa = new kakao.maps.InfoWindow
	                             ({
	                                 content: '<div style="width:150px;text-align:center;padding:6px 0;">현재위치</div>'
	                             });
	                             
	                             infowindowaa.open(map, marker);
	                             
	     		                map.setCenter(new kakao.maps.LatLng(x,y));
	                             for(var j=0;j<comparearr.length;j++)
	                             {
	                                 if(comparearr[j][1] <= 2)
	                                 {
	                                 	distanceStr += '<li class="m-b-10"><a href="./menu_list.php?type=take&pl_id=' +comparearr[j][4]+ '"><div class="address bg-g-ea"><h4>' + comparearr[j][0] + '<span class="col-r">'+ comparearr[j][1] +'km</span></h4><p> ' + comparearr[j][2] + '</p><p>' + comparearr[j][3] + '</p></div></a></li>';
	                                	 if(comparearr[j][1] == 0)
		                                 {
		                                 	infowindowaa.setContent('<div style="width:150px;text-align:center;padding:6px 0;">근처</div>');
		                                 }
		                             }
	                             }
	                             if(distanceStr == "")
	                             {
	                             	distanceStr = "<h3>근처에 지점이 없습니다.</h3>";
	                             }
	                             
	                             distanceGap.innerHTML = distanceStr;
	                  },function(error){alert(error);}	);
	            }
			}
  			
  				
function searchAddrFromCoords(coords, callback) {
    // 좌표로 행정동 주소 정보를 요청합니다
    geocoder.coord2RegionCode(coords.getLng(), coords.getLat(), callback);         
}

function searchDetailAddrFromCoords(coords, callback) {
    // 좌표로 법정동 상세 주소 정보를 요청합니다
    geocoder.coord2Address(coords.getLng(), coords.getLat(), callback);
}
  				
           
            </script>