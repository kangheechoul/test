<?php
include_once('./_common.php');
include_once('./head.sub.php');

if ($is_member == "")
{
    echo "<script>
        alert('로그인해주세요','".G5_APP_URL."/login.php');
</script>";
}

$tab = $_REQUEST['tab'];

$it_id = $_REQUEST['it_id'];

//상품 정보
//g5_shop_item 테이블
//브랜드 : it_brand 필요한가?
//원산지 : it_maker
//내용 : it_mobile_explan
$sql = "select * from {$g5['g5_shop_item_table']} where it_id = ".$it_id;
$res = sql_query($sql);
$row = sql_fetch_array($res);


if(strpos($row['it_name'], "출시예정"))
{
    echo "<script>alert('출시예정 상품입니다','".$_SERVER['HTTP_REFERER']."')</script>";
    return false;
}

//판매 x
if($row['it_use'] == 0)
{
    echo "<script>alert('판매 중지  상품입니다.','".$_SERVER['HTTP_REFERER']."')</script>";
    return false;
}

if($row['it_stock_qty'] <= 0)
{
    echo "<script>alert('상품이 매진입니다.','".$_SERVER['HTTP_REFERER']."')</script>";
    return false;
}

$it_img =  $row['it_img1'];
$it_img = str_replace($row['it_id']."/","", $it_img);


//상품 추가 주문 아이템 정보
//g5_shop_item_option 테이블
//추가금액 io_price

$itemsql ="select * from {$g5['g5_shop_item_option_table']} where it_id = ".$it_id;
$itemres = sql_query($itemsql);


//상품후기 
//g5_shop_item_use 테이블
//전체가져오기


$review_type = $_REQUEST['review_type'];
//is_time 최신순
//low_is_score 별점 낮은순 
//high_is_score 별점 높은순
    $orderby = " order by is_time desc";
    if($review_type == "low_is_score" || $review_type == "high_is_score")
    {
        if($review_type == "low_is_score")
        {
            $orderby = " order by is_score asc, is_time desc";
        }
        else if($review_type == "high_is_score")
        {
            $orderby = " order by is_score desc, is_time desc";
        }
    }
    else
    {
        $orderby = " order by is_time desc";
    }
    $usesql = "select * from {$g5['g5_shop_item_use_table']} where it_id = ".$it_id.$orderby;
    $useres = sql_query($usesql);


//else if ($review_type) $orderby = "order by ".$review_type;



//리뷰 갯수
$usecount = sql_num_rows($useres);

//점수별 갯수
$scorearr = array();
$staravgarr = array();
$scoresql = "select *, count(is_score)as score from {$g5['g5_shop_item_use_table']} where it_id = {$it_id} group by is_score order by is_score asc";
$scoreres = sql_query($scoresql);
//각 리뷰의 갯수를 구하고 게이지를 위한 퍼센트를 구함
for($i = 0 ; $avgrow = sql_fetch_array($scoreres); $i++)
{
    $score_index = $avgrow['is_score'];
    $scorearr[$score_index] =  $avgrow['score'];
    $staravgarr[$score_index] = sprintf('%0.0f', $avgrow['score'] / $usecount * 100);
}
//점수가 없으면 0으로 값 주기
for($i = 1; $i <= 5; $i++)
{
    if($scorearr[$i] == NULL)
    {
        $scorearr[$i] = 0;
        $staravgarr[$i] = 0;
    }
    
}


//리뷰 평점
$useavgsql = "select avg(is_score) as score from {$g5['g5_shop_item_use_table']} where it_id = ".$it_id;
$useavgres = sql_query($useavgsql);
$userow = sql_fetch_array($useavgres);

$useavg = sprintf('%0.1f', $userow['score']);



//찜했는지의 여부

$wishsql = "select * from {$g5['g5_shop_wish_table']} where mb_id = '".$_SESSION['ss_mb_id']."' and it_id = '".$it_id."'";
$wishrow = sql_fetch($wishsql);

?>
<style>
.recipe_img{width:100%;padding:5px}
</style>
<link rel="stylesheet" href="<?php echo G5_APP_URL ?>/css/my_page.css">
<body <?php if($review_type == 'is_time' || $review_type == 'high_is_score' || $review_type == 'low_is_score') echo "onload='review();avg()'"?> >

    <div class="wrap">
        <div class="head flex-c-m">
            <a href="javascript:back()" class="back_btn" ><i class="material-icons">arrow_back_ios</i></a>
            <h2><?php echo $row['it_name'];?></h2>
        </div>
        <script>
		function back()
		{
			<?php if(isset($_GET['tab']))
			{
			    echo 'location.replace("'.G5_APP_URL.'/menu_list.php?tab='.$_GET['tab'].'")';
			}
			else
			{
			    echo 'history.go(-1)';
			}
			    ?>
		}

		
        </script>
        <section class="sec_1"><!-- menu_info_wrap -->
            <div class="container menu_info_wrap">
                 <div class="img_box m-b-10">
                    <img src="<?= get_it_imageurl($row['it_id'])?>" alt="menu">
                </div>
                <div class="row">
                    <h3 class="title"><?php echo $row['it_name'];?></h3>
                    
                    <p class="text-center">
                        <i class="material-icons star" style="position:relative; top:4px;">star_rate</i><?= $row['it_use_avg']?><span style="date">(<?= $row['it_use_cnt']?>)</span>
                    </p>
                    
                    <span class="dis-block text-center"><i class="material-icons" style="color :#909090; position:relative; top:4px;" id = "pick1" onclick = "pick();">favorite</i>찜</span>
                    <!-- 찜하기는 개인정보를 알아야 할수 있으듯 -->
                    <?php 
                    if($wishrow['wi_id'] == "" || $wishrow['wi_id'] == null)
                    {
                        echo "<script>
                               document.getElementById('pick1').style.color = 'rgb(100,100,100)';
                        </script>";                    
                    }
                    else
                    {
                        if($wishrow['wi_time'] == "0000-00-00 00:00:00")
                        {
                            echo "<script>
                               document.getElementById('pick1').style.color = 'rgb(100,100,100)';
                            </script>"; 
                        }
                        else
                        {
                            echo "<script>
                               document.getElementById('pick1').style.color = 'rgb(255, 255, 34)';
                            </script>";  
                        }
                    }
                    ?>
                </div>
             <SCRIPT>
             function pick()
             {
                var pick = document.getElementById('pick1').style.color;
            	 $.ajax({
     	            type : "POST",
     	            url : "./controllor/pick_check.php",
     	            data: {
         	            	id : "<?= $it_id?>",
     		           	 	pick : pick
     		            },
     	            dataType : "json",
     	            success : function(result)
     	            {
     	            	document.getElementById('pick1').style.color = result.data;
     	            }
     	         });
             }
             </SCRIPT>
               </div>
                <!-- 정보 없음 -->
                <div class="container price_info p-t-10 p-b-10">
				
					<ul class="row row-col-4">
						<li class="col">
							<dt><i class="material-icons">timer</i></dt>
							<dd><span>조리 <span><?= $row['it_cook_time']?></span></span></dd>
						</li>
						<li class="col">
							<dt><i class="material-icons">accessibility_new</i></dt>
							<dd><span><?= $row['it_inbun']?></span></dd>
						</li>
						<li class="col">
							<dt><i class="material-icons">star</i></dt>
							<dd><span>난이도 <span><?= $row['it_level']?></span></span></dd>
						</li>
						<li class="col">
							<dt><i class="material-icons">ac_unit</i></dt>
							<dd><span><span><?= $row['it_storage']?></span></span></dd>
						</li>
					</ul>
                    
                </div>
                <!-- 정보 없음 -->
                
                <div class="container">
					<nav>
						<div class="row row-col-3 nav nav-tabs" id="nav-tab" role="tablist">
						  <a class="col text-center nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home"  aria-selected="true">주문</a>
						  <a class="col text-center nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">정보</a>
						  <a class="col text-center nav-item nav-link" id="nav-contact-tab" data-toggle="tab" href="#nav-contact" role="tab" aria-controls="nav-contact" aria-selected="false" onclick = "avg();">리뷰</a>
						</div>
					</nav>
                </div>
                  <div class="container tab-content" id="nav-tabContent">
                    <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                        
                        
                        <div class="oder">
							<ul class="row">
								<li class="col-12">
									<dt>인분</dt>
									<dd class="flex-sb-m">
										<button type="button" onClick="decrease()" style="border: none; background-color: transparent; font-size: 2em;">-</button>
										<p><a id="clicks" name = "clicks">1</a></p>
										<button type="button" onClick="increase()" style="border: none; background-color: transparent; font-size: 2em;">+</button>
									</dd>
								<li>
								
								
							
                            <script>
                                var clicks = 1;
                                function increase() {
                                    clicks += 1;
                                    document.getElementById("clicks").innerHTML = clicks;
                                    document.getElementById("it_qty").value = clicks;
                                }
                                
                                function decrease() 
                                {
                                    if(clicks <= 0){
                                        clicks = 1
                                        alert('최소주문은 1인분 입니다.');
                                    }else{
                                        clicks -= 1;
                                        document.getElementById("clicks").innerHTML = clicks;
                                        document.getElementById("it_qty").value = clicks;
                                    }
                                }
                                
                                function order()
                              	{
									var form = document.getElementById('addr');
                              		form.submit();
                              	} 
                                
                            </script>
                            <!-- 반복해서 출력 해야함 (라벨 for, input id 바꿔줘야함)-->
                                <form id = "addr" name = "addr" action = "./controllor/cart_add.php" method = "POST">
                                <input type ="hidden" id = "tab" name = "tab" value = "<?= $tab?>">
                                <input type= "hidden" id= "it_id" name = "it_id" value = "<?= $it_id?>">
                                <input type = "hidden" id = "it_name" name = "it_name" value = "<?= $row['it_name']?>">
                                <input type= "hidden" id = "it_price" name = "it_price" value = "<?= $row['it_price']?>">
                                <input type = "hidden" id= "it_qty" name = "it_qty" value = "1">
                                <input type = "hidden" id= "item_option" name = "item_option" value = "">
                            
                            
                            	
                            <?php 
                            for($i = 0; $itemrow = sql_fetch_array($itemres); $i++)
                            {
                            ?>
							
							<li class="col-12">
								<div class="inner check-inner flex-sb-m">
                                <input type="checkbox" class="check-input" name= "check_index[]" onclick = "add_option('<?= $i?>','<?= $itemrow['io_id']?>')" id="check_index<?= $i?>" value ="<?= $i?>">
                                
                                
                                <label for="check_index<?= $i?>" style = "margin-bottom:2%"><?= $itemrow['io_id']."추가(+".$itemrow['io_price']?>원)<i class="material-icons">radio_button_unchecked</i><i class="material-icons">radio_button_checked</i></label>
                                <input type="hidden" name = "check_id[]" id = "check_id<?= $i?>" value = "<?= $itemrow['io_id']?>">
                                <input type="hidden" name = "check_price[]" id = "check_price<?= $i?>" value = "<?= $itemrow['io_price']?>">
                            </div>
							<li>
                            
                            
                            <?php 
                            }
                            ?>
                            </form>
                            </ul>
                            <script>
							function add_option(num, name)
							{
								
								var option = $('#item_option').val();

								var check = $('input[name="check_index[]"]').eq(num).is(":checked");

								var it_id = $('#it_id').val();

								var io_price = $('input[name="check_price[]"]').eq(num).val();

								var text = it_id +":"+name+":"+io_price+";";
							
								if(check == true)
								{
									$('#item_option').val(option + text);
								}
								else
								{
									var re_text = option.replace(text,"");
									$('#item_option').val(re_text);
								}
							}
                            </script>
                            
                        </div>
                        
                    </div>
                    <button type= "button" class="btn btn-lg btn-block btn-red bottom-0 flex-col-c-m" style= "position:fixed; right:0; z-index:300" onclick="order();">주문하기</button>
                        
                    
                    <!-- 정보 div -->
                    <div class="tab-pane fade m-b-70" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
                        <div class="menu_info">
                        <table class="table it_info">
						<colgroup>
							<col width="20%">
							<col width="30%">
							<col width="20%">
							<col width="30%">
						</colgroup>
						<thead>
							<tr>
								<th>메뉴명</th>
								<th>원산지</th>
								<th>공통양념</th>
								<th>원산지</th>
							</tr>
						</thead>
						<tbody>
                            <?php 
                            $it_maker_tmp = $row['it_maker'];
						    $it_maker_arr = explode('),',$it_maker_tmp);
                            for($i = 0; $i < count($it_maker_arr); $i++)
                            {
                                $tmp = explode('(',$it_maker_arr[$i]);
                                $it_maker[$i][0] = $tmp[0];
                                $it_maker[$i][1] = str_replace(')','',$tmp[1]);
                            }
                            $it_origin_tmp = $row['it_origin'];
                            $it_origin_arr = explode('),',$it_origin_tmp);
                            
                            for($i = 0; $i < count($it_origin_arr); $i++)
                            {
                                $tmp = explode('(',$it_origin_arr[$i]);
                                $it_origin[$i][0] = $tmp[0];  
                                $it_origin[$i][1] = str_replace(')','',$tmp[1]);
                            }
                            
                            if(count($it_origin) > count($it_maker))
                            {
                                $len = count($it_origin);
                            }
                            else
                            {
                                $len = count($it_maker);
                            }
                            
                            for($i = 0; $i < $len; $i++)
                            {
                                ?>
                                <tr>
                                <td><?= $it_maker[$i][0]?></td>
                                <td><?= $it_maker[$i][1]?></td>
                                <td><?= $it_origin[$i][0]?></td>
                                <td><?= $it_origin[$i][1]?></td>                                
                            	</tr>
                            	<?php      
                            }
                            ?>
                            </tbody>
                            </table>
							<img class = "recipe_img" src = "<?= G5_DATA_URL."/item/".$row['it_img10']?>">                            
                        </div>
                    </div>
                    
                    <!-- 리뷰 div -->
                    <div class="tab-pane fade m-b-70" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab">
                        <div class="review_wrap">
                            <div class="left_point pos-relative">
                                <div class="m-t-40 text-center">
                                    <h4><?= $useavg?></h4>
                                    <span style="color: #fdc600;">
                                    <?php 
                                    for($i = 1; $i < $useavg; $i++)
                                    {
                                        ?>
                                        <i class="material-icons">star</i>
                                        <?php 
                                    }
                                    ?>
                                    </span>
                                </div>
                            </div>
                            <div class="right_point">
                            <script>
								    function avg()
								    {
								    	<?php 
                                        for($i = 5; $i >= 1; $i--)
								    	{
											
											echo "var avg = document.getElementById('star-{$i}');";
											
											echo "avg.style.width = '{$staravgarr[$i]}%';";
								    	};
								    	?>
								    }
                            </script>
                                <ul>
                                    <?php 
                                    for($i = 5; $i >= 1 ; $i--)
                                    {
                                        ?>
 										<li class="flex-sb-m">
                                        	<p><?= $i?>점</p>
                                        	<span class="point-box point-<?= $i?>"><span class="point" id = "star-<?=$i?>"></span></span>
                                        	<span class="score"><?php echo $scorearr[$i];?></span>
                                        	
                                    	</li>                                       
                                        <?php 
                                    }
                                    ?>
                                </ul>
                            </div>
                        </div>
                        
                        <div class="review_write border-b border-g p-b-10">
                        
                        <!-- 최근리뷰의 최대 개수 지정을 해줘야함 -->
                        
                        	<form id = "review_write" name = "review_write" action = "./review_write.php" method="POST" >
                        	<input type= "hidden" id= "it_id" name = "it_id" value = "<?= $it_id?>">
                        	<input type= "hidden" id= "it_name" name = "it_name" value = "<?= $row['it_name']?>">
                        	</form>
                        	
                            <h4 class = "m-t-10">최근 리뷰 <?php if($row['it_use_cnt'] >100) echo "100+"; else echo $row['it_use_cnt'];?>개 <span><a href="javascript:order_check()">리뷰 쓰기</a></span></h4>
                            <div class="selec_wrap m-t-10">
                                <select name="" id="review_type" onchange="review_type();">
                                    <option value="is_time" id = "is_time" <?php if($review_type == "is_time" || $review_type="") echo "selected=selected";?>>최신순</option>
                                    <option value="high_is_score" id = "high_is_score" <?php if($review_type == "high_is_score") echo "selected=selected";?>>별점높은순</option>
                                    <option value="low_is_score" id = "low_is_score"<?php if($review_type == "low_is_score") echo "selected=selected";?>>별점낮은순</option>
                                </select>
                            </div>
                            
                        </div>
                        <script>
						function order_check()
						{
							$.ajax({
								url : "./controllor/order_check.php",
								type : "POST",
								data : {
									it_id : $('#it_id').val()
									},
								success : function(result)
								{
									if(result > 0)
									{
										review_write.submit();
									}
									else
									{
										alert('주문 내역에 없습니다');
									}
								}
								});
						}
                        function review_type()
						{	
							var review_type = $("#review_type").val();
							var form = document.getElementById('addr');
							form.action = './menu.php?it_id=' + <?= $it_id?> + '&review_type=' + review_type;
							form.submit();
							//window.location.href='./menu.php?it_id=' + <?= $it_id?> + '&review_type=' + review_type;
						}
                        
                        function review()
                        {
                        	$('a[href="#nav-contact"]').tab('show');
                        	var review_type = "<?= $_REQUEST['review_type']?>";
                        	//select 선택하기
							$('#'+review_type).val(review_type).prop("selected",true);    	
                        }
                        
                        </script>
                        
                        <!-- 리뷰 리스트 띄우기 -->
                        <?php 
                        //전체 리뷰 띄우기
                        for($i = 0; $alluserow = sql_fetch_array($useres); $i++)
                        {
                        ?>
                        <div class="review_list">
                        <div class="review border-b border-g m-t-10">
                        <div class="nick">
                        <i class="material-icons m-r-5">supervised_user_circle</i><span><?= $alluserow['mb_nick']?></span>
                        </div>
                        <span style="color: #fdc600;">
                        <?php 
                            //리뷰당 별표 개수
                            for($j = 0; $j < $alluserow['is_score']; $j++)
                            {
                                ?>
		                        <i class="material-icons">star</i>
                                <?php 
                            }
                           
                           //오늘과의 날짜 차이
                           $day = "오늘";
                           
                           $today = new DateTime(date('Y-m-d'));
                           
                           $endday = new DateTime(date('Y-m-d',strtotime($alluserow['is_time'])));
                           
                           $diff    = date_diff($today, $endday);
                           
                           if($diff->days == "1")
                           {
                               $day = "어제";
                           }
                           else if($diff->days == "0")
                           {
                               $day = "오늘";
                           }
                           else
                           {
                               $day = date('Y-m-d',strtotime($alluserow['is_time']));
                           }
                        ?>
                        <span class="date"><?= $day?></span>
                        <?php 
                        if($alluserow['is_img'] != "")
                        {
                            ?>
							<div class="img_box m-b-10">
                        	<img src="<?= G5_DATA_URL.$alluserow['is_img']?>" alt="review-img">
                        	</div>                            
                            <?php 
                        }
                        ?>
                        <?php echo "<p>".$alluserow['is_content']."</p>";?>
                        <br/>
                        </div>
                        </div>
                        <?php 
                        }
                        ?>
                    </div>
                </div>
        </section>
        
    <script>
        $(window).resize(function(){
            var winWidth = $(window).width();
            var boxWidth = $('.img_box').width();
            //max-width값인 500px아래서만 작동00000000000000000000000000000000000000000000000000000000000000
            if(winWidth <= 1024){
                //1.681:1
                $('.img_box').height(boxWidth*0.681);
            }else if (winWidth <= 600){
                $('.img_box').height(boxWidth*0.781);
            }
        });
    </script>
    <script>
        $(document).ready(function(){
        var i = 0;
        $(".pick>i").click(function(){
            
            if(i == 0 ){
                $(this).css({color:'#ffff22'});
                i++;
            }else if(i == 1){
                $(this).css({color:'#909090'});
                i = 0;
            }
        });
    });
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>

<?php include_once('./cart_icon.php');?>