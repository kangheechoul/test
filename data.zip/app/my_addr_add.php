<?php
include_once('./_common.php');
include_once('./head.sub.php');

?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="<?php echo G5_APP_URL ?>/css/delivery.css">
<link rel="stylesheet" href="<?php echo G5_APP_URL ?>/css/mypage.css">

<body>


<script src="https://t1.daumcdn.net/mapjsapi/bundle/postcode/prod/postcode.v2.js"></script>

    <div class="wrap">
        <div class="head flex-c-m">
            <a href="javascript:" class="back_btn" id="cancel"><i class="material-icons">arrow_back_ios</i></a>
            <h2>주소 등록</h2>
        </div>
        <section class="sec_1">
            <!-- <h3 class="sm-title">주소를 설정해 주세요</h3> -->
            <div class="container">
                <div class="sear_address_wrap">
                    <div class="sear_box flex-col-c">
                        <div class="flex-c-m">
                            <input type="text" id = "mapsearch" placeholder="지도, 도로명, 건물명을 입력하세요." onclick = "sample3_execDaumPostcode();">
                            <button class="btn search-btn btn-sm btn-dark" onclick = "sample3_execDaumPostcode();"><i class="material-icons">search</i></button>
                        </div>

						<!-- 타입 -->
						<input type="hidden" id="zip">
						<!-- 주소1 -->
						<input type="hidden" id="addr1">
						<!-- 주소2 -->
						<input type="hidden" id="addr2">
						<!-- 주소3 -->
						<input type="hidden" id="addr3">
						<!-- 우편번호 -->
						<input type="hidden" id="jibeon">

						<div id="wrap" style="display:none;border:1px solid;width:95%;height:70%;margin:5px 0;">
						<img src="//t1.daumcdn.net/postcode/resource/images/close.png" id="btnFoldWrap" style="cursor:pointer;position:absolute;right:0px;top:-1px;z-index:1" onclick="foldDaumPostcode()" alt="접기 버튼">
						</div>
                            
                        <button class="btn" onclick = "location.href='./addr_map.php?type=addnow'">현 위치로 주소 설정</button>
                    </div>
                </div>
            </div>
			
			<div class="container write">
				<h4 class="title">주소확인</h4>
            <ul class="row">
				<form id= "addaddr" name = "addaddr" action = "./controllor/addr_insert.php" method = "POST">
					<li class="col-12">
						<dt>우편번호</dt>
						<dd><input type ="text" id = "addzip" name = "addzip" value ="<?= $_REQUEST['mb_zip1'].$_REQUEST['mb_zip2']?>"></dd>
						<input type = "hidden" id = "addzip1" name = "addzip1" value = "<?= $_REQUEST['mb_zip1']?>">
						<input type = "hidden" id = "addzip2" name = "addzip2" value = "<?= $_REQUEST['mb_zip2']?>">
					</li>
			
					<li class="col-12">
						<dt>주소 1</dt>
						<dd><input type ="text" id = "addaddr1" name = "addaddr1" value ="<?= $_REQUEST['mb_addr1']?>"><br></dd>
					</li>
					
					<li class="col-12">
						<dt>상세주소</dt>
						<dd><input type ="text" id = "addaddr2" name = "addaddr2" value ="<?= $_REQUEST['mb_addr2']?>"></dd>
					</li>
            
					<li class="col-12">
						<dt>주소 2</dt>
						<dd><input type ="text" id = "addaddr3" name = "addaddr3" value ="<?= $_REQUEST['mb_addr3']?>"></dd>
					</li>
            
					<input type ="hidden" id = "addjibeon" name = "addjibeon" value ="<?= $_REQUEST['mb_addr_jibeon']?>">
				</form>
			</ul>
        </div>
        </section>
		
		<div class="choice_wrap">
            <button class="btn btn-red" onclick="addrcheck()">등록</button>
        </div>
<!-- 메뉴 리스트 이동하기 -->
<script>

	var zib = document.getElementById('zip');
    var addr1 = document.getElementById('addr1');
    var addr2 = document.getElementById('addr2');
    var addr3 = document.getElementById('addr3');
    var jibeon = document.getElementById('jibeon');

	function search()
	{
		var map = document.getElementById('mapsearch').value;
		sample3_execDaumPostcode();
		
		if(map == "")
		{
			alert('주소를 검색하여 주세요'); 
		}
		else
		{
			location.href="./addr_map.php?type=add&ad_jibeon=" + jibeon.value + "&zip=" + zip.value + "&addr1=" + addr1.value + "&addr3=" + addr3.value;	
		}		
	}
	
    // 우편번호 찾기 찾기 화면을 넣을 element
    var element_wrap = document.getElementById('wrap');
    
    function foldDaumPostcode()
     {
        // iframe을 넣은 element를 안보이게 한다.
        element_wrap.style.display = 'none';
    }

    function sample3_execDaumPostcode() {
    	
        // 현재 scroll 위치를 저장해놓는다.
        var currentScroll = Math.max(document.body.scrollTop, document.documentElement.scrollTop);
        document.getElementById('btnFoldWrap').style.top = "";
        new daum.Postcode({
            oncomplete: function(data) {
                // 검색결과 항목을 클릭했을때 실행할 코드를 작성하는 부분.
			
                // 각 주소의 노출 규칙에 따라 주소를 조합한다.
                // 내려오는 변수가 값이 없는 경우엔 공백('')값을 가지므로, 이를 참고하여 분기 한다.
                var addr = ''; // 주소 변수
                var extraAddr = ''; // 참고항목 변수

                //사용자가 선택한 주소 타입에 따라 해당 주소 값을 가져온다.
                if (data.userSelectedType === 'R') { // 사용자가 도로명 주소를 선택했을 경우
                    addr = data.roadAddress;
                    jibeon.value = "R";
                } else { // 사용자가 지번 주소를 선택했을 경우(J)
                    addr = data.jibunAddress;
                    jibeon.value = "J";
                }

                // 사용자가 선택한 주소가 도로명 타입일때 참고항목을 조합한다.
                if(data.userSelectedType === 'R'){
                    // 법정동명이 있을 경우 추가한다. (법정리는 제외)
                    // 법정동의 경우 마지막 문자가 "동/로/가"로 끝난다.
                    if(data.bname !== '' && /[동|로|가]$/g.test(data.bname)){
                        extraAddr += data.bname;
                    }
                    // 건물명이 있고, 공동주택일 경우 추가한다.
                    if(data.buildingName !== '' && data.apartment === 'Y'){
                        extraAddr += (extraAddr !== '' ? ', ' + data.buildingName : data.buildingName);
                    }
                    // 표시할 참고항목이 있을 경우, 괄호까지 추가한 최종 문자열을 만든다.
                    if(extraAddr !== ''){
                        extraAddr = ' (' + extraAddr + ')';
                    }
                    // 조합된 참고항목을 해당 필드에 넣는다.
                    addr3.value = extraAddr;
                
                } else {
                    addr3.value = '';
                }

                // 우편번호와 주소 정보를 해당 필드에 넣는다.
                zip.value = data.zonecode;
                addr1.value = addr;
                
               	document.getElementById('mapsearch').value = addr1.value;
                
                search();
                
                // iframe을 넣은 element를 안보이게 한다.
                // (autoClose:false 기능을 이용한다면, 아래 코드를 제거해야 화면에서 사라지지 않는다.)
                element_wrap.style.display = 'none';

                // 우편번호 찾기 화면이 보이기 이전으로 scroll 위치를 되돌린다.
                document.body.scrollTop = currentScroll;
            },
            // 우편번호 찾기 화면 크기가 조정되었을때 실행할 코드를 작성하는 부분. iframe을 넣은 element의 높이값을 조정한다.
            onresize : function(size) {
                element_wrap.style.height = size.height+'px';
            },
            width : '100%',
            height : '100%'
        }).embed(element_wrap);
			
        // iframe을 넣은 element를 보이게 한다.
        element_wrap.style.display = 'block';
    }
    
    
</script>
        
    </div>
    <script>

		function addrcheck()
		{
			if(document.getElementById('addzip').value == "")
			{
				alert('우편번호를 설정해주세요');
				$('#addzip').focus();
			}
			else if(document.getElementById('addaddr1').value == "")
			{
				alert('주소를 설정해주세요');
				$('#addaddr1').focus();
			}
			else if(document.getElementById('addaddr2').value == "")
			{
				alert('상세주소를 설정해주세요');
				$('#addaddr2').focus();
			}
			else if(document.getElementById('addaddr3').value == "")
			{
				alert('참고항목을 설정해주세요');
				$('#addaddr3').focus();
			}
			else
			{
				document.getElementById('addaddr').submit();
			}
		}
	
        
        function test(){
            var category = document.getElementsByName("categoryrate");
            var check1 = 0;
            for(i=0;i<category.length;i++){
                if(category[i].checked){
                check1++;
                break;
                }
            }
            var company = document.getElementsByName("companyrate");
            var check2 = 0;
            for(i=0;i<company.length;i++){
                if(company[i].checked){
                check2++;
                break;
                }
            }
            if(check1 && check2){
            }else{
                alert("you must select ratings for both company and category");
                return false;
            }
        }
    </script>

