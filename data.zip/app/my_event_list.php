<?php
include_once('./_common.php');
include_once('./head.sub.php');

$ev_use = "";
if($_REQUEST['ev_use'] == "0")
{
    $ev_use = "0";
}
else 
{
    $ev_use = "1";
}

$evlistsql = "select * from {$g5['g5_shop_event_table']} where ev_use = ".$ev_use;
$evlistres = sql_query($evlistsql);

?>
<link rel="stylesheet" href="<?php echo G5_APP_URL ?>/css/mypage.css">
<body>
    <div class="wrap">
        <div class="head flex-c-m">
            <a href="javascript:" class="back_btn" id="cancel"><i class="material-icons">arrow_back_ios</i></a>
            <h2>이벤트</h2>
        </div>
    
        <section class="sec_1">
            <div class="container min-h-100 my_ul event">
                <ul class="row">
                	
                	<?php 
                    for($i = 0; $evlistrow = sql_fetch_array($evlistres); $i++)
                    {
                	        
                	     //테이블에 이벤트 이미지에 대한 정보가 안보임
                	       ?>
                    		<li class="col-12">
                        	<a href="<?= G5_APP_URL ?>/my_event.php?ev_id=<?= $evlistrow['ev_id']?>">
                        		<h4 class="h4-font"><?= $evlistrow['ev_subject']?></h4>
                            	<div class="img_box" >
                                <img src="<?php echo G5_DATA_URL ?>/event/<?= $evlistrow['ev_id']?>_m" alt="event" style="width:<?= $evlistrow['ev_img_width']?>; height: <?= $evlistrow['ev_img_height']?>">
                            	</div>
                        	</a>
                   		 	</li>    
                	    <?php
                	}
                	?>
                	
				<!-- 
                    <li class="event m-t-20">
                        <a href="#none">
                            <div class="img_box">
                                <img src="<?php echo G5_APP_URL ?>/img/menu1.jpg" alt="event">
                            </div>
                        </a>
                    </li>
                     -->
                </ul>
                <?php
                if($ev_use == 1)
                {
                    ?>
                    <button class="col-12 btn more_btn" onclick = "prevevent()">지난 이벤트 더보기</button>
                    <?php 
                }
                else
                {
                    ?>
                    <button class="col-12 btn more_btn" onclick = "ingevent()">진행 이벤트 더보기</button>
                    <?php 
                }
                ?>
                
            </div>
            <script>
            	function prevevent()
            	{
					location.href = "./my_event_list.php?ev_use=0";            	
            	}
            	
            	function ingevent()
            	{
					location.href = "./my_event_list.php?ev_use=1";            	
            	}
            </script>
        </section>
    </div>
	<?php include_once('./tail.php'); ?>