<?php
include_once('./_common.php');
include_once('./head.sub.php');


$qasql = "select * from {$g5['qa_content_table']} where mb_id = '".$_SESSION['ss_mb_id']."' and qa_type = 0 order by qa_datetime desc";
$qares = sql_query($qasql);


?>
<link rel="stylesheet" href="<?php echo G5_APP_URL ?>/css/mypage.css">
<body>
    <div class="wrap">
        <div class="head flex-c-m">
            <a href="<?php echo G5_APP_URL ?>/my_1on1_list.php" class="back_btn" id="cancel"><i class="material-icons">arrow_back_ios</i></a>
            <h2>문의하기</h2>
        </div>
        <section class="sec_1">
			<div class="container">
            <nav>
                <div class="row row-col-2 text-center">
                    <a href="<?php echo G5_APP_URL ?>/my_1on1_write.php" class="col">1:1 문의하기</a>
                    <a href="<?php echo G5_APP_URL ?>/my_my_1on1.php" class="col active">나의 문의내역</a>
                </div>
            </nav>
			</div>
			
            <div class="container faq">
                <ul class="row">
                
                <?php 
                for($i = 0; $qarow = sql_fetch_array($qares); $i++)
                {
                    $anssql = "select * from {$g5['qa_content_table']}
                                where qa_parent ='".$qarow['qa_parent']."' and qa_related = '".$qarow['qa_related']."' and qa_type = 1";
                    $ansres = sql_query($anssql);
                    $ansrow = sql_fetch_array($ansres);
                    
                    $qatime = date('Y-m-d',strtotime($qarow['qa_datetime']));
                    
                    $anstme = date('Y-m-d',strtotime($ansrow['qa_datetime']));
                    ?>
					<li class="col-12 board-list faq-list show">
                                <dt class="faq_list_q">
                                    <p class=""><?= $qarow['qa_subject']?>
                                    <span class="badge-pill badge-info arrow"><?php if($ansrow['qa_status'] == 1)echo "답변완료";else echo "처리중";?>
                                        </span></p>
                                    <span class="date"><?= $qatime?></span>
                                </dt>
                                <dd class="faq_list_a dis-none">
                                <p class=""><?= $qarow['qa_content']?>
                                <?php 
                                if($qarow['qa_file1'])
                                {
                                    ?>
                                	<img style = "width:100%; margin-top:15px;"src = "<?= G5_DATA_URL.$qarow['qa_file1']?>">    
                                    <?php 
                                }
                                if($qarow['qa_file2'])
                                {
                                    ?>
                                    <img style = "width:100%; margin-top:15px;"src = "<?= G5_DATA_URL.$qarow['qa_file2']?>">
                                    <?php 
                                }
                                ?>
                               	</p>
                               	
                              <?php
                              if($ansrow['qa_status'] == 1)
                              {
                                   ?>
                                   <div class="m-t-15 p-t-15" style = "border-top:1px solid #dddddd">
                                        <span><?= $ansrow['qa_subject']?></span><br>
                                        <span class="date p-t-10 p-b-10">답변 날짜 : <?= $anstme?></span>
                                         <?php 
                                         if($ansrow['qa_file1'])
                                        {
                                            ?>
                                        	<img style = "width:100%"src = "<?= G5_DATA_URL.$ansrow['qa_file1']?>">    
                                            <?php 
                                        }
                                        if($ansrow['qa_file2'])
                                        {
                                            ?>
                                            <img style = "width:100%"src = "<?= G5_DATA_URL.$ansrow['qa_file2']?>">
                                            <?php 
                                        }
                                        ?>
                                        <?= $ansrow['qa_content']?>
                                    </div>
                                </dd>
                                   
                                   <?php                                  
                              }
                              else
                              {
                                  ?>
                                    <span>문의 처리중</span><br>
                                    <div class="m-t-15"><span>답변을 기다려주세요</span></div>
                                </dd>
                                  <?php 
                              }
                              ?>
                    </li>
                    <?php                     
                }
                if($i == 0)
                {
                    ?>
                    <h5>문의내역이 없습니다</h5>
                    <?php 
                }
                ?>
                    
                    
                 <!-- 
                    <li class="faq-list">
                        <div class="inner">
                            <dl class="faq-list-wrap border">
                                <dt class="faq-list-q">
                                    <p class="">문의 제목<span class="badge badge-pill badge-info float-r
                                        ">처리완료</span></p>
                                    <span class="date font-07em col-g">2020-09-01</span>
                                </dt>
                                <dd class="faq-list-a m-b-0 bg-g-ea dis-none">
                                    <span>내가 작성한 문의 내용</span>
                                    <div><span>답변입니다.</span></div>
                                </dd>
                            </dl>
                        </div>
                    </li>
                   -->   
                    
                </ul>
            </div>
            
            
        </section>
    </div>
    <script>
        $(document).ready(function(){
            
            $('.faq_list_a').each(function(index){
                $(this).attr('data-index',index);
            });
            $('.board-list > .i-arrow').each(function(index){
                $(this).attr('data-index',index);
        });
            $('.board-list').each(function(index){
                $(this).attr('data-index',index);
            }).click(function(){
                var p = $(this).attr('data-index');
                $('.board-list > .i-arrow[data-index='+p+']').toggleClass("open");
                $('.faq_list_a[data-index='+p+']').toggle(300);
            });
            
            /* $(".faq-list-a").each(function(index){
                $(this).attr('data-index',index);
        });
        
            $(".faq-list-q").each(function(index){
                $(this).attr('data-index',index);
        }).click(function() {
                var p = $(this).attr('data-index');
                
                
                $(".faq-list-q > .i-arrow").toggleClass("open");
                $(".faq-list-a").slideToggle(300);
            }); */
        });
        </script>

