<?php
include_once('./_common.php');
include_once('./head.sub.php');
include_once(G5_CAPTCHA_PATH.'/captcha.lib.php');
include_once(G5_LIB_PATH.'/register.lib.php');

if ($is_member == "")
{
    echo "<script>
        alert('로그인해주세요','".G5_APP_URL."/login.php');
        
</script>";
}


$sql = "select * from {$g5['member_table']} where mb_id = '{$_SESSION['ss_mb_id']}'";
$row = sql_fetch($sql);


?>
<link rel="stylesheet" href="<?php echo G5_APP_URL ?>/css/mypage.css">
<script src="<?php echo G5_JS_URL ?>/jquery.register_form.js"></script>
<?php if($config['cf_cert_use'] && ($config['cf_cert_ipin'] || $config['cf_cert_hp'])) { ?>
<script src="<?php echo G5_JS_URL ?>/certify.js?v=<?php echo G5_JS_VER; ?>"></script>
<?php } ?>

<style>
label{padding-left:5px !important;}

</style>
<body>
    <div class="wrap">
        <div class="head flex-c-m">
            <a href="javascript:" class="back_btn" id="cancel"><i class="material-icons">arrow_back_ios</i></a>
            <h2>회원정보 수정</h2>
        </div>
        
        <section class="sec_1">
                <div class=" container join-info">
					<ul class="row">
					<input type="hidden" name="type" id="type" value = "">
                        <h4 class="title">정보 수정</h4>
						<li class="col-12">
							<dt>아이디</dt>
							<dd><input type="text" name="info_mb_id" id="info_mb_id" class="w-full m-b-5" value = "<?= $row['mb_id']?>" placeholder="아이디" readonly></li></dd>
						
						<li class="col-12">
							<dt>비밀번호</dt>
							<dd><input type="password" name="info_mb_password" id="info_mb_password" value = "" class="w-full m-b-5" placeholder="비밀번호(영문+숫자+특수문자 조합 8자리 이상)"></li></dd>
							
						<li class="col-12">
							<dt>이름</dt>
							<dd><input type="text" name="mb_name" id="mb_name" class="w-full m-b-5" value = "<?= $row['mb_name']?>" placeholder="이름" readonly></li></dd>
						
						<li class="col-12">
							<dt>닉네임</dt>
							<dd><input type="text" name="info_mb_nick" id="info_mb_nick" class="w-full m-b-5" value = "<?= $row['mb_nick']?>" placeholder="닉네임"></li></dd>
						<li class="col-12">
							<dt>E-mail</dt>
							<dd><input type="text" name="mb_email" id="mb_email" class="w-full m-b-5" value = "<?= $row['mb_email']?>" placeholder="E-mail" readonly></li></dd>
						<!-- <input type="text" name="mb_hp" id="reg_mb_hp" value = "<?= $row['mb_hp']?>"class="w-full m-b-5" placeholder="E-mail"> -->
					</ul>   
						<div class="col-12"><button class="btn w-full btn-secondary" onclick = "info_ch()">정보 변경하기</button></div>
					</ul>
                </div>
        </section>
         <section class="sec_1">
                <div class=" container join-info">
					<ul class="row">
                        <h4 class="title">비밀번호 변경</h4>

						<li class="col-12">
							<dt>아이디</dt>
							<dd><input type="text" name="mb_id" id="reg_mb_id" class="w-full m-b-5" value = "<?= $row['mb_id']?>" placeholder="아이디" readonly></li></dd>
						
						<li class="col-12">
							<dt>현재비밀번호</dt>
							<dd><input type="password" name="pass_mb_password" id="pass_mb_password" value = "" class="w-full m-b-5" placeholder="현재 비밀번호"></li></dd>
						
						
						<li class="col-12">
							<dt>새 비밀번호</dt>
							<dd><input type="password" name="new_mb_password" id="new_mb_password" value = "" class="w-full m-b-5" placeholder="새 비밀번호 (영문+숫자+특수문자 조합 8자리 이상)"></li></dd>
						
						<li class="col-12">
							<dt>새 비밀번호 확인</dt>
							<dd><input type="password" name="new_mb_repassword" id="new_mb_repassword" value = "" class="w-full m-b-5" placeholder="새 비밀번호 확인 (영문+숫자+특수문자 조합 8자리 이상)"></li></dd>
						
					</ul>   
						<div class="col-12"><button class="btn w-full btn-secondary" onclick = "pass_ch();">비밀번호 변경하기</button></div>
					</ul>
                </div>
        </section>
    </div>
	  <script>
    function info_ch()
    {
    	$.ajax({
				url : "./controllor/my_info_up.php",
				type : "POST",
				data : {
					type : "info",
					pass : $('#info_mb_password').val(),
					nick : $('#info_mb_nick').val(),
					id : $('#reg_mb_id').val(),
					},
					success : function(result) 
					{

						if(result == "0")
						{
							alert("비밀번호를 확인해주세요");
						}
						else if(result == "1")
						{
							alert("사용중인 닉네임입니다");
						}
						else if(result == "2")
						{
							//정보 변경 성공
							alert("정보수정 성공","<?= G5_APP_URL?>");
						}
						
						
					}
        	});
    }
    
    function pass_ch()
    {
    	$.ajax({
			url : "./controllor/my_info_up.php",
			type : "POST",
			data : {
				type : "pass",
				pass : $('#pass_mb_password').val(),
				new_pass : $('#new_mb_password').val(),
				new_repass : $('#new_mb_repassword').val(),
				id : $('#reg_mb_id').val()
				},
				success : function(result) 
				{
					if(result == "0")
					{
						alert("비밀번호를 확인해주세요");
					}
					else if(result == "3")
					{
						alert("비밀번호 변경 성공", "<?= G5_APP_URL?>");
					}
					else if(result=="4")
					{
						alert("새 비밀번호가 일치하지 않습니다");
					}
					
				}
    	});
    }
</script>
<?php include_once('./tail.php'); ?>