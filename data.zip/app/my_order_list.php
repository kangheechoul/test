<?php
include_once('./_common.php');
include_once('./head.sub.php');


if ($is_member == "")
{
    echo "<script>
        alert('로그인해주세요','".G5_APP_URL."/login.php');
</script>";
    
}

$ordersql = "select * from {$g5['g5_shop_order_table']} where mb_id = '".$_SESSION['ss_mb_id']."'";


$cartsql = "select * from {$g5['g5_shop_cart_table']} where mb_id = '".$_SESSION['ss_mb_id']."'";
$cartres = sql_query($cartsql);


if($_REQUEST['firstdate'] != NULL)
{
   
    $day = " and od_time between date ('".$_REQUEST['firstdate']." 00:00:00') and date('".$_REQUEST['lastdate']." 00:00:00')+1";
    
    $ordersql .= $day." order by od_time desc";
    
    $orderres = sql_query($ordersql);
}
else
{
    $ordersql .= " order by od_time desc";
    $orderres = sql_query($ordersql);
}

if(isset($_REQUEST['num']))
{
    $num = $_REQUEST['num'];
}

?>
<style>
.active {color:#2eaea9;}


</style>
<link rel="stylesheet" href="<?php echo G5_APP_URL ?>/css/mypage.css">
<body>
    <div class="wrap">
        <div class="head flex-c-m">
            <a href="javascript:" class="back_btn" id="cancel"><i class="material-icons">arrow_back_ios</i></a>
            <h2>주문내역</h2>
        </div>
        <section class="sec_1">
			<div class="container">
            <ul class="row row-col-4 tabs flex-sb-m">
                <li class="col">
                    <a class="<?php if($num == 7) echo "active";?>" ><div onclick = "date(7);"/>1주일</a>
                </li>
                <li class="col">
                    <a class="<?php if($num == 30) echo "active";?>"><div onclick = "date(30);"/>1개월</a>
                </li>
                <li class="col">
                    <a class="<?php if($num == 90) echo "active";?>"><div onclick = "date(90);"/>3개월</a>
                </li>
                <li class="col">
                    <a class="<?php if($num == 180) echo "active";?>"><div onclick = "date(180);"/>6개월</a>
                </li>
            </ul>
            </div>
            
            <div class="container date_input">
                <input type="date" class="data-input" id = "firstdate" value ="<?php if($_REQUEST['firstdate']) echo $_REQUEST['firstdate']; else echo date("Y-m-d"); ?>" max="<?= date("Y-m-d") ?>" min = "2020-01-01">
                <span class="m-l-3 m-r-3">~</span>
                <input type="date" class="data-input" id = "lastdate" value ="<?php if($_REQUEST['lastdate']) echo $_REQUEST['lastdate']; else echo date("Y-m-d"); ?>"  max="<?= date("Y-m-d") ?>" min = "2020-01-02"> 
                <button class="bg-r col-w bo-n" onclick = "date(0)">조회</button>
            </div>
			
			<div class="container my_ul">
                <ul class="row order_list">
                    <?php 
                    
                    for($i = 0; $orderrow = sql_fetch_array($orderres); $i++)
                    {
                         $it_list_tmp = explode(';', $orderrow['od_it_list']);
                        
                        for($k = 0; $k < count($it_list_tmp)-1; $k++)
                        {
                            $it_tmp = explode(':', $it_list_tmp[$k]);
                            if($k == 0)
                            {
                                $it_view_name = $it_tmp[1];
                               
                            }
                            $ct_price += $it_tmp[2] * $it_tmp[3];
                            
                        }
                        /*
                        $op_list_tmp = explode(';',$orderrow['od_it_option']);
                        
                        for($k = 0; $k < count($op_list_tmp)-1; $k++)
                        {
                            $op_tmp = explode(':', $op_list_tmp[$k]);
                            if($k == 0)
                            {
                                $op_view_name = $op_tmp[1];
                                
                            }
                            $ct_price += $op_tmp[2]; 
                        }
                        
                        if($orderrow['pl_id'] == 0 || $orderrow['pl_id'] == "")
                        {
                            $ct_price += $orderrow['od_delivery_pay'];
                        } */
                        
                        //리스트에 표현할 상품 수   -2 => ex) 찌개 외 3개 
                        $count = count($it_list_tmp)-2;
                        
                        /* 1611732102:야식으로 어때 해물 볶음 사리:20000:3;
                        1608620375:해물가득 볶음밥:12000:4;
                        1611732038:초간단 어묵탕:20000:3;
                        1611728020:닭한마리 간장 찜닭:15000:4; */
                        
                        ?>
						<li class="col-12">
                                <dt>
                                    <h4 class="h4-font m-b-0"><?php if($orderrow['od_type'] == "delivery") echo "배달"; else echo "포장";?>
                                    <!-- 시간 설정 -->
                                    <span class="font-08em col-g m-l-5">
                                    <?php 
                                    $day = "오늘";
                                    
                                    $today = new DateTime(date('Y-m-d'));
                                    
                                    $endday = new DateTime(date('Y-m-d',strtotime($orderrow['od_time'])));
                                    
                                    $diff    = date_diff($today, $endday);
                                    
                                    if($diff->days == "1")
                                    {
                                        $day = "어제";
                                    }
                                    else if($diff->days == "0")
                                    {
                                        $day = "오늘";
                                    }
                                    else
                                    {
                                        $day = date('Y-m-d',strtotime($orderrow['od_time']));
                                    }
                                    ?>
                                    <?= $day?>
                                    </span>
                                    </h4>
									<!-- 상세보기 페이지 만들어야함 -->
                                
                                    <a class="arrow" href="./my_order_info.php?od_id=<?= $orderrow['od_id']?>&pl_id=<?= $plrow['pl_id']?>"><span class="">
                                    상세보기
                                    </span></a>
                                </dt>
                                
                            </dl>
                            <dl class="flex-sb-m m-b-0">
                                <dt>
                                    <p class="font-08em col-g f-w-500">
                                    <?php 
                                    
                                       if($count > 1)
                                       {
                                           echo $it_view_name." 외 ".$count."개 ".number_format($orderrow['od_cart_price'])." 원";
                                       }
                                       else
                                       {
                                           echo $it_view_name." 1개 ".number_format($orderrow['od_cart_price'])." 원";
                                           
                                       }
                                    ?></p>
                                </dt>
                                <dd>
                                    <span class="" id = "status"><?= $orderrow['od_status']?></span>
                                </dd>
                    	</li>
                        <?php       
                    }
                    if($i == 0)
                    {
                        ?>
						<span>주문내역이 없습니다.</span>                        
                        <?php 
                    }
                    ?>
                    
                    <!-- 샘플 -->
                    <!-- 
                     <li class="border-b border-g">
                        <div class="inner">
                            <dl class="flex-sb-m m-b-0">
                                <dt>
                                    <h4 class="h4-font m-b-0">해운대점<span class="font-08em col-g m-l-5">1일전</span></h4>
                                </dt>
                                <dd>
                                    <span class="badge badge-pill badge-danger">배달완료</span>
                                </dd>
                            </dl>
                            <dl class="flex-sb-m m-b-0">
                                <dt>
                                    <p class="font-08em col-g f-w-500">김치찌개 외 1개 16,000원</p>
                                </dt>
                                <dd>
                                    <span class="borders border-r padding-lr-4 font-08em col-gr">상세보기</span>
                                </dd>
                            </dl>
                        </div>
                    </li>
                     -->
                    <!-- 샘플 -->
                </ul>
            </div>
        </section>
        
        <script>
        	function date(day)
        	{
        		var first = document.getElementById('firstdate').value;
        		var last = document.getElementById('lastdate').value;
        	
        		if(day == 0)
        		{
					  location.href="<?= G5_APP_URL?>/order_list.php?firstdate="+first+"&lastdate="+last;      			
        		}
        		else
        		{
        			var fday = new Date(first);
        			var lday = new Date(last);
        		
        			var before= new Date(Date.parse(lday) - day * 1000 * 60 * 60 * 24);
        		
        			let YYYYMMDD = before.toISOString().slice(0, 10);
								
					document.getElementById('firstdate').value = YYYYMMDD;
				
					var fparam = "firstdate="+ YYYYMMDD;
					var lparam = "&lastdate="+ last;
				
					location.href="<?= G5_APP_URL?>/order_list.php?"+fparam+lparam+"&num="+day;
        		}
				
        	}
        	
        </script>
        

    </div>

<?php include_once('./tail.php'); ?>
