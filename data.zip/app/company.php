<?php 
include_once('./_common.php');
include_once('./head.sub.php');
?>

    <title>미미쿡 - 회사 소개</title>

<body>
    <div class="wrap">
    <div class="head flex-c-m"><img src="<?php echo G5_APP_URL ?>/img/mimicook-logo.png" alt="logo"></div>
        <section>
            <div class="container company">
                <h3 class="start-img text-center"><img src="<?= G5_URL?>/img/start.png" alt=""></h3>
                <p class="s-title">주식회사 시작은 식문화에 대한 바른 이해와 기본을 제일의 가치로 생각합니다.</p>
                <p class="s-title">종사자 대부분이 외식 관련 분야에서 오랜 기간 경험을 갖춘 외식 전문 기업으로써 
                    2012년 모모스테이크 브랜드를 론칭하여 105개의 누적 가맹점을 오픈한 경험과 현재까지도 다양한 외식 분야에서 끝없는 도전과 열정, 믿음을 갖춘 기업입니다.</p>
                <p class="s-title">자체 물류 창고 및 배송 시스템을 갖추고 있으며 20여 년 동안 다양한 외식 브랜드의 론칭과 운영 경험을 갖춘 프랜차이즈 전문 기업입니다.</p>
                <h3 class="title border-top">본사</h3>
                <p class="s-title">부산광역시 기장군 기장읍 반송로 1595</p>
                <p class="s-title">대표번호 1899 - 1195</p>

                <div class="row mt-4">
                    <div class="col-lg-6 col-md-6 col-sm-12">
                        <img class="imgs" src="<?= G5_URL?>/img/company-item1.jpg" alt="company-item1">
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12">
                        <div><img class="imgs mb-4" src="<?= G5_URL?>/img/company-item2.jpg" alt="company-item2"></div>
                        <div><img class="imgs" src="<?= G5_URL?>/img/company-item3.jpg" alt="company-item3"></div>
                    </div>
                </div>
            </div>
        </section>
    </div>

</body>
<?php include_once('./tail.php'); ?>