<?php
include_once('./_common.php');
include_once('./head.sub.php');
?>
<link rel="stylesheet" href="<?php echo G5_APP_URL ?>/css/mypage.css">
<body>
    <div class="wrap">
        <div class="head flex-c-m"><img src="<?php echo G5_APP_URL ?>/img/mimicook-logo.png" alt="logo"></div>
        <section class="sec_1">
			<div class="container min-h-f">
			<div class="row">
			<h3 class="col-12 title text-center m-b-10">회원가입을 축하드립니다.</h3>
			<button class="btn btn-secondary m-b-10" onclick ="location.href='<?php echo G5_APP_URL?>'">홈으로</button>
        	<button class="btn bg-gr" onclick ="location.href='./menu_list.php'">주문하러가기</button>
			</div>
			</div>
        </section>

        

    
    </div>
<?php include_once('./tail.php'); ?>
