<?php
header('Cache-Control: no cache');
include_once('./_common.php');
include_once('./head.sub.php');


if ($is_member == "")
{
    echo "<script>
         alert('로그인해주세요','".G5_APP_URL."/login.php');
</script>";
    
}

$placesql = "select * from {$g5['place_table']}";
$placeres = sql_query($placesql);
//위도와 경도를 구해서 배열에 넣었다
echo "<script>var arr = new Array(); var comparearr = new Array();</script>";

for($i = 0; $placerow = sql_fetch_array($placeres); $i++)
{
    echo "<script>
          arr[{$i}] = ['{$placerow['pl_name']}',{$placerow['pl_latitude']},{$placerow['pl_longitude']}, '{$placerow['pl_addr1']}', '{$placerow['pl_addr2']}','{$placerow['pl_addr3']}','{$placerow['pl_hp']}',{$placerow['pl_id']}];
</script>";
}

$delivery_pay = 2000;

$type = "";

//장바구니 결제 페이지로 변경해야함 __________________________
    
    $mb_sql = "select * from {$g5['member_table']} where mb_id = '".$_SESSION['ss_mb_id']."'";
    $mb_row = sql_fetch($mb_sql);
    
    $mb_hp = $mb_row['mb_hp'];
    
    $P_UNAME = $mb_row['mb_name'];
    



$ct_id = $_REQUEST['ct_id'];
$ct_price = $_REQUEST['ct_price'];
$ct_name = $_REQUEST['ct_name'];
$ct_qty = $_REQUEST['ct_qty'];
$ct_option = $_REQUEST['ct_option'];
$io_price = $_REQUEST['io_price'];
$it_id = $_REQUEST['it_id'];
$io_id = $_REQUEST['io_id'];


$site = G5_APP_URL;

//세션 유지용
//사용자 아이디
$mb_id = $_SESSION['ss_mb_id'];
//카트번호
$od_id = $_SESSION['ss_cart_id'];
//사용자 키
$mb_key = $_SESSION['ss_mb_key'];


//주문자 이름
$od_name = $mb_row['mb_name'];
//주문자 이메일
$od_email = $mb_row['mb_email'];
//주문자 비밀번호 (왜 필요한지 모르나 db에 있음)
$od_pwd = $mb_row['mb_password'];


//주문자 전화번호
$od_hp = $mb_row['mb_hp'];

//주문자 우편번호
$od_zip1 = $_REQUEST['od_zip1'];
$od_zip2 = $_REQUEST['od_zip2'];
//주문자 주소 1
$od_addr1 = $_REQUEST['od_addr1'];
//주문자 주소 2
$od_addr2 = $_REQUEST['od_addr2'];
//주문자 주소 3
$od_addr3 = $_REQUEST['od_addr3'];
//주문자 주소 타입 도로명 R / 지번 ?
$od_addr_jibeon = $_REQUEST['od_addr_jibeon'];
//예금자 이름 (주문자 이름)
$od_deposit_name = $mb_row['mb_name'];
//주문 메모
$od_memo = $_REQUEST['od_memo'];

$ct_option = $_REQUEST['ct_option'];

//배송비
$od_delivery_pay = "2000";

$it_id = $_REQUEST['it_id'];
$it_name = $_REQUEST['it_name'];

//카트아이템 개수
$od_cart_count = count($it_id);

//각 상품 가격
$od_ct_price = $_REQUEST['ct_price'];
//각 상품 개수
$od_ct_qty = $_REQUEST['ct_qty'];
//상품들의 옵션 가격 합 배열
$io_all_price = $_REQUEST['io_all_price'];


//상품들의 가격 더하기
for($i = 0; $i < $od_cart_count; $i++)
{
    $price += $od_ct_price[$i] * $od_ct_qty[$i];
    $price += $io_all_price[$i];
    
    $od_it_list .= $it_id[$i].":".$it_name[$i].":".$od_ct_price[$i].":".$od_ct_qty[$i].";";
    $od_it_option .= $ct_option[$i];
    $P_GOODS = $it_name[0];
}

if($i > 1)
{
    $P_GOODS .= " 외 ".($i-1)."개";
}



//카트 아이템 총 가격
//echo $price;
$od_cart_price = $price;

//3% 할인
$dc = 3;
$dc_price = round($price * ($dc/100));
$price = $price - $dc_price;

//가격 + 배송비
$price_all = $price +  $od_delivery_pay;

//결제방식
$od_settle_case = $_REQUEST['od_settle_case'];
//ex
if($od_settle_case == "1")
{
    $od_settle_case = "무통장";
}



//주문 은행?
$od_bank_account = "";
//부가세 포함가격
$od_tax_mny = round($od_cart_price/1.1);
//부가세
$od_vat_mny = round($od_cart_price - $od_tax_mny);
//주문 시간
$od_time = date("Y-m-d H:i:s");
//상점 번호
$pl_id = "";
//주문 상태
$od_status = "입금";
//아이피
$od_ip = $_SERVER['REMOTE_ADDR'];
//지점 번호
$pl_id = $_REQUEST['pl_id'];

// 이니시스 결제요청 필수 파라미터

//CARD, BANK, VBANK, MOBILE

$P_INI_PAYMENT = $od_settle_case;
//$P_MID = "SIRmimicoo";
$P_MID = "INIpayTest";
$P_MNAME = "mimicook";
$P_UNAME = $mb_row['mb_name'];


?>

<script>
function create_url()
{
	var url = "mb_id=<?= $mb_id?>&"
		+"od_name=<?= $od_name?>&"
		+"od_email=<?= $od_email?>&"
		+"od_hp=<?= $od_hp?>&"
		+"od_zip1="+$('#od_zip1').val()+"&"
		+"od_zip2="+$('#od_zip2').val()+"&"
		+"od_addr1="+$('#od_addr1').val()+"&"
		+"od_addr2="+$('#od_addr2').val()+"&"
		+"od_addr3="+$('#od_addr3').val()+"&"
		+"od_addr_jibeon="+$('#od_addr_jibeon').val()+"&"
		+"od_deposit_name=<?= $od_deposit_name?>&"
		+"od_cart_price=<?= $od_cart_price?>&"
		+"od_cart_count=<?= $od_cart_count?>&"
		+"od_memo="+$('#od_memo').val()+"&"
		+"od_delivery_pay="+$('#delivery_pay').val()+"&"
		+"od_status=<?= $od_status?>&"
		+"od_settle_case="+$('#od_settle_case').val()+"&"
		+"od_tax_mny=<?= $od_tax_mny?>&"
		+"od_vat_mny=<?= $od_vat_mny?>&"
		+"od_time=<?= $od_time?>&"
		+"od_ip=<?= $od_ip?>&"
		+"mb_key=<?= $mb_key?>&"
		+"od_id=<?= $od_id?>&"
		+"od_pwd=<?= $od_pwd?>&"
		+"od_it_list=<?= $od_it_list?>&"
		+"od_it_option=<?= $od_it_option?>&"
		+"od_sale_price=<?= $dc_price?>&"
		+"od_type="+$('#od_type').val()+"&"
		+"pl_id="+$('#pl_id').val()+"";

		url = encodeURI(url);
		$('#P_NOTI').val(url);
		
}

</script>

<style>
#tel_div{padding:15px}
</style>


<script src="https://t1.daumcdn.net/mapjsapi/bundle/postcode/prod/postcode.v2.js"></script>

<?php 

$cf = get_config();
?>
<script src="//dapi.kakao.com/v2/maps/sdk.js?appkey=<?php echo $cf['cf_kakao_rest_key']?>&libraries=services"></script>
<link rel="stylesheet" href="<?php echo G5_APP_URL ?>/css/order.css">

<body>
    <div class="wrap">
        <div class="head flex-m">
            <a href="javascript:" class="back_btn" id="cancel"><i class="material-icons">arrow_back_ios</i></a>
            <h2>주문 결제</h2>
            <!-- <button class="btn float-r delet"><i class="material-icons">delete</i></button> -->
        </div>
        
        <form id= "order_form" name = "order_form" action = "https://mobile.inicis.com/smart/payment/" accept-charset="EUC-KR" method="POST">
        <input type = "hidden" id = "od_type" name = "od_type" value = "delivery">
        <input type= "hidden" id = "od_sale_price" name = "od_sale_price" value = "<?= $dc_price?>">
        <!-- 배달 가능 여부 -->
        <input type = "hidden" id = "deli_check" name = "deli_check" value = "0">
        <!-- 결제 타입 -->
        <input type= "hidden" id = "P_INI_PAYMENT" name="P_INI_PAYMENT" value="" >
        
        <!-- 상점 아이디 -->
        <input type= "hidden" name = "P_MID" value ="<?= $P_MID?>">
        <!-- 주문번호 -->
        <input type= "hidden" name = "P_OID" value ="<?= $P_MID.$od_id?>">
        <!-- 가격 -->
        <input type= "hidden" id = "P_AMT" name = "P_AMT" value ="<?= $price_all?>">
        <!-- <input type= "hidden" id = "P_AMT" name = "P_AMT" value ="1000"> -->
        <!-- 상품이름 -->
        <input type= "hidden" name = "P_GOODS" value ="<?= $P_GOODS?>">
        <!-- 구매자 이름 -->
        <input type= "hidden" name = "P_UNAME" value ="<?= $P_UNAME?>">
        
        <!-- 가맹점 이름 -->
        <input type="hidden" id = "P_MNAME" name="P_MNAME" value="<?= $P_MNAME?>" >
        <!-- 결과 페이지 -->
        <input type= "hidden" name = "P_NEXT_URL" value ="<?= $site."/controllor/order_form_submit.php"?>">
        <!-- noti수신 페이지 -->
        <input type= "hidden" name = "P_NOTI_URL" value ="<?= $site."/controllor/noti.php"?>">
        <!-- 결제 상품 유형 -->
        <input type= "hidden" name = "P_HPP_METHOD" value ="2">
        <!-- merchantData -->
        <input type= "hidden" id= "P_NOTI" name = "P_NOTI" value = "">
        <!-- 결제별 추가옵션 -->
        <input type= "hidden" name = "P_RESERVED" value ="vbank_receipt=N&bank_receipt=N"/>
        
        <div id="map_2" style="display:none"></div>
       	<!-- 배달지 정보? --> 
        <section class="sec_1">
            <div class="container write">
                <div class="row choic">
                    <h4 class="col-12 m-b-10">주소</h4>
                    
                    <input type= "hidden" id = "delivery_pay" name = "delivery_pay" value ="<?= $delivery_pay?>">
                    <div class="col-6"><input type ="radio" name ="order_type" onchange="type_check()" value = "delivery" checked>배달</div>
					<div class="col-6"><input type ="radio" name ="order_type" onchange="type_check()" value = "take" >포장</div>
                    
                    
                    
                    <div id = "delivery_div" style = "display:block">
                    
                    <!--배달 -->
					<div class="row row-col-3">
                    <span class="col-4 address active" id = "open_my_addr" onclick ="ad_addr()">내 주소</span>
                    <span class="col-4 address" id = "open_late_addr" onclick ="od_addr()">최근 주소</span>
                    <span class="col-4 address" id = "open_search_addr" onclick ="sample3_execDaumPostcode()">주소검색</span>
                   	</div>
					
                   	<div id = "ad_addr">
                   	<?php 
                   	$ad_sql = "select * from {$g5['g5_shop_order_address_table']} where mb_id = '".$_SESSION['ss_mb_id']."' limit 5";
                   	$ad_res = sql_query($ad_sql);
                   	for($i = 0 ; $ad_row = sql_fetch_array($ad_res); $i++)
                   	{
                   	    ?>
                   	    -<span onclick = "ad_addr_choice('<?= $i?>')"><?= $ad_row['ad_addr1']." ".$ad_row['ad_addr3']." ".$ad_row['ad_addr2']?></span><br>
                   	    <input type= "hidden" id = "ad_<?= $i?>_zip1"  value ="<?= $ad_row['ad_zip1']?>">
						<input type= "hidden" id = "ad_<?= $i?>_zip2"  value ="<?= $ad_row['ad_zip2']?>">
                   	    <input type ="hidden" id = "ad_<?= $i?>_addr1"  value = "<?= $ad_row['ad_addr1']?>">
                   	    <input type ="hidden" id = "ad_<?= $i?>_addr2"  value = "<?= $ad_row['ad_addr2']?>">
                   	    <input type ="hidden" id = "ad_<?= $i?>_addr3"  value = "<?= $ad_row['ad_addr3']?>">
                   	    <input type ="hidden" id = "ad_<?= $i?>_addr_jibeon" value = "<?= $ad_row['ad_addr_jibeon']?>"> 
                   	    <?php 
                   	}
                   	if($i == 0)
                   	{
                   	    ?>
                   	    <span>주소가 없습니다</span>
                   	    <?php 
                   	}
                   	
                   	?>
                   	</div>
                   	
                   	<!-- 최근 주소 -->
                   	<div id = "od_addr" style = "display:none">
                   	<?php 
                   	$ordersql = "select * from {$g5['g5_shop_order_table']} where mb_id = '".$_SESSION['ss_mb_id']. "' and pl_id = '' limit 5";
                   	$orderres = sql_query($ordersql);
                   	for($i = 0; $orderrow = sql_fetch_array($orderres); $i++)
                   	{
                    ?>
                   	-<span onclick = "od_addr_choice('<?= $i?>')"><?= $orderrow['od_addr1']." ".$orderrow['od_addr2']." ".$orderrow['od_addr3']?></span><br>
                   	    <input type= "hidden" id = "od_<?=$i?>_zip1" value ="<?= $orderrow['od_zip1']?>">
						<input type= "hidden" id = "od_<?=$i?>_zip2"  value ="<?= $orderrow['od_zip2']?>">
                   	    <input type ="hidden" id = "od_<?=$i?>_addr1"  value = "<?= $orderrow['od_addr1']?>">
                   	    <input type ="hidden" id = "od_<?=$i?>_addr2"  value = "<?= $orderrow['od_addr2']?>">
                   	    <input type ="hidden" id = "od_<?=$i?>_addr3"  value = "<?= $orderrow['od_addr3']?>">
                   	    <input type ="hidden" id = "od_<?=$i?>_addr_jibeon"  value = "<?= $orderrow['od_addr_jibeon']?>"> 
                    <?php                    	    
                   	}
                   	if($i == 0)
                   	{
                   	    ?>
                   	    <span>주소가 없습니다</span>
                   	    <?php 
                   	}
                   	
                   	?>
                   	</div>
                   	
                   	<!-- 주소 검색창 -->
                   	<div id="wrap" style="display:none;border:1px solid;width:95%;height:70%;margin:10px 0;">
					<img src="//t1.daumcdn.net/postcode/resource/images/close.png" id="btnFoldWrap" onclick="foldDaumPostcode()" alt="접기 버튼">
					</div>
                    
                    <div id = "od_addr_div" class="inner m-b-5">
                    		<h4 class="h4-font" id = "storename"></h4>
                            <input type="hidden" id = "od_zip1" name = "od_zip1" value = "">
                            <input type="hidden" id = "od_zip2" name = "od_zip2" value = "">
                            <input type="hidden" id = "od_addr_jibeon" name = "od_addr_jibeon" value = "">
                            <p class="title">배달 주소</p>
                            <input type="text" class="f-input" id = "od_addr1" name = "od_addr1" placeholder="주소 1" value = "">
                            </div>
                            <div class="inner m-b-5">
                            <input type="text" class="f-input" id = "od_addr2" name = "od_addr2" placeholder="주소 2" value = "">
                            </div>
                            <div class="inner m-b-5">
                            <input type="text" class="f-input" id = "od_addr3" name = "od_addr3" placeholder="상세주소" value = "">
                            </div>
                   </div>
                 </div>
                <!--배달 -->
                <div id = "take_div" style="display:none">
                	<div id = "pl_cho" style="display:none">
                	
                    <div id="map" style="width:100%;height:500px;"></div>
                	
                    <p class="info m-t-10">현재위치에서 <span class="col-r">2km</span> 이내 매장만 가능하며 바로결제, 방문결제 선택이 가능합니다.</p>
                    <ul>
                    	<div id="distance"></div>
                    </ul>
                    </div>
                    <div id = "store" style ="width:80%;">
                    	<h4 class="h4-font" id= "pl_name" style= "margin-bottom:5px"></h4>
                    	<input type= "hidden" id = "pl_id" name= "pl_id" value = "">
						<!--
                     	<input type="text" id = "pl_addr1" name ="pl_addr1" class="f-input" placeholder="주소 1" value = "" readonly>
                     	<input type="text" id = "pl_addr2" name ="pl_addr2" class="f-input" placeholder="주소 2" value = "" readonly>
                     	<input type="text" id = "pl_addr2" name ="pl_addr3" class="f-input" placeholder="상세주소" value = "" readonly>
                     	<h5 class="h5-font" id = "storehp">
						-->
                    </div>
                 </div>
            </div>
            <div class = "container" id = "tel_div" >
			<div class="row">
			<h4 class="col-10 m-b-10">연락처</h4>
            <h4 class="col-10" id="od_hp_text"><?php echo $mb_hp;?></h4>
            <span class="col-2 bg-gr border-radi-20" id="hp_c" onclick = "hp_ch(1)">변경</span>
            <span class="col-2 bg-gr border-radi-20" id= "hp_n"style ="display:none" onclick = "hp_ch(2)">취소</span>
			
            				<script>
							function hp_ch(num)
							{
								if(num == 1)
								{
									$('#hp_c').css('display', 'none');
									$('#hp_n').css('display', 'inline-block');
									
									$('#od_hp_text').text('');
									$('#od_hp').val('');
									$('#od_hp').attr('type', 'text');
									$('#od_hp').attr('readonly', false);
								}
								else if (num == 2)
								{
									$('#hp_c').css('display', 'inline-block');
									$('#hp_n').css('display', 'none');
									
									$('#od_hp_text').text('<?= $mb_hp?>');
									$('#od_hp').val('<?=str_replace("-","",$mb_hp)?>');
									$('#od_hp').attr('type', 'hidden');
									$('#od_hp').attr('readonly', true);
								}
									
								
							}
            				</script>
            				
                            <div class="col-12 check-inner m-t-10">
                            	<input type="hidden" name= "od_hp"id = "od_hp" value = "<?=str_replace("-","",$mb_hp)?>">    
                            
                            <!-- <input type="checkbox" name=  "" class="check-inputs float-l" id="check">
                            <label for="check">안심번호사용하기</label> -->
                            </div>
				</div>
            </div>		
        </section>
        
        <!-- 요청사항 수정란  -->
        <section class="sec_2">
            <div class="container write">
                <div class="row choic">
                    <h4 class="col-12">요청사항</h4>
                    <div class="col-12 inner m-b-5">
                        <p class="title">가게 사장님께</p>
                        <input type="text" id = "od_memo" name = "od_memo" class="f-input" placeholder="예)견과류는 빼주세요, 덜 맴게 해주세요">
                    </div>
                    
               <!--      <div class="check-inner">
                        <input type="checkbox" name = "" class="check-inputs float-l" id="again">
                        <label for="again" class="float-l">다음에도 사용</label>
                    </div> -->
                    
                    <!-- <div class="check-inner">
                        <input type="checkbox" name = "od_memo" class="check-inputs float-l" id="no_po">
                        <label for="no_po" class="float-l">일회용 수저, 포크 안 주셔도 돼요</label>
                    </div> -->
                </div>
            </div>
			
			<div class="container write">
			<!-- 모듈에 있는 결제수단을 알아야 수정가능 -->
			<div class="row">
                <h4 class="col-12 m-b-10">결제수단</h4>
                <div class="col-12 inner pos-relative">
                    <select name="od_settle_case" id="od_settle_case" class="f-select">
                        <option value="CARD">신용카드</option>
                        <option value="BANK">계좌이체</option>
                        <option value="VBANK">무통장입금</option>
                    </select>
                </div>
				</div>
            </div>
			
			<div class="container min-h my_ul">
                
                <ul class="row choic" id = "delivery_pay_div">
				<h4 class="col-12">주문 정보</h4>
				<li class="col-12"><dt>금액</dt><dd><?= number_format($price + $dc_price)?> 원</dd></li>
				<li class="col-12"><dt>할인</dt><dd>- <?= number_format($dc_price)?> 원</dd></li>
				<li class="col-12 border-b"><dt>배달료</dt><dd id = "view_delivery_pay" ><?= number_format($delivery_pay)?> 원</dd></li>
				<li class="col-12"><dt class="total">최종 금액</dt><dd class="total-price" id = "view_pay"><?= number_format($price_all)?> 원</dd></li>
					
                </ul>
                <input type= "hidden" id = "price" name = "price" value = "<?= $price_all?>">
                    <!-- 주문하기 모듈 필요 -->
       	 			
            </div>
        </section>
        
        
        
        <?php 
        $i= 0;
        foreach ($_REQUEST as $key => $value)
        {
            if(gettype($value) == "array")
            {
                foreach ($value as $k => $v)
                {
                    ?>
                    <input type ="hidden" id= "<?= $key.$i?>"name ="<?= $key?>[]" value = "<?= $v?>">
                    <?php 
                    $i++;
                }
            }
            else 
            {
            ?>
            <input type= "hidden" name=  "<?= $key?>[]" value = "<?= $value?>">
            <?php
            }
            $i = 0;
        }
        
        
        ?>
        
        </form>
        <!-- 거리확인용 -->
        <!-- <div id="map"></div> -->
    </div>
    <button class="btn btn-red" onclick="order()" ><span class="cir"><?= $_POST['od_qty']?></span> <span id = "payment"><?= number_format($price + $delivery_pay)?></span>원 결제</button>
    
    <script>

    

    
    // 우편번호 찾기 찾기 화면을 넣을 element
    var element_wrap = document.getElementById('wrap');
    
    
    function foldDaumPostcode()
     {
        // iframe을 넣은 element를 안보이게 한다.
        element_wrap.style.display = 'none';
    }

    function addr_reset()
    {
    	$('#od_addr_jibeon').val();
		$('#od_zip1').val();
		$('#od_zip2').val();
		$('#od_addr1').val();
		$('#od_addr2').val();
		$('#od_addr3').val();
    }

	var address_class = "col-4 address";

    
  	function ad_addr()
   	{
   		$('#ad_addr').css("display", "block");
   		$('#od_addr').css("display", "none");
   	 	element_wrap.style.display = 'none';

   	 	$('#open_my_addr').attr('class', address_class + ' active');
   		$('#open_late_addr').attr('class', address_class);
	   	$('#open_search_addr').attr('class', address_class);
    }
	

	function od_addr()
   	{
   		$('#ad_addr').css("display", "none");
   		$('#od_addr').css("display", "block");
   	 	element_wrap.style.display = 'none';
   	 	
   	 $('#open_my_addr').attr('class', address_class);
		$('#open_late_addr').attr('class', address_class + ' active');
	   	$('#open_search_addr').attr('class', address_class);
    }

    function sample3_execDaumPostcode() {
    	$('#od_addr').css("display", "none");
   		$('#ad_addr').css("display", "none");
   		
   		$('#open_my_addr').attr('class', address_class);
   		$('#open_late_addr').attr('class', address_class);
	   	$('#open_search_addr').attr('class', address_class + ' active');
   		
        // 현재 scroll 위치를 저장해놓는다.
        var currentScroll = Math.max(document.body.scrollTop, document.documentElement.scrollTop);
        document.getElementById('btnFoldWrap').style.top = "";
        new daum.Postcode({
            oncomplete: function(data) {
                // 검색결과 항목을 클릭했을때 실행할 코드를 작성하는 부분.
			
                // 각 주소의 노출 규칙에 따라 주소를 조합한다.
                // 내려오는 변수가 값이 없는 경우엔 공백('')값을 가지므로, 이를 참고하여 분기 한다.
                var addr = ''; // 주소 변수
                var extraAddr = ''; // 참고항목 변수
                addr_reset();
                //사용자가 선택한 주소 타입에 따라 해당 주소 값을 가져온다.
                if (data.userSelectedType === 'R') { // 사용자가 도로명 주소를 선택했을 경우
                    addr = data.roadAddress;
                    $('#od_addr_jibeon').val("R");
                } else { // 사용자가 지번 주소를 선택했을 경우(J)
                    addr = data.jibunAddress;
                    $('#od_addr_jibeon').val("J");
                }

                // 사용자가 선택한 주소가 도로명 타입일때 참고항목을 조합한다.
                if(data.userSelectedType === 'R'){
                    // 법정동명이 있을 경우 추가한다. (법정리는 제외)
                    // 법정동의 경우 마지막 문자가 "동/로/가"로 끝난다.
                    if(data.bname !== '' && /[동|로|가]$/g.test(data.bname)){
                        extraAddr += data.bname;
                    }
                    // 건물명이 있고, 공동주택일 경우 추가한다.
                    if(data.buildingName !== '' && data.apartment === 'Y'){
                        extraAddr += (extraAddr !== '' ? ', ' + data.buildingName : data.buildingName);
                    }
                    // 표시할 참고항목이 있을 경우, 괄호까지 추가한 최종 문자열을 만든다.
                    if(extraAddr !== ''){
                        extraAddr = ' (' + extraAddr + ')';
                    }
                    // 조합된 참고항목을 해당 필드에 넣는다.
                    $('#od_addr2').val(extraAddr);
                
                } else {
                	$('#od_addr2').val('');
                }
                
                // 우편번호와 주소 정보를 해당 필드에 넣는다.
                var zip = data.zonecode;
                var zip1 = zip.substring(0,3);
                var zip2 = zip.substring(3); 
                $('#od_addr1').val(addr);
                $('#od_zip1').val(zip1);
                $('#od_zip2').val(zip2);
                
//               	document.getElementById('mapsearch').value = addr1.value;
                
                // iframe을 넣은 element를 안보이게 한다.
                // (autoClose:false 기능을 이용한다면, 아래 코드를 제거해야 화면에서 사라지지 않는다.)
                element_wrap.style.display = 'none';
                delivery_address();
                // 우편번호 찾기 화면이 보이기 이전으로 scroll 위치를 되돌린다.
                document.body.scrollTop = currentScroll;
            },
            // 우편번호 찾기 화면 크기가 조정되었을때 실행할 코드를 작성하는 부분. iframe을 넣은 element의 높이값을 조정한다.
            onresize : function(size) {
                element_wrap.style.height = size.height+'px';
            },
            width : '95%',
            height : '100%'
        }).embed(element_wrap);
			
        // iframe을 넣은 element를 보이게 한다.
        element_wrap.style.display = 'block';
        
    }

	
	function ad_addr_choice(num)
	{
		addr_reset();
			$('#od_addr_jibeon').val($('#ad'+num+'_addr_jibeon').val());
			$('#od_zip1').val($('#ad_'+num+'_zip1').val());
			$('#od_zip2').val($('#ad_'+num+'_zip2').val());
			$('#od_addr1').val($('#ad_'+num+'_addr1').val());
			$('#od_addr3').val($('#ad_'+num+'_addr2').val());
			$('#od_addr2').val($('#ad_'+num+'_addr3').val());

	 	$('#ad_addr').css('display', 'none');
	 	delivery_address();
	/*	$('#open_my_addr').css("display", "none");
		$('#open_search_addr').css("display", "none"); */
	}

	function od_addr_choice(num)
	{
		addr_reset();
			$('#od_addr_jibeon').val($('#od_'+num+'_addr_jibeon').val());
			$('#od_zip1').val($('#od_'+num+'_zip1').val());
			$('#od_zip2').val($('#od_'+num+'_zip2').val());
			$('#od_addr1').val($('#od_'+num+'_addr1').val());
			$('#od_addr3').val($('#od_'+num+'_addr2').val());
			$('#od_addr2').val($('#od_'+num+'_addr3').val());
			
		$('#od_addr').css('display', 'none');
		delivery_address();
/*		$('#ad_addr').css('display', 'none');
		$('#open_my_addr').css("display", "none");
		$('#open_search_addr').css("display", "none");*/
	}
	
	
	 	var x = AppInterface.getGPSLatitude(); // 위도
	  var y = AppInterface.getGPSLongitude(); // 경도
	  // 	var x = 35.2663010648876;    // 현재 GPS x좌표
	  //  var y = 129.226020704517;  // 현재 GPS y좌표
   	function type_check()
   	{
		var delivery_pay = <?= $delivery_pay?>;
   	   	
   		if($('input[name="order_type"]:checked').val() != "take")
   		{
   	   		$('#delivery_pay').val(delivery_pay);
   	   		$('#delivery_div').css('display','block');
   	   		$('#take_div').css('display','none');

   	   		$('#od_addr_div').css('display','block');
   	   		
   	   		
   			$('#open_my_addr').css("display", "block");
			$('#open_search_addr').css("display", "block");

			//$('#delivery_pay_div').css('display','block');

			$('#view_delivery_pay').text(delivery_pay.toLocaleString() + " 원");

			var price = (Number($('#price').val())).toLocaleString();
			
			$('#P_AMT').val((Number($('#price').val())));
			
			$('#payment').text(price);
			$('#view_pay').text(price + " 원");	
       	}
   		else
   		{
   			$('#delivery_pay').val("0");
   			$('#delivery_div').css('display','none');
   			$('#take_div').css('display','block');
   			$('#pl_cho').css('display','block');
   			$('#od_addr_div').css('display','none');
   			
   			//$('#delivery_pay_div').css('display','none');
   			
   			$('#view_delivery_pay').text('0 원'); 

   			var price = (Number($('#price').val()) - Number(delivery_pay)).toLocaleString();
   			
   			$('#payment').text(price);	
   			$('#view_pay').text(price + " 원");

   			$('#P_AMT').val(price);

   			
   			
   			open_map(x,y,2000,document.getElementById("map"));		
   			/* $('#my_addr').css('display', 'none');
   			($'#open_my_addr').css("display", "none");
			$('#open_search_addr').css("display", "none"); */
       	}
    }


    
    function open_map(x,y, radius, map)
    {
    //var x = AppInterface.getGPSLatitude(); // 위도
   	//var y = AppInterface.getGPSLongitude(); // 경도

               //	var x = position.coords.latitude, // 위도
                //    y = position.coords.longitude; // 경도
                
                    var mapContainer = map;
                    var coordXY   = document.getElementById("coordXY");
                    var distanceGap  = document.getElementById("distance");

    //                   var x = 35.1659324519479;    // 현재 GPS x좌표
      //                 var y = 129.132411521392;  // 현재 GPS y좌표
//                         var radius = 2000;  // 반경 미터(m), 2km
                         
                         var latlngyo = new kakao.maps.LatLng(x, y);
                         
                         var mapOption =
                              {
                               center: latlngyo, // 지도의 중심좌표
                               level: 3      // 지도의 확대 레벨
                             
                              };
                         
                         var map = new kakao.maps.Map(mapContainer, mapOption); // 지도를 생성합니다
                         
                         var circle = new kakao.maps.Circle({
                             map: map,
                             center : latlngyo,
                             radius: radius,
                             strokeWeight: 2,
                             strokeColor: '#FF0000',
                             fillColor: '#D3D5BF',
                             fillOpacity: 0.5
                         });
                         
                         
                         var marker = new kakao.maps.Marker({
                          position: latlngyo, // 마커의 좌표
                          title: "마커1",
                          map: map          // 마커를 표시할 지도 객체
                         });
                         
                         var markerTmp;      // 마커
                         var polyLineTmp;    // 두지점간 직선거리
                         var distanceArr = new Array();
                         var distanceStr = "";

                         var imageSrc = "<?= G5_DATA_URL?>/icon/mark.png"; 
                         // 마커 이미지의 이미지 크기 입니다
                         var imageSize = new kakao.maps.Size(28, 39); 
                         
                         // 마커 이미지를 생성합니다    
                         var markerImage = new kakao.maps.MarkerImage(imageSrc, imageSize); 

                         var arr_len = 0;
                         
                         for (var i=0;i<arr.length;i++) 
                         {
                             polyLineTmp = new kakao.maps.Polyline({
                                 map: map,
                                 path: [
                                     latlngyo, new kakao.maps.LatLng(arr[i][1],arr[i][2])
                                 ],
                                 strokeWeight: 2,   
                                 strokeColor: '#ff1122',
                            		strokeOpacity: 0.8,
                             });
                         
                         	//2km 이하만 배열에 담는다 (2000 = 2km)
                         	if(polyLineTmp.getLength() <= radius)
                         	{
                             	distance[i] = polyLineTmp.getLength();  // 도보의 시속은 평균 4km/h 이고 도보의 분속은 67m/min입니다    
                                	markerTmp = new kakao.maps.Marker({
                                     position: new kakao.maps.LatLng(arr[i][1],arr[i][2]),
                                     title: arr[i][0],
                                     image : markerImage,
                                     map:map
                                 });
                                 
                                 	// 인포윈도우로 장소에 대한 설명을 표시합니다
                            	/*  var infowindow = new kakao.maps.InfoWindow
                             	({
                                 	content: '<div style="width:150px;text-align:center;padding:6px 0;">'+ arr[i][0] + '</div>',
                             	}); 
*/
                            	var pl_content = '<div class="marker-info" style="margin-bottom:130px;height:auto;background-color:#fff;border:1px solid cornflowerblue;border-radius:5px;text-align:center; padding:5px 15px;">'
                          			+'<span style="font-size:16px; display:block;font-weight:600;">'+arr[i][0]+'</span>'
                          			+'</div>';

                  	            	 // 커스텀 오버레이를 생성합니다
                  	     	          var customOverlay = new kakao.maps.CustomOverlay({
                  	     	              position: markerTmp.getPosition(),
                  	     	              content: pl_content   
                  	     	          });
                  	    
                  	     	          // 커스텀 오버레이를 지도에 표시합니다
                  	     	          customOverlay.setMap(map); 
                             	
                                 //infowindow.open(map, markerTmp);
                         		comparearr[arr_len] = [arr[i][0], parseFloat(distance[i] / 1000).toFixed(2),arr[i][2], arr[i][3], arr[i][4], arr[i][5],arr[i][6],arr[i][7]];
                         		arr_len++;
                         	}
                         	else
                         	{
                         		polyLineTmp.setMap(null); // 지도에서 제거한다
                         	}
                         
                             //distanceStr += arr[i][0] + " : "  +  parseFloat(distance[i] / 1000).toFixed(2) + " km <br>";
                         }


  						
                         for(var x = 0; x < comparearr.length; x++)
    						{
    							if(isNaN(comparearr[x][1]))
    							{
    								comparearr.splice(x,1);
    							}
    						}
 						
							comparearr.sort(function(a, b) {
	    						return a[1] - b[1];
	    						});
                         
                         // 인포윈도우로 장소에 대한 설명을 표시합니다
                         var infowindowaa = new kakao.maps.InfoWindow
                         ({
                             content: '<div style="width:150px;text-align:center;padding:6px 0;">현재위치</div>'
                         });
                         
                         infowindowaa.open(map, marker);
                         
    		             map.setCenter(new kakao.maps.LatLng(x,y));
                         for(var j=0;j<comparearr.length;j++)
                         {
                             if(comparearr[j][1] <= radius/1000)
                             {
                             	distanceStr += '<li class="m-b-10"><a href="javascript:pl_select('+comparearr[j][7]+')"><div class="address bg-g-ea"><h4>' + comparearr[j][0] + '<span class="col-r">'+ comparearr[j][1] +'km</span></h4><p> ' + comparearr[j][3] + '</p><p>' + comparearr[j][6] + '</p></div></a></li>';
//                             	 if(comparearr[j][1] == 0)
//                                  {
//                                  	infowindowaa.setContent('<div style="width:150px;text-align:center;padding:6px 0;">근처</div>');
//                                  }
                             }
                         }
                         if(distanceStr == "")
                         {
                         	distanceStr = "<h3>근처에 지점이 없습니다.</h3>";
                         	$('#storename').text('배달가능한 지역이 아닙니다');
                         	$('#deli_check').val('1');
                         }
                         else
                         {
							pl_near(comparearr[0][7]);
                       	 }
                         
                         distanceGap.innerHTML = distanceStr;
    		
    }

    function pl_near(pl_id)
    {
    		$.ajax({
 				url : "./controllor/place_check.php",
 				type : "POST",
 				data : {
 				pl_id : pl_id
 					},
 				success : function (result)
 				{
 					if(result == 0)
 					{
 						$('#pl_id').val(pl_id);
 						$('#storename').text(comparearr[0][0]);
 						$('#deli_check').val('0');
 					}
 					else
 					{
 						$('#deli_check').val('1');
 						$('#storename').text('배달가능한 지역이 아닙니다');
 	 				}
 				}
 			});
    }

    function delivery_address()
    {
		for(var i = 0; i < comparearr.length; i++)
		{
			comparearr.pop();	
		}
    	var mapContainer = document.getElementById('map_2'), // 지도를 표시할 div 
    	mapOption = {
    	    center: new kakao.maps.LatLng(33.450701, 126.570667), // 지도의 중심좌표
    	    level: 3 // 지도의 확대 레벨
    	};  

    	//지도를 생성합니다    
    	var map = new kakao.maps.Map(mapContainer, mapOption); 

    	//주소-좌표 변환 객체를 생성합니다
    	var geocoder = new kakao.maps.services.Geocoder();

    	//주소로 좌표를 검색합니다
    	geocoder.addressSearch($('#od_addr1').val(), function(result, status) {

    	// 정상적으로 검색이 완료됐으면 
    	 if (status === kakao.maps.services.Status.OK) {

    	    var coords = new kakao.maps.LatLng(result[0].y, result[0].x);
    		var message = 'latlng: new kakao.maps.LatLng(' + result[0].y + ', ';
    		message += result[0].x + ')';

		open_map(result[0].y, result[0].x, 3000, mapContainer);
		
    	} 
    	});
    }
    
   	function pl_select(pl_id)
   	{
		$.ajax({
			url : "./controllor/place_check.php",
			type : "POST",
			data : {
				pl_id : pl_id
				},
				success : 
				function(result)
				{
					if(result == 0)
					{
						var pl = 0;
						for(var i = 0; i < arr.length;i++)
						{
							if(pl_id == arr[i][7])
							{
								pl = i;
							}
						}
						$('#pl_name').text(arr[pl][0]);
						$('#pl_id').val(arr[pl][7]);
						$('#pl_addr1').val(arr[pl][3]);
						$('#pl_addr2').val(arr[pl][4]);
						$('#pl_addr3').val(arr[pl][5]);

						$('#pl_cho').css('display', 'none');
						}
					
				else if(result == 1)
				{
					alert('매장이 쉬는 날 입니다');
				} 
				else if(result == 2)
				{
					alert('영업 준비중입니다');
				}
				}
			});
   	}
   	function order()
    {
		var type = $('input[name="order_type"]:checked').val();

		$('#P_INI_PAYMENT').val($('#od_settle_case').val());	
			
		if(type == "delivery")
		{
			$('od_type').val('delivery');
			if($('#od_addr1').val() == "")
			{
				alert('주소를 기입해주세요');
				return false;
			}
			else
			{
				delivery_address();
			}
			if($('#deli_check').val() == "1")
			{
				alert('배달 가능한 지역이 아닙니다');
				return false;
			}
			else if($('#od_addr3').val() == "")
			{
				alert('상세주소를 기입해주세요');
				return false;
			}
			else
			{
				create_url();
				order_form.submit();
			}
		
		}
		else if(type == "take")
		{
			$('od_type').val('take');
			if($('#pl_id').val() == "0" || $('#pl_id').val() == "")
			{
				alert('매장을 선택해주세요');
				return false;
			}
			else
			{
				create_url();
				order_form.submit();
			}
		}
     }
    </script>
