<?php
include_once('./_common.php');
include_once('./head.sub.php');

//인기,최근,가격 순
$arr1 = $_REQUEST['arr1'];
//별점 순
$arr2 = $_REQUEST['arr2'];

//기본값
$orderby = "it_hit";
$sort = "desc";
$starsort = "desc";
if($arr1 == "low_price" || $arr1 == "high_price")
{
    $orderby = "it_price";
    if($arr1 == "low_price")
    {
        $sort = "asc";
    }
}
else if ($arr1) $orderby = $arr1;

if($arr2)
{
/*     if($arr1 == "")
    {
        $orderby = "a.it_hit";
    }
 */    
    if($arr1 == "" && $arr2 == "high_star" || $arr1 == "" && $arr2 == "")
    {
        $orderby = "it_use_avg ";
        $sort = "desc";
    }
    else 
    {
        $sort = "asc";
        $orderby = "it_use_avg ";
    }
}

/* $sql = "select *,a.it_id, count(*) as count, ifnull(avg(b.is_score),0) as star from {$g5['g5_shop_item_table']} as a
left join {$g5['g5_shop_item_use_table']} as b on a.it_id = b.it_id group by a.it_id
order by {$orderby} {$sort}"; */

$sql = "select * from {$g5['g5_shop_item_table']} where it_use != 0 and it_soldout != 1 order by {$orderby} {$sort}";

function get_mshop_category($ca_id, $len)
{
    global $g5;
    
    $sql = " select ca_id, ca_name from {$g5['g5_shop_category_table']}
                where ca_use = '1' ";
    if($ca_id)
        $sql .= " and ca_id like '$ca_id%' ";
        $sql .= " and length(ca_id) = '$len' order by ca_order, ca_id ";
        
        return $sql;
}


$cate = array();

$cateres = sql_query(get_mshop_category('10',4));

?>

<style>
    .active{color: #2eaea9; border-bottom: 1px solid #2eaea9; border-spacing: 1.5em;}
	#no_menu_icon{font-size: 50px; text-align:center; width:100%}
	#no_menu_text{text-align:center;width:100%;margin:0 auto}
	#menulist{letter-spacing:-1px}
	nav{scroll-behavior: smooth;}
</style>


<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/lozad/dist/lozad.min.js"></script>
<script>
window.onpageshow = function(event) {

   if ( event.persisted || (window.performance && window.performance.navigation.type == 2)) {
		var tab = $('#menu_tab').val();
		$("#nav-"+tab+"-tab").get(0).click();
   }

};

</script>
<body>
    <div class="wrap">
        <div class="head flex-m">
            <a href="javascript:location.replace('<?= G5_APP_URL?>')" class="back_btn" id=""><i class="material-icons">arrow_back_ios</i></a>
            <h2 id = "menutitle">전체 메뉴</h2>
            
        </div>
        <section class="sec_1">
        <input type = "hidden" id = "menu_tab" value = "1">
            <div class="container menu_list pos-relative">
				<nav id="cate_scroll">
					<div class="nav nav-tabs" id="nav-tab" role="tablist">
					 <?php 
					 $m_list_cate;
                       	for($i = 0; $caterow = sql_fetch_array($cateres); $i++)
                       	{
                       	    $m_list_cate[$i] = $caterow['ca_id'];
                       	    if(strlen($caterow['ca_name']) > 20)
                       	    {
                       	        $caterow['ca_name'] =  substr($caterow['ca_name'], 0, -10)."..";
                       	    }
                       	    
                       	    $cate[$caterow['ca_id']] = $caterow['ca_name'];
                       	    ?>
                       	    <?php 
                       	        if(strlen($caterow['ca_name']) > 15)
                       	        {
                       	             ?>
                       	             <a class="nav-link<?php if($i== 0) echo " active";?>" id="nav-<?=$i+1?>-tab" data-bs-toggle="tab" href="javascript:self(<?= $i+1?>,'<?= $caterow['ca_name']?>');filterSelection(<?= $caterow['ca_id']?>);$('#menu_tab').val('<?= $i+1?>');" role="tab" aria-controls="nav-<?=$i+1?>" aria-selected="<?php if($i==0)echo"true";else echo "false";?>"><?= $caterow['ca_name']?></a>
                       	             <?php 
                       	        }
                       	        else
                       	        {
                       	            ?>
                       	            <a class="nav-link<?php if($i== 0) echo " active";?>" id="nav-<?=$i+1?>-tab" data-bs-toggle="tab" href="javascript:self(<?= $i+1?>,'<?= $caterow['ca_name']?>');filterSelection(<?= $caterow['ca_id']?>);$('#menu_tab').val('<?= $i+1?>');" role="tab" aria-controls="nav-<?=$i+1?>" aria-selected="<?php if($i==0)echo"true";else echo "false";?>"><?= $caterow['ca_name']?></a>
                       	            <?php                        	        
                       	        }
                       	    ?>
                       	    
                       	    <?php 
                       	}
                       	?>
									
					</div>
				</nav>
                <?php 
                if(isset($_REQUEST['tab']))
                {
                    echo '<script>window.onload=function(){
                    $("#nav-'.$_REQUEST['tab'].'-tab").get(0).click();
                }</script>';
                }
                ?>
                <div class="select_wrap">
                
                      <select name="arr1" id="arr1" onchange="arr1change()">
                          <option value="it_hit" <?php if($arr1 == 'it_hit' || $arr == '') echo "selected=selected";?>>인기순</option>
                          <option value="it_time" <?php if($arr1 == 'it_time') echo "selected=selected";?>>최신순</option>
                          <option value="low_price" <?php if($arr1 == 'low_price') echo "selected=selected";?>>낮은가격순</option>
                          <option value="high_price" <?php if($arr1 == 'high_price') echo "selected=selected";?>>높은가격순</option>
                      </select>
                      
                      <select name="arr2" id="arr2" onchange="arr2change()">
                        <option value="high_star" <?php if($arr2 == 'high_star' || $arr == '') echo "selected=selected";?>>높은별점순</option>
                        <option value="low_star"<?php if($arr2 == 'low_star') echo "selected=selected";?>>낮은별점순</option>
                      </select>
                      <!-- 
                      <select name="arr3" id="arr3">
                        <option value="">기타</option>
                        <option value="">기타</option>
                      </select>
                       -->
                  </div>
            </div>
            
            <div class="container min-h-f" id ="menulist" >
            <div class="row row-col-2">
            <?php 
			    $res = sql_query($sql);
			    
			    for($i = 0; $row = sql_fetch_array($res); $i++)
			    {
			        $it_id = $row['it_id'];
			        $itemtype = "";
			       
			        
			        $it_img =  $row['it_img1'];
			        $it_img = str_replace($it_id."/","", $it_img);
			        ?>
			  
			    
			    <!-- id를 div 순서로 가정하자 -->
                    
					<div class="col-6 menu <?= $row['ca_id'].$row['ca_id2'].$row['ca_id3']?>" id= "<?php echo "item".$i;?>">
							<a href="javascript:addr('<?= $row['it_id']?>');" >
                        <div class="img_box">
                              <!-- <img alt="메뉴 이미지" src="<?php  //echo G5_APP_URL."/img/".$it_img;?>"> -->
                             <!-- <img data-src="<?= G5_DATA_URL."/item/".$row['it_img1']?>" alt="메뉴이미지" class="lozad" /> -->  
                            <?php echo get_it_thumbnail($row['it_img1'], 167.500);?>
                            <input type = "hidden" id = "pop" value = <?php echo $row['it_hit'];?>/>
                        </div>
                    	<h4 id= "it_name" name ="it_name"><?php echo $row['it_name']; ?></h4> 
						<h5><?= number_format($row['it_price'])?>원</h5>
						<div class="sit_star">
                       	<?php 
                       	
                       	for($j = 0; $j < $row['it_use_avg']; $j++)
                       	{
                       	?>
                       	    <i class="material-icons">star_rate</i>
                       	<?php 
                       	}
                       	echo sprintf('%0.1f', $row['it_use_avg']);
                       	if($row['it_use_avg']== 0)
                       	{
                       	 ?>
                       	 <span style="color:#909090; padding-left:5px;">(0)</span></p>
                       	 <?php    
                       	}
                       	else
                       	{
                       	    ?>
                       	    <span style="color:#909090;">(<?= $row['it_use_cnt']?>)</span></p>
                       	    <?php 
                       	}
                       	?>
                       	</div>
							</a>
                    </div>
                    
                
			    
			    <?php 
			     }
			?>
			<div id = "no_menu" style= "display:none">
			<i class="material-icons" id="no_menu_icon">storefront</i><br>
			<h5>자료가 없습니다</h5>
			</div>
			</div>
		</div>
            
            <!-- 주소 정보 -->
            <script>
            const observer = lozad();
        	observer.observe();
    		var len = $('h4[name="it_name"]').length;

    		for(var i = 0; i  < len; i++)
    		{
    			if($('h4[name="it_name"]').eq(i).text().length > 15)
    			{
    				$('h4[name="it_name"]').eq(i).text($('h4[name="it_name"]').eq(i).text().substring(0,14) + "..");
    			}			
    			
    		}

            function addr(id)
            {
                var tab = $('#menu_tab').val();
            	location.replace("<?php echo G5_APP_URL."/menu.php?it_id=";?>" + id+"&tab="+tab);
            }
            </script>
            
            <!-- 메뉴 타이틀 고르기 -->
            <script>
            
                //셀렉값 확인하기	
				function arr1change()
				{
					var arr1 = $("#arr1").val();
					var url = './menu_list.php?arr1=' + arr1;
					var form = document.getElementById('addr');
					form.action = url;
					document.getElementById('addr').submit();
					//window.location.href= url;
				}
				
				function arr2change()
				{
					var arr2 = $("#arr2").val();
					var url2 = './menu_list.php?arr1=<?= $arr1?>&arr2=' + arr2;
					var form = document.getElementById('addr');
					form.action = url2;
					document.getElementById('addr').submit();
					//window.location.href=url2;
				}
                
                //filter
				var auto = 0;
				var len = $('.nav-link').length;
				
				for(var i = 0; i < len; i++)
				{
					var width = $.trim($('.nav-link').eq(i).css('width').replace('px',''));
					auto += Math.ceil(width);
				}

				$('#nav-tab').css('width', auto);

	            
                function self(num, title)
                {
    				var a_len = $('#nav-tab > a').length;

    				var width = ($('#nav-tab').css('width').replace("px","") - $('#cate_scroll').css('width').replace("px", "")) / len;

    				var tmp = 0;
    				
                    for(var i = 1; i <= a_len ; i++)
                    {
    					if(i != num)
    					{
    						$('#nav-'+i+'-tab').attr('class', 'nav-link');
    						$('#nav-'+i).attr('class', 'tab-pane fade');
    						$('#nav-'+i).attr('aria-selected', 'false');
    						if(i < num)
    						{
        						tmp += Number($('#nav-'+i+'-tab').css("width").replace("px",""));
        					}
    					}
                    }
    				$('#nav-'+num+'-tab').attr('class', 'nav-link active');
    				$('#nav-'+num).attr('class', 'tab-pane fade show active');
    				$('#nav-'+num).attr('aria-selected', 'true');
					
    				$('#cate_scroll').scrollLeft(tmp-width*2);
    				
    				$('#menutitle').text(title);
                }

                
                filterSelection('all');
                
                function filterSelection(c) 
                {
                  var title = document.getElementById('menutitle');
                  var x, i;
                  
                  x = document.getElementsByClassName("menu");
                  if (c == "all") c = "";
                  for (i = 0; i < x.length; i++) {
                    w3RemoveClass(x[i], "show");
                    if (x[i].className.indexOf(c) > -1) w3AddClass(x[i], "show");
                  }
                  var len = $(".show").length;
					if(len == 0)
					{
						$('#no_menu').css('display', 'flex');
					}
					else
					{
						$('#no_menu').css('display', 'none');
					}
						
                }
                
                function w3AddClass(element, name) {
                  var i, arr1, arr2;
                  arr1 = element.className.split(" ");
                  arr2 = name.split(" ");
                  for (i = 0; i < arr2.length; i++) {
                    if (arr1.indexOf(arr2[i]) == -1) {element.className += " " + arr2[i];}
                  }
                }
                
                function w3RemoveClass(element, name) {
                  var i, arr1, arr2;
                  arr1 = element.className.split(" ");
                  arr2 = name.split(" ");
                  for (i = 0; i < arr2.length; i++) {
                    while (arr1.indexOf(arr2[i]) > -1) {
                      arr1.splice(arr1.indexOf(arr2[i]), 1);     
                    }
                  }
                  element.className = arr1.join(" ");
                }
                


                
                
                </script>
               
        </section>
        </div>
        <div class="top"><i class="material-icons"></i></div>
        
    
<?php 
include_once('./cart_icon.php');
include_once('./tail.php'); 
?>