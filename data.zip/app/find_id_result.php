<?php
include_once('./_common.php');
include_once('./head.sub.php');

$email = $_REQUEST['email'];

$sql = "select * from {$g5['member_table']} where mb_email = '{$email}' ";
$row = sql_fetch($sql);

?>
<link rel="stylesheet" href="<?php echo G5_APP_URL ?>/css/login.css">
<body>
    <div class="wrap">
        <div class="head flex-c-m">
            <a href="javascript:" class="back_btn" id="cancel"><i class="material-icons">arrow_back_ios</i></a>
            <h2>아이디 찾기</h2>
        </div>

        <section class="sec_1">
            <div class="container min-h-f">
                <div class="find-info m-t-20">
                	<?php 
                	if($row['mb_id'])
                	{
                	    ?>
                	    <div class="find text-center">
                            <h4 class="title">아이디 검색 내역</h4>
							<span class="dis-block">아이디 : <?= $row['mb_id'];?> 이름 : <?= $row['mb_name']?></span>
                            <span class="dis-block">고객님의 정보와 일치하는 아이디입니다.</span>
                            <span>로그인 또는 비밀번호 찾기 버튼을 눌러주세요.</span>
                            <div class="inner flex-sb-m m-t-10">
                            <button class="btn bg-r col-w w-full m-r-5" onclick="location.href='<?php echo G5_APP_URL ?>/login.php'">로그인</button>
                            <button class="btn btn-secondary w-full m-l-5" onclick="location.href='<?php echo G5_APP_URL ?>/find_pw.php'">비밀번호 찾기</button>
							</div>
                    	</div>
                	    <?php 
                	}
                	else
                	{
                	    ?>
                	    <div class="n-find text-center">
                            <h4 class="title">아이디검색 내역</h4>
                            <span class="dis-block">고객님의 정보와 일하는 아이디가 없습니다.</span>
                            <span>회원가입 버튼을 눌러주세요</span>
                            <button class="btn w-full btn-secondary m-t-10" onclick="location.href='<?php echo G5_APP_URL ?>/join.php'">회원가입</button>
                    	</div>
                	    <?php
                	}
                	
                	?>
                </div>
            </div>
        </section>
    </div>

<?php include_once('./tail.php'); ?>