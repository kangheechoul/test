<?php
include_once('./_common.php');
include_once('./head.sub.php');

if($is_member != "")
{
    $memsql = "select * from {$g5['member_table']} where mb_id = '".$_SESSION['ss_mb_id']."'";
    $memres = sql_query($memsql);
    $memrow = sql_fetch_array($memres);
}

?>
<link rel="stylesheet" href="<?php echo G5_APP_URL ?>/css/mypage.css">
<body>
    <div class="wrap">
        <div class="head flex-c-m">
            <a href="javascript:location.replace('<?= G5_APP_URL?>')" class="back_btn" id=""><i class="material-icons">arrow_back_ios</i></a>
            <h2>MYPAGE</h2>
        </div>
        <section class="sec_1">
			<div class="container log">
                <div class="row row-col-2">
			<?php if ($is_member == "")
			{ 
			
			?>
						<button class="col btn bg-r" style="margin-right: 2%;" onclick="location.href='<?php echo G5_APP_URL ?>/login.php'">로그인</button>
                        <button class="col btn btn-secondary" onclick="location.href='<?php echo G5_APP_URL ?>/join.php'">회원가입</button>
            <?php 
			}	
			else 
            {
            ?>
				<a href="#none" class="flex-m"><i class="material-icons">supervised_user_circle</i><span><?= $memrow['mb_nick']?></span><span class="float-r">></span></a>
            <?php
            }
            ?>
                </div>
            </div>
            
			<div class="container my_btn">
				<ul class="row row-col-4 ">
					<li class="col">
						<a href="<?php echo G5_APP_URL?>/my_info.php" class="active"><i class="material-icons">manage_accounts</i><span class="font-08em">정보수정</span></a>
					</li>
					<li class="col">
						<a href="<?php echo G5_APP_URL?>/my_addr.php"><i class="material-icons">edit_location</i><span class="font-08em">배송지 관리</span></a>
					</li>
					<li class="col">
						<a href="<?php echo G5_APP_URL ?>/my_order_list.php"><i class="material-icons">list_alt</i><span class="font-08em">주문확인</span></a>
					</li>
					<li class="col">
						<a href="<?php echo G5_APP_URL ?>/my_review.php"><i class="material-icons">rate_review</i><span class="font-08em">리뷰</span></a>
					</li>
				</ul>
			</div>
			
			<div class="container min-h-250 my_ul">
                <ul class="row">
                    <li class="col-12">
                        <a href="<?php echo G5_APP_URL ?>/my_notice_list.php">
                            공지사항<span class="arrow">></span>
                        </a>
                    </li>
                    <li class="col-12">
                        <a href="<?php echo G5_APP_URL ?>/my_event_list.php">
                            이벤트<span class="arrow">></span>
                        </a>
                    </li>
                    <li class="col-12">
                        <a href="<?php echo G5_APP_URL ?>/my_1on1_list.php">
                            1:1문의<span class="arrow">></span>
                        </a>
                    </li>
                    
<!--                     <li class="col-12"> -->
<!--                         <a href="#none"> -->
<!--                             환경설정<span class="arrow">></span> -->
<!--                         </a> -->
<!--                     </li> -->
					<?php if ($is_member) { ?>
					<li class="col-12">
                        <a href="<?php echo G5_APP_URL ?>/logout.php">
                            로그아웃
                        </a>
                    </li>
					<?php } ?>
                    <li class="col-12">
                        <a href="#none">
                            현재 버전<span>00.00.0</span>
                        </a>
                    </li>
                </ul>
            </div>
        </section>
            
      
    </div>
    

<?php include_once('./tail.php'); ?>