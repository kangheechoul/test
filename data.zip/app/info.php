<?php
include_once('./_common.php');
include_once('./head.sub.php');

//ss_cart_id = 2020122308565307
//2020122314474926
?>
<link rel="stylesheet" href="<?php echo G5_APP_URL ?>/css/index.css">
<link rel="stylesheet" href="<?php echo G5_APP_URL ?>/css/swiper.min.css">
<script src="<?php echo G5_APP_URL ?>/vendor/swiper/swiper.min.js"></script>
<script src="<?php echo G5_APP_URL ?>/js/swiper_slide.js"></script>


<body>
	<?php 
	$info_type = $_REQUEST['info_type'];
	
	$info_sql = "select * from {$g5['content_table']} where co_id = '".$info_type."'";
	$info_row = sql_fetch($info_sql);
	$info_content = $info_row['co_content'];
	?>
    <div class="wrap">
         <div class="head flex-c-m"><img src="<?php echo G5_APP_URL ?>/img/mimicook-logo.png" alt="logo"></div>
	
	<section>
	
		<div class ="container">
        <h2 style = "text-align:center;padding-top:5px"><?= $info_row['co_subject']?></h2>
		
		<?= $info_content?>
		</div>
		
	</section>
	

    </div>
    
<?php include_once('./tail.php'); ?>
