<?php
include_once('./_common.php');
include_once('./head.sub.php');

?>
<link rel="stylesheet" href="<?php echo G5_APP_URL ?>/css/review.css">
<script src="<?php echo G5_APP_URL ?>/js/star_rating.js"></script>
<body>
    <div class="wrap">
    
        <div class="head">
            <!--  <a href="javascript:" class="back_btn" id="cancel"><i class="material-icons">arrow_back_ios</i></a>-->
            <a href="<?php echo G5_APP_URL ?>" class="enter_btn">완료</a>
            <!-- <a href="" class="enter_btn">완료</a> -->
        </div>
        
        
        
        <section class="sec_1">
            <div class="container min-h-f">
                <h3 class = "title">작성이 완료되었습니다. <br>감사합니다.</h3>
                                
        		<button class = "btn bg-gr" onclick ="location.replace('<?php echo G5_APP_URL?>')">홈페이지 이동</button>
            </div>
        </section>
        
        
    </div>
