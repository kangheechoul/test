<?php 
$cookie_name = "search_history";
$cookie_value = $_REQUEST['searchlist'];


setcookie($cookie_name, $cookie_value, time() + (1 * 30), "/");

$result['data'] = $cookie_value;

echo json_encode($result);
?>