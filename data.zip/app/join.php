<?php
include_once('./_common.php');
include_once(G5_CAPTCHA_PATH.'/captcha.lib.php');
include_once(G5_LIB_PATH.'/register.lib.php');
include_once('./head.sub.php');

?>
<link rel="stylesheet" href="<?php echo G5_APP_URL ?>/css/mypage.css">
<script src="<?php echo G5_JS_URL ?>/jquery.register_form.js"></script>
<?php if($config['cf_cert_use'] && ($config['cf_cert_ipin'] || $config['cf_cert_hp'])) { ?>
<script src="<?php echo G5_JS_URL ?>/certify.js?v=<?php echo G5_JS_VER; ?>"></script>
<?php } ?>

<?php 
// KAKAO LOGIN
$sql = "select * from {$g5['config_table']}";
$row = sql_fetch($sql);
define('KAKAO_CLIENT_ID', $row['cf_kakao_rest_key']);
define('KAKAO_CLIENT_SECRET', $row['cf_kakao_client_secret']); // 필수 아님
define('KAKAO_CALLBACK_URL', G5_APP_URL."/controllor/login_kakao.php"); // 콜백URL

// 카카오 로그인 접근토큰 요청 예제
$kakao_state = md5(microtime() . mt_rand()); // 보안용 값
$_SESSION['kakao_state'] = $kakao_state;
$kakao_apiURL = "https://kauth.kakao.com/oauth/authorize?client_id=".KAKAO_CLIENT_ID."&redirect_uri=".urlencode(KAKAO_CALLBACK_URL)."&client_secret=".KAKAO_CLIENT_SECRET."&response_type=code&state=".$kakao_state;

define('NAVER_CLIENT_ID', $row['cf_naver_clientid']);
define('NAVER_CLIENT_SECRET', $row['cf_naver_secret']);
define('NAVER_CALLBACK_URL', G5_APP_URL.'/controllor/login_naver.php');

$naver_state = md5(microtime() . mt_rand());
$_SESSION['naver_state'] = $naver_state;
$naver_apiURL = "https://nid.naver.com/oauth2.0/authorize?response_type=code&client_id=".NAVER_CLIENT_ID."&redirect_uri=".urlencode(NAVER_CALLBACK_URL)."&state=".$naver_state;

if(isset($_REQUEST['sns']))
{
    $join_id = $_SESSION['join_id'];
    $join_nick = $_SESSION['join_nick'];
    $join_token = $_SESSION['join_token'];
    $join_email = $_SESSION['join_email'];
}

$filter = $row['cf_filter'];
$filter = explode(',',$filter);
?>
<style>
.sec_1 {margin-bottom:10%}
.easy-login button{width:50% !important}

</style>
<body>
    <div class="wrap">
        <div class="head flex-c-m">
            <a href="javascript:" class="back_btn" id="cancel"><i class="material-icons">arrow_back_ios</i></a>
            <h2>회원가입</h2>
        </div>
        
        <section class="sec_1">
      			
                <div class=" container join-info">
                 <div class="easy-login flex-sb-m">
                	<button onclick = "naver()"><img src="<?php echo G5_APP_URL ?>/img/i-naver.png" alt="네이버">로그인</button>
                    <button onclick = "kakao()"><img src="<?php echo G5_APP_URL ?>/img/i-kakao.png" alt="카카오">로그인</button>
                </div>
					<ul class="row">
                    <form name="frm" id="frm" action="<?php echo G5_APP_URL.'/join_update.php';?>" onsubmit="return fregisterform_submit(this);" method="post" >
                        <h4 class="title">회원가입 정보</h4>
                        <?php if(isset($_REQUEST['sns'])) echo "<h5>추가사항 작성</h5>";?>
						<input type="hidden" name="w" id="w">
						<li class="col-12">
							<dt>아이디</dt>
							<dd><input type="text" name="mb_id" id="reg_mb_id" class="w-full m-b-5" <?php if(isset($_REQUEST['sns'])) echo 'value="'.$join_id.'" readonly';?> placeholder="아이디"></li></dd>
						
						<?php
						if(isset($_REQUEST['sns']))
						{
						?>
							<input type="hidden" name="mb_password" id="reg_mb_password" class="w-full m-b-5" value ="mimi1111!" placeholder="비밀번호(영문+숫자+특수문자 조합 8자리 이상)"></li>
							<input type="hidden" name="mb_password_re" id="reg_mb_password_re" class="w-full m-b-5" value ="mimi1111!" placeholder="비밀번호 확인"></li>
						<?php     
						}
						else 
						{
						    ?>
						    <li class="col-12">
							<dt>비밀번호</dt>
							<dd><input type="password" name="mb_password" id="reg_mb_password" class="w-full m-b-5" placeholder="비밀번호(영문+숫자+특수문자 조합 8자리 이상)"></li></dd>
						
						<li class="col-12">
							<dt>비밀번호 확인</dt>
							<dd><input type="password" name="mb_password_re" id="reg_mb_password_re" class="w-full m-b-5" placeholder="비밀번호 확인"></li></dd>
						
						    <?php 
						}
						?>
						<li class="col-12">
							<dt>이름</dt>
							<dd><input type="text" name="mb_name" id="reg_mb_name" class="w-full m-b-5" placeholder="이름"></li></dd>
						
						<li class="col-12">
							<dt>닉네임</dt>
							<dd><input type="text" name="mb_nick" id="reg_mb_nick" class="w-full m-b-5" <?php if(isset($_REQUEST['sns'])) echo 'value = "'.$join_nick.'"'?> placeholder="닉네임"></li></dd>
						
						<li class="col-12">
							<dt>E-mail</dt>
							<dd><input type="text" name="mb_email" id="reg_mb_email" class="w-full m-b-5" <?php if(isset($_REQUEST['sns'])) echo 'value = "'.$join_email.'"'?> placeholder="E-mail"></li></dd>
						
						<?php 
						if(isset($_REQUEST['sns']))
						{
						    ?>
						    <input type="hidden" name="mb_token" class="w-full m-b-5" value = "<?= $join_token?>" >
						    <?php 
						}
						?>
						<li class="col-12">
							<dt>핸드폰번호</dt>
							<dd><input type="text" name="mb_hp" id="reg_mb_hp" class="w-full m-b-5" value = "" placeholder="ex)01012345678"></li></dd>
						
						
					</ul>   
                        <div class="row agree">
                            <h4 class="h4-font">약관 및 동의</h4>
                            <div class="col-12 inner">
                                <input type="checkbox" class="check" id="check_all">
                                <label for="check_all">
                                    전체 동의
                                    <i class="material-icons">check_box_outline_blank</i>
                                    <i class="material-icons">check_box</i>
                                </label>
                            </div>
                            <div class="col-12 inner flex-sb-m">
                                <input type="checkbox" class="check" name="check" id="check1">
                                <label for="check1">
                                    이용약관 동의(필수)
                                    <i class="material-icons">check_box_outline_blank</i>
                                    <i class="material-icons">check_box</i>
                                </label>
                                <a href="javascript:">내용보기</a>
                            </div>
                            <div class="col-12 inner flex-sb-m">
                                <input type="checkbox" class="check" name="check" id="check2">
                                <label for="check2">
                                    개인정보 수집 및 이용동의(필수)
                                    <i class="material-icons">check_box_outline_blank</i>
                                    <i class="material-icons">check_box</i>
                                </label>
                                <a href="javascript:">내용보기</a>
                            </div>
                            <div class="col-12 inner flex-sb-m">
                                <input type="checkbox" class="check" name="check" id="check3">
                                <label for="check3">
                                    전자금융거래 이용약관(필수)
                                    <i class="material-icons">check_box_outline_blank</i>
                                    <i class="material-icons">check_box</i>
                                </label>
                                <a href="javascript:">내용보기</a>
                            </div>
                            <div class="col-12 inner flex-sb-m">
                                <input type="checkbox" class="check" name="check" id="check4">
                                <label for="check4">
                                    만14세 이상 이용자(필수)
                                    <i class="material-icons">check_box_outline_blank</i>
                                    <i class="material-icons">check_box</i>
                                </label>
                                <a href="javascript:">내용보기</a>
                            </div>
                            <div class="col-12 inner flex-sb-m">
                                <input type="checkbox" class="check" name="check" id="check5">
                                <label for="check5">
                                    혜택 알림 동의(선택)
                                    <i class="material-icons">check_box_outline_blank</i>
                                    <i class="material-icons">check_box</i>
                                </label>
                            </div>
                        </div>
						<div class="col-12"><button class="btn w-full btn-secondary">가입하기</button></div>
                    </form>
					</ul>
                </div>
        </section>
    </div>
    
    <script>
    
        //체크박스 전체석택 및 전체해제
        $('#check_all').click(function(){
            if($('#check_all').is(':checked'))
            {
                $('.check').prop('checked',true);
            }else{
                $('.check').prop('checked',false);
            }
        });

        //한개의 체크박스 선택 해제시 전체선택 체크박스도 해제
        $('.check').click(function(){
			
            if($("input[name='check']:checked").length == 5){
                $('#check_all').prop('checked',true);
            }else{
                $('#check_all').prop('checked',false);
            }
        });
    </script>
	
	
	
	<script>

		var filter = <?= json_encode($filter)?>;
	
	  function kakao()
	    {
			location.href = "<?=$kakao_apiURL;?>";
	    }

	    function naver()
	    {
			location.href ="<?= $naver_apiURL?>";
	    }
	
/* 	 var ph = AppInterface.phone();
	ph = ph.replace(/-/g,'');
	
    $('#reg_mb_hp').val(ph); */
	
	// submit 최종 폼체크
	function fregisterform_submit(f)
	{
		// 회원아이디 검사
		if (f.w.value == "") {
			var msg = reg_mb_id_check();
			if (msg) {
				alert(msg);
				f.mb_id.select();
				return false;
			}
		}

		//비밀번호 패턴 체크 필요 !
		if (f.w.value == "") {
			 var pw = $("#reg_mb_password").val();
			 var num = pw.search(/[0-9]/g);
			 var eng = pw.search(/[a-z]/ig);
			 var spe = pw.search(/[`~!@@#$%^&*|₩₩₩'₩";:₩/?]/gi);

			 if(pw.length < 8 || pw.length > 20){
			  alert("비밀번호를 8자리 ~ 20자리 이내로 입력해주세요.");
			  return false;
			 }
			 else if(pw.search(/\s/) != -1){
			  alert("비밀번호는 공백 없이 입력해주세요.");
			  return false;
			 }
			 else if(num < 0 || eng < 0 || spe < 0 ){
			  alert("비밀번호를 영문,숫자, 특수문자를 혼합하여 입력해주세요.");
			  return false;
			 }
			/* if (f.mb_password.value.length < 3) {
				alert("비밀번호를 3글자 이상 입력하십시오.");
				f.mb_password.focus();
				return false;
			} */
		}

		if (f.mb_password.value != f.mb_password_re.value) {
			alert("비밀번호가 같지 않습니다.");
			f.mb_password_re.focus();
			return false;
		}

		if (f.mb_password.value.length > 0) {
			if (f.mb_password_re.value.length < 3) {
				alert("비밀번호를 3글자 이상 입력하십시오.");
				f.mb_password_re.focus();
				return false;
			}
		}


		if(filter.includes(f.mb_nick.value) == true)
		{
			alert("닉네임에 비속어를 사용할 수 없습니다");
			f.mb_nick.focus();
			return false;
		}

		// 이름 검사
		if (f.w.value=="") {
			if (f.mb_name.value.length < 1) {
				alert("이름을 입력하십시오.");
				f.mb_name.focus();
				return false;
			}

			/*
			var pattern = /([^가-힣\x20])/i;
			if (pattern.test(f.mb_name.value)) {
				alert("이름은 한글로 입력하십시오.");
				f.mb_name.select();
				return false;
			}
			*/
		}

		<?php if($w == '' && $config['cf_cert_use'] && $config['cf_cert_req']) { ?>
		// 본인확인 체크
		if(f.cert_no.value=="") {
			alert("회원가입을 위해서는 본인확인을 해주셔야 합니다.");
			return false;
		}
		<?php } ?>

		// 닉네임 검사
		if ((f.w.value == "") || (f.w.value == "u" && f.mb_nick.defaultValue != f.mb_nick.value)) {
			var msg = reg_mb_nick_check();
			if (msg) {
				alert(msg);
				f.reg_mb_nick.select();
				return false;
			}
		}

		// E-mail 검사
		if ((f.w.value == "") || (f.w.value == "u" && f.mb_email.defaultValue != f.mb_email.value)) {
			var msg = reg_mb_email_check();
			if (msg) {
				alert(msg);
				f.reg_mb_email.select();
				return false;
			}
		}

		var len = $("input[name='check']").length;
		for(var i = 0; i < len-1; i++)
		{
			var ch = $("input[name='check']").eq(i);
			if(!ch.is(':checked'))
			{
				switch(i)
				{
				case 0 : alert('이용약관을 체크해주세요');return false;
				case 1 : alert('개인정보 수집 및 이용동의를 체크해주세요');return false;
				case 2 : alert('전자금융거래 이용약관을 체크해주세요');return false;
				case 3 : alert('만 14세 이상 이용자를 체크해주세요');return false;
				}
				i = len;
			}
		}

		<?php if (($config['cf_use_hp'] || $config['cf_cert_hp']) && $config['cf_req_hp']) {  ?>
		// 휴대폰번호 체크
		var msg = reg_mb_hp_check();
		if (msg) {
			alert(msg);
			f.reg_mb_hp.select();
			return false;
		}
		<?php } ?>

		if (typeof f.mb_icon != "undefined") {
			if (f.mb_icon.value) {
				if (!f.mb_icon.value.toLowerCase().match(/.(gif|jpe?g|png)$/i)) {
					alert("회원아이콘이 이미지 파일이 아닙니다.");
					f.mb_icon.focus();
					return false;
				}
			}
		}

		if (typeof f.mb_img != "undefined") {
			if (f.mb_img.value) {
				if (!f.mb_img.value.toLowerCase().match(/.(gif|jpe?g|png)$/i)) {
					alert("회원이미지가 이미지 파일이 아닙니다.");
					f.mb_img.focus();
					return false;
				}
			}
		}

		if (typeof(f.mb_recommend) != "undefined" && f.mb_recommend.value) {
			if (f.mb_id.value == f.mb_recommend.value) {
				alert("본인을 추천할 수 없습니다.");
				f.mb_recommend.focus();
				return false;
			}

			var msg = reg_mb_recommend_check();
			if (msg) {
				alert(msg);
				f.mb_recommend.select();
				return false;
			}
		}


		document.getElementById("btn_submit").disabled = "disabled";

		return true;
	}
	</script>

<?php include_once('./tail.php'); ?>