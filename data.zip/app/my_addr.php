<?php
include_once('./_common.php');
include_once('./head.sub.php');

if ($is_member == "")
{
    echo "<script>
         alert('로그인해주세요','".G5_APP_URL."/login.php');
        </script>";
}
//My배달지
$mydelisql = "select * from {$g5['g5_shop_order_address_table']} where mb_id = '".$_SESSION['ss_mb_id']."' limit 5";
$mydelires = sql_query($mydelisql);

$latelastrow = 0;
?>
<link rel="stylesheet" href="<?php echo G5_APP_URL ?>/css/mypage.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>

<body>




<script src="https://t1.daumcdn.net/mapjsapi/bundle/postcode/prod/postcode.v2.js"></script>

    <div class="wrap">
        <div class="head flex-c-m">
            <a href="javascript:" class="back_btn" id="cancel"><i class="material-icons">arrow_back_ios</i></a>
            <h2>배달지 관리</h2>
        </div>
        <section class="sec_1">
			
			<div class="container min-h-100 my_ul">
            
            
               <h3>My배달지</h3>
                  
                  
                    <!-- My 배달지  1개 이상?-->
					<ul class="row w-full">
                    <?php 
                    for($i= 0; $mydelirow = sql_fetch_array($mydelires); $i++)
                    {
                        if($mydelirow['ad_addr1'] != "")
                        {
                            ?>
                        
							<li class="col-12" id = "<?php echo $mydelirow['ad_id']?>">
								<p class="text" stlye="padding-right:10px;"><?= $mydelirow['ad_addr1']." ". $mydelirow['ad_addr2']?></p>
								<input type = "hidden" id = "radio_<?= $latelastrow?>_id" name = "radio_<?= $latelastrow?>_id" value = "<?= $mydelirow['ad_id']?>">
								<input type="hidden" id = "radio_<?= $latelastrow?>_zip" name = "radio_<?= $latelastrow?>_zip" value = "<?= $mydelirow['ad_zip1'].$mydelirow['ad_zip2']?>">
								<input type="hidden" id = "radio_<?= $latelastrow?>_addr1" name = "radio_<?= $latelastrow?>_addr1" value = "<?= $mydelirow['ad_addr1']?>">
								<input type="hidden" id = "radio_<?= $latelastrow?>_addr2" name = "radio_<?= $latelastrow?>_addr2" value = "<?= $mydelirow['ad_addr2']?>">
								<input type="hidden" id = "radio_<?= $latelastrow?>_addr3" name = "radio_<?= $latelastrow?>_addr3" value = "<?= $mydelirow['ad_addr3']?>">
								<input type="hidden" id = "radio_<?= $latelastrow?>_jibeon" name = "radio_<?= $latelastrow?>_jibeon" value = "<?= $mydelirow['ad_jibeon']?>">
								<span class="arrow"><i class="material-icons" onclick = "dele_addr('<?= $mydelirow['ad_id']?>')">close</i></span>
							</li>
                            
                        
                        <?php
                        }
                        $latelastrow++;
                    }
                    if($i == 0)
                    {
                        ?>
                        <h3>My 배달지가 없습니다.</h3>
                        <?php 
                    }
                    
                    ?>
                    </ul>
				  <div class="col-12 text-center" style="position:absolute; bottom:20px; left:0;">배달주소는 최대 5개까지만 등록 가능합니다.</div>
        </div>
        </section>
<!-- 메뉴 리스트 이동하기 -->
        
        <a class="btn btn-red" href="<?= G5_APP_URL?>/my_addr_add.php">주소등록</a>
        </div>
        
    </div>
    <script>
    
		function dele_addr(num)
		{
		 	$.ajax({
				url : "./controllor/addr_delete.php",
				type : "POST",
				data : {
					num : num
					},
					success : function(result)
					{
						alert(result);
						$('section #'+num).remove();
					}
				});
		}
        
        function test(){
            var category = document.getElementsByName("categoryrate");
            var check1 = 0;
            for(i=0;i<category.length;i++){
                if(category[i].checked){
                check1++;
                break;
                }
            }
            var company = document.getElementsByName("companyrate");
            var check2 = 0;
            for(i=0;i<company.length;i++){
                if(company[i].checked){
                check2++;
                break;
                }
            }
            if(check1 && check2){
            }else{
                alert("you must select ratings for both company and category");
                return false;
            }
        }
    </script>

