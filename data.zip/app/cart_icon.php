<?php 
include_once('./_common.php');
include_once('./head.sub.php');



$cart_count_sql = "select * from {$g5['g5_shop_cart_table']} where od_id = '{$_SESSION['ss_cart_id']}' AND mb_id = '{$_SESSION['ss_mb_id']}' AND ct_status = '주문'";
$cart_count_res = sql_query($cart_count_sql);
$cart_count = sql_num_rows($cart_count_res);

?>
<div class="cart_icon" >
    <a href = "javascript:gocart()"><i class="material-icons">shopping_cart</i><?php if($cart_count > 0) {?><span class="cart_count" id = "cart_count"><?= $cart_count?></span><?php }?></a>
</div>

<form id = "addr"  method = "POST">
<input type = "hidden" id = "type" value = "<?= $_REQUEST['type']?>">
<?php 
if($_REQUEST['type'] == "take")
{
    ?>
    <input type = "hidden" id = "pl_id" value = "<?= $_REQUEST['pl_id']?>">
    <?php 
}
else
{
    ?>
    <input type = "hidden" id = "mb_zip1" value = "<?= $_REQUEST['mb_zip1']?>">
    <input type = "hidden" id = "mb_zip2" value = "<?= $_REQUEST['mb_zip2']?>">
    <input type = "hidden" id = "mb_addr1" value = "<?= $_REQUEST['mb_addr1']?>">
    <input type = "hidden" id = "mb_addr2" value = "<?= $_REQUEST['mb_addr2']?>">
    <input type = "hidden" id = "mb_addr3" value = "<?= $_REQUEST['mb_addr3']?>">
    <input type = "hidden" id = "mb_addr_jibeon" value = "<?= $_REQUEST['mb_addr_jibeon']?>">
    <?php
}
?>
</form>

<script>
function gocart()
{
	var form = document.getElementById('addr');
	form.action = "<?= G5_APP_URL?>/cart.php";
	form.submit();
}
</script>





