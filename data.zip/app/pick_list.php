<?php
include_once('./_common.php');
include_once('./head.sub.php');

$picksql = "select * from {$g5['g5_shop_wish_table']} where mb_id = '".$_SESSION['ss_mb_id']."' and wi_time != '0000-00-00 00:00:00'"; 
$pickres = sql_query($picksql);

if ($is_member == "")
{
    echo "<script>
        alert('로그인해주세요','".G5_APP_URL."/login.php');
</script>";
    
}


?>
<link rel="stylesheet" href="<?php echo G5_APP_URL ?>/css/review.css">
<link rel="stylesheet" href="<?php echo G5_APP_URL ?>/css/mypage.css">
<body>
    <div class="wrap">
        <div class="head flex-c-m">
            <a href="javascript:location.replace('<?= G5_APP_URL?>')" class="back_btn" id=""><i class="material-icons">arrow_back_ios</i></a>
            <h2>찜한메뉴</h2>
        </div>
        <section class="sec_1">
            <div class="container my_ul pick">
                <ul class="row">
                	<?php
                	
                	if(sql_num_rows($pickres) < 1)
                	{
                	    ?>
                	    <div id="no_menu">
                	    <i class="material-icons" id="no_menu_icon">storefront</i>
                	    <h5>찜한 메뉴가 없습니다.</h5>
                	    </div>
                	    <?php 
                	}
                	else
                	{
                	   for($i = 0; $pickrow = sql_fetch_array($pickres); $i++)
                	   {
                	    $itemsql = "select * from {$g5['g5_shop_item_table']} where it_id = ". $pickrow['it_id'];
                	    $itemres = sql_query($itemsql);
                	    $itemrow = sql_fetch_array($itemres);
                	    ?>
                	    <li class="col-12">
                        <a href ="./menu.php?it_id=<?= $pickrow['it_id']?>">
                            <dt>
                            	<!-- 이미지 필요  -->
                            	
                                <div class="img_box"><img src="<?= G5_DATA_URL."/item/".$itemrow['it_img1']?>" alt="메뉴이미지" loading="lazy"/></div>
								<p><?= $itemrow['it_name']?><a href = "javascript:pick_uncheck('<?= $pickrow['it_id']?>')"><span class="arrow"><i class="material-icons">close</i></span></a></p>
                                <span class="date">가격 : <span><?= number_format($itemrow['it_price'])?> 원</span></span>
                            </dt>
                        </a>
                    	</li>
                	    <?php 
                	   }
                	}
                	?>
                </ul>
            </div>
        </section>
        
        <script>
			function pick_uncheck(num)
			{
				$.ajax({
					type : "POST",
					url : "./controllor/pick_check.php",
					data : {
								id : num,
								pick : "rgb(255, 255, 34)"
							},
					dataType : "json",
					success : function(result)
					{
						window.location.reload();
					}
					});
			}
		


        </script>
        
    </div>

<?php include_once('./tail.php'); ?>