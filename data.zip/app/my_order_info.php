<?php
include_once('./_common.php');
include_once('./head.sub.php');

$od_id = $_REQUEST['od_id'];


$sql = "select * from {$g5['g5_shop_order_table']} where od_id = '".$od_id."'";
$row = sql_fetch($sql);

$bank = explode('|', $row['od_bank_account']);

$bank_title = $bank[2];
$bank_name = $bank[0];
$bank_num = $bank[1];

?>
<link rel="stylesheet" href="<?php echo G5_APP_URL ?>/css/order.css">
<body>
    <div class="wrap">
    
            <div class="head flex-c-m">
            <a href="javascript:" class="back_btn" id="cancel"><i class="material-icons">arrow_back_ios</i></a>
            	<h2>주문 상세</h2>
        	</div>
        	
        
        
        <section class="sec_1">
            <div class="container">
                <div class="choic">
                    <ul class="m-t-5">
                    	<li class="m-b-10">
							<h6 style="color:gray"><?= $row['od_time']?></h6>
                        </li>
                        <li class="m-b-10">
                                <h5 id = "deiltype"><?php if($row['od_type'] == "delivery") echo "배달"; else echo "포장";?></h5>
                        </li>
                        <li class="m-b-10">
                                <h6 style = "color:red"><?= $row['od_status']?></h6>
                        </li>
                    </ul>
                </div>
            </div>
        </section>
        
        
        
        <!-- 주소 -->
        
        <?php 
        if($row['pl_id'] == "")
        {
            ?>
            <section class="sec_1">
            <div class="container">
            <h4 class="h4-font" id = "">배달 주소</h4>
                    <ul class="m-t-5">
                    
                        <li class="m-b-10">
                        <?php 
                        if($row['od_addr2'] != "")
                        {
                            ?>
                            <span><?= $row['od_addr1']." ".$row['od_addr3']?></span>
                            <?php
                        }
                        else
                        {
                            ?>
                            <span><?= $row['od_addr2']." ".$row['od_addr3']?></span>
                            <?php 
                        }
                        ?>
                        	<!-- <span><?= $row['od_addr1']." ".$row['od_addr2']." ".$row['od_addr3']?></span> -->
                        </li>
                        
                        <li class="m-b-10">
                        	<h6><?php echo $row['od_hp'];?></h6>
                        </li>
                        
                    </ul>
            </div>
        	</section>
            <?php             
        }
        else
        {
            $pl_sql = "select * from {$g5['place_table']} where pl_id = '{$row['pl_id']}'";
            $pl_row = sql_fetch($pl_sql);
            ?>
            <section class="sec_1">
            <div class="container">
            <h4 class="h4-font">매장 주소</h4>
                    <ul class="m-t-5">
                    	<li class="m-b-10">
                        	<span><?= $pl_row['pl_name']?></span>
                        </li>
                        <li class="m-b-10">
                        	<span><?= $pl_row['pl_addr1']." ".$pl_row['pl_addr2']." ".$pl_row['pl_addr3']?></span>
                        </li>
                        
                        <li class="m-b-10">
                        	<h6><?= $pl_row['pl_hp']?></h6>
                        </li>
                    </ul>
            </div>
        	</section>
            <?php 
        }
        ?>
        
        
        <section class="sec_3">
            <div class="container">
            <h3 class = "h3-font">메뉴</h3>
            <?php 
            
            $total  = 0;
            
            $it_list_tmp = explode(';', $row['od_it_list']);
            
            for($k = 0; $k < count($it_list_tmp)-1; $k++)
            {
                $it_tmp = explode(':', $it_list_tmp[$k]);
                
                $it_id = $it_tmp[0];
                $it_name = $it_tmp[1];
                $it_price = $it_tmp[2];
                $it_qty = $it_tmp[3];
                ?>
                  <dl class="flex-sb-m">
                  	<dt><?= $it_name?></dt> 
    		      	
	              </dl>
	              <dl class="flex-sb-m">
                  	<dt><?= Number_format($it_price)?> 원 <?= $it_qty?> 개</dt> 
    		      	<dd><?= Number_format($it_qty * $it_price)?>원</dd>
	              </dl>
                <?php 
                
                
                $op_list_tmp = explode(';', $row['od_it_option']);
                for($i = 0; $i < count($op_list_tmp); $i++)
                {
                    $op_tmp = explode(':', $op_list_tmp[$i]);                    
                    
                    $op_it_id = $op_tmp[0];
                    $op_it_name = $op_tmp[1];
                    $op_it_price = $op_tmp[2];
                    
                    if($it_id == $op_it_id)
                    {
                        ?>
                        <dl class="flex-sb-m">
                        	<dt style = "color:gray"><?= $op_it_name?> 추가</dt>
                            <dd><?= Number_format($op_it_price) ?>원</dd>
                        </dl>
                        <?php 
                    }
                    
                }
                
            }
            ?>
            	</div>  
        </section>
        
         <section class="sec_3">
         	<?php 
         	if($row['od_settle_case'] == "무통장")
         	{
                ?>
                <div class="container">
				<div class="row row-col-2">
					<h3 class="col-12 m-b-10">무통장입금<?php if($row['od_misu'] == "0") echo " (입금 완료)";?></h3>
					<div class="col-12 m-b-10"><?= $bank_title?></div>
					<div class="col-6"><?= $bank_name?></div>
					<div class="col-6 text-right"><?= $bank_num?></div>
				</div>
				</div>
                <?php          	    
         	}
         	else
         	{
         	    ?>
         	    <div class="container">
				<div class="row row-col-2">
					<h3 class="col-12"><?= $row['od_settle_case']?></h3>
				</div>
				</div>
         	    
         	    <?php 
         	}
         	
         	if($row['od_memo'] != "")
         	{
                ?>
                <div class="container">
				<div class="row row-col-2">
					<h3 class="col-12 m-b-10">요청사항</h3>
					<div class="col-12 m-b-10"><?= $row['od_memo']?></div>
				</div>
				</div>
                <?php          	    
         	}
         	?>
            <div class="container" style = "margin-bottom:10%">
            <h3>결제</h3>
			<br>
                <dl class="flex-sb-m">
                    <dt>총 주문금액</dt><dd><?= Number_format($row['od_cart_price'])?>원</dd>
                </dl>
                <?php 
                if($row['pl_id'] == 0 || $orw['pl_id'] == "")
                {
                ?>
                    <dl class="flex-sb-m">
                        <dt>배달비</dt><dd><?= Number_format($row['od_delivery_pay'])?> 원</dd>
                    </dl>
                <?php 
                }
                ?>
                <dl class="flex-sb-m">
                    <dt>할인 금액</dt>
                    <dd><?= Number_format($row['od_sale_price'])?>원</dd>
                </dl>
                <dl class="flex-sb-m">
                    <dt>결제 금액</dt>
                    <dd><?= Number_format($row['od_cart_price']- $row['od_sale_price']+$row['od_delivery_pay'])?>원</dd>
                </dl>
                <?php 
                if($_REQUEST['status'] == "취소")
                {
                    ?>
                    <dl class="flex-sb-m">
        	            <dt style="color:red">취소 금액</dt>
    	                <dd><?= $row['od_cancel_price']?>원</dd>
	                </dl>
                    <?php                     
                }
                ?>
                
            </div>
			
        </section>
    </div>

<?php include_once('./tail.php'); ?>