<?php
include_once('./_common.php');
include_once('./head.sub.php');

if ($is_member == "")
{
    echo "<script>
        alert('로그인해주세요','".G5_APP_URL."/login.php');
</script>";
    
}

$myresql = "select * from {$g5['g5_shop_item_use_table']} where mb_id = '".$_SESSION['ss_mb_id']."' order by is_time desc";
$myreres = sql_query($myresql);


?>
<link rel="stylesheet" href="<?php echo G5_APP_URL ?>/css/mypage.css">
<style>
.material-icons{letter-spacing:-4px;font-size:18px}


</style>
<body>
    <div class="wrap">
        <div class="head flex-c-m">
            <a href="<?php echo G5_APP_URL ?>/my_home.php" class="back_btn" id="cancel"><i class="material-icons">arrow_back_ios</i></a>
            <h2>내 리뷰</h2>
        </div>
        <section class="sec_1">
            

            <div class="container faq">
                <ul class="row">
                
                <?php 
                for($i = 0; $myrerow = sql_fetch_array($myreres); $i++)
                {
                    ?>
					<li class="col-12 board-list faq-list show">
                                <dt class="faq_list_q">
								<div class="img_box"><img style = "width:100%"src = "<?= get_it_imageurl($myrerow['it_id'])?>" alt = "이미지"></div>
                                    <p><?= $myrerow['is_name']?></p>
                                    <span class="date">
                                     <?php 
                                     for($j = 0; $j < $myrerow['is_score']; $j++)
                                    {
                                        ?>
		    	                    <i class="material-icons star">star</i>
                	                <?php 
                                    }
                                    //오늘과의 날짜 차이
                                       $day = "오늘";
                                       
                                       $today = new DateTime(date('Y-m-d'));
                                       
                                       $endday = new DateTime(date('Y-m-d',strtotime($myrerow['is_time'])));
                                       
                                       $diff    = date_diff($today, $endday);
                                       
                                       if($diff->days == "1")
                                       {
                                           $day = "어제";
                                       }
                                       else if($diff->days == "0")
                                       {
                                           $day = "오늘";
                                       }
                                       else
                                       {
                                           $day = date('Y-m-d',strtotime($myrerow['is_time']));
                                       }
                                       ?>
                                      <span><?= $day?> </span>
									</span>
                                </dt>
                                
                                <dd class="faq_list_a dis-none">
                                    <!-- <span class="date"><?= $myrerow['is_subject']?></span> -->
                                    
                                    <div class="m-t-15">
                                    <?php
                                    for($j = 0; $j < $myrerow['is_score']; $j++)
                                    {
                                        ?>
		    	                    <!-- <i class="material-icons star">star</i> -->
                	                <?php 
                                    }
                                    if($myrerow['is_img'] != "")
                                    {
                                        ?>
                                    	<img style = "width:100%" src = "<?= G5_DATA_URL.$myrerow['is_img']?>">
                                    	<?php    
                                    }
                                    ?>
                                    <span><?= $myrerow['is_content']?>aaa</span></div>
                                </dd>
                                   
                    </li>
                    <?php                     
                }
                if($i == 0)
                {
                    ?>
                    <div style ="margin-top: 10%">
        	                <h3>작성한 리뷰가 없습니다.</h3>
                        </div>
                    <?php 
                }
                ?>
                    
                    
                </ul>
            </div>
            
            
        </section>
    </div>
    
    <script>
        $(document).ready(function(){
            
            $('.faq_list_a').each(function(index){
                $(this).attr('data-index',index);
            });
            $('.faq_list_q > .i-arrow').each(function(index){
                $(this).attr('data-index',index);
        });
            $('.faq_list_q').each(function(index){
                $(this).attr('data-index',index);
            }).click(function(){
                var p = $(this).attr('data-index');
                $('.faq_list_q > .i-arrow[data-index='+p+']').toggleClass("open");
                $('.faq_list_a[data-index='+p+']').toggle(300);
            });
            
            /* $(".faq-list-a").each(function(index){
                $(this).attr('data-index',index);
        });
        
            $(".faq-list-q").each(function(index){
                $(this).attr('data-index',index);
        }).click(function() {
                var p = $(this).attr('data-index');
                
                
                $(".faq-list-q > .i-arrow").toggleClass("open");
                $(".faq-list-a").slideToggle(300);
            }); */
        });
        </script>

