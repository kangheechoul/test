<?php
include_once ('./_common.php');
include_once ('./head.sub.php');

if ($_REQUEST['searchitem'] != "") {
    $searchsql = "select * from {$g5['g5_shop_item_table']} where it_name like '%" . $_REQUEST['searchitem'] . "%'";
    $searchres = sql_query($searchsql);
} else {
    $searchsql = "select * from {$g5['g5_shop_item_table']}";
    $searchres = sql_query($searchsql);
}
// 쿠키 지우기 setcookie('hist1', '', time() - 3600, '/');

?>
<link rel="stylesheet" href="<?php echo G5_APP_URL ?>/css/mypage.css">
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/lozad/dist/lozad.min.js"></script>
<body>
	<div class="wrap">
		<div class="head flex-c-m" id = "head">
			<a href="javascript:location.replace('<?= G5_APP_URL?>')" class="back_btn" id=""><i class="material-icons">arrow_back_ios</i></a>
			<div class="sear_box flex-col-c w-80">
				<div class="flex-c-m">
					<input type="text" id="itemtext" onkeyup = "search_enter()" value = "<?php if($_REQUEST['searchitem']) echo $_REQUEST['searchitem'];?>" placeholder="검색어를 입력해 주세요">
					<button class="btn search-btn btn-sm btn-dark"onclick="searchitem()">
						<i class="material-icons">search</i>
					</button>
				</div>
			</div>
		</div>


		<section id = "search_list_section sec_1">
			<!--<div class="container">
				<ul class="search_list_wrap m-t-10">
					<div id = "search_list" style ="display: none"></div>
				</ul>
			</div>-->
			<div class="container min-h-f faq" id = "itemlist">
        		
                		<?php
                if ($_REQUEST['searchitem'] != "") 
                {
                    ?>    
                        <ul class="row row-col-2 order_list">
                        	<?php
                    for ($i = 0; $searchrow = sql_fetch_array($searchres); $i ++) 
                    {
                        ?>
                           <li class="col-6 menu show">
        					<a class="inner" href="./menu.php?it_id=<?= $searchrow['it_id']?>">
        							<div class="img_box">
        							
        								<!-- 이미지 필요  -->
        								<!-- <img src="<?= G5_DATA_URL."/item/".$searchrow['it_img1']?>" alt="menu"> -->
        								<?php echo get_it_thumbnail($searchrow['it_img1'], 167.500);?>
        							</div>
        								<h4><?= $searchrow['it_name']?>
        								</h4>
        								<h5>가격 :<?= number_format($searchrow['it_price'])?>원</h5>
										<div class="sit_star">
                       	<?php 
                       	
                       	for($j = 0; $j < $searchrow['it_use_avg']; $j++)
                       	{
                       	?>
                       	    <i class="material-icons">star_rate</i>
                       	<?php 
                       	}
                       	echo sprintf('%0.1f', $searchrow['it_use_avg']);
                       	if($searchrow['it_use_avg']== 0)
                       	{
                       	 ?>
                       	 <span style="color:#909090; padding-left:5px;">(0)</span></p>
                       	 <?php    
                       	}
                       	else
                       	{
                       	    ?>
                       	    <span style="color:#909090;">(<?= $searchrow['it_use_cnt']?>)</span></p>
                       	    <?php 
                       	}
                       	?>
                       	</div>
        					</a>
        					</li>
                                    <?php
                    }
                    if(sql_num_rows($searchres) < 1)
                    {
                        ?>
                        <div style ="margin-top: 10%">
        	                <h3>검색기록이 없습니다.</h3>
                        </div>
                        <?php 
                    }
                    ?>
                        </ul>
                		<?php
                }
                else
                {
                    ?>
                     <div style ="margin-top: 10%">
        	                <h3>검색하여 주세요.</h3>
                        </div>
                    <?php 
                }
                ?>    
                
            </div>
		</section>
	</div>

	<script>
	  	const observer = lozad();
  		observer.observe();
	
		function searchitem()
		{
			var item = document.getElementById('itemtext').value;
			setCookieArray('search_history', item, "1");
			location.href = "<?= G5_APP_URL?>/search.php?searchitem="+item;
		}


		function strarr(str)
		{
			const arr = str.split(",");

			return arr;
		}

		function search_enter()
		{
			if(window.event.keyCode == "13")
			{
				searchitem();
			}
		}
		//
		addcookie();
		
		$("#itemtext").focus(function(){
			document.getElementById('search_list').style.display = "block";			 
			});

		
		$("#search_list").focusout(function(){
			document.getElementById('search_list').style.display = "none";			 
			});
		
		//검색기록 html에 추가 보여주는건 별개 함수필요
		function addcookie()
		{	
			var fullStr = getCookie('search_history');
			
			var list = strarr(fullStr);
			
			for(var i = list.length-2; i >= 0 ; i--)
			{
				document.getElementById('search_list').innerHTML += '<li class="border-b border-g search_list"><a href="./search.php?searchitem='+list[i]+'">'+list[i]+'<span id = "search'+i+'" onclick = "removeitem('+i+')"><i class="material-icons">close</i></span></a></li>';
			} 
		}

		//삭제를 해주고 index를 재 배치해야함
		function removeitem(num)
		{
			var fullStr = getCookie('search_history');
			
			var list = strarr(fullStr);
			
			//배열을 통해 중복값 확인 후 삭제 알고리즘 필요 (값을 증가시키지않고 유지 맨뒤로 이동됌)
			var index = list.indexOf(list[num]);
			list.splice(index,1);
			setCookie("search_history",list, "1");

		    $.ajax({
	            type : "POST",
	            url : "search_history.php",
	            data: {
		           	 	searchlist : list.toString()
		            },
	            dataType : "json",
	            success : function(result)
	            {
	            	$("#search_list").empty();
	            	addcookie();
	            }
	         });
		}

		
		function setCookie( cname, cvalue, exdays ) 
		{
		      var d = new Date();

		      d.setTime(d.getTime() + (exdays*24*60*60*1000));

		      var expires = "expires="+d.toUTCString();

		      document.cookie = cname + "=" + cvalue + "; " + expires;
		 }
		 /**

		   * 쿠키 가져오기

		   * @param cname 키값

		   * @return str

		   */
			
		   function getCookie( cname ) 
		   {
		      var name = cname + "=";

		      var ca = document.cookie.split(';');

		      for(var i = 0; i < ca.length; i++) {

		          var c = ca[i];

		          while (c.charAt(0) == ' ') {
		              c = c.substring(1);
		          }
		          if (c.indexOf(name) == 0) {
		              return c.substring(name.length, c.length);
		          }
		      }
		      return "";
		  }
		 /**

		   * 쿠키 삭제

		   * @param cname 키값

		   */
		  function delCookie( cname ) 
		  {
		  	setCookie( cname );
		  }
		  /**

		   * 배열데이타 쿠키 저장

		   * @param cname 키값

		   * @param carray 저장할 배열

		   * @param exdays 쿠키 저장 일수

		   */

		   function setCookieArray( cname, carray, exdays )
		   {
			
			var getco = getCookie("search_history");
		   	var str = "";
			
			// 문자열을 배열로 변환 성공
			var checkar = strarr(getco);

			//배열을 통해 중복값 확인 후 삭제 알고리즘 필요 (값을 증가시키지않고 유지 맨뒤로 이동됌)
			var removeindex = checkar.indexOf(carray);
			if(checkar[removeindex] == carray)
			{
				checkar.splice(removeindex,1);
			}

				str += checkar.toString() + carray + ",";

	   		this.setCookie( cname, str, exdays );

		  	}
		
		  /**

		   * 쿠키에서 배열로 저장된 데이타 가져옴

		   * @param cname

		   * @return array

		   */
		   function getCookieArray( cname ) {

		   	var str = this.getCookie( cname );

		   	var tmp1 = str.split(",");
	
		   	var reData = {};

		   	for( var i in tmp1 )
			{

		    	var tmp2 = tmp1[i].split(":");

		    	reData[tmp2[0]] = tmp2[1];

		   }
		   return reData;
		  }


    </script>

<?php include_once('./tail.php'); ?>