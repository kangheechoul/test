<?php
include_once('./_common.php');
include_once('./head.sub.php');


$type = $_REQUEST['type'];
$jibun = $_REQUEST['ad_jibeon'];
$zip = $_REQUEST['zip'];
$addr1 = $_REQUEST['addr1'];
$addr3 = $_REQUEST['addr3'];


$mb_zip1 = substr($zip, 0, 3);
$mb_zip2 = substr($zip, 3);

?>

<!-- 주소 검색값 받은 후 메뉴리스트로 보내기 -->
<link rel="stylesheet" href="<?php echo G5_APP_URL ?>/css/delivery.css">

<script type="text/javascript" src="//dapi.kakao.com/v2/maps/sdk.js?appkey=0ca41baf8cbc0beac688b54d7371d330&libraries=services"></script>
<body>
    
<div class="wrap">

	<input type = "hidden" id = "type" value = "<?= $type?>">

        <div class="head flex-c-m">
            <a href="javascript:" class="back_btn" id="cancel"><i class="material-icons">arrow_back_ios</i></a>
            <p>지도를 움직여 배달맏을 곳을 <br/>아이콘에 위치시켜 설정하세요</p>
        </div>
        
        <section class="sec_1">
            <div class="container">
             	<div class="row" id="map" style="height:400px;"></div>
            </div>
			
			<div class="container write">
                <div class="row address">
                    <h4 id = "result2"><?= $addr1?></h4>
                    <span id = "result"><?= $addr3?></span>
					<div class="col-12 p-t-5">
						<dt>상세주소</dt>
						
						<dt></dt>
						
						<dd><input type = "text"  id = "result3" placeholder = "상세주소" value = "<?php if($_REQUEST['addr2'] != "") echo $_REQUEST['addr2'];?>"></dd>
					</div>
                        
		                
		                
                </div>
            </div>
            
            <form id = "golist" action="<?= G5_APP_URL?>/addaddr.php" method = "POST">
            	<input type = "hidden" id = "type" name = "type" value = "delivery"><br>
            	<input type = "hidden" id = "mb_zip1" name = "mb_zip1" value = "<?= $mb_zip1?>"><br>
            	<input type = "hidden" id = "mb_zip2" name = "mb_zip2" value = "<?= $mb_zip2?>">
            	<input type = "hidden" id = "mb_addr1" name = "mb_addr1" value = "<?= $addr1?>"><br>
            	<input type = "hidden" id = "mb_addr2" name = "mb_addr2">
            	<input type = "hidden" id = "mb_addr3" name = "mb_addr3" value = "<?= $addr3?>"><br>
            	<input type = "hidden" id = "mb_addr_jibeon" name = "mb_addr_jibeon" value = "<?= $jibun?>"><br>
				<button type="button" class="btn btn-red" onclick = "gomenu()">선택</button>
            </form>
        </section>
        
    </div>
	<script>

	var mb_zip1 = document.getElementById('mb_zip1').value;
	var mb_zip2 = document.getElementById('mb_zip2').value;
	var mb_addr1 = document.getElementById('mb_addr1').value;
	var mb_addr2 = document.getElementById('mb_addr2').value;
	var mb_addr3 = document.getElementById('mb_addr3').value;
	var mb_addr_jibeon = document.getElementById('mb_addr_jibeon').value;
	
	function gomenu()
	{
		document.getElementById('mb_addr2').value = document.getElementById('result3').value;

		var type = document.getElementById('type').value;
			if($('#result2').text() == "" && $('#result').text() == "")
			{
				alert('도로명주소나 지번주소가 표시되게 지도를 조금만 움직여주세요');
			}
			else
			{
				if(document.getElementById('mb_addr2').value == "")
				{
					alert("상세주소를 적어주세요");
				}
				else
				{
					if(type == "addnow" || type == "add")
					{
						document.getElementById('golist').action = "<?= G5_APP_URL?>/my_addr_add.php";
						document.getElementById('golist').submit();
					}
					else
					{
						document.getElementById('mb_addr2').value = document.getElementById('result3').value;
						document.getElementById('golist').submit();
					}
				}
			}	
	}

	
	var mapContainer = document.getElementById('map'); // 지도를 표시할 div
	var type = document.getElementById('type').value;
	
	mapOption = 
   	{
        center: new kakao.maps.LatLng(33.450701, 126.570667), // 지도의 중심좌표
        level: 3 // 지도의 확대 레벨
    };  
    
    // 지도를 생성합니다    
    var map = new kakao.maps.Map(mapContainer, mapOption); 
	
	    
    // 주소-좌표 변환 객체를 생성합니다
    var geocoder = new kakao.maps.services.Geocoder();
    
    if(type == "search" || type == "add")
    {
   	// 주소로 좌표를 검색합니다
    	geocoder.addressSearch('<?= $addr1?>', function(result, status) {
    
        // 정상적으로 검색이 완료됐으면 
         if (status === kakao.maps.services.Status.OK) 
         {
            var coords = new kakao.maps.LatLng(result[0].y, result[0].x);
    
    		// 결과값으로 받은 위치를 마커로 표시합니다
            var marker = new kakao.maps.Marker({
                map: map,
                position: coords
            });
         }

		// 지도의 드래그 이벤트 리스너
            kakao.maps.event.addListener(map, 'dragend', function()
            {        
                // 지도 중심좌표를 얻어옵니다 
                var latlng = map.getCenter(); 
		
        		//마커가 지도 중간으로 고정        
                marker.setPosition(latlng);      
                     
                // 위도 경도 값
                var message = '변경된 지도 중심좌표는 ' + latlng.getLat() + ' 이고, ';
                message += '경도는 ' + latlng.getLng() + ' 입니다';
                
                // 인포윈도우가 마커를 따라가게
                infowindow.setPosition(latlng);
                
                searchDetailAddrFromCoords(map.getCenter(), function(result, status) {
                        
                        	var resjson = JSON.stringify(result); 
                        	
                        	if(result[0].road_address == undefined)
                            {
           					   // 인포윈도우로 장소에 대한 설명을 표시합니다
                                var infowindow = new kakao.maps.InfoWindow({
                                    content: '<div style="width:150px;text-align:center;padding:6px 0;">여기가 맞습니까?</div>'
                                });
                                
                        		document.getElementById('mb_addr3').value = result[0].address.address_name;
                        		
                        		document.getElementById('mb_addr_jibeon').value = "J";
                            	
            					infowindow.setContent(result[0].address.address_name);
                            }
                            else
                            {
                            	document.getElementById('result2').innerHTML = result[0].road_address.address_name;
                            	document.getElementById('result').innerHTML = result[0].address.address_name;
                            	
                            	document.getElementById('mb_zip1').value = result[0].road_address.zone_no.substring(0,3);
                        		//document.getElementById('mb_addr2').value = result[0].road_address.zone_no.substring(3);
                        		
                        		document.getElementById('mb_addr1').value = result[0].road_address.address_name;
                        		document.getElementById('mb_addr3').value = result[0].address.address_name;
                        		document.getElementById('mb_addr_jibeon').value = "R";
                            	
                            	   // 인포윈도우로 장소에 대한 설명을 표시합니다
                                var infowindow = new kakao.maps.InfoWindow({
                                    content: '<div style="width:150px;text-align:center;padding:6px 0;">여기가 맞습니까?</div>'
                                });
                            }
                    });
        	});
    		
            // 인포윈도우로 장소에 대한 설명을 표시합니다
               // 인포윈도우로 장소에 대한 설명을 표시합니다
            var infowindow = new kakao.maps.InfoWindow({
                content: '<div style="width:150px;text-align:center;padding:6px 0;">여기가 맞습니까?</div>'
            });
            
            infowindow.open(map, marker);
    
            // 지도의 중심을 결과값으로 받은 위치로 이동시킵니다
            map.setCenter(coords);
            
      });
    }
    else
    {
			var lat = AppInterface.getGPSLatitude(); // 위도
    	 	var lon = AppInterface.getGPSLongitude(); // 경도
    	 	        
    	        	//var lat = position.coords.latitude, // 위도
    	           // 	lon = position.coords.longitude; // 경도
    	        	console.log(lat + " "+ lon);
    	        	console.log('asd');
    	            var coords = new kakao.maps.LatLng(lat, lon);
    	    
    	    		mapOption = 
    	   				{
    	        			center: coords, // 지도의 중심좌표
    	        			level: 3 // 지도의 확대 레벨
    	    			};  
    	    
    				    // 지도를 생성합니다    
    	    		map = new kakao.maps.Map(mapContainer, mapOption); 
    	    
    	    		// 결과값으로 받은 위치를 마커로 표시합니다
    	            marker = new kakao.maps.Marker({
    	                map: map,
    	                position: coords
    	            });
    	            
    	            map.setCenter(coords);
    	            
    	            searchDetailAddrFromCoords(map.getCenter(), function(result, status) {
    	                        
    	                        if(result[0].road_address == undefined)
    	                            {
    	           					   // 인포윈도우로 장소에 대한 설명을 표시합니다
    	                                var infowindow = new kakao.maps.InfoWindow({
    	                                    content: '<div style="width:150px;text-align:center;padding:6px 0;">여기가 맞습니까?</div>'
    	                                });
    	                        		document.getElementById('mb_addr3').value = result[0].address.address_name;
    	                        		
    	                        		document.getElementById('mb_addr_jibeon').value = "J";
    	                            	
    	            					infowindow.setContent(result[0].address.address_name);
    	                            }
    	                            else
    	                            {
    	                            	document.getElementById('result2').innerHTML = result[0].road_address.address_name;
    	                            	document.getElementById('result').innerHTML = result[0].address.address_name;
    	                            	
    	                            	document.getElementById('mb_zip1').value = result[0].road_address.zone_no.substring(0,3);
    	                        		document.getElementById('mb_zip2').value = result[0].road_address.zone_no.substring(3);
    	                        		document.getElementById('mb_addr1').value = result[0].road_address.address_name;
    	                        		document.getElementById('mb_addr3').value = result[0].address.address_name;
    	                        		document.getElementById('mb_addr_jibeon').value = "R";
    	                            	
    	                            	   // 인포윈도우로 장소에 대한 설명을 표시합니다
    	                                var infowindow = new kakao.maps.InfoWindow({
    	                                    content: '<div style="width:150px;text-align:center;padding:6px 0;">여기가 맞습니까?</div>'
    	                                });
    	                            }
    	                    });
    	                  
    						
    				// 지도의 드래그 이벤트 리스너
    	            kakao.maps.event.addListener(map, 'dragend', function()
    	            {        
    	                // 지도 중심좌표를 얻어옵니다 
    	                var latlng = map.getCenter(); 
    			
    	        		//마커가 지도 중간으로 고정        
    	                marker.setPosition(latlng);      
    	                     
    	                // 위도 경도 값
    	                var message = latlng.getLat() + ', ' + latlng.getLng();
    	                
    	                // 인포윈도우가 마커를 따라가게
    	                infowindow.setPosition(latlng);
    	                
    	                searchDetailAddrFromCoords(map.getCenter(), function(result, status) {
    	                        
    	                        	var resjson = JSON.stringify(result); 
    	                        
    	                        	if(result[0].road_address == undefined)
    	                            {
    	           					   // 인포윈도우로 장소에 대한 설명을 표시합니다
    	                                var infowindow = new kakao.maps.InfoWindow({
    	                                    content: '<div style="width:150px;text-align:center;padding:6px 0;">여기가 맞습니까?</div>'
    	                                });
    	                            	
    	                        		document.getElementById('mb_addr3').value = result[0].address.address_name;
    	                        		
    	                        		document.getElementById('mb_addr_jibeon').value = "J";
    	                            	
    	            					infowindow.setContent(result[0].address.address_name);
    	                            }
    	                            else
    	                            {
    	                            	document.getElementById('result2').innerHTML = result[0].road_address.address_name;
    	                            	
    	                            	document.getElementById('result').innerHTML = result[0].address.address_name;
    	                            	
    	                            	document.getElementById('mb_zip1').value = result[0].road_address.zone_no.substring(0,3);
    	                        		document.getElementById('mb_zip2').value = result[0].road_address.zone_no.substring(3);
    	                        		document.getElementById('mb_addr1').value = result[0].road_address.address_name;
    	                        		document.getElementById('mb_addr3').value = result[0].address.address_name;
    	                        		document.getElementById('mb_addr_jibeon').value = "R";
    	                            	
    	                            	   // 인포윈도우로 장소에 대한 설명을 표시합니다
    	                                var infowindow = new kakao.maps.InfoWindow({
    	                                    content: '<div style="width:150px;text-align:center;padding:6px 0;">여기가 맞습니까?</div>'
    	                                });
    	                            }
    	                    });
    	        	});
    	            // 인포윈도우로 장소에 대한 설명을 표시합니다
    	            var infowindow = new kakao.maps.InfoWindow({
    	                content: '<div style="width:150px;text-align:center;padding:6px 0;">여기가 맞습니까?</div>'
    	            });
    	           
    	            infowindow.open(map, marker);
    	    
    	            // 지도의 중심을 결과값으로 받은 위치로 이동시킵니다
    	            map.setCenter(coords);    	
    	 	
    	 	
    }
    
function searchAddrFromCoords(coords, callback)
 {
    // 좌표로 행정동 주소 정보를 요청합니다
    geocoder.coord2RegionCode(coords.getLng(), coords.getLat(), callback);         
}

function searchDetailAddrFromCoords(coords, callback) 
{
    // 좌표로 법정동 상세 주소 정보를 요청합니다
    geocoder.coord2Address(coords.getLng(), coords.getLat(), callback);
}
    
</script> 
