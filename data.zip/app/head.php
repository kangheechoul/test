<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

if (G5_IS_MOBILE) {
    include_once(G5_THEME_MOBILE_PATH.'/head.php');
    return;
}

include_once(G5_PATH.'/head.sub.php');

// if(G5_COMMUNITY_USE === false) {
// define('G5_IS_COMMUNITY_PAGE', true);
// include_once(G5_THEME_SHOP_PATH.'/shop.head.php');
// return;
// }

/* include_once(G5_LIB_PATH.'/latest.lib.php');
include_once(G5_LIB_PATH.'/outlogin.lib.php');
include_once(G5_LIB_PATH.'/poll.lib.php');
include_once(G5_LIB_PATH.'/visit.lib.php');
include_once(G5_LIB_PATH.'/connect.lib.php');
include_once(G5_LIB_PATH.'/popular.lib.php');  */

echo '<link rel="stylesheet" href="'.G5_APP_URL.'/css/header-1.css">'.PHP_EOL;

/* 
function get_mshop_category($ca_id, $len)
{
    global $g5;
    
    $sql = " select ca_id, ca_name from {$g5['g5_shop_category_table']}
                where ca_use = '1' ";
    if($ca_id)
        $sql .= " and ca_id like '$ca_id%' ";
        $sql .= " and length(ca_id) = '$len' order by ca_order, ca_id ";
        
        return $sql;
}

$mshop_categories = get_shop_category_array(true);


$i = 0;
$li_content = '<div class="sub-menu-box">';
foreach($mshop_categories as $cate1){
    if( empty($cate1) ) continue;
    
    $mshop_ca_row1 = $cate1['text'];
    if($i == 0)
        $li_content .= '<ul class="sub-menu flex-sb">';
        
        $li_content .= '	<li style="float:left;width:150px;">';
        $li_content .= '		<a href="'.$mshop_ca_row1['url'].'">'.get_text($mshop_ca_row1['ca_name']).'</a>';
        $j=0;
        
        foreach($cate1 as $key=>$cate2){
            if( empty($cate2) || $key === 'text' ) continue;
            
            $mshop_ca_row2 = $cate2['text'];
            if($j == 0)
                $li_content .= '<ul class="sub_cate sub_cate1">';
                $li_content .= '<li class="cate_li_2">';
                $li_content .= '<a href="'.$mshop_ca_row2['url'].'">'.get_text($mshop_ca_row2['ca_name']).'</a>';
                $li_content .= '</li>';
                $j++;
        }
        
        if($j > 0)
            $li_content .= '</ul>';
            $li_content .= '</li>';
            $i++;
}   // end for
$li_content .= $add_content;


if($i > 0) {
    $li_content .= '</ul>';
    $li_content .= '</div>';
}
else
    $li_content = '<p class="no-cate">등록된 분류가 없습니다.</p>';
    
   */ ?> 
<style>
.sub-menu-box{
display:none;
}
</style>

    <header>
        <nav>
			<div class="bottom-head">
				<a href="<?php echo G5_APP_URL; ?>" class="logo"><img src="<?php echo G5_APP_URL; ?>/img/mimicook-logo.png" alt="logo"></a>
				<div class="m-menu-btn"><i class="xi-bars"></i></div>
			</div>
		</nav>
        
		
    </header>

	<div class="m-menu-bg">
		<div class="m-menu">
			<div class="close-btn"><i class="xi-hamburger-back"></i></div>
				
				<div class="back-btn">Back</div>

				<ul class="mo-menu">
					<li class="sub"><a href=<?php echo G5_APP_URL."/menu_list.php";?>>전체 메뉴</a></li>
					<li class="sub"><a href=<?php echo G5_APP_URL."/search.php";?>>검 색</a></li>
					<li class="sub"><a href=<?php echo G5_APP_URL."/pick_list.php";?>>찜 목록</a></li>
					<li class="sub"><a href=<?php echo G5_APP_URL."/order_list.php";?>>주문 내역</a></li>
					<li class="sub"><a href=<?php echo G5_APP_URL."/my_home.php";?>>My Page</a></li>
					
				</ul>
		

    	</div>

    </div>
